package com.excelto.pdf.converter.office

import com.excelto.pdf.converter.core.engine.NumberFormat
import com.excelto.pdf.converter.core.engine.PageNumberEngine
import com.excelto.pdf.converter.core.engine.TextChunk
import com.excelto.pdf.converter.core.engine.UserFacingException
import com.excelto.pdf.converter.core.office.Colors
import com.excelto.pdf.converter.core.office.Deck
import com.excelto.pdf.converter.core.office.DocxReader
import com.excelto.pdf.converter.core.office.DocxWriter
import com.excelto.pdf.converter.core.office.Flow
import com.excelto.pdf.converter.core.office.OfficeZip
import com.excelto.pdf.converter.core.office.PdfLayout
import com.excelto.pdf.converter.core.office.PptxReader
import com.excelto.pdf.converter.core.office.PptxWriter
import com.excelto.pdf.converter.core.office.WordDoc
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import java.io.File
import java.util.zip.ZipFile

class OfficeTest {

    @get:Rule val tmp = TemporaryFolder()

    private fun sample(name: String) = File(javaClass.classLoader!!.getResource("samples/office/$name")!!.toURI())

    // ---- .docx reader ---------------------------------------------------------------------

    @Test fun docxReadsStylesListsTablesAndPictures() {
        val doc = DocxReader().read(sample("report.docx"))
        assertEquals(612f, doc.page.widthPt, 0.5f)
        assertEquals(792f, doc.page.heightPt, 0.5f)
        assertEquals(72f, doc.page.left, 0.5f)

        val paras = doc.blocks.filterIsInstance<Flow.Paragraph>()
        val title = paras.first { it.text == "Quarterly Report" }
        assertEquals(28f, title.runs.first().style.sizePt, 0.01f)

        val h1 = paras.first { it.text == "Summary" }
        assertEquals(16f, h1.runs.first().style.sizePt, 0.01f)
        assertEquals(0xFF2F5496.toInt(), h1.runs.first().style.color)

        val mixed = paras.first { it.text.startsWith("Sales grew") }
        assertTrue(mixed.runs.any { it.style.bold && it.text == "Revenue rose 12 percent" })
        assertTrue(mixed.runs.any { it.style.italic && it.text == "costs fell" })
        assertTrue(mixed.runs.any { it.style.underline && it.style.color == 0xFFFF0000.toInt() })

        // Symbol-font bullets become a real bullet; numbered lists count per level.
        assertEquals("•", paras.first { it.text == "First bullet point" }.marker)
        assertEquals("1.", paras.first { it.text == "Step one" }.marker)
        assertEquals("a)", paras.first { it.text == "Detail of step one" }.marker)
        assertEquals("2.", paras.first { it.text == "Step two" }.marker)
        assertEquals(36f, paras.first { it.text == "Step one" }.indentLeft, 0.01f)

        val table = doc.blocks.filterIsInstance<Flow.Table>().single()
        assertEquals(3, table.rows.size)
        assertTrue(table.borders)
        assertTrue(table.rows.first().header)
        assertEquals(0xFFD9E2F3.toInt(), table.rows.first().cells.first().fill)
        assertEquals(2, table.rows[2].cells[1].span)
        assertEquals(3, table.columns.size)

        val image = doc.blocks.filterIsInstance<Flow.Image>().single()
        assertNotNull(image.bytes)
        assertEquals(240f, image.widthPt, 0.5f)
        assertEquals(Flow.Align.CENTER, image.align)

        assertTrue(doc.blocks.contains(Flow.PageBreak))
        assertEquals(Flow.Align.JUSTIFY, paras.first { it.text.startsWith("This paragraph") }.align)
        assertTrue(paras.first { it.text.startsWith("مرحبا") }.rtl)
        val sub = paras.first { it.text.startsWith("Water") }.runs
        assertTrue(sub.any { it.style.vertAlign == -1 } && sub.any { it.style.vertAlign == 1 })
    }

    @Test fun damagedWordFileGivesAClearMessage() {
        try {
            DocxReader().read(sample("damaged.docx"))
            fail("expected an error")
        } catch (e: UserFacingException) {
            assertTrue(e.message!!.contains("couldn't be opened"))
        }
    }

    @Test fun listNumberFormats() {
        assertEquals("iv", DocxReader.format(4, "lowerRoman"))
        assertEquals("XIV", DocxReader.format(14, "upperRoman"))
        assertEquals("AA", DocxReader.format(27, "upperLetter"))
        assertEquals("c", DocxReader.format(3, "lowerLetter"))
        assertEquals("03", DocxReader.format(3, "decimalZero"))
        assertEquals("22nd", DocxReader.format(22, "ordinal"))
        assertEquals("11th", DocxReader.format(11, "ordinal"))
    }

    // ---- .pptx reader -----------------------------------------------------------------------

    @Test fun pptxInheritsFromLayoutAndMaster() {
        val deck = PptxReader().read(sample("deck.pptx"))
        assertEquals(960f, deck.widthPt, 0.5f)
        assertEquals(540f, deck.heightPt, 0.5f)
        assertEquals("hidden slide skipped", 4, deck.slides.size)

        val s1 = deck.slides[0]
        // The master's decorative band shows behind every slide.
        assertTrue(s1.elements.any { it is Deck.Shape && it.fill == 0xFF2E7D32.toInt() && it.box.y > 500f })
        val title = s1.elements.filterIsInstance<Deck.Shape>().first { it.text?.paras?.firstOrNull()?.runs?.firstOrNull()?.text == "Quarterly Review" }
        assertEquals(66f, title.box.x, 0.5f) // from the master placeholder
        val run = title.text!!.paras[0].runs[0]
        assertEquals(44f, run.sizePt, 0.01f)
        assertEquals(0xFF1F3864.toInt(), run.color) // tx2 → dk2
        assertEquals("Georgia", run.font) // +mj-lt
        assertEquals(Deck.Anchor.MIDDLE, title.text.anchor)
        val sub = s1.elements.filterIsInstance<Deck.Shape>().first { it.text?.paras?.firstOrNull()?.runs?.firstOrNull()?.text == "Sales and operations" }
        assertEquals(null, sub.text!!.paras[0].bullet)

        val body = deck.slides[1].elements.filterIsInstance<Deck.Shape>().first { s -> s.text?.paras?.any { p -> p.runs.any { it.text == "Costs down 4%" } } == true }.text!!
        assertEquals(0.925f, body.fontScale, 0.001f)
        assertEquals("•", body.paras[0].bullet)
        assertTrue(body.paras[0].runs[0].bold)
        assertEquals(28f * 0.925f, body.paras[1].runs[0].sizePt, 0.01f)
        assertEquals("–", body.paras[2].bullet)
        assertEquals(24f * 0.925f, body.paras[2].runs[0].sizePt, 0.01f)
        assertEquals("1.", body.paras[3].bullet)
        assertEquals("2.", body.paras[4].bullet)
        assertEquals(0xFFC00000.toInt(), body.paras[4].runs[0].color)

        val table = deck.slides[2].elements.filterIsInstance<Deck.Table>().single()
        assertEquals(3, table.rows.size)
        assertEquals(0xFF2E7D32.toInt(), table.rows[0].cells[0].fill) // header row in accent 1
        assertEquals(0xFFFFFFFF.toInt(), table.rows[0].cells[0].text.paras[0].runs[0].color)

        val s4 = deck.slides[3]
        assertEquals(0xFFF3F8F3.toInt(), s4.background)
        val rounded = s4.elements.filterIsInstance<Deck.Shape>().first { it.geometry == "roundRect" }
        assertEquals(0xFF2E7D32.toInt(), rounded.fill) // fillRef with accent1
        assertEquals(0xFFFFFFFF.toInt(), rounded.text!!.paras[0].runs[0].color) // fontRef lt1
        val oval = s4.elements.filterIsInstance<Deck.Shape>().first { it.geometry == "ellipse" }
        assertEquals(20f, oval.box.rotation, 0.01f)
        assertTrue(s4.elements.any { it is Deck.Pic && it.picture.bytes != null })
        assertTrue(s4.elements.any { it is Deck.Shape && it.geometry == "line" && it.line == 0xFFC00000.toInt() })
        // A group scales its children: 400x200 pt child in a 200x100 pt group.
        val arrow = s4.elements.filterIsInstance<Deck.Shape>().first { it.geometry == "rightArrow" }
        assertEquals(680f, arrow.box.x, 0.5f)
        assertEquals(200f, arrow.box.w, 0.5f)
        assertTrue(s4.elements.filterIsInstance<Deck.Shape>().any { s -> s.text?.paras?.any { it.rtl } == true })
    }

    @Test fun pptxCanIncludeHiddenSlides() {
        val deck = PptxReader().read(sample("deck.pptx"), includeHidden = true)
        assertEquals(5, deck.slides.size)
        assertTrue(deck.slides.last().hidden)
    }

    @Test fun damagedPresentationGivesAClearMessage() {
        try {
            PptxReader().read(sample("damaged.pptx"))
            fail("expected an error")
        } catch (e: UserFacingException) {
            assertTrue(e.message!!.contains("couldn't be opened"))
        }
    }

    @Test fun colorModifiers() {
        assertEquals(0xFF808080.toInt(), Colors.modify(0xFF000000.toInt(), listOf("tint" to 0.5f)))
        assertEquals(0xFF808080.toInt(), Colors.modify(0xFFFFFFFF.toInt(), listOf("lumMod" to 0.5f)))
        assertEquals(0xFFFFFFFF.toInt(), Colors.modify(0xFF000000.toInt(), listOf("lumMod" to 0f, "lumOff" to 1f)))
        assertEquals(0xFF000000.toInt(), Colors.modify(0xFFFFFFFF.toInt(), listOf("shade" to 0f)))
        assertEquals(0x80, Colors.modify(0xFFFF0000.toInt(), listOf("alpha" to 0.5f)) ushr 24)
    }

    // ---- Writers round trip through our own readers -------------------------------------------

    @Test fun docxWriterRoundTrip() {
        val out = tmp.newFile("out.docx")
        DocxWriter.write(
            out,
            listOf(
                WordDoc.Paragraph(listOf(WordDoc.Run("Title & <more>")), WordDoc.Style.TITLE),
                WordDoc.Paragraph(listOf(WordDoc.Run("Bold ", bold = true), WordDoc.Run("and italic", italic = true, sizePt = 14f))),
                WordDoc.Table(listOf(listOf("A", "B"), listOf("1", "2"))),
                WordDoc.PageBreak,
                WordDoc.Paragraph(listOf(WordDoc.Run("مرحبا")), align = WordDoc.Align.RIGHT, rtl = true),
            ),
            WordDoc.Page(842f, 595f, 36f),
        )
        ZipFile(out).use { z -> assertNotNull(z.getEntry("word/document.xml")); assertNotNull(z.getEntry("[Content_Types].xml")) }
        val doc = DocxReader().read(out)
        assertEquals(842f, doc.page.widthPt, 0.5f)
        val paras = doc.blocks.filterIsInstance<Flow.Paragraph>()
        assertEquals("Title & <more>", paras[0].text)
        assertEquals(22f, paras[0].runs[0].style.sizePt, 0.01f) // Title style, size 44 half-points
        assertTrue(paras[1].runs[0].style.bold)
        assertEquals(14f, paras[1].runs[1].style.sizePt, 0.01f)
        assertEquals(listOf("A", "B"), doc.blocks.filterIsInstance<Flow.Table>().single().rows[0].cells.map { (it.blocks[0] as Flow.Paragraph).text })
        assertTrue(doc.blocks.contains(Flow.PageBreak))
        assertTrue(paras.last().rtl)
    }

    @Test fun pptxWriterRoundTrip() {
        val out = tmp.newFile("out.pptx")
        val png = javaClass.classLoader!!.getResource("samples/office/deck.pptx")!!.let { ZipFile(File(it.toURI())).use { z -> z.getInputStream(z.getEntry("ppt/media/image1.png")).readBytes() } }
        PptxWriter.write(out, 595f, 842f, 3) { i -> PptxWriter.Slide(png, isPng = true, notes = "Notes for page ${i + 1}", aspect = 595f / 842f) }
        val deck = PptxReader().read(out)
        assertEquals(3, deck.slides.size)
        assertEquals(595f, deck.widthPt, 0.5f)
        val pic = deck.slides[0].elements.filterIsInstance<Deck.Pic>().single()
        assertNotNull(pic.picture.bytes)
        assertEquals(595f, pic.box.w, 1f)
        ZipFile(out).use { z -> assertTrue(String(z.getInputStream(z.getEntry("ppt/notesSlides/notesSlide2.xml")).readBytes()).contains("Notes for page 2")) }
    }

    @Test fun xmlEscapingDropsInvalidCharacters() {
        assertEquals("a&amp;b&lt;c&gt;&quot;d", OfficeZip.esc("a&b<c>\"d\u0001￾"))
    }

    // ---- PDF layout rebuild -------------------------------------------------------------------

    private fun chunk(x0: Float, x1: Float, y: Float, text: String, size: Float = 10f, bold: Boolean = false) =
        TextChunk(x0, x1, y, y - size, y + size * 0.22f, text, size, bold)

    @Test fun layoutFindsHeadingsParagraphsAndTables() {
        val chunks = listOf(
            chunk(72f, 300f, 80f, "Annual Report", size = 24f, bold = true),
            chunk(72f, 520f, 120f, "This is the first line of a paragraph that wraps onto the"),
            chunk(72f, 300f, 132f, "second line with hyphen-"),
            chunk(72f, 200f, 144f, "ated words."),
            chunk(72f, 120f, 180f, "Name"), chunk(300f, 360f, 180f, "Amount"),
            chunk(72f, 120f, 192f, "Rent"), chunk(300f, 360f, 192f, "1200"),
            chunk(72f, 120f, 204f, "Food"), chunk(300f, 360f, 204f, "300"),
        )
        val blocks = PdfLayout.rebuild(chunks, 595f).map { it.block }
        val heading = blocks[0] as WordDoc.Paragraph
        assertEquals(WordDoc.Style.TITLE, heading.style)
        val para = blocks[1] as WordDoc.Paragraph
        assertEquals(WordDoc.Style.NORMAL, para.style)
        assertTrue(para.text, para.text.contains("the second line with hyphenated words."))
        val table = blocks[2] as WordDoc.Table
        assertEquals(listOf("Rent", "1200"), table.rows[1])
        assertFalse(blocks.size > 3)
    }

    @Test fun shortLinesStaySeparateParagraphs() {
        val chunks = listOf(
            chunk(72f, 180f, 80f, "Quarterly Report", size = 12f),
            chunk(72f, 300f, 100f, "Revenue grew in every region this quarter.", size = 12f),
            chunk(72f, 250f, 120f, "The secret code is ALPHA-7731.", size = 12f),
        )
        val blocks = PdfLayout.rebuild(chunks, 595f).map { (it.block as WordDoc.Paragraph).text }
        assertEquals(listOf("Quarterly Report", "Revenue grew in every region this quarter.", "The secret code is ALPHA-7731."), blocks)
    }

    // ---- Page numbers ---------------------------------------------------------------------------

    @Test fun pageNumberLabels() {
        assertEquals("3", PageNumberEngine.label(NumberFormat.PLAIN, 3, 10))
        assertEquals("Page 3", PageNumberEngine.label(NumberFormat.PAGE, 3, 10))
        assertEquals("Page 3 of 10", PageNumberEngine.label(NumberFormat.PAGE_OF, 3, 10))
        assertEquals("3 / 10", PageNumberEngine.label(NumberFormat.SLASH, 3, 10))
    }
}
