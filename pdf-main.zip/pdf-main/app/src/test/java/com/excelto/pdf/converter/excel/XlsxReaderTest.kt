package com.excelto.pdf.converter.excel

import com.excelto.pdf.converter.core.engine.UserFacingException
import com.excelto.pdf.converter.core.excel.CellKind
import com.excelto.pdf.converter.core.excel.CellRange
import com.excelto.pdf.converter.core.excel.ExcelSheet
import com.excelto.pdf.converter.core.excel.ExcelWorkbook
import com.excelto.pdf.converter.core.excel.HAlign
import com.excelto.pdf.converter.core.excel.LineStyle
import com.excelto.pdf.converter.core.excel.XlsxReader
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import org.kxml2.io.KXmlParser
import java.io.File
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

class XlsxReaderTest {

    @get:Rule val tmp = TemporaryFolder()

    private val reader = XlsxReader { KXmlParser() }

    private fun sampleFile(): File {
        val f = tmp.newFile("sample.xlsx")
        javaClass.getResourceAsStream("/samples/sample.xlsx")!!.use { input -> f.outputStream().use { input.copyTo(it) } }
        return f
    }

    private fun ExcelWorkbook.text(sheet: ExcelSheet, r: Int, c: Int): String {
        val row = sheet.rows[r] ?: return ""
        val i = row.indexOf(c)
        return if (i < 0) "" else display(row, i).text
    }

    @Test fun sheetsAndVisibility() {
        val names = reader.sheetNames(sampleFile())
        assertEquals(listOf("Formats", "Wide", "Image", "Arabic", "Secret", "PrintArea"), names.map { it.first })
        assertEquals(listOf(false, false, false, false, true, false), names.map { it.second })
    }

    @Test fun valuesAndNumberFormats() {
        val wb = reader.read(sampleFile())
        val s = wb.sheets[0]
        assertEquals("Sales summary", wb.text(s, 0, 0))
        assertEquals("2023-03-15", wb.text(s, 2, 1))
        assertEquals("$1,234.50", wb.text(s, 2, 2))
        assertEquals("12.5%", wb.text(s, 2, 3))
        assertEquals("-$50.00", wb.text(s, 4, 2))
        assertEquals("$1,284.49", wb.text(s, 8, 2)) // cached formula result
        assertEquals("TRUE", wb.text(s, 8, 3))
        assertEquals("6:00 PM", wb.text(s, 8, 1))
        assertFalse(wb.date1904)
    }

    @Test fun stylesMergesAndLayout() {
        val wb = reader.read(sampleFile())
        val s = wb.sheets[0]
        assertTrue(CellRange(0, 0, 0, 4) in s.merges)
        val title = wb.style(s.rows[0]!!.styles[0])
        assertEquals(0xFF1F4E79.toInt(), title.fill)
        assertTrue(title.font.bold)
        assertEquals(0xFFFFFFFF.toInt(), title.font.color)
        assertEquals(HAlign.CENTER, title.hAlign)
        assertTrue(wb.style(s.rows[2]!!.let { it.styles[it.indexOf(4)] }).wrap)
        val borders = s.rows[6]!!
        val thin = wb.style(borders.styles[borders.indexOf(0)])
        assertEquals(LineStyle.THIN, thin.left?.style)
        assertEquals(0xFFC80000.toInt(), thin.bottom?.color)
        assertEquals(LineStyle.DOUBLE, wb.style(borders.styles[borders.indexOf(5)]).top?.style)
        assertEquals(45f, s.rowHeights[2]!!, 0.01f)
        assertTrue(11 in s.hiddenRows)
        assertTrue(6 in s.hiddenCols)
        assertEquals(14f, s.colWidths[0]!!, 0.01f)
    }

    @Test fun pageSetupImagesRtlAndPrintArea() {
        val wb = reader.read(sampleFile())
        val wide = wb.sheets[1]
        assertEquals(true, wide.pageSetup.landscape)
        assertEquals(9, wide.pageSetup.paperSize)
        assertEquals(60, wide.rows.size)
        val image = wb.sheets[2].images.single()
        assertEquals(1, image.fromCol); assertEquals(2, image.fromRow)
        assertEquals(4, image.toCol); assertEquals(10, image.toRow)
        assertEquals(0x89.toByte(), image.bytes[0]); assertEquals('P'.code.toByte(), image.bytes[1])
        val arabic = wb.sheets[3]
        assertTrue(arabic.rightToLeft)
        assertEquals("المنتج", wb.text(arabic, 0, 0))
        assertEquals(CellRange(2, 1, 5, 3), wb.sheets[5].printArea)
    }

    @Test fun readsOnlyChosenSheets() {
        val wb = reader.read(sampleFile(), onlySheets = setOf(1))
        assertTrue(wb.sheets[0].rows.isEmpty())
        assertEquals(60, wb.sheets[1].rows.size)
    }

    /** A tiny hand-written file: inline strings, rich text, errors, 1904 dates and a chart. */
    @Test fun minimalFileWithChart() {
        val f = tmp.newFile("chart.xlsx")
        ZipOutputStream(f.outputStream()).use { zip ->
            fun put(path: String, xml: String) { zip.putNextEntry(ZipEntry(path)); zip.write(xml.toByteArray()); zip.closeEntry() }
            val ns = "xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\" xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\""
            val rel = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
            put("_rels/.rels", "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\"><Relationship Id=\"rId1\" Type=\"$rel/officeDocument\" Target=\"xl/workbook.xml\"/></Relationships>")
            put("xl/workbook.xml", "<workbook $ns><workbookPr date1904=\"1\"/><sheets><sheet name=\"Data\" sheetId=\"1\" r:id=\"rId1\"/></sheets></workbook>")
            put("xl/_rels/workbook.xml.rels", "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\"><Relationship Id=\"rId1\" Type=\"$rel/worksheet\" Target=\"worksheets/sheet1.xml\"/><Relationship Id=\"rId2\" Type=\"$rel/sharedStrings\" Target=\"sharedStrings.xml\"/></Relationships>")
            put("xl/sharedStrings.xml", "<sst $ns><si><r><t>Hello </t></r><r><rPr><b/></rPr><t>world</t></r><rPh><t>skip</t></rPh></si></sst>")
            put("xl/worksheets/sheet1.xml", "<worksheet $ns><sheetData>" +
                "<row r=\"1\"><c r=\"A1\" t=\"s\"><v>0</v></c><c r=\"B1\" t=\"inlineStr\"><is><t>inline</t></is></c><c r=\"C1\" t=\"e\"><v>#DIV/0!</v></c></row>" +
                "<row r=\"3\"><c r=\"C3\"><v>2.5</v></c></row></sheetData><drawing r:id=\"rId1\"/></worksheet>")
            put("xl/worksheets/_rels/sheet1.xml.rels", "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\"><Relationship Id=\"rId1\" Type=\"$rel/drawing\" Target=\"../drawings/drawing1.xml\"/></Relationships>")
            put("xl/drawings/drawing1.xml", "<xdr:wsDr xmlns:xdr=\"http://schemas.openxmlformats.org/drawingml/2006/spreadsheetDrawing\" xmlns:c=\"http://schemas.openxmlformats.org/drawingml/2006/chart\" xmlns:a=\"http://schemas.openxmlformats.org/drawingml/2006/main\">" +
                "<xdr:twoCellAnchor><xdr:from><xdr:col>1</xdr:col><xdr:colOff>0</xdr:colOff><xdr:row>1</xdr:row><xdr:rowOff>0</xdr:rowOff></xdr:from>" +
                "<xdr:to><xdr:col>5</xdr:col><xdr:colOff>0</xdr:colOff><xdr:row>10</xdr:row><xdr:rowOff>0</xdr:rowOff></xdr:to>" +
                "<xdr:graphicFrame><a:graphic><a:graphicData><c:chart r:id=\"rId9\"/></a:graphicData></a:graphic></xdr:graphicFrame></xdr:twoCellAnchor></xdr:wsDr>")
        }
        val wb = reader.read(f)
        val s = wb.sheets.single()
        assertTrue(wb.date1904)
        assertEquals("Hello world", wb.text(s, 0, 0))
        assertEquals("inline", wb.text(s, 0, 1))
        assertEquals("#DIV/0!", wb.text(s, 0, 2))
        assertEquals(CellKind.ERROR, s.rows[0]!!.kinds[2])
        assertEquals("2.5", wb.text(s, 2, 2))
        assertEquals(1, s.chartCount)
        assertNotNull(s.usedRange(wb))
    }

    @Test fun passwordProtectedFileGivesClearMessage() {
        val f = tmp.newFile("locked.xlsx")
        f.writeBytes(byteArrayOf(0xD0.toByte(), 0xCF.toByte(), 0x11, 0xE0.toByte(), 0xA1.toByte(), 0xB1.toByte(), 0x1A, 0xE1.toByte()))
        try {
            reader.read(f)
            fail("Expected a password message")
        } catch (e: UserFacingException) {
            assertTrue(e.message!!.contains("password protected"))
        }
    }
}
