package com.excelto.pdf.converter

import com.excelto.pdf.converter.subscription.PaywallMath
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class MonetizationTest {

    @Test fun trialLengths() {
        assertEquals(3, PaywallMath.days("P3D"))
        assertEquals(7, PaywallMath.days("P1W"))
        assertEquals(30, PaywallMath.days("P1M"))
        assertNull(PaywallMath.days("weird"))
        assertNull(PaywallMath.days(null))
    }

    @Test fun monthlySaving() {
        // $2.99 a week is about $12.96 a month; $5.99 a month saves 53%.
        assertEquals(53, PaywallMath.savingPercent(2_990_000, 5_990_000))
        assertNull("no saving to show", PaywallMath.savingPercent(1_000_000, 5_000_000))
        assertNull(PaywallMath.savingPercent(null, 5_990_000))
    }
}
