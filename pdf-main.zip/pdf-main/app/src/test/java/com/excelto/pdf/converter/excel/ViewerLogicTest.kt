package com.excelto.pdf.converter.excel

import com.excelto.pdf.converter.core.excel.CellKind
import com.excelto.pdf.converter.core.excel.CellRange
import com.excelto.pdf.converter.core.excel.CellStyle
import com.excelto.pdf.converter.core.excel.ExcelSheet
import com.excelto.pdf.converter.core.excel.ExcelWorkbook
import com.excelto.pdf.converter.core.excel.Formulas
import com.excelto.pdf.converter.core.excel.GridGeometry
import com.excelto.pdf.converter.core.excel.RowData
import com.excelto.pdf.converter.core.excel.SheetUnits
import com.excelto.pdf.converter.core.excel.XlsxReader
import com.excelto.pdf.converter.core.excel.formulaKey
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import org.kxml2.io.KXmlParser
import java.util.TreeMap
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

class ViewerLogicTest {

    @get:Rule val tmp = TemporaryFolder()

    @Test fun shiftsSharedFormulas() {
        assertEquals("A2+\$B\$1", Formulas.shift("A1+\$B\$1", 1, 0))
        assertEquals("SUM(C1:C9)", Formulas.shift("SUM(B1:B9)", 0, 1))
        assertEquals("\"A1\"&B3", Formulas.shift("\"A1\"&A2", 1, 1))
        assertEquals("Sheet2!\$A2+AB10", Formulas.shift("Sheet2!\$A1+AA9", 1, 1))
        assertEquals("ROUND(B2,2)", Formulas.shift("ROUND(A1,2)", 1, 1))
        assertEquals("AA", Formulas.columnName(26))
        assertEquals("XFD", Formulas.columnName(16383))
    }

    private fun sheet(rows: Int): Pair<ExcelWorkbook, ExcelSheet> {
        val map = TreeMap<Int, RowData>()
        for (r in 0 until rows) map[r] = RowData().apply { put(0, CellKind.NUMBER, r.toDouble()); put(1, CellKind.STRING, str = "Row $r") }
        val sheet = ExcelSheet(
            "Big", rows = map, colWidths = mapOf(1 to 20f), rowHeights = mapOf(2 to 30f), hiddenRows = setOf(3),
            merges = listOf(CellRange(5, 0, 6, 1)), freezeRows = 1,
        )
        return ExcelWorkbook(listOf(sheet), listOf(CellStyle.DEFAULT)) to sheet
    }

    @Test fun geometryFindsCellsQuicklyOnLargeSheets() {
        val (wb, sheet) = sheet(100_000)
        val start = System.nanoTime()
        val g = GridGeometry(sheet, wb)
        assertTrue("geometry took too long", (System.nanoTime() - start) / 1_000_000 < 2000)
        assertEquals(100_019, g.lastRow)
        assertEquals(19, g.lastCol)
        val defaultW = SheetUnits.columnPoints(sheet.defaultColWidth)
        assertEquals(defaultW, g.colX[1], 0.01f)
        assertEquals(1, g.colAt(defaultW + 1f))
        assertEquals(0f, g.rowY[4] - g.rowY[3], 0.01f) // hidden row
        assertEquals(30f, g.rowY[3] - g.rowY[2], 0.01f)
        assertEquals(2, g.rowAt(g.rowY[2] + 29f))
        assertEquals(99_999, g.rowAt(g.rowY[99_999] + 1f))
        assertEquals(5 to 0, g.anchorOf(6, 1))
        assertEquals(CellRange(5, 0, 6, 1), g.mergeStarting(5, 0))
        assertNull(g.mergeStarting(6, 1))
        assertEquals("AB12", GridGeometry.name(11, 27))
    }

    @Test fun readsFormulasAndFrozenPanesFromXlsx() {
        val file = tmp.newFile("f.xlsx")
        ZipOutputStream(file.outputStream()).use { z ->
            fun put(name: String, text: String) { z.putNextEntry(ZipEntry(name)); z.write(text.toByteArray()); z.closeEntry() }
            put("[Content_Types].xml", """<?xml version="1.0"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"/>""")
            put("_rels/.rels", """<?xml version="1.0"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>""")
            put("xl/workbook.xml", """<?xml version="1.0"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="S" sheetId="1" r:id="rId1"/></sheets></workbook>""")
            put("xl/_rels/workbook.xml.rels", """<?xml version="1.0"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/></Relationships>""")
            put("xl/worksheets/sheet1.xml", """<?xml version="1.0"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetViews><sheetView workbookViewId="0"><pane xSplit="1" ySplit="2" topLeftCell="B3" activePane="bottomRight" state="frozen"/></sheetView></sheetViews><sheetData>
                <row r="1"><c r="A1"><v>1</v></c><c r="B1"><v>2</v></c><c r="C1"><f t="shared" ref="C1:C3" si="0">A1+B1</f><v>3</v></c></row>
                <row r="2"><c r="A2"><v>4</v></c><c r="B2"><v>5</v></c><c r="C2"><f t="shared" si="0"/><v>9</v></c></row>
                <row r="3"><c r="C3"><f>SUM(C1:C2)</f><v>12</v></c></row>
                </sheetData></worksheet>""")
        }
        val wb = XlsxReader { KXmlParser() }.read(file)
        val s = wb.sheets[0]
        assertEquals(2, s.freezeRows)
        assertEquals(1, s.freezeCols)
        assertEquals("A1+B1", s.formulas[formulaKey(0, 2)])
        assertEquals("A2+B2", s.formulas[formulaKey(1, 2)])
        assertEquals("SUM(C1:C2)", s.formulas[formulaKey(2, 2)])
        assertNull(s.formulas[formulaKey(0, 0)])
    }
}
