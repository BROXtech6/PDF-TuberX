package com.excelto.pdf.converter.excel

import com.excelto.pdf.converter.core.excel.NumberFormatter
import com.excelto.pdf.converter.core.excel.NumberFormatter.format
import com.excelto.pdf.converter.core.excel.NumberFormatter.general
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class NumberFormatterTest {

    private fun f(v: Double, code: String, date1904: Boolean = false) = format(v, code, date1904).text

    @Test fun general_upTo11SignificantDigits() {
        assertEquals("0", general(0.0))
        assertEquals("1234.5", general(1234.5))
        assertEquals("-42", general(-42.0))
        assertEquals("0.33333333333", general(1.0 / 3))
        assertEquals("0.3", general(0.1 + 0.2))
        assertEquals("12345678901", general(12345678901.0))
        assertEquals("1.23457E+11", general(123456789012.0))
        assertEquals("1E-10", general(1e-10))
        assertEquals("1234.5", f(1234.5, "General"))
    }

    @Test fun digitsAndSeparators() {
        assertEquals("1235", f(1234.567, "0"))
        assertEquals("1234.57", f(1234.567, "0.00"))
        assertEquals("1,235", f(1234.567, "#,##0"))
        assertEquals("1,234.57", f(1234.567, "#,##0.00"))
        assertEquals("-1,234.57", f(-1234.567, "#,##0.00"))
        assertEquals("2.68", f(2.675, "0.00")) // Excel rounds half up on the decimal value
        assertEquals(".5", f(0.5, "#.0#"))
        assertEquals("0.5", f(0.5, "0.0#"))
        assertEquals(".5", f(0.5, "#.#"))
        assertEquals("007", f(7.0, "000"))
        assertEquals("123-45-6789", f(123456789.0, "000-00-0000"))
    }

    @Test fun thousandsScaling() {
        assertEquals("1,235", f(1234567.0, "#,##0,"))
        assertEquals("1.2", f(1234567.0, "0.0,,"))
    }

    @Test fun percent() {
        assertEquals("26%", f(0.256, "0%"))
        assertEquals("25.60%", f(0.256, "0.00%"))
        assertEquals("12.5%", f(0.125, "0.0%"))
    }

    @Test fun currencyAndLiteralText() {
        assertEquals("$1,234.50", f(1234.5, "\"$\"#,##0.00"))
        assertEquals("-$50.00", f(-50.0, "\"$\"#,##0.00"))
        assertEquals("€ 1,234.50", f(1234.5, "[$€-407] #,##0.00"))
        assertEquals("12 kg", f(12.0, "0 \"kg\""))
        assertEquals("12 units", f(12.0, "0\\ \\u\\n\\i\\t\\s"))
    }

    @Test fun sections() {
        assertEquals("$1,234 ", f(1234.0, NumberFormatter.builtIn(5)!!))
        assertEquals("($1,234)", f(-1234.0, NumberFormatter.builtIn(5)!!))
        assertEquals("(5.00)", f(-5.0, "#,##0.00;(#,##0.00)"))
        assertEquals("zero", f(0.0, "0;-0;\"zero\""))
        assertEquals("Name: Bob", NumberFormatter.formatText("Bob", "0;0;0;\"Name: \"@").text)
        assertEquals("plain", NumberFormatter.formatText("plain", "0.00").text)
        assertEquals("big", f(500.0, "[>100]\"big\";\"small\""))
        assertEquals("small", f(5.0, "[>100]\"big\";\"small\""))
    }

    @Test fun colorTags() {
        val r = format(-5.0, "#,##0;[Red]-#,##0")
        assertEquals("-5", r.text)
        assertEquals(0xFFFF0000.toInt(), r.color)
        assertNull(format(5.0, "#,##0;[Red]-#,##0").color)
    }

    @Test fun scientificAndFractions() {
        assertEquals("1.23E+04", f(12345.0, "0.00E+00"))
        assertEquals("1.23E-04", f(0.000123, "0.00E+00"))
        assertEquals("12.3E+3", f(12345.0, "##0.0E+0"))
        assertEquals("1 1/2", f(1.5, "# ?/?").trim())
        assertEquals("3/4", f(0.75, "# ??/??").trim())
        assertEquals("1/3", f(1.0 / 3, "?/?").trim())
    }

    @Test fun builtInDates() {
        // 45000 is Wednesday 15 March 2023.
        assertEquals("3/15/2023", f(45000.0, NumberFormatter.builtIn(14)!!))
        assertEquals("15-Mar-23", f(45000.0, NumberFormatter.builtIn(15)!!))
        assertEquals("15-Mar", f(45000.0, NumberFormatter.builtIn(16)!!))
        assertEquals("Mar-23", f(45000.0, NumberFormatter.builtIn(17)!!))
        assertEquals("6:00 PM", f(0.75, NumberFormatter.builtIn(18)!!))
        assertEquals("6:00:00 PM", f(0.75, NumberFormatter.builtIn(19)!!))
        assertEquals("18:00", f(0.75, NumberFormatter.builtIn(20)!!))
        assertEquals("18:00:00", f(0.75, NumberFormatter.builtIn(21)!!))
        assertEquals("4/15/2023 12:00", f(45031.5, NumberFormatter.builtIn(22)!!))
        assertEquals("30:00", f(0.5 / 24, NumberFormatter.builtIn(45)!!))
        assertEquals("36:00:00", f(1.5, NumberFormatter.builtIn(46)!!))
        assertEquals("00:01.5", f(1.5 / 86400, NumberFormatter.builtIn(47)!!))
    }

    @Test fun customDates() {
        assertEquals("2023-03-15", f(45000.0, "yyyy-mm-dd"))
        assertEquals("Wednesday, March 15, 2023", f(45000.0, "dddd, mmmm d, yyyy"))
        assertEquals("Wed 15 Mar", f(45000.0, "ddd d mmm"))
        assertEquals("M", f(45000.0, "mmmmm"))
        assertEquals("03", f(45000.0, "mm"))
        assertEquals("12:30", f(0.5 + 30.0 / 1440, "h:mm"))
        assertEquals("05", f(5.0 / 1440, "[mm]"))
        assertEquals("12 AM", f(0.0, "h AM/PM"))
        assertEquals("1:05 p", f(13.0 / 24 + 5.0 / 1440, "h:mm a/p"))
        assertEquals("12:00:01", f(0.5 + 1.0 / 86400, "h:mm:ss"))
        assertTrue(NumberFormatter.isDateFormat("yyyy-mm-dd"))
        assertFalse(NumberFormatter.isDateFormat("#,##0.00"))
    }

    @Test fun leapYearBugAnd1904() {
        assertEquals("1900-01-01", f(1.0, "yyyy-mm-dd"))
        assertEquals("1900-02-28", f(59.0, "yyyy-mm-dd"))
        assertEquals("1900-02-29", f(60.0, "yyyy-mm-dd")) // the day Excel invents
        assertEquals("1900-03-01", f(61.0, "yyyy-mm-dd"))
        assertEquals("Sunday", f(1.0, "dddd")) // Excel's weekday for serial 1
        assertEquals("1904-01-01", f(0.0, "yyyy-mm-dd", date1904 = true))
        assertEquals("2027-03-16", f(45000.0, "yyyy-mm-dd", date1904 = true))
        assertEquals("##########", f(-1.0, "yyyy-mm-dd"))
    }
}
