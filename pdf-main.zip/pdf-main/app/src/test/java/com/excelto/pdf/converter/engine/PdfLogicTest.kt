package com.excelto.pdf.converter.engine

import com.excelto.pdf.converter.core.engine.ArabicShaper
import com.excelto.pdf.converter.core.engine.ChangeKind
import com.excelto.pdf.converter.core.engine.CompareEngine
import com.excelto.pdf.converter.core.engine.PageRanges
import com.excelto.pdf.converter.core.engine.PdfToExcelEngine
import com.excelto.pdf.converter.core.engine.TextChunk
import com.excelto.pdf.converter.core.engine.TextEngine
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

/** The PDF tools' pure logic: page ranges, the text diff, Arabic shaping and table detection. */
class PdfLogicTest {

    @Test fun pageRanges() {
        assertEquals(listOf(1..3, 5..5, 8..10), PageRanges.parse("1-3, 5, 8-10", 10))
        assertEquals(listOf(2..2), PageRanges.parse(" 2 ", 4))
        assertNull(PageRanges.parse("", 5))
        assertNull(PageRanges.parse("0-2", 5))
        assertNull(PageRanges.parse("4-2", 5))
        assertNull(PageRanges.parse("1-9", 5))
        assertNull(PageRanges.parse("a", 5))
        assertNull(PageRanges.parse("1-2-3", 5))
    }

    @Test fun diffFindsChangedAddedAndRemovedLines() {
        val a = CompareEngine.linesOf(listOf("Hello\nWorld\nSame", "Gone"))
        val b = CompareEngine.linesOf(listOf("Hello\nPlanet\nSame\nNew line"))
        val changes = CompareEngine.diff(a, b)
        assertEquals(2, changes.size)
        assertEquals(ChangeKind.CHANGED, changes[0].kind)
        assertEquals("World", changes[0].before); assertEquals("Planet", changes[0].after)
        assertEquals(ChangeKind.CHANGED, changes[1].kind) // "Gone" paired with "New line"
        assertEquals(2, changes[1].pageBefore)
        assertEquals(0, CompareEngine.diff(a, a).size)
        val onlyAdded = CompareEngine.diff(CompareEngine.linesOf(listOf("x")), CompareEngine.linesOf(listOf("x\ny")))
        assertEquals(ChangeKind.ADDED, onlyAdded.single().kind)
        assertEquals(ChangeKind.REMOVED, CompareEngine.diff(CompareEngine.linesOf(listOf("x\ny")), CompareEngine.linesOf(listOf("x"))).single().kind)
        // Spaces are normalized before comparing.
        assertEquals(0, CompareEngine.diff(CompareEngine.linesOf(listOf("a  b")), CompareEngine.linesOf(listOf(" a b "))).size)
    }

    @Test fun arabicShaping() {
        assertEquals("ﻣﺮﺣﺒﺎ", ArabicShaper.shape("مرحبا"))
        assertEquals("ﺳﻼﻡ", ArabicShaper.shape("سلام")) // lam-alef ligature
        assertEquals("ﭘﺎﮐﺴﺘﺎﻥ", ArabicShaper.shape("پاکستان")) // Urdu letters
        assertEquals("ﺑِﺴﻢ", ArabicShaper.shape("بِسم")) // marks don't break joining
        assertEquals("Hello 123", ArabicShaper.shape("Hello 123"))
        assertEquals("ﺍ ﺏ", ArabicShaper.shape("ا ب")) // spaces separate words
    }

    private fun chunk(x0: Float, x1: Float, y: Float, text: String) = TextChunk(x0, x1, y, y - 9f, y + 2f, text)

    @Test fun tableDetection() {
        val chunks = listOf(
            chunk(60f, 90f, 100f, "Item"), chunk(200f, 220f, 100f, "Qty"),
            chunk(60f, 100f, 120f, "Apples"), chunk(200f, 212f, 120.5f, "12"),
            chunk(60f, 90f, 140f, "Big"), chunk(93f, 130f, 140f, "pears"), chunk(200f, 206f, 140f, "4"),
        )
        assertEquals(
            listOf(listOf("Item", "Qty"), listOf("Apples", "12"), listOf("Big pears", "4")),
            PdfToExcelEngine.table(chunks),
        )
        assertEquals(emptyList<List<String>>(), PdfToExcelEngine.table(emptyList()))
    }

    @Test fun lineBoxesAreNormalizedFromTheTopLeft() {
        val lines = TextEngine.group(listOf(chunk(100f, 200f, 50f, "Hello"), chunk(205f, 250f, 50f, "there")), 0, 500f, 1000f)
        val line = lines.single()
        assertEquals("Hello there", line.text)
        assertEquals(0.2f, line.rect.left, 0.001f)
        assertEquals(0.041f, line.rect.top, 0.001f)
        assertEquals(0.5f, line.rect.right, 0.001f)
    }
}
