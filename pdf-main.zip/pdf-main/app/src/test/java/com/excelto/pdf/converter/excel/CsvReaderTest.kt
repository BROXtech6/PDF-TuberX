package com.excelto.pdf.converter.excel

import com.excelto.pdf.converter.core.excel.CellKind
import com.excelto.pdf.converter.core.excel.CsvReader
import org.junit.Assert.assertEquals
import org.junit.Test

class CsvReaderTest {

    private fun sample() = javaClass.getResourceAsStream("/samples/sample.csv")!!

    @Test fun rfc4180_quotesNewlinesAndDoubledQuotes() {
        val rows = CsvReader.parse(sample())
        assertEquals(4, rows.size)
        assertEquals(listOf("Name", "City", "Amount", "Note"), rows[0]) // BOM removed
        assertEquals("Smith, Jane", rows[1][0])
        assertEquals("Said \"hello\"", rows[1][3])
        assertEquals("Two\nlines", rows[2][3])
    }

    @Test fun detectsDelimiter() {
        assertEquals(';', CsvReader.detectDelimiter("a;b;c\n1;2;3\n"))
        assertEquals(',', CsvReader.detectDelimiter("a,b,c\n1,2,3\n"))
        assertEquals('\t', CsvReader.detectDelimiter("a\tb\n1\t2\n"))
        assertEquals(';', CsvReader.detectDelimiter("\"x,y\";b\n\"1,5\";2\n")) // commas inside quotes don't count
    }

    @Test fun emptyFieldsAndLastLineWithoutNewline() {
        assertEquals(listOf(listOf("a", "", "c"), listOf("", "2", "")), CsvReader.parse("a,,c\n,2,", ','))
        assertEquals(listOf(listOf("x")), CsvReader.parse("x\r\n", ','))
    }

    @Test fun numbersBecomeNumbersButLeadingZerosStayText() {
        val sheet = CsvReader.read(sample(), "sample").sheets[0]
        val r1 = sheet.rows[1]!!
        val amount = r1.indexOf(2)
        assertEquals(CellKind.NUMBER, r1.kinds[amount])
        assertEquals(1250.5, r1.nums[amount], 0.0)
        val r3 = sheet.rows[3]!!
        assertEquals(CellKind.STRING, r3.kinds[r3.indexOf(2)])
        assertEquals("007", r3.strs[r3.indexOf(2)])
        assertEquals(-30.0, sheet.rows[2]!!.let { it.nums[it.indexOf(2)] }, 0.0)
    }
}
