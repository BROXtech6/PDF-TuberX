package com.excelto.pdf.converter.excel

import com.excelto.pdf.converter.core.excel.CellKind
import com.excelto.pdf.converter.core.excel.CellRange
import com.excelto.pdf.converter.core.excel.ExcelSheet
import com.excelto.pdf.converter.core.excel.PageSetup
import com.excelto.pdf.converter.core.excel.Paper
import com.excelto.pdf.converter.core.excel.PrintOptions
import com.excelto.pdf.converter.core.excel.RowData
import com.excelto.pdf.converter.core.excel.SheetLayout
import com.excelto.pdf.converter.core.excel.SheetUnits
import org.junit.Assert.assertEquals
import org.junit.Test

class SheetLayoutTest {

    /** 30 columns × 100 rows at default size, A4 portrait, Excel's default margins. */
    private fun sheet(setup: PageSetup = PageSetup()): ExcelSheet {
        val rows = java.util.TreeMap<Int, RowData>()
        for (r in 0 until 100) rows[r] = RowData().apply { for (c in 0 until 30) put(c, CellKind.NUMBER, r.toDouble()) }
        return ExcelSheet("S", rows = rows, pageSetup = setup)
    }

    private val range = CellRange(0, 0, 99, 29)

    @Test fun columnWidthUnits() {
        assertEquals(48f, SheetUnits.columnPoints(SheetUnits.DEFAULT_WIDTH), 0.01f) // 8.43 characters = 64 px
        assertEquals(48f, SheetUnits.columnPoints(SheetUnits.storedWidth(8.43f)), 0.01f)
    }

    @Test fun fitColumnsShrinksToOnePageWide() {
        val l = SheetLayout(sheet(), range, PrintOptions(paper = Paper.A4, fitColumnsOnOnePage = true))
        assertEquals(1, l.colBands.size)
        assertEquals((595f - 2 * 0.7f * 72f) / (30 * 48f), l.scale, 0.001f)
    }

    @Test fun pagesGoDownThenOver() {
        val l = SheetLayout(sheet(), range, PrintOptions(paper = Paper.A4, fitColumnsOnOnePage = false))
        // 494.2 pt wide fits 10 columns of 48 pt; 734 pt tall fits 48 rows of 15 pt.
        assertEquals(listOf(0 until 10, 10 until 20, 20 until 30), l.colBands)
        assertEquals(listOf(0 until 48, 48 until 96, 96 until 100), l.rowBands)
        val pages = l.pages
        assertEquals(9, pages.size)
        assertEquals(0 until 10, pages[1].first) // second page: same columns, next rows
        assertEquals(48 until 96, pages[1].second)
        assertEquals(10 until 20, pages[3].first)
    }

    @Test fun orientationAndSheetFitToPage() {
        val landscape = SheetLayout(sheet(PageSetup(landscape = true)), range, PrintOptions(fitColumnsOnOnePage = false))
        assertEquals(842f, landscape.pageWidth, 0.01f)
        val forcedPortrait = SheetLayout(sheet(PageSetup(landscape = true)), range, PrintOptions(landscape = false, fitColumnsOnOnePage = false))
        assertEquals(595f, forcedPortrait.pageWidth, 0.01f)
        val fit = SheetLayout(sheet(PageSetup(fitToPage = true, fitWidth = 1, fitHeight = 0)), range, PrintOptions(fitColumnsOnOnePage = false))
        assertEquals(1, fit.colBands.size)
        val letter = SheetLayout(sheet(PageSetup(paperSize = 1)), range, PrintOptions(fitColumnsOnOnePage = false))
        assertEquals(612f, letter.pageWidth, 0.01f)
    }

    @Test fun hiddenRowsAndColumnsAreSkipped() {
        val s = ExcelSheet("S", rows = sheet().rows, hiddenCols = setOf(1, 2), hiddenRows = setOf(0))
        val l = SheetLayout(s, range, PrintOptions())
        assertEquals(28, l.cols.size)
        assertEquals(99, l.rows.size)
        assertEquals(48f, l.xOf(3), 0.01f) // column D sits right after column A
    }
}
