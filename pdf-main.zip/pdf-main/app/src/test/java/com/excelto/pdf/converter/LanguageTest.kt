package com.excelto.pdf.converter

import com.excelto.pdf.converter.language.AppLanguage
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test
import java.util.Locale

class LanguageTest {

    private fun tagFor(locale: String) = AppLanguage.match(Locale.forLanguageTag(locale))?.tag

    @Test fun phoneLanguagesMatchTheAppsLanguages() {
        assertEquals("ar", tagFor("ar-SA"))
        assertEquals("ur", tagFor("ur-PK"))
        assertEquals("pt-BR", tagFor("pt-BR"))
        assertEquals("pt-PT", tagFor("pt-PT"))
        assertEquals("pt-BR", tagFor("pt"))
        assertEquals("id", tagFor("id-ID"))
        assertEquals("id", tagFor("in"))
        assertEquals("zh", tagFor("zh-CN"))
        assertEquals("en", tagFor("en-GB"))
        assertNull(tagFor("sw-KE"))
    }

    @Test fun everyLanguageIsListedOnce() {
        val tags = AppLanguage.ALL.map { it.tag }
        assertEquals(20, tags.size)
        assertEquals(tags.size, tags.toSet().size)
        AppLanguage.ALL.forEach { assertEquals(it.tag, tagFor(it.tag)) }
    }
}
