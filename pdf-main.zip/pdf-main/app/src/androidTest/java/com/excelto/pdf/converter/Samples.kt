package com.excelto.pdf.converter

import android.content.Context
import androidx.test.platform.app.InstrumentationRegistry
import com.excelto.pdf.converter.core.engine.PdfTools
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.text.PDFTextStripper
import java.io.File

/** Sample files (from src/test/resources/samples) copied to a fresh folder for each test class. */
object Samples {
    val context: Context get() = InstrumentationRegistry.getInstrumentation().targetContext
    private val testContext: Context get() = InstrumentationRegistry.getInstrumentation().context

    val dir: File by lazy {
        PDFBoxResourceLoader.init(context)
        File(context.cacheDir, "samples-test").apply { deleteRecursively(); mkdirs() }
    }

    fun file(name: String): File {
        val out = File(dir, name).also { it.parentFile?.mkdirs() }
        if (!out.exists()) testContext.assets.open("samples/$name").use { input -> out.outputStream().use { input.copyTo(it) } }
        return out
    }

    fun input(name: String, password: String? = null) = PdfTools.Input(file(name).absolutePath, password)

    fun out(name: String) = File(dir, name).also { it.delete() }

    fun text(file: File, password: String? = null, page: Int? = null): String =
        PDDocument.load(file, password ?: "").use { doc ->
            PDFTextStripper().apply {
                sortByPosition = true // the same reading order the app uses (TextEngine)
                if (page != null) { startPage = page; endPage = page }
            }.getText(doc)
        }

    fun pages(file: File, password: String? = null): Int = PDDocument.load(file, password ?: "").use { it.numberOfPages }
}
