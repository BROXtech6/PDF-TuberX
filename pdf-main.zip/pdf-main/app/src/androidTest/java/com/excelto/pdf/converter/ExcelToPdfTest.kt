package com.excelto.pdf.converter

import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.excelto.pdf.converter.Samples.out
import com.excelto.pdf.converter.Samples.pages
import com.excelto.pdf.converter.Samples.text
import com.excelto.pdf.converter.core.engine.ExcelEngine
import com.excelto.pdf.converter.core.engine.ExcelOptions
import com.excelto.pdf.converter.core.engine.PageChoice
import com.excelto.pdf.converter.core.engine.Progress
import com.excelto.pdf.converter.core.engine.UserFacingException
import com.excelto.pdf.converter.core.excel.XlsReader
import com.tom_roush.pdfbox.pdmodel.PDDocument
import kotlinx.coroutines.Job
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test
import org.junit.runner.RunWith
import java.util.concurrent.CancellationException

/** Excel to PDF with our own reader and renderer, on a real device. */
@RunWith(AndroidJUnit4::class)
class ExcelToPdfTest {

    private val p = Progress.NONE

    private fun renders(file: java.io.File) {
        ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY).use { fd -> PdfRenderer(fd).use { assertTrue(it.pageCount > 0) } }
    }

    @Test fun visibleSheetNames() {
        assertEquals(listOf("Formats", "Wide", "Image", "Arabic", "PrintArea"), ExcelEngine.sheetNames(Samples.file("sample.xlsx").absolutePath))
        assertEquals(listOf("Legacy"), ExcelEngine.sheetNames(Samples.file("legacy.xls").absolutePath))
    }

    @Test fun xlsxAllSheets() {
        val o = out("sample.pdf")
        val result = ExcelEngine.toPdf(Samples.file("sample.xlsx").absolutePath, ExcelOptions(), o, p)
        assertEquals(pages(o), result.pages)
        assertTrue(result.notes.isEmpty())
        val t = text(o)
        for (s in listOf("Sales summary", "2023-03-15", "$1,234.50", "12.5%", "-$50.00", "$1,284.49", "6:00 PM", "TRUE", "Col 30", "R3C2", "R6C4")) {
            assertTrue("missing $s", t.contains(s))
        }
        // Hidden sheet, row and column, and cells outside the print area, are not printed.
        for (s in listOf("Should not print", "Hidden row text", "Hidden column text", "R1C1", "R7C5")) {
            assertFalse("should not print $s", t.contains(s))
        }
        assertTrue(t.contains("This long note spills"))
        renders(o)
    }

    @Test fun chosenSheetsPageSizeAndOrientation() {
        val o = out("wide.pdf")
        // Visible index 1 = "Wide"; A4 portrait overrides the sheet's landscape setup; no fitting.
        ExcelEngine.toPdf(Samples.file("sample.xlsx").absolutePath, ExcelOptions(sheets = setOf(1), fitColumnsOnOnePage = false, page = PageChoice.A4, landscape = false), o, p)
        PDDocument.load(o).use { doc ->
            assertEquals(595f, doc.getPage(0).mediaBox.width, 1f)
            assertTrue("wide sheet should split across pages", doc.numberOfPages >= 3)
        }
        val fit = out("wide-fit.pdf")
        ExcelEngine.toPdf(Samples.file("sample.xlsx").absolutePath, ExcelOptions(sheets = setOf(1), fitColumnsOnOnePage = true), fit, p)
        PDDocument.load(fit).use { doc ->
            assertEquals(842f, doc.getPage(0).mediaBox.width, 1f) // the sheet's own landscape A4
            assertEquals(1, doc.numberOfPages)
        }
        val grid = out("grid.pdf")
        ExcelEngine.toPdf(Samples.file("sample.xlsx").absolutePath, ExcelOptions(sheets = setOf(0), printGridlines = true), grid, p)
        renders(grid)
    }

    @Test fun arabicRightToLeftAndImage() {
        val o = out("arabic.pdf")
        ExcelEngine.toPdf(Samples.file("sample.xlsx").absolutePath, ExcelOptions(sheets = setOf(2, 3)), o, p)
        assertEquals(2, pages(o))
        PDDocument.load(o).use { doc ->
            val images = doc.getPage(0).resources.xObjectNames.count()
            assertTrue("the picture should be on the Image sheet's page", images >= 1)
        }
        val t = text(o, page = 2)
        assertTrue(t.any { it.code in 0x0600..0x06FF || it.code in 0xFE70..0xFEFF })
        renders(o)
    }

    @Test fun legacyXlsRunsOnAndroid() {
        val wb = XlsReader.read(Samples.file("legacy.xls"))
        assertEquals("Legacy", wb.sheets[0].name)
        val o = out("legacy.pdf")
        ExcelEngine.toPdf(Samples.file("legacy.xls").absolutePath, ExcelOptions(), o, p)
        val t = text(o)
        for (s in listOf("Amina", "1-Jan-20", "52,000.00", "61,500.50", "Merged footer across three columns")) assertTrue("missing $s", t.contains(s))
        renders(o)
    }

    @Test fun csv() {
        val o = out("csv.pdf")
        ExcelEngine.toPdf(Samples.file("sample.csv").absolutePath, ExcelOptions(), o, p)
        val t = text(o)
        assertTrue(t.contains("Smith, Jane"))
        assertTrue(t.contains("1250.5"))
        assertTrue(t.contains("007"))
    }

    @Test fun fiftyThousandRowsStreamInChunks() {
        val big = out("big.csv")
        big.bufferedWriter().use { w ->
            w.write("Id,Name,Amount\n")
            for (i in 1..50_000) w.write("$i,Customer $i,${i * 1.5}\n")
        }
        val o = out("big.pdf")
        var last = 0
        val result = ExcelEngine.toPdf(big.absolutePath, ExcelOptions(), o, Progress(null) { last = it })
        assertEquals(100, last)
        assertTrue("expected many pages, got ${result.pages}", result.pages > 500)
        assertEquals(result.pages, pages(o))
        assertTrue(text(o, page = result.pages).contains("50000"))
    }

    @Test fun cancelStopsAndDeletesOutput() {
        val o = out("cancel.pdf")
        val job = Job().apply { cancel() }
        try {
            ExcelEngine.toPdf(Samples.file("sample.xlsx").absolutePath, ExcelOptions(), o, Progress(job) {})
            fail()
        } catch (e: CancellationException) {
        }
        assertFalse(o.exists())
    }

    @Test fun passwordProtectedWorkbook() {
        val locked = out("locked.xlsx")
        locked.writeBytes(byteArrayOf(0xD0.toByte(), 0xCF.toByte(), 0x11, 0xE0.toByte(), 0xA1.toByte(), 0xB1.toByte(), 0x1A, 0xE1.toByte()) + ByteArray(512))
        try {
            ExcelEngine.toPdf(locked.absolutePath, ExcelOptions(), out("locked.pdf"), p)
            fail()
        } catch (e: UserFacingException) {
            assertTrue(e.message!!.contains("password"))
        }
    }
}
