package com.excelto.pdf.converter

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.excelto.pdf.converter.Samples.input
import com.excelto.pdf.converter.Samples.out
import com.excelto.pdf.converter.Samples.pages
import com.excelto.pdf.converter.Samples.text
import com.excelto.pdf.converter.core.engine.CropEngine
import com.excelto.pdf.converter.core.engine.HtmlOptions
import com.excelto.pdf.converter.core.engine.HtmlToPdfEngine
import com.excelto.pdf.converter.core.engine.ImageFormat
import com.excelto.pdf.converter.core.engine.NRect
import com.excelto.pdf.converter.core.engine.NeedsOcrException
import com.excelto.pdf.converter.core.engine.NumberFormat
import com.excelto.pdf.converter.core.engine.NumberPosition
import com.excelto.pdf.converter.core.engine.OcrEngine
import com.excelto.pdf.converter.core.engine.OcrScript
import com.excelto.pdf.converter.core.engine.PageNumberEngine
import com.excelto.pdf.converter.core.engine.PageNumberOptions
import com.excelto.pdf.converter.core.engine.PageSpec
import com.excelto.pdf.converter.core.engine.PdfToImageEngine
import com.excelto.pdf.converter.core.engine.PdfToPdfAEngine
import com.excelto.pdf.converter.core.engine.PdfToPptEngine
import com.excelto.pdf.converter.core.engine.PdfToWordEngine
import com.excelto.pdf.converter.core.engine.PdfTools
import com.excelto.pdf.converter.core.engine.PowerPointToPdfEngine
import com.excelto.pdf.converter.core.engine.Progress
import com.excelto.pdf.converter.core.engine.RepairEngine
import com.excelto.pdf.converter.core.engine.UserFacingException
import com.excelto.pdf.converter.core.engine.WordToPdfEngine
import com.excelto.pdf.converter.core.office.DocxReader
import com.excelto.pdf.converter.core.office.Flow
import com.excelto.pdf.converter.core.office.PptxReader
import com.tom_roush.pdfbox.cos.COSName
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.pdmodel.font.PDType0Font
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test
import org.junit.runner.RunWith
import java.io.File

/** The 14 new tools on a real device. First pages are also saved as PNGs for a visual check. */
@RunWith(AndroidJUnit4::class)
class NewToolsTest {

    private val p = Progress.NONE
    private val work get() = File(Samples.context.cacheDir, "work").apply { mkdirs() }

    /** Renders [page] with Android's renderer, checks it isn't blank, and saves it for review. */
    private fun render(file: File, expectedPages: Int, name: String, page: Int = 0): Bitmap {
        ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY).use { fd ->
            PdfRenderer(fd).use { r ->
                assertEquals(expectedPages, r.pageCount)
                r.openPage(page).use { pg ->
                    val bmp = Bitmap.createBitmap(pg.width, pg.height, Bitmap.Config.ARGB_8888)
                    bmp.eraseColor(Color.WHITE)
                    pg.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                    var ink = 0
                    for (y in 0 until bmp.height step 4) for (x in 0 until bmp.width step 4) if (bmp.getPixel(x, y) != Color.WHITE) ink++
                    assertTrue("$name page ${page + 1} is blank", ink > 20)
                    val dir = File(Samples.context.getExternalFilesDir(null), "renders").apply { mkdirs() }
                    File(dir, "$name.png").outputStream().use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
                    return bmp
                }
            }
        }
    }

    // ---- Convert to PDF ---------------------------------------------------------------------

    @Test fun wordToPdf() {
        val o = out("report.pdf")
        val r = WordToPdfEngine.convert(Samples.file("office/report.docx").path, o, p)
        assertTrue("pages ${r.pages}", r.pages >= 2)
        val t = text(o)
        for (s in listOf("Quarterly Report", "Revenue rose 12 percent", "First bullet point", "Step two", "North", "Merged: 98 / 110", "Second page", "Centered line")) {
            assertTrue("missing $s", t.contains(s))
        }
        assertTrue(text(o, page = 2).contains("Second page"))
        PDDocument.load(o).use { assertEquals(612f, it.getPage(0).mediaBox.width, 1f) }
        render(o, r.pages, "word_to_pdf_1")
        render(o, r.pages, "word_to_pdf_2", page = 1)
    }

    @Test fun damagedWordFileFailsCleanly() {
        val o = out("damaged.pdf")
        try {
            WordToPdfEngine.convert(Samples.file("office/damaged.docx").path, o, p)
            fail("expected an error")
        } catch (e: UserFacingException) {
            assertTrue(!o.exists())
        }
    }

    @Test fun powerPointToPdf() {
        val o = out("deck.pdf")
        val r = PowerPointToPdfEngine.convert(Samples.file("office/deck.pptx").path, includeHidden = false, out = o, progress = p)
        assertEquals(4, r.slides)
        assertEquals(4, pages(o))
        assertTrue(text(o, page = 1).contains("Quarterly Review"))
        assertTrue(text(o, page = 2).contains("Costs down 4%"))
        assertTrue(text(o, page = 3).contains("South"))
        PDDocument.load(o).use { assertEquals(960f, it.getPage(0).mediaBox.width, 1f) }
        for (i in 0 until 4) render(o, 4, "ppt_to_pdf_${i + 1}", page = i)

        val all = out("deck_all.pdf")
        assertEquals(5, PowerPointToPdfEngine.convert(Samples.file("office/deck.pptx").path, true, all, p).slides)
    }

    @Test fun damagedPresentationFailsCleanly() {
        val o = out("damaged_deck.pdf")
        try {
            PowerPointToPdfEngine.convert(Samples.file("office/damaged.pptx").path, false, o, p)
            fail("expected an error")
        } catch (e: UserFacingException) {
            assertTrue(!o.exists())
        }
    }

    @Test fun htmlFileToPdf() = runBlocking {
        val o = out("page.pdf")
        val n = HtmlToPdfEngine.convert(Samples.context, Samples.file("office/page.html").path, HtmlOptions(), o, p)
        render(o, n, "html_to_pdf_1")
        val t = text(o)
        assertTrue("pages $n, text: ${t.take(200)}", n >= 2)
        assertTrue("text: ${t.take(300)}", t.contains("Sample web page"))
        assertTrue(t.contains("Line 60"))
        val land = out("page_land.pdf")
        HtmlToPdfEngine.convert(Samples.context, Samples.file("office/page.html").path, HtmlOptions(612f, 792f, landscape = true, marginPt = 0f), land, p)
        PDDocument.load(land).use { assertEquals(792f, it.getPage(0).mediaBox.width, 1f) }
    }

    @Test fun findsLinksInSharedText() {
        assertEquals("https://example.com/a?b=1", HtmlToPdfEngine.findUrl("Look at this: https://example.com/a?b=1."))
        assertEquals(null, HtmlToPdfEngine.findUrl("no link here"))
    }

    // ---- Convert from PDF -------------------------------------------------------------------

    @Test fun pdfToWord() {
        val o = out("plain.docx")
        val r = PdfToWordEngine.convert(input("plain.pdf"), o, p)
        assertEquals(3, r.pages)
        val doc = DocxReader().read(o)
        val all = doc.blocks.joinToString("\n") { b ->
            when (b) {
                is Flow.Paragraph -> b.text
                is Flow.Table -> b.rows.joinToString("\n") { row -> row.cells.joinToString(" ") { c -> c.blocks.filterIsInstance<Flow.Paragraph>().joinToString(" ") { it.text } } }
                else -> ""
            }
        }
        assertTrue(all, all.contains("Quarterly Report"))
        assertEquals(2, doc.blocks.count { it == Flow.PageBreak })
        // Round trip: the .docx converts back to a PDF with the same words.
        val back = out("plain_back.pdf")
        WordToPdfEngine.convert(o.path, back, p)
        assertTrue(text(back).contains("Quarterly Report"))
        render(back, pages(back), "pdf_to_word_roundtrip")
    }

    @Test fun scannedPdfToWordOffersOcr() {
        try {
            PdfToWordEngine.convert(input("scanned.pdf"), out("scan.docx"), p)
            fail("expected NeedsOcrException")
        } catch (e: NeedsOcrException) {
            assertTrue(e.path.endsWith("scanned.pdf"))
        }
    }

    @Test fun pdfToPowerPoint() {
        val o = out("plain.pptx")
        assertEquals(3, PdfToPptEngine.convert(input("plain.pdf"), o, work, p))
        val deck = PptxReader().read(o)
        assertEquals(3, deck.slides.size)
        // Round trip back to PDF: three image slides.
        val back = out("plain_pptx_back.pdf")
        assertEquals(3, PowerPointToPdfEngine.convert(o.path, false, back, p).slides)
        render(back, 3, "pdf_to_ppt_roundtrip")
    }

    @Test fun pdfToPdfA() {
        val o = out("plain_PDFA.pdf")
        val r = PdfToPdfAEngine.convert(Samples.context, input("plain.pdf"), o, work, p)
        assertEquals(3, r.pages)
        PDDocument.load(o).use { doc ->
            val catalog = doc.documentCatalog
            val xmp = String(catalog.metadata.toByteArray())
            assertTrue(xmp.contains("<pdfaid:part>2</pdfaid:part>"))
            assertTrue(xmp.contains("<pdfaid:conformance>B</pdfaid:conformance>"))
            assertEquals(1, catalog.outputIntents.size)
            assertNotNull(doc.document.documentID)
            for (page in doc.pages) for (name in page.resources.fontNames) {
                val font = page.resources.getFont(name)
                assertTrue("font ${font.name} must be embedded", font.isEmbedded)
                assertTrue(font is PDType0Font)
            }
            assertTrue(!doc.isEncrypted)
        }
        assertTrue(text(o).contains("Quarterly Report"))
        render(o, 3, "pdf_to_pdfa")
    }

    @Test fun pdfToJpg() {
        val dir = File(Samples.dir, "jpgs").apply { deleteRecursively(); mkdirs() }
        val made = PdfToImageEngine.convert(input("plain.pdf"), emptyList(), 150f, ImageFormat.JPG, dir, "plain", work, p)
        assertEquals(3, made.size)
        val png = PdfToImageEngine.convert(input("plain.pdf"), listOf(1), 72f, ImageFormat.PNG, dir, "one", work, p)
        assertEquals(1, png.size)
        assertTrue(png[0].name.endsWith(".png"))
        val bmp = android.graphics.BitmapFactory.decodeFile(made[0].path)
        assertTrue(bmp.width > 1000)
    }

    // ---- Organize, optimize, edit -------------------------------------------------------------

    @Test fun removeAndExtractPages() {
        val o = out("removed.pdf")
        PdfTools.organize(input("plain.pdf"), listOf(PageSpec(1), PageSpec(3)), o, p)
        assertEquals(2, pages(o))
        val parts = PdfTools.split(input("plain.pdf"), listOf(2..2), { out("extract$it.pdf") }, p)
        assertEquals(1, pages(parts.single()))
    }

    @Test fun rotatePages() {
        val o = out("rotated_out.pdf")
        PdfTools.organize(input("plain.pdf"), listOf(PageSpec(1, 90), PageSpec(2), PageSpec(3, 180)), o, p)
        PDDocument.load(o).use { assertEquals(90, it.getPage(0).rotation); assertEquals(180, it.getPage(2).rotation) }
    }

    @Test fun pageNumbers() {
        val o = out("numbered.pdf")
        PageNumberEngine.apply(input("plain.pdf"), PageNumberOptions(NumberPosition.BOTTOM_CENTER, NumberFormat.PAGE_OF, startNumber = 1, firstPage = 2), o, p)
        assertTrue(!text(o, page = 1).contains("Page 1 of"))
        assertTrue(text(o, page = 2).contains("Page 1 of"))
        render(o, 3, "page_numbers", page = 2)
    }

    @Test fun cropPages() {
        val o = out("cropped.pdf")
        CropEngine.apply(input("plain.pdf"), NRect(0.1f, 0.1f, 0.9f, 0.6f), null, false, o, p)
        PDDocument.load(o).use { doc ->
            val media = doc.getPage(0).mediaBox
            val crop = doc.getPage(0).cropBox
            assertEquals(media.width * 0.8f, crop.width, 2f)
            assertEquals(media.height * 0.5f, crop.height, 2f)
        }
        render(o, 3, "crop")
    }

    @Test fun repairDamagedPdf() {
        val good = Samples.file("plain.pdf").readBytes()
        val broken = File(Samples.dir, "broken.pdf").apply { writeBytes(good.copyOf(good.size - 200)) }
        val o = out("repaired.pdf")
        val r = RepairEngine.repair(PdfTools.Input(broken.path), o, p)
        assertTrue(r.pages >= 1)
        render(o, r.pages, "repair")
    }

    @Test fun ocrScannedPdf() {
        val o = out("searchable.pdf")
        val r = OcrEngine.apply(input("scanned.pdf"), OcrScript.LATIN, o, work, p)
        assertTrue(r.recognized >= 1)
        assertTrue(text(o).isNotBlank())
    }

    @Test fun pdfFormsStillOpen() {
        PDDocument.load(Samples.file("form.pdf")).use { assertNotNull(it.documentCatalog.acroForm) }
        assertTrue(COSName.ACRO_FORM.name.isNotEmpty())
    }
}
