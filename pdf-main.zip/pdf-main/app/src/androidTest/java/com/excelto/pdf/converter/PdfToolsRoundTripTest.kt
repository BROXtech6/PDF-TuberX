package com.excelto.pdf.converter

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.ParcelFileDescriptor
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.excelto.pdf.converter.Samples.input
import com.excelto.pdf.converter.Samples.out
import com.excelto.pdf.converter.Samples.pages
import com.excelto.pdf.converter.Samples.text
import com.excelto.pdf.converter.core.engine.CompareEngine
import com.excelto.pdf.converter.core.engine.CompressEngine
import com.excelto.pdf.converter.core.engine.CompressLevel
import com.excelto.pdf.converter.core.engine.EditEngine
import com.excelto.pdf.converter.core.engine.FieldKind
import com.excelto.pdf.converter.core.engine.FormEngine
import com.excelto.pdf.converter.core.engine.ImageToPdfEngine
import com.excelto.pdf.converter.core.engine.Mark
import com.excelto.pdf.converter.core.engine.NPoint
import com.excelto.pdf.converter.core.engine.NRect
import com.excelto.pdf.converter.core.engine.OcrScript
import com.excelto.pdf.converter.core.engine.PageChoice
import com.excelto.pdf.converter.core.engine.PageSpec
import com.excelto.pdf.converter.core.engine.PasswordRequiredException
import com.excelto.pdf.converter.core.engine.PdfToExcelEngine
import com.excelto.pdf.converter.core.engine.PdfTools
import com.excelto.pdf.converter.core.engine.Progress
import com.excelto.pdf.converter.core.engine.ScanEngine
import com.excelto.pdf.converter.core.engine.TableLayout
import com.excelto.pdf.converter.core.engine.TextEngine
import com.excelto.pdf.converter.core.engine.UserFacingException
import com.excelto.pdf.converter.core.engine.WatermarkEngine
import com.excelto.pdf.converter.core.engine.WatermarkOptions
import com.excelto.pdf.converter.core.engine.WatermarkPosition
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.pdmodel.interactive.annotation.PDAnnotationText
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test
import org.junit.runner.RunWith
import java.io.File
import java.util.zip.ZipFile

/** Every PDF tool on a real device: the output opens, has the right pages, and keeps or removes the right text. */
@RunWith(AndroidJUnit4::class)
class PdfToolsRoundTripTest {

    private val p = Progress.NONE

    /** Android's own renderer must open the output too (that's what the app's viewer uses). */
    private fun assertRenders(file: File, expectedPages: Int) {
        ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY).use { fd ->
            PdfRenderer(fd).use { r ->
                assertEquals(expectedPages, r.pageCount)
                r.openPage(0).use { page ->
                    val bmp = Bitmap.createBitmap(page.width / 2, page.height / 2, Bitmap.Config.ARGB_8888)
                    page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                    bmp.recycle()
                }
            }
        }
    }

    @Test fun merge() {
        val o = out("merged.pdf")
        PdfTools.merge(listOf(input("plain.pdf"), input("rotated.pdf"), input("protected.pdf", "owner456")), o, p)
        assertEquals(7, pages(o))
        val t = text(o)
        assertTrue(t.indexOf("Quarterly Report") < t.indexOf("Upright page"))
        assertTrue(t.contains("Confidential salary table"))
        assertRenders(o, 7)
    }

    @Test fun split() {
        val made = PdfTools.split(input("plain.pdf"), listOf(1..1, 2..3), { out("part$it.pdf") }, p)
        assertEquals(2, made.size)
        assertEquals(1, pages(made[0]))
        assertEquals(2, pages(made[1]))
        assertTrue(text(made[1]).contains("Apples"))
        assertFalse(text(made[1]).contains("Quarterly Report"))
        assertEquals(3, PdfTools.split(input("plain.pdf"), PdfTools.everyPage(3), { out("each$it.pdf") }, p).size)
    }

    @Test fun organize() {
        val o = out("organized.pdf")
        PdfTools.organize(input("plain.pdf"), listOf(PageSpec(3, 90), PageSpec(1)), o, p)
        assertEquals(2, pages(o))
        PDDocument.load(o).use { doc ->
            assertEquals(90, doc.getPage(0).rotation)
            assertEquals(0, doc.getPage(1).rotation)
        }
        assertTrue(text(o, page = 1).contains("Page three"))
        assertTrue(text(o, page = 2).contains("Quarterly Report"))
        assertRenders(o, 2)
    }

    @Test fun protectThenUnlock() {
        val locked = out("locked.pdf")
        PdfTools.protect(input("plain.pdf"), "abcdef", allowPrinting = false, allowCopying = false, locked, p)
        assertTrue(PdfTools.isPasswordProtected(locked.absolutePath))
        try { PdfTools.open(locked.absolutePath).close(); fail() } catch (e: PasswordRequiredException) { }
        PDDocument.load(locked, "abcdef").use { doc ->
            assertEquals(3, doc.numberOfPages)
            assertEquals(256, doc.encryption.length)
            assertFalse(doc.currentAccessPermission.canPrint())
            assertFalse(doc.currentAccessPermission.canExtractContent())
        }
        // The random owner password means the user password can't remove the limits.
        try {
            PdfTools.unlock(PdfTools.Input(locked.absolutePath, "abcdef"), out("x.pdf"), p); fail()
        } catch (e: UserFacingException) {
            assertTrue(e.message!!.contains("doesn't allow removing"))
        }
        assertFalse(out("x.pdf").exists()) // half-written output deleted

        val open = out("open.pdf")
        PdfTools.protect(input("plain.pdf"), "abcdef", allowPrinting = true, allowCopying = true, open, p)
        val unlocked = out("unlocked.pdf")
        PdfTools.unlock(PdfTools.Input(open.absolutePath, "abcdef"), unlocked, p)
        assertFalse(PdfTools.isPasswordProtected(unlocked.absolutePath))
        assertEquals(3, pages(unlocked))
    }

    @Test fun existingPasswordFile() {
        assertTrue(PdfTools.isPasswordProtected(Samples.file("protected.pdf").absolutePath))
        try { PdfTools.pageCount(Samples.file("protected.pdf").absolutePath); fail() } catch (e: PasswordRequiredException) { }
        assertEquals(1, PdfTools.pageCount(Samples.file("protected.pdf").absolutePath, "secret123"))
        val o = out("unlocked2.pdf")
        PdfTools.unlock(input("protected.pdf", "owner456"), o, p)
        assertEquals("Confidential salary table", text(o).trim())
    }

    @Test fun watermarkOnUprightAndRotatedPages() {
        val o = out("wm.pdf")
        WatermarkEngine.apply(input("plain.pdf"), WatermarkOptions("CONFIDENTIAL", 0.3f, WatermarkPosition.CENTER, pageNumbers = true), o, p)
        assertEquals(3, pages(o))
        val t = text(o)
        assertTrue(t.contains("CONFIDENTIAL"))
        assertTrue(t.contains("Page 2 of 3"))
        assertRenders(o, 3)

        val d = out("wm-diagonal.pdf")
        WatermarkEngine.apply(input("plain.pdf"), WatermarkOptions("DRAFT", 0.2f, WatermarkPosition.DIAGONAL), d, p)
        assertRenders(d, 3)

        val r = out("wm-rotated.pdf")
        WatermarkEngine.apply(input("rotated.pdf"), WatermarkOptions("سري للغاية", position = WatermarkPosition.FOOTER, pageNumbers = true), r, p)
        assertEquals(3, pages(r))
        assertTrue(text(r).contains("Page 1 of 3"))
        assertRenders(r, 3)
    }

    @Test fun compressShrinksPhotos() {
        val o = out("small.pdf")
        val result = CompressEngine.compress(input("scanned.pdf"), CompressLevel.STRONG, o, p)
        assertTrue("after ${result.after} before ${result.before}", result.after < result.before / 2)
        assertEquals(o.length(), result.after)
        assertRenders(o, 1)
        // A text-only file can't shrink: the original bytes are kept.
        val t = out("same.pdf")
        val same = CompressEngine.compress(input("plain.pdf"), CompressLevel.LIGHT, t, p)
        assertTrue(same.after <= same.before)
        assertEquals(3, pages(t))
    }

    private fun signaturePng(): String {
        val bmp = Bitmap.createBitmap(300, 100, Bitmap.Config.ARGB_8888)
        Canvas(bmp).drawLine(10f, 80f, 290f, 20f, Paint().apply { color = Color.BLUE; strokeWidth = 6f })
        val f = out("sig.png")
        f.outputStream().use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
        return f.absolutePath
    }

    @Test fun editMarks() {
        val o = out("edited.pdf")
        val marks = listOf(
            Mark.Highlight(0, NRect(0.1f, 0.05f, 0.5f, 0.08f)),
            Mark.Ink(0, listOf(listOf(NPoint(0.1f, 0.5f), NPoint(0.3f, 0.55f), NPoint(0.5f, 0.5f))), Color.RED, 0.004f),
            Mark.Note(0, NPoint(0.8f, 0.2f), "Check this number"),
            Mark.TextBox(1, NRect(0.1f, 0.3f, 0.8f, 0.35f), "Added line of text", 0.016f, Color.BLACK, coverOriginal = false),
            Mark.TextBox(1, NRect(0.1f, 0.4f, 0.8f, 0.45f), "نص عربي مضاف", 0.016f, Color.BLACK, coverOriginal = true),
            Mark.Signature(2, NRect(0.5f, 0.7f, 0.9f, 0.8f), signaturePng()),
        )
        EditEngine.apply(input("plain.pdf"), marks, o, Samples.dir, p)
        assertEquals(3, pages(o))
        assertTrue(text(o, page = 2).contains("Added line of text"))
        PDDocument.load(o).use { doc ->
            val note = doc.getPage(0).annotations.filterIsInstance<PDAnnotationText>().single()
            assertEquals("Check this number", note.contents)
        }
        assertRenders(o, 3)
        // Rotated pages take marks too.
        val r = out("edited-rotated.pdf")
        EditEngine.apply(input("rotated.pdf"), listOf(Mark.Note(0, NPoint(0.5f, 0.5f), "n"), Mark.Highlight(1, NRect(0.1f, 0.1f, 0.5f, 0.2f))), r, Samples.dir, p)
        assertRenders(r, 3)
    }

    @Test fun redactionRemovesTheText() {
        val line = TextEngine.lines(input("plain.pdf"), 0).first { "ALPHA-7731" in it.text }
        val o = out("redacted.pdf")
        val r = line.rect
        EditEngine.apply(input("plain.pdf"), listOf(Mark.Redaction(0, NRect(r.left - 0.01f, r.top - 0.005f, r.right + 0.01f, r.bottom + 0.005f))), o, Samples.dir, p)
        assertEquals(3, pages(o))
        val all = text(o)
        assertFalse("redacted text still in the file", all.contains("ALPHA-7731"))
        assertFalse(all.contains("Quarterly Report")) // the whole redacted page is now an image
        assertTrue(all.contains("Apples")) // other pages keep their text
        // The raw bytes don't contain it either.
        assertFalse(String(o.readBytes(), Charsets.ISO_8859_1).contains("ALPHA"))
        PDDocument.load(o).use { doc ->
            assertEquals(595f, doc.getPage(0).mediaBox.width, 1f)
            assertEquals(842f, doc.getPage(0).mediaBox.height, 1f)
        }
        assertRenders(o, 3)
    }

    @Test fun fillForm() {
        val fields = FormEngine.read(input("form.pdf"))
        assertEquals(listOf("agree", "city", "full_name", "plan", "size"), fields.map { it.name })
        assertEquals(FieldKind.CHECKBOX, fields.first { it.name == "agree" }.kind)
        assertEquals(listOf("Yes"), fields.first { it.name == "agree" }.options)
        assertEquals(listOf("Large", "Small"), fields.first { it.name == "size" }.options)
        assertEquals(FieldKind.CHOICE, fields.first { it.name == "plan" }.kind)

        val values = mapOf("full_name" to "Jane Doe", "city" to "لاہور", "agree" to "Yes", "size" to "Large", "plan" to "Pro")
        val o = out("filled.pdf")
        FormEngine.fill(input("form.pdf"), values, flatten = false, o, p)
        val back = FormEngine.read(PdfTools.Input(o.absolutePath)).associate { it.name to it.value }
        assertEquals("Jane Doe", back["full_name"])
        assertEquals("لاہور", back["city"]) // stored in logical order
        assertEquals("Yes", back["agree"])
        assertEquals("Large", back["size"])
        assertEquals("Pro", back["plan"])
        assertRenders(o, 1)

        val flat = out("flat.pdf")
        FormEngine.fill(input("form.pdf"), values, flatten = true, flat, p)
        assertTrue(FormEngine.read(PdfTools.Input(flat.absolutePath)).isEmpty())
        val flatText = java.text.Normalizer.normalize(text(flat), java.text.Normalizer.Form.NFKC)
        assertTrue(flatText.contains("Jane Doe"))
        assertRenders(flat, 1)
    }

    @Test fun compareAndReport() {
        val organized = out("cmp.pdf")
        PdfTools.organize(input("plain.pdf"), listOf(PageSpec(1), PageSpec(3)), organized, p)
        val changes = CompareEngine.compare(input("plain.pdf"), PdfTools.Input(organized.absolutePath), p)
        assertTrue(changes.any { it.before.contains("Apples") })
        val report = out("report.pdf")
        CompareEngine.report("plain.pdf", "cmp.pdf", changes, report)
        val t = text(report)
        assertTrue(t.contains("Comparison report"))
        assertTrue(t.contains("Apples"))
        assertRenders(report, pages(report))
    }

    private fun photo(name: String, w: Int, h: Int): Uri {
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        Canvas(bmp).apply { drawColor(Color.rgb(30, 120, 200)); drawCircle(w / 2f, h / 2f, minOf(w, h) / 3f, Paint().apply { color = Color.YELLOW }) }
        val f = out(name)
        f.outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 90, it) }
        return Uri.fromFile(f)
    }

    @Test fun imagesToPdf() {
        val resolver = Samples.context.contentResolver
        val o = out("images.pdf")
        ImageToPdfEngine.convert(resolver, listOf(photo("tall.jpg", 600, 900), photo("wide.jpg", 1200, 600)), PageChoice.A4, 20f, o, p)
        PDDocument.load(o).use { doc ->
            assertEquals(2, doc.numberOfPages)
            assertEquals(595f, doc.getPage(0).mediaBox.width, 1f)
            assertEquals(842f, doc.getPage(1).mediaBox.width, 1f) // landscape photo, landscape page
        }
        val orig = out("images-orig.pdf")
        ImageToPdfEngine.convert(resolver, listOf(photo("wide2.jpg", 1200, 600)), PageChoice.ORIGINAL, 20f, orig, p)
        PDDocument.load(orig).use { assertEquals(842f, it.getPage(0).mediaBox.width, 1f) }
        assertRenders(o, 2)
    }

    @Test fun scanWithInvisibleTextLayer() {
        val bmp = Bitmap.createBitmap(1200, 1600, Bitmap.Config.ARGB_8888)
        Canvas(bmp).apply {
            drawColor(Color.WHITE)
            drawText("HELLO SCANNER 2024", 100f, 300f, Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 90f; color = Color.BLACK })
        }
        val f = out("page.jpg")
        f.outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 95, it) }
        val o = out("scan.pdf")
        ScanEngine.build(Samples.context.contentResolver, listOf(Uri.fromFile(f)), OcrScript.LATIN, o, p)
        assertEquals(1, pages(o))
        assertTrue(text(o).uppercase().contains("HELLO"))
        assertRenders(o, 1)
    }

    @Test fun pdfToExcel() {
        val o = out("tables.xlsx")
        val rows = PdfToExcelEngine.convert(input("plain.pdf"), TableLayout.SHEET_PER_PAGE, o, p)
        assertTrue(rows > 5)
        ZipFile(o).use { zip ->
            val sheet2 = zip.getInputStream(zip.getEntry("xl/worksheets/sheet2.xml")).readBytes().toString(Charsets.UTF_8)
            assertTrue(sheet2.contains("Apples"))
            assertTrue(sheet2.contains("<v>12</v>"))
        }
        try {
            PdfToExcelEngine.convert(input("scanned.pdf"), TableLayout.ONE_SHEET, out("none.xlsx"), p); fail()
        } catch (e: UserFacingException) {
            assertNotNull(e.message)
        }
    }

    @Test fun textAndLinesFromRotatedAndCroppedPages() {
        assertTrue(TextEngine.pages(input("rotated.pdf"))[0].contains("Rotated ninety"))
        assertTrue(TextEngine.lines(input("rotated.pdf"), 0).isEmpty()) // rotated: no boxes, like before
        val lines = TextEngine.lines(input("rotated.pdf"), 2) // upright with a crop box
        val line = lines.single { it.text == "Upright page" }
        assertTrue(line.rect.left in 0f..0.1f)
        assertTrue(line.rect.top in 0f..0.1f)
    }
}
