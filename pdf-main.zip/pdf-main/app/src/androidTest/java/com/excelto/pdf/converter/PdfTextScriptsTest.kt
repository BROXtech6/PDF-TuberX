package com.excelto.pdf.converter

import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import android.util.Log
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.excelto.pdf.converter.Samples.out
import com.excelto.pdf.converter.Samples.text
import com.excelto.pdf.converter.core.engine.PdfFlow
import com.excelto.pdf.converter.core.engine.PdfText
import com.tom_roush.pdfbox.pdmodel.PDDocument
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import java.text.Normalizer

/** The PdfBox text helper with Arabic, Urdu, Hindi, Chinese, Russian and Turkish. */
@RunWith(AndroidJUnit4::class)
class PdfTextScriptsTest {

    private val samples = mapOf(
        "arabic" to "مرحبا بالعالم، هذا اختبار",
        "urdu" to "پاکستان زندہ باد، یہ ایک جانچ ہے",
        "hindi" to "नमस्ते दुनिया, यह एक परीक्षण है",
        "chinese" to "你好，世界。这是一个测试。",
        "russian" to "Привет, мир! Это проверка.",
        "turkish" to "Merhaba dünya, bu bir sınavdır: ğüşıöç İ",
    )

    private fun renders(file: java.io.File) =
        ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY).use { fd -> PdfRenderer(fd).use { it.pageCount } }

    @Test fun everyScriptRendersAndLatinCyrillicStaySelectable() {
        val o = out("scripts.pdf")
        PDDocument().use { doc ->
            val flow = PdfFlow(doc)
            for ((name, s) in samples) {
                flow.paragraph(name, 10f, isBold = true)
                flow.paragraph(s, 14f)
            }
            flow.close()
            doc.save(o)
        }
        assertEquals(1, renders(o))
        val t = Normalizer.normalize(text(o), Normalizer.Form.NFKC)
        Log.i("PdfTextScriptsTest", t)
        assertTrue(t.contains(samples.getValue("russian")))
        assertTrue(t.contains(samples.getValue("turkish")))
        // Arabic and Urdu are written as shaped glyphs in visual order; the letters must be there.
        for (word in listOf("مرحبا", "پاکستان")) {
            val letters = word.toSet()
            assertTrue("missing letters of $word", letters.all { it in t })
        }
    }

    @Test fun widthsAndWrapping() {
        PDDocument().use { doc ->
            val text = PdfText(doc)
            for ((_, s) in samples) {
                val w = text.width(s, 12f)
                assertTrue("width of $s", w > 20f)
                val lines = text.wrap(s, 12f, w / 2)
                assertTrue("$s should wrap", lines.size >= 2)
                lines.forEach { assertTrue(text.width(it, 12f) <= w / 2 + 0.5f || !it.contains(' ')) }
            }
        }
    }

    @Test fun shapingAndBidi() {
        // Logical "مرحبا" shaped, then reversed for right-to-left display.
        val visual = PdfText.visualOrder(PdfText.shapeArabic("مرحبا"))
        assertEquals("ﺎﺒﺣﺮﻣ", visual)
        // Numbers inside Arabic keep their own order.
        assertTrue(PdfText.visualOrder(PdfText.shapeArabic("رقم 123")).contains("123"))
        assertTrue(PdfText.isRtlParagraph("مرحبا hello"))
        assertTrue(!PdfText.isRtlParagraph("hello مرحبا"))
    }
}
