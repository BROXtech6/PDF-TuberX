package com.excelto.pdf.converter

import android.content.Intent
import android.graphics.Bitmap
import androidx.test.core.app.ActivityScenario
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import com.excelto.pdf.converter.core.engine.ExcelEngine
import com.excelto.pdf.converter.core.excel.GridGeometry
import com.excelto.pdf.converter.excelviewer.ExcelViewActivity
import com.excelto.pdf.converter.excelviewer.SheetSearch
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import java.io.File

/** The spreadsheet viewer on a device: big sheets load within memory, and real files draw. */
@RunWith(AndroidJUnit4::class)
class ExcelViewerTest {

    @Test fun hundredThousandRowsLoadWithinMemory() {
        val csv = File(Samples.dir, "big.csv")
        csv.bufferedWriter().use { w ->
            w.write("Id,Name,Amount,Date,Note\n")
            for (i in 1..100_000) w.write("$i,Customer $i,${i * 1.5},2026-01-${(i % 28) + 1},Row number $i\n")
        }
        val rt = Runtime.getRuntime()
        System.gc()
        val before = rt.totalMemory() - rt.freeMemory()
        val start = System.currentTimeMillis()
        val (wb, sheet) = ExcelEngine.readSheet(csv.path, 0) {}
        val g = GridGeometry(sheet, wb)
        val ms = System.currentTimeMillis() - start
        System.gc()
        val usedMb = (rt.totalMemory() - rt.freeMemory() - before) / 1024 / 1024
        assertEquals(100_001, sheet.rows.size)
        assertTrue("used $usedMb MB", usedMb < 160)
        assertTrue("took $ms ms", ms < 30_000)
        assertEquals(99_999, g.rowAt(g.rowY[99_999] + 1f))
        val found = SheetSearch.find(wb, sheet, "Customer 99999")
        assertEquals(listOf(99_999 to 1), found)
        android.util.Log.i("ExcelViewerTest", "100k rows: $ms ms, $usedMb MB")
    }

    private fun screenshot(name: String, path: String) {
        val intent = Intent(Samples.context, ExcelViewActivity::class.java).putExtra(ExcelViewActivity.EXTRA_PATH, path)
        ActivityScenario.launch<ExcelViewActivity>(intent).use {
            Thread.sleep(3500)
            InstrumentationRegistry.getInstrumentation().waitForIdleSync()
            val shot: Bitmap = InstrumentationRegistry.getInstrumentation().uiAutomation.takeScreenshot()
            val dir = File(Samples.context.getExternalFilesDir(null), "renders").apply { mkdirs() }
            File(dir, "$name.png").outputStream().use { shot.compress(Bitmap.CompressFormat.PNG, 100, it) }
            // The first rows must have been drawn: count non-white pixels under the column headers.
            var ink = 0
            for (y in shot.height * 15 / 100 until shot.height * 25 / 100 step 3) for (x in shot.width / 8 until shot.width * 3 / 4 step 3) {
                if (shot.getPixel(x, y) != android.graphics.Color.WHITE) ink++
            }
            assertTrue("$name looks empty", ink > 200)
        }
    }

    @Test fun opensXlsx() = screenshot("viewer_xlsx", Samples.file("sample.xlsx").path)

    @Test fun opensXls() = screenshot("viewer_xls", Samples.file("legacy.xls").path)

    @Test fun opensCsv() = screenshot("viewer_csv", Samples.file("sample.csv").path)
}
