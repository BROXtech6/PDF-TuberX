package com.excelto.pdf.converter.ads

import android.app.Activity
import android.content.Context
import android.util.Log
import com.excelto.pdf.converter.R
import com.excelto.pdf.converter.app.App
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback
import com.google.android.ump.ConsentInformation
import com.google.android.ump.ConsentRequestParameters
import com.google.android.ump.UserMessagingPlatform
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Ads for free users, placed to follow AdMob and Google Play policies:
 *  - Native ad cards in the Home feed and the Files list, labeled "Ad".
 *  - An interstitial at a natural break: after every finished job, before its result
 *    shows (only when one has loaded, and never when coming back to the app later).
 *  - An opt-in rewarded video to use a Pro tool once.
 *  - No ads for Pro users, on viewers, in the editor, while working, or on the paywall.
 *
 * Ad unit IDs live in res/values/ads.xml: Google's test IDs in src/main (debug and qa
 * builds) and the real ones in src/release. Nothing loads until the consent form (EU/UK)
 * has been answered.
 */
object Ads {

    private const val TAG = "Ads"

    private val started = AtomicBoolean(false)
    /** Compose state, so ad cards appear as soon as the SDK is ready. */
    var ready by androidx.compose.runtime.mutableStateOf(false)
        private set

    private var interstitial: InterstitialAd? = null
    private var interstitialLoading = false
    private var rewarded: RewardedAd? = null
    private var rewardedLoading = false

    val enabled: Boolean get() = !App.getInstance().isSubscribed

    /** Asks for consent where the law requires it, then starts the SDK. Call from the main activity. */
    fun start(activity: Activity) {
        if (!enabled || !started.compareAndSet(false, true)) return
        val consent = UserMessagingPlatform.getConsentInformation(activity)
        consent.requestConsentInfoUpdate(
            activity,
            ConsentRequestParameters.Builder().build(),
            {
                UserMessagingPlatform.loadAndShowConsentFormIfRequired(activity) { error ->
                    if (error != null) Log.w(TAG, "Consent form: ${error.message}")
                    if (consent.canRequestAds()) initialize(activity)
                }
            },
            { error ->
                Log.w(TAG, "Consent info: ${error.message}")
                // Ads may still be allowed from an earlier answer.
                if (consent.canRequestAds()) initialize(activity)
            },
        )
        if (consent.canRequestAds()) initialize(activity)
    }

    /** True when the user should be able to change their ad privacy choices (EU/UK). */
    fun privacyOptionsRequired(context: Context): Boolean =
        UserMessagingPlatform.getConsentInformation(context).privacyOptionsRequirementStatus ==
            ConsentInformation.PrivacyOptionsRequirementStatus.REQUIRED

    fun showPrivacyOptions(activity: Activity) {
        UserMessagingPlatform.showPrivacyOptionsForm(activity) { e -> if (e != null) Log.w(TAG, "Privacy options: ${e.message}") }
    }

    private val initOnce = AtomicBoolean(false)

    private fun initialize(activity: Activity) {
        if (!initOnce.compareAndSet(false, true)) return
        val app = activity.applicationContext
        Thread {
            MobileAds.initialize(app) {
                activity.runOnUiThread {
                    ready = true
                    loadInterstitial(app)
                    loadRewarded(app)
                }
            }
        }.start()
    }

    fun request(): AdRequest = AdRequest.Builder().build()

    fun nativeUnit(context: Context) = context.getString(R.string.ad_unit_native)

    // ---- Interstitial after a saved file -------------------------------------------------

    private fun loadInterstitial(context: Context) {
        if (!ready || !enabled || interstitial != null || interstitialLoading) return
        interstitialLoading = true
        InterstitialAd.load(context, context.getString(R.string.ad_unit_interstitial), request(), object : InterstitialAdLoadCallback() {
            override fun onAdLoaded(ad: InterstitialAd) { interstitial = ad; interstitialLoading = false }
            override fun onAdFailedToLoad(error: LoadAdError) { interstitialLoading = false; Log.i(TAG, "Interstitial: ${error.message}") }
        })
    }

    /**
     * Called when a job's result is about to show. Shows an interstitial after every job
     * when one is loaded, then calls [then]; otherwise calls [then] straight away.
     */
    fun afterJob(activity: Activity, then: () -> Unit) {
        val ad = interstitial
        if (!enabled || ad == null) {
            loadInterstitial(activity.applicationContext)
            then()
            return
        }
        interstitial = null
        ad.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdDismissedFullScreenContent() { then(); loadInterstitial(activity.applicationContext) }
            override fun onAdFailedToShowFullScreenContent(error: AdError) { then(); loadInterstitial(activity.applicationContext) }
        }
        ad.show(activity)
    }

    // ---- Rewarded: use a Pro tool once ---------------------------------------------------------

    private fun loadRewarded(context: Context) {
        if (!ready || !enabled || rewarded != null || rewardedLoading) return
        rewardedLoading = true
        RewardedAd.load(context, context.getString(R.string.ad_unit_rewarded), request(), object : RewardedAdLoadCallback() {
            override fun onAdLoaded(ad: RewardedAd) { rewarded = ad; rewardedLoading = false }
            override fun onAdFailedToLoad(error: LoadAdError) { rewardedLoading = false; Log.i(TAG, "Rewarded: ${error.message}") }
        })
    }

    val rewardedReady: Boolean get() = rewarded != null

    /** Shows the rewarded video; [onReward] runs only if it was watched to the end. */
    fun showRewarded(activity: Activity, onReward: () -> Unit, onUnavailable: () -> Unit) {
        val ad = rewarded
        if (ad == null) {
            loadRewarded(activity.applicationContext)
            onUnavailable()
            return
        }
        rewarded = null
        var earned = false
        ad.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdDismissedFullScreenContent() {
                if (earned) onReward()
                loadRewarded(activity.applicationContext)
            }
            override fun onAdFailedToShowFullScreenContent(error: AdError) {
                onUnavailable()
                loadRewarded(activity.applicationContext)
            }
        }
        ad.show(activity) { earned = true }
    }
}
