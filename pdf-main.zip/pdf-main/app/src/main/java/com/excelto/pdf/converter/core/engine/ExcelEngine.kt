package com.excelto.pdf.converter.core.engine

import com.excelto.pdf.converter.R
import android.util.Xml
import com.excelto.pdf.converter.core.excel.CsvReader
import com.excelto.pdf.converter.core.excel.ExcelWorkbook
import com.excelto.pdf.converter.core.excel.Paper
import com.excelto.pdf.converter.core.excel.PrintOptions
import com.excelto.pdf.converter.core.excel.SheetRenderer
import com.excelto.pdf.converter.core.excel.XlsReader
import com.excelto.pdf.converter.core.excel.XlsxReader
import java.io.File

data class ExcelOptions(
    /** Indexes (into [ExcelEngine.sheetNames]) of the sheets to include. Null means every visible sheet. */
    val sheets: Set<Int>? = null,
    val fitColumnsOnOnePage: Boolean = true,
    val page: PageChoice = PageChoice.ORIGINAL,
    val landscape: Boolean? = null,
    val printGridlines: Boolean = false,
)

/** What came out: the page count, and notes for the user (for example "Charts aren't included."). */
data class ExcelResult(val pages: Int, val notes: List<String>)

/**
 * Excel to PDF with our own reader and renderer (core/excel): .xlsx/.xlsm read with
 * java.util.zip + XmlPullParser, .xls with Apache POI HSSF, .csv with our parser.
 * Pages are drawn with Android's PdfDocument, so there is no license and no watermark.
 */
object ExcelEngine {

    private enum class Format { XLSX, XLS, CSV }

    private fun formatOf(file: File): Format {
        when (file.extension.lowercase()) {
            "xlsx", "xlsm", "xltx", "xltm" -> return Format.XLSX
            "xls", "xlt" -> return Format.XLS
            "csv", "tsv", "txt" -> return Format.CSV
        }
        val head = ByteArray(4)
        val n = runCatching { file.inputStream().use { it.read(head) } }.getOrDefault(0)
        return when {
            n >= 2 && head[0] == 'P'.code.toByte() && head[1] == 'K'.code.toByte() -> Format.XLSX
            n >= 4 && head[0] == 0xD0.toByte() && head[1] == 0xCF.toByte() -> Format.XLS
            else -> Format.CSV
        }
    }

    private fun xlsx() = XlsxReader { Xml.newPullParser() }

    /** Names of the visible sheets, in workbook order. */
    fun sheetNames(path: String): List<String> = guard {
        val file = File(path)
        when (formatOf(file)) {
            Format.XLSX -> xlsx().sheetNames(file)
            Format.XLS -> XlsReader.sheetNames(file)
            Format.CSV -> listOf(file.nameWithoutExtension to false)
        }.filter { !it.second }.map { it.first }
    }

    fun toPdf(path: String, options: ExcelOptions, out: File, progress: Progress): ExcelResult = PdfTools.writing(out) {
        guard {
            val file = File(path)
            progress.report(3)
            val format = formatOf(file)
            val all = when (format) {
                Format.XLSX -> xlsx().sheetNames(file)
                Format.XLS -> XlsReader.sheetNames(file)
                Format.CSV -> listOf(file.nameWithoutExtension to false)
            }
            // The screen lists visible sheets only; map its indexes back to the workbook's.
            val visible = all.indices.filter { !all[it].second }
            val chosen = options.sheets?.let { set ->
                if (set.isEmpty()) throw UserFacingException(R.string.err_choose_at_least_one, "Choose at least one sheet.")
                set.sorted().mapNotNull { visible.getOrNull(it) }
            } ?: visible
            if (chosen.isEmpty()) throw UserFacingException(R.string.err_workbook_no_visible_sheets, "This workbook has no visible sheets to print.")
            progress.report(8)
            val workbook: ExcelWorkbook = when (format) {
                Format.XLSX -> xlsx().read(file, chosen.toSet()) { progress.check() }
                Format.XLS -> XlsReader.read(file, chosen.toSet()) { progress.check() }
                Format.CSV -> CsvReader.read(file)
            }
            progress.report(40)
            val print = PrintOptions(
                paper = when (options.page) {
                    PageChoice.A4 -> Paper.A4
                    PageChoice.LETTER -> Paper.LETTER
                    PageChoice.ORIGINAL -> null
                },
                landscape = options.landscape,
                fitColumnsOnOnePage = options.fitColumnsOnOnePage,
                printGridlines = options.printGridlines,
            )
            val workDir = File(System.getProperty("java.io.tmpdir") ?: out.parent ?: ".")
            val result = SheetRenderer(workbook, print, workDir, onPage = { done, total -> progress.step(done, total, 40, 98) }, check = { progress.check() })
                .render(chosen, out)
            progress.report(100)
            ExcelResult(result.pages, result.notes)
        }
    }

    /** A sheet the viewer can show: its position among visible sheets and in the workbook. */
    class SheetRef(val visibleIndex: Int, val workbookIndex: Int, val name: String)

    /** The visible sheets, for the viewer's tabs. */
    fun sheets(path: String): List<SheetRef> = guard {
        val file = File(path)
        val all = when (formatOf(file)) {
            Format.XLSX -> xlsx().sheetNames(file)
            Format.XLS -> XlsReader.sheetNames(file)
            Format.CSV -> listOf(file.nameWithoutExtension to false)
        }
        all.indices.filter { !all[it].second }.mapIndexed { v, w -> SheetRef(v, w, all[w].first) }
    }

    /**
     * Reads one sheet for the viewer. [check] is called while reading so a large file can
     * be canceled. Returns the workbook (for styles) and the sheet.
     */
    fun readSheet(path: String, workbookIndex: Int, check: () -> Unit): Pair<ExcelWorkbook, com.excelto.pdf.converter.core.excel.ExcelSheet> = guard {
        val file = File(path)
        val wb = when (formatOf(file)) {
            Format.XLSX -> xlsx().read(file, setOf(workbookIndex), check)
            Format.XLS -> XlsReader.read(file, setOf(workbookIndex), check)
            Format.CSV -> CsvReader.read(file)
        }
        wb to (wb.sheets.getOrNull(workbookIndex) ?: wb.sheets.first())
    }

    private inline fun <T> guard(block: () -> T): T = try {
        block()
    } catch (e: UserFacingException) {
        throw e
    } catch (e: java.util.concurrent.CancellationException) {
        throw e
    } catch (e: OutOfMemoryError) {
        throw UserFacingException(R.string.err_spreadsheet_too_large_convert, "This spreadsheet is too large to convert on this phone.", e)
    } catch (e: Exception) {
        throw UserFacingException(R.string.err_spreadsheet_couldnt_opened_may, "This spreadsheet couldn't be opened. It may be damaged or in an unsupported format.", e)
    }
}
