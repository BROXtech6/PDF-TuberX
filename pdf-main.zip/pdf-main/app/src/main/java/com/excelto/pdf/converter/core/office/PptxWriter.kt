package com.excelto.pdf.converter.core.office

import com.excelto.pdf.converter.core.office.OfficeZip.Companion.XML_HEADER
import com.excelto.pdf.converter.core.office.OfficeZip.Companion.emu
import com.excelto.pdf.converter.core.office.OfficeZip.Companion.esc
import java.io.File

/**
 * Writes a .pptx where every slide is one picture, with optional speaker notes.
 * Includes the parts PowerPoint, Google Slides and Keynote expect: a slide master, a
 * layout, themes and a notes master. Pure Kotlin, unit tested.
 */
object PptxWriter {

    /** One slide: a JPEG or PNG image, its notes, and the page's width / height ([aspect]). */
    class Slide(val image: ByteArray, val isPng: Boolean, val notes: String, val aspect: Float)

    private const val NS_P = "http://schemas.openxmlformats.org/presentationml/2006/main"
    private const val NS_A = "http://schemas.openxmlformats.org/drawingml/2006/main"
    private const val NS_R = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
    private const val REL = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
    private const val PKG_REL = "http://schemas.openxmlformats.org/package/2006/relationships"

    /**
     * Writes [count] slides at [widthPt] × [heightPt]. [slide] is called once per slide, so
     * only one page image is in memory at a time. Pictures are fitted and centered.
     */
    fun write(out: File, widthPt: Float, heightPt: Float, count: Int, slide: (Int) -> Slide) {
        require(count > 0)
        val cx = emu(widthPt).coerceIn(914400, 51206400)
        val cy = emu(heightPt).coerceIn(914400, 51206400)
        OfficeZip(out).use { z ->
            val exts = mutableSetOf<String>()
            for (i in 1..count) {
                val s = slide(i - 1)
                val ext = if (s.isPng) "png" else "jpeg"
                exts += ext
                z.bytes("ppt/media/image$i.$ext", s.image)
                z.text("ppt/slides/slide$i.xml", slideXml(cx, cy, s.aspect))
                z.text("ppt/slides/_rels/slide$i.xml.rels", rels(
                    "rId1" to ("$REL/slideLayout" to "../slideLayouts/slideLayout1.xml"),
                    "rId2" to ("$REL/image" to "../media/image$i.$ext"),
                    "rId3" to ("$REL/notesSlide" to "../notesSlides/notesSlide$i.xml"),
                ))
                z.text("ppt/notesSlides/notesSlide$i.xml", notesXml(s.notes))
                z.text("ppt/notesSlides/_rels/notesSlide$i.xml.rels", rels(
                    "rId1" to ("$REL/notesMaster" to "../notesMasters/notesMaster1.xml"),
                    "rId2" to ("$REL/slide" to "../slides/slide$i.xml"),
                ))
            }
            z.text("[Content_Types].xml", contentTypes(count, exts))
            z.text("_rels/.rels", rels(
                "rId1" to ("$REL/officeDocument" to "ppt/presentation.xml"),
                "rId2" to ("http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" to "docProps/core.xml"),
                "rId3" to ("$REL/extended-properties" to "docProps/app.xml"),
            ))
            z.text("docProps/core.xml", OfficeParts.coreXml("Converted PDF"))
            z.text("docProps/app.xml", """$XML_HEADER<Properties xmlns="http://schemas.openxmlformats.org/officeDocument/2006/extended-properties"><Application>PDF Converter</Application><Slides>$count</Slides></Properties>""")
            z.text("ppt/presentation.xml", presentationXml(count, cx, cy))
            z.text("ppt/_rels/presentation.xml.rels", rels(
                *(listOf(
                    "rId1" to ("$REL/slideMaster" to "slideMasters/slideMaster1.xml"),
                    "rId2" to ("$REL/notesMaster" to "notesMasters/notesMaster1.xml"),
                    "rId3" to ("$REL/theme" to "theme/theme1.xml"),
                    "rId4" to ("$REL/presProps" to "presProps.xml"),
                    "rId5" to ("$REL/viewProps" to "viewProps.xml"),
                    "rId6" to ("$REL/tableStyles" to "tableStyles.xml"),
                ) + (1..count).map { "rId${it + 100}" to ("$REL/slide" to "slides/slide$it.xml") }).toTypedArray(),
            ))
            z.text("ppt/presProps.xml", """$XML_HEADER<p:presentationPr xmlns:a="$NS_A" xmlns:r="$NS_R" xmlns:p="$NS_P"/>""")
            z.text("ppt/viewProps.xml", """$XML_HEADER<p:viewPr xmlns:a="$NS_A" xmlns:r="$NS_R" xmlns:p="$NS_P"><p:normalViewPr><p:restoredLeft sz="15620"/><p:restoredTop sz="94660"/></p:normalViewPr><p:gridSpacing cx="76200" cy="76200"/></p:viewPr>""")
            z.text("ppt/tableStyles.xml", """$XML_HEADER<a:tblStyleLst xmlns:a="$NS_A" def="{5C22544A-7EE6-4342-B048-85BDC9FD1C3A}"/>""")
            z.text("ppt/slideMasters/slideMaster1.xml", masterXml())
            z.text("ppt/slideMasters/_rels/slideMaster1.xml.rels", rels(
                "rId1" to ("$REL/slideLayout" to "../slideLayouts/slideLayout1.xml"),
                "rId2" to ("$REL/theme" to "../theme/theme1.xml"),
            ))
            z.text("ppt/slideLayouts/slideLayout1.xml", layoutXml())
            z.text("ppt/slideLayouts/_rels/slideLayout1.xml.rels", rels("rId1" to ("$REL/slideMaster" to "../slideMasters/slideMaster1.xml")))
            z.text("ppt/notesMasters/notesMaster1.xml", notesMasterXml())
            z.text("ppt/notesMasters/_rels/notesMaster1.xml.rels", rels("rId1" to ("$REL/theme" to "../theme/theme2.xml")))
            z.text("ppt/theme/theme1.xml", OfficeParts.themeXml("Office Theme"))
            z.text("ppt/theme/theme2.xml", OfficeParts.themeXml("Office Theme"))
        }
    }

    private fun rels(vararg items: Pair<String, Pair<String, String>>): String = buildString {
        append(XML_HEADER).append("""<Relationships xmlns="$PKG_REL">""")
        for ((id, rel) in items) append("""<Relationship Id="$id" Type="${rel.first}" Target="${rel.second}"/>""")
        append("</Relationships>")
    }

    private fun contentTypes(count: Int, exts: Set<String>) = buildString {
        append(XML_HEADER).append("""<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">""")
        append("""<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>""")
        append("""<Default Extension="xml" ContentType="application/xml"/>""")
        if ("jpeg" in exts) append("""<Default Extension="jpeg" ContentType="image/jpeg"/>""")
        if ("png" in exts) append("""<Default Extension="png" ContentType="image/png"/>""")
        val pml = "application/vnd.openxmlformats-officedocument.presentationml"
        append("""<Override PartName="/ppt/presentation.xml" ContentType="$pml.presentation.main+xml"/>""")
        append("""<Override PartName="/ppt/slideMasters/slideMaster1.xml" ContentType="$pml.slideMaster+xml"/>""")
        append("""<Override PartName="/ppt/slideLayouts/slideLayout1.xml" ContentType="$pml.slideLayout+xml"/>""")
        append("""<Override PartName="/ppt/notesMasters/notesMaster1.xml" ContentType="$pml.notesMaster+xml"/>""")
        append("""<Override PartName="/ppt/presProps.xml" ContentType="$pml.presProps+xml"/>""")
        append("""<Override PartName="/ppt/viewProps.xml" ContentType="$pml.viewProps+xml"/>""")
        append("""<Override PartName="/ppt/tableStyles.xml" ContentType="$pml.tableStyles+xml"/>""")
        append("""<Override PartName="/ppt/theme/theme1.xml" ContentType="application/vnd.openxmlformats-officedocument.theme+xml"/>""")
        append("""<Override PartName="/ppt/theme/theme2.xml" ContentType="application/vnd.openxmlformats-officedocument.theme+xml"/>""")
        append("""<Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/>""")
        append("""<Override PartName="/docProps/app.xml" ContentType="application/vnd.openxmlformats-officedocument.extended-properties+xml"/>""")
        for (i in 1..count) {
            append("""<Override PartName="/ppt/slides/slide$i.xml" ContentType="$pml.slide+xml"/>""")
            append("""<Override PartName="/ppt/notesSlides/notesSlide$i.xml" ContentType="$pml.notesSlide+xml"/>""")
        }
        append("</Types>")
    }

    private fun presentationXml(count: Int, cx: Long, cy: Long) = buildString {
        append(XML_HEADER).append("""<p:presentation xmlns:a="$NS_A" xmlns:r="$NS_R" xmlns:p="$NS_P" saveSubsetFonts="1">""")
        append("""<p:sldMasterIdLst><p:sldMasterId id="2147483648" r:id="rId1"/></p:sldMasterIdLst>""")
        append("""<p:notesMasterIdLst><p:notesMasterId r:id="rId2"/></p:notesMasterIdLst>""")
        append("<p:sldIdLst>")
        for (i in 1..count) append("""<p:sldId id="${255 + i}" r:id="rId${i + 100}"/>""")
        append("</p:sldIdLst>")
        append("""<p:sldSz cx="$cx" cy="$cy"/><p:notesSz cx="6858000" cy="9144000"/>""")
        append("""<p:defaultTextStyle><a:defPPr><a:defRPr lang="en-US"/></a:defPPr></p:defaultTextStyle>""")
        append("</p:presentation>")
    }

    private fun emptyTree() = """<p:nvGrpSpPr><p:cNvPr id="1" name=""/><p:cNvGrpSpPr/><p:nvPr/></p:nvGrpSpPr><p:grpSpPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="0" cy="0"/><a:chOff x="0" y="0"/><a:chExt cx="0" cy="0"/></a:xfrm></p:grpSpPr>"""

    private fun slideXml(cx: Long, cy: Long, aspect: Float) = buildString {
        val slideAspect = cx.toFloat() / cy
        val (w, h) = if (aspect >= slideAspect) cx to (cx / aspect).toLong() else (cy * aspect).toLong() to cy
        val x = (cx - w) / 2
        val y = (cy - h) / 2
        append(XML_HEADER).append("""<p:sld xmlns:a="$NS_A" xmlns:r="$NS_R" xmlns:p="$NS_P"><p:cSld><p:spTree>""")
        append(emptyTree())
        append("""<p:pic><p:nvPicPr><p:cNvPr id="2" name="Page"/><p:cNvPicPr><a:picLocks noChangeAspect="1"/></p:cNvPicPr><p:nvPr/></p:nvPicPr>""")
        append("""<p:blipFill><a:blip r:embed="rId2"/><a:stretch><a:fillRect/></a:stretch></p:blipFill>""")
        append("""<p:spPr><a:xfrm><a:off x="$x" y="$y"/><a:ext cx="$w" cy="$h"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom></p:spPr></p:pic>""")
        append("""</p:spTree></p:cSld><p:clrMapOvr><a:masterClrMapping/></p:clrMapOvr></p:sld>""")
    }

    private fun notesXml(notes: String) = buildString {
        append(XML_HEADER).append("""<p:notes xmlns:a="$NS_A" xmlns:r="$NS_R" xmlns:p="$NS_P"><p:cSld><p:spTree>""")
        append(emptyTree())
        append("""<p:sp><p:nvSpPr><p:cNvPr id="2" name="Notes"/><p:cNvSpPr><a:spLocks noGrp="1"/></p:cNvSpPr><p:nvPr><p:ph type="body" idx="1"/></p:nvPr></p:nvSpPr><p:spPr/>""")
        append("""<p:txBody><a:bodyPr/><a:lstStyle/>""")
        val paragraphs = notes.replace("\r", "").split('\n')
        for (p in paragraphs) {
            if (p.isEmpty()) append("<a:p/>") else append("""<a:p><a:r><a:rPr lang="en-US" dirty="0"/><a:t>${esc(p)}</a:t></a:r></a:p>""")
        }
        append("""</p:txBody></p:sp></p:spTree></p:cSld><p:clrMapOvr><a:masterClrMapping/></p:clrMapOvr></p:notes>""")
    }

    private const val CLR_MAP = """<p:clrMap bg1="lt1" tx1="dk1" bg2="lt2" tx2="dk2" accent1="accent1" accent2="accent2" accent3="accent3" accent4="accent4" accent5="accent5" accent6="accent6" hlink="hlink" folHlink="folHlink"/>"""

    private fun masterXml() = buildString {
        append(XML_HEADER).append("""<p:sldMaster xmlns:a="$NS_A" xmlns:r="$NS_R" xmlns:p="$NS_P"><p:cSld>""")
        append("""<p:bg><p:bgRef idx="1001"><a:schemeClr val="bg1"/></p:bgRef></p:bg><p:spTree>""").append(emptyTree()).append("</p:spTree></p:cSld>")
        append(CLR_MAP)
        append("""<p:sldLayoutIdLst><p:sldLayoutId id="2147483649" r:id="rId1"/></p:sldLayoutIdLst>""")
        append("""<p:txStyles><p:titleStyle><a:lvl1pPr><a:defRPr sz="4400"/></a:lvl1pPr></p:titleStyle><p:bodyStyle><a:lvl1pPr><a:defRPr sz="2800"/></a:lvl1pPr></p:bodyStyle><p:otherStyle><a:lvl1pPr><a:defRPr sz="1800"/></a:lvl1pPr></p:otherStyle></p:txStyles>""")
        append("</p:sldMaster>")
    }

    private fun layoutXml() = buildString {
        append(XML_HEADER).append("""<p:sldLayout xmlns:a="$NS_A" xmlns:r="$NS_R" xmlns:p="$NS_P" type="blank" preserve="1"><p:cSld name="Blank"><p:spTree>""")
        append(emptyTree()).append("""</p:spTree></p:cSld><p:clrMapOvr><a:masterClrMapping/></p:clrMapOvr></p:sldLayout>""")
    }

    private fun notesMasterXml() = buildString {
        append(XML_HEADER).append("""<p:notesMaster xmlns:a="$NS_A" xmlns:r="$NS_R" xmlns:p="$NS_P"><p:cSld>""")
        append("""<p:bg><p:bgRef idx="1001"><a:schemeClr val="bg1"/></p:bgRef></p:bg><p:spTree>""").append(emptyTree())
        append("""<p:sp><p:nvSpPr><p:cNvPr id="2" name="Notes Placeholder"/><p:cNvSpPr><a:spLocks noGrp="1"/></p:cNvSpPr><p:nvPr><p:ph type="body" idx="1"/></p:nvPr></p:nvSpPr>""")
        append("""<p:spPr><a:xfrm><a:off x="685800" y="4400550"/><a:ext cx="5486400" cy="3600450"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom></p:spPr><p:txBody><a:bodyPr/><a:lstStyle/><a:p><a:endParaRPr lang="en-US"/></a:p></p:txBody></p:sp>""")
        append("</p:spTree></p:cSld>").append(CLR_MAP)
        append("""<p:notesStyle><a:lvl1pPr><a:defRPr sz="1200"/></a:lvl1pPr></p:notesStyle></p:notesMaster>""")
    }
}

/** Parts shared by the .docx and .pptx writers. */
object OfficeParts {

    fun coreXml(title: String): String {
        val now = java.time.Instant.now().truncatedTo(java.time.temporal.ChronoUnit.SECONDS).toString()
        return """${OfficeZip.XML_HEADER}<cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:dcterms="http://purl.org/dc/terms/" xmlns:dcmitype="http://purl.org/dc/dcmitype/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"><dc:title>${esc(title)}</dc:title><dc:creator>PDF Converter</dc:creator><dcterms:created xsi:type="dcterms:W3CDTF">$now</dcterms:created><dcterms:modified xsi:type="dcterms:W3CDTF">$now</dcterms:modified></cp:coreProperties>"""
    }

    /** A complete Office theme (colors, fonts and the three required style lists). */
    fun themeXml(name: String): String {
        val a = "http://schemas.openxmlformats.org/drawingml/2006/main"
        fun solid(c: String) = """<a:solidFill><a:schemeClr val="$c"/></a:solidFill>"""
        val line = """<a:ln w="6350" cap="flat" cmpd="sng" algn="ctr">${solid("phClr")}<a:prstDash val="solid"/><a:miter lim="800000"/></a:ln>"""
        return buildString {
            append(OfficeZip.XML_HEADER).append("""<a:theme xmlns:a="$a" name="${esc(name)}"><a:themeElements>""")
            append("""<a:clrScheme name="Office"><a:dk1><a:sysClr val="windowText" lastClr="000000"/></a:dk1><a:lt1><a:sysClr val="window" lastClr="FFFFFF"/></a:lt1>""")
            append("""<a:dk2><a:srgbClr val="44546A"/></a:dk2><a:lt2><a:srgbClr val="E7E6E6"/></a:lt2><a:accent1><a:srgbClr val="4472C4"/></a:accent1><a:accent2><a:srgbClr val="ED7D31"/></a:accent2>""")
            append("""<a:accent3><a:srgbClr val="A5A5A5"/></a:accent3><a:accent4><a:srgbClr val="FFC000"/></a:accent4><a:accent5><a:srgbClr val="5B9BD5"/></a:accent5><a:accent6><a:srgbClr val="70AD47"/></a:accent6>""")
            append("""<a:hlink><a:srgbClr val="0563C1"/></a:hlink><a:folHlink><a:srgbClr val="954F72"/></a:folHlink></a:clrScheme>""")
            append("""<a:fontScheme name="Office"><a:majorFont><a:latin typeface="Calibri Light"/><a:ea typeface=""/><a:cs typeface=""/></a:majorFont><a:minorFont><a:latin typeface="Calibri"/><a:ea typeface=""/><a:cs typeface=""/></a:minorFont></a:fontScheme>""")
            append("""<a:fmtScheme name="Office"><a:fillStyleLst>${solid("phClr")}${solid("phClr")}${solid("phClr")}</a:fillStyleLst>""")
            append("""<a:lnStyleLst>$line$line$line</a:lnStyleLst>""")
            append("""<a:effectStyleLst><a:effectStyle><a:effectLst/></a:effectStyle><a:effectStyle><a:effectLst/></a:effectStyle><a:effectStyle><a:effectLst/></a:effectStyle></a:effectStyleLst>""")
            append("""<a:bgFillStyleLst>${solid("phClr")}${solid("phClr")}${solid("phClr")}</a:bgFillStyleLst></a:fmtScheme>""")
            append("""</a:themeElements><a:objectDefaults/><a:extraClrSchemeLst/></a:theme>""")
        }
    }
}
