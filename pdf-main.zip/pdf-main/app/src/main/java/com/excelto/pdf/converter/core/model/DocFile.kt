package com.excelto.pdf.converter.core.model

import com.excelto.pdf.converter.R

import java.io.File

enum class DocType(val badge: String, val extensions: Set<String>) {
    PDF("PDF", setOf("pdf")),
    EXCEL("XLS", setOf("xls", "xlsx", "xlsm", "csv")),
    WORD("DOC", setOf("doc", "docx")),
    POWERPOINT("PPT", setOf("ppt", "pptx")),
    HTML("HTML", setOf("html", "htm")),
    IMAGE("IMG", setOf("jpg", "jpeg", "png", "webp", "heic")),
    OTHER("FILE", emptySet());

    companion object {
        fun of(name: String): DocType {
            val ext = name.substringAfterLast('.', "").lowercase()
            return entries.firstOrNull { ext in it.extensions } ?: OTHER
        }
    }
}

/** Where a file came from. Cloud sources arrive through the system file picker. */
enum class Source(@androidx.annotation.StringRes private val labelRes: Int) { PHONE(R.string.source_phone), CREATED(R.string.source_created), IMPORTED(R.string.source_imported); val label: String get() = com.excelto.pdf.converter.language.tr(labelRes) }

data class DocFile(
    val path: String,
    val name: String,
    val type: DocType,
    val size: Long,
    val modified: Long,
    val source: Source,
    val favorite: Boolean = false,
) {
    val file: File get() = File(path)
    val stem: String get() = name.substringBeforeLast('.')

    companion object {
        fun from(file: File, source: Source, favorite: Boolean = false) = DocFile(
            path = file.absolutePath,
            name = file.name,
            type = DocType.of(file.name),
            size = file.length(),
            modified = file.lastModified(),
            source = source,
            favorite = favorite,
        )
    }
}
