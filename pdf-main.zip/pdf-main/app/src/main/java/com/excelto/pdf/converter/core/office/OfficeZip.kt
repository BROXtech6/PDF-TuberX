package com.excelto.pdf.converter.core.office

import java.io.Closeable
import java.io.File
import java.io.FileOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/** Writes the parts of an Office Open XML package (.docx, .pptx). Pure Kotlin. */
class OfficeZip(file: File) : Closeable {
    private val zip = ZipOutputStream(FileOutputStream(file))

    fun text(path: String, xml: String) = bytes(path, xml.toByteArray(Charsets.UTF_8))

    fun bytes(path: String, data: ByteArray) {
        zip.putNextEntry(ZipEntry(path))
        zip.write(data)
        zip.closeEntry()
    }

    override fun close() = zip.close()

    companion object {
        const val XML_HEADER = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>"""

        /** Escapes text for XML and drops characters XML doesn't allow. */
        fun esc(text: String): String = buildString(text.length) {
            for (ch in text) {
                when {
                    ch == '&' -> append("&amp;")
                    ch == '<' -> append("&lt;")
                    ch == '>' -> append("&gt;")
                    ch == '"' -> append("&quot;")
                    ch.code < 0x20 && ch != '\t' && ch != '\n' && ch != '\r' -> Unit
                    ch in '￾'..'￿' -> Unit
                    else -> append(ch)
                }
            }
        }

        /** Points to EMU (English Metric Units: 12,700 per point). */
        fun emu(points: Float): Long = (points * 12700f).toLong()
    }
}
