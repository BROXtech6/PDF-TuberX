package com.excelto.pdf.converter.core.render

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import android.util.LruCache
import java.io.File

/** Page thumbnails with Android's built-in PdfRenderer. Returns null for locked or damaged files. */
object PdfPages {

    private val cache = object : LruCache<String, Bitmap>(24 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap) = value.byteCount
    }
    private val lock = Any()

    fun pageCount(file: File): Int? = synchronized(lock) {
        runCatching {
            ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY).use { fd ->
                PdfRenderer(fd).use { it.pageCount }
            }
        }.getOrNull()
    }

    /** Renders page [index] (0-based) at [widthPx] wide. */
    fun render(file: File, index: Int, widthPx: Int): Bitmap? {
        val key = "${file.absolutePath}:${file.lastModified()}:$index:$widthPx"
        cache.get(key)?.let { return it }
        val bitmap = synchronized(lock) {
            runCatching {
                ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY).use { fd ->
                    PdfRenderer(fd).use { renderer ->
                        if (index !in 0 until renderer.pageCount) return@use null
                        renderer.openPage(index).use { page ->
                            val height = (widthPx.toFloat() * page.height / page.width).toInt().coerceAtLeast(1)
                            val bmp = Bitmap.createBitmap(widthPx, height, Bitmap.Config.ARGB_8888)
                            bmp.eraseColor(Color.WHITE)
                            page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                            bmp
                        }
                    }
                }
            }.getOrNull()
        } ?: return null
        cache.put(key, bitmap)
        return bitmap
    }
}
