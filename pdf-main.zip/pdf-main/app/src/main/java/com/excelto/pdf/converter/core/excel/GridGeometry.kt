package com.excelto.pdf.converter.core.excel

/**
 * Where every row and column of a sheet sits, in points from the top-left, for the
 * spreadsheet viewer. Hidden rows and columns have zero size. Lookups are binary
 * searches, so sheets with 100,000+ rows scroll smoothly. Pure logic, unit tested.
 */
class GridGeometry(val sheet: ExcelSheet, workbook: ExcelWorkbook) {

    /** The last row and column shown: the used range plus some empty cells, like Excel. */
    val lastRow: Int
    val lastCol: Int

    /** colX[c] is the left edge of column c; colX[lastCol + 1] is the total width. */
    val colX: FloatArray
    val rowY: FloatArray

    /** Merged areas by their top-left cell, and the cells they cover. */
    private val mergeAt = HashMap<Long, CellRange>()
    private val covered = HashMap<Long, CellRange>()

    init {
        val used = sheet.usedRange(workbook)
        lastRow = maxOf((used?.lastRow ?: 0) + 20, 49).coerceAtMost(MAX_ROWS - 1)
        lastCol = maxOf((used?.lastCol ?: 0) + 5, 19).coerceAtMost(MAX_COLS - 1)
        colX = FloatArray(lastCol + 2)
        for (c in 0..lastCol) {
            val w = if (c in sheet.hiddenCols) 0f else SheetUnits.columnPoints(sheet.colWidths[c] ?: sheet.defaultColWidth)
            colX[c + 1] = colX[c] + w
        }
        rowY = FloatArray(lastRow + 2)
        for (r in 0..lastRow) {
            val h = if (r in sheet.hiddenRows) 0f else (sheet.rowHeights[r] ?: sheet.defaultRowHeight)
            rowY[r + 1] = rowY[r] + h
        }
        for (m in sheet.merges) {
            if (m.firstRow > lastRow || m.firstCol > lastCol) continue
            mergeAt[key(m.firstRow, m.firstCol)] = m
            // Only remember covered cells for merges of a sensible size.
            if ((m.lastRow - m.firstRow + 1).toLong() * (m.lastCol - m.firstCol + 1) <= 20_000) {
                for (r in m.firstRow..minOf(m.lastRow, lastRow)) for (c in m.firstCol..minOf(m.lastCol, lastCol)) {
                    if (r != m.firstRow || c != m.firstCol) covered[key(r, c)] = m
                }
            }
        }
    }

    val width: Float get() = colX[lastCol + 1]
    val height: Float get() = rowY[lastRow + 1]

    /** The column at [x] points (clamped to the grid). */
    fun colAt(x: Float): Int = find(colX, x, lastCol)
    fun rowAt(y: Float): Int = find(rowY, y, lastRow)

    private fun find(edges: FloatArray, v: Float, last: Int): Int {
        if (v <= 0f) return 0
        var lo = 0
        var hi = last
        while (lo < hi) {
            val mid = (lo + hi + 1) ushr 1
            if (edges[mid] <= v) lo = mid else hi = mid - 1
        }
        return lo
    }

    /** The merged area that starts at this cell, if any. */
    fun mergeStarting(r: Int, c: Int): CellRange? = mergeAt[key(r, c)]

    /** The merged area covering this cell (not its top-left), if any. */
    fun mergeCovering(r: Int, c: Int): CellRange? = covered[key(r, c)]

    /** The cell a tap lands on, moved to the top-left of a merged area. */
    fun anchorOf(r: Int, c: Int): Pair<Int, Int> = covered[key(r, c)]?.let { it.firstRow to it.firstCol } ?: (r to c)

    companion object {
        const val MAX_ROWS = 1_048_576
        const val MAX_COLS = 16_384
        fun key(r: Int, c: Int): Long = (r.toLong() shl 20) or c.toLong()
        fun name(r: Int, c: Int) = Formulas.columnName(c) + (r + 1)
    }
}
