package com.excelto.pdf.converter.ads

import android.content.Context
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import com.excelto.pdf.converter.ui.theme.LocalPalette
import com.google.android.gms.ads.AdListener
import com.google.android.gms.ads.AdLoader
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.nativead.NativeAd
import com.google.android.gms.ads.nativead.NativeAdOptions
import com.google.android.gms.ads.nativead.NativeAdView

/**
 * A native ad shaped like the app's own cards: icon, headline with an "Ad" label,
 * one line of text and a button. Shows nothing for Pro users or when no ad loads,
 * so the layout never jumps around an empty box.
 */
@Composable
fun NativeAdCard(modifier: Modifier = Modifier) {
    if (!Ads.enabled) return
    val context = LocalContext.current
    var ad by remember { mutableStateOf<NativeAd?>(null) }
    val ready = Ads.ready
    DisposableEffect(ready) {
        var alive = true
        if (ready) {
            AdLoader.Builder(context, Ads.nativeUnit(context))
                .forNativeAd { loaded -> if (alive) ad = loaded else loaded.destroy() }
                .withAdListener(object : AdListener() { override fun onAdFailedToLoad(error: LoadAdError) = Unit })
                .withNativeAdOptions(NativeAdOptions.Builder().setAdChoicesPlacement(NativeAdOptions.ADCHOICES_TOP_RIGHT).build())
                .build()
                .loadAd(Ads.request())
        }
        onDispose { alive = false; ad?.destroy() }
    }
    val loaded = ad ?: return
    val p = LocalPalette.current
    val colors = AdColors(p.surface.toArgb(), p.text.toArgb(), p.muted.toArgb(), p.primary.toArgb(), p.onPrimary.toArgb(), p.primarySoft.toArgb(), p.primaryText.toArgb())
    AndroidView(
        modifier = modifier.fillMaxWidth(),
        factory = { ctx -> buildView(ctx, colors) },
        update = { view -> bind(view, loaded) },
    )
}

private class AdColors(val surface: Int, val text: Int, val muted: Int, val button: Int, val onButton: Int, val badge: Int, val badgeText: Int)

private fun Context.dp(v: Float) = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, resources.displayMetrics).toInt()

private fun buildView(ctx: Context, c: AdColors): NativeAdView {
    val root = NativeAdView(ctx)
    val row = LinearLayout(ctx).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        setPadding(ctx.dp(12f), ctx.dp(12f), ctx.dp(12f), ctx.dp(12f))
        background = GradientDrawable().apply { setColor(c.surface); cornerRadius = ctx.dp(16f).toFloat() }
        minimumHeight = ctx.dp(72f)
    }
    val icon = ImageView(ctx).apply {
        layoutParams = LinearLayout.LayoutParams(ctx.dp(44f), ctx.dp(44f)).apply { marginEnd = ctx.dp(12f) }
        scaleType = ImageView.ScaleType.CENTER_CROP
        clipToOutline = true
        background = GradientDrawable().apply { cornerRadius = ctx.dp(10f).toFloat(); setColor(c.badge) }
    }
    val texts = LinearLayout(ctx).apply {
        orientation = LinearLayout.VERTICAL
        layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
    }
    val titleRow = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
    val badge = TextView(ctx).apply {
        text = "Ad"
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 10f)
        setTypeface(typeface, Typeface.BOLD)
        setTextColor(c.badgeText)
        setPadding(ctx.dp(5f), ctx.dp(1f), ctx.dp(5f), ctx.dp(1f))
        background = GradientDrawable().apply { cornerRadius = ctx.dp(4f).toFloat(); setColor(c.badge) }
        layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { marginEnd = ctx.dp(6f) }
    }
    val headline = TextView(ctx).apply {
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
        setTypeface(typeface, Typeface.BOLD)
        setTextColor(c.text)
        maxLines = 1
        ellipsize = TextUtils.TruncateAt.END
    }
    val body = TextView(ctx).apply {
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
        setTextColor(c.muted)
        maxLines = 2
        ellipsize = TextUtils.TruncateAt.END
    }
    val cta = Button(ctx).apply {
        isAllCaps = false
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
        setTextColor(c.onButton)
        minHeight = ctx.dp(44f)
        minimumHeight = ctx.dp(44f)
        minWidth = 0
        minimumWidth = 0
        setPadding(ctx.dp(14f), 0, ctx.dp(14f), 0)
        background = GradientDrawable().apply { cornerRadius = ctx.dp(22f).toFloat(); setColor(c.button) }
        stateListAnimator = null
        layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, ctx.dp(44f)).apply { marginStart = ctx.dp(10f) }
    }
    titleRow.addView(badge)
    titleRow.addView(headline)
    texts.addView(titleRow)
    texts.addView(body)
    row.addView(icon)
    row.addView(texts)
    row.addView(cta)
    root.addView(row)
    root.iconView = icon
    root.headlineView = headline
    root.bodyView = body
    root.callToActionView = cta
    return root
}

private fun bind(view: NativeAdView, ad: NativeAd) {
    (view.headlineView as TextView).text = ad.headline
    (view.bodyView as TextView).apply {
        text = ad.body
        visibility = if (ad.body.isNullOrBlank()) View.GONE else View.VISIBLE
    }
    (view.callToActionView as Button).apply {
        text = ad.callToAction ?: "Open"
        visibility = if (ad.callToAction.isNullOrBlank()) View.GONE else View.VISIBLE
    }
    (view.iconView as ImageView).apply {
        val d = ad.icon?.drawable
        setImageDrawable(d)
        visibility = if (d == null) View.GONE else View.VISIBLE
    }
    view.setNativeAd(ad)
}
