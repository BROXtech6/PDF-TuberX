package com.excelto.pdf.converter.ui.screens

import com.excelto.pdf.converter.R
import com.excelto.pdf.converter.language.tr
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.excelto.pdf.converter.core.model.DocFile
import com.excelto.pdf.converter.core.model.DocType
import com.excelto.pdf.converter.core.render.PdfPages
import com.excelto.pdf.converter.ui.AppViewModel
import com.excelto.pdf.converter.ui.LocalHost
import com.excelto.pdf.converter.ui.Route
import com.excelto.pdf.converter.ui.Tool
import com.excelto.pdf.converter.ui.components.Card16
import com.excelto.pdf.converter.ui.components.Card22
import com.excelto.pdf.converter.ui.components.IconBadge
import com.excelto.pdf.converter.ui.components.SectionTitle
import com.excelto.pdf.converter.ui.components.TextAction
import com.excelto.pdf.converter.ui.components.formatSize
import com.excelto.pdf.converter.ui.components.mirrorInRtl
import com.excelto.pdf.converter.ui.components.tint
import com.excelto.pdf.converter.ui.sheets.FileActionsSheet
import com.excelto.pdf.converter.ui.theme.AppIcons
import com.excelto.pdf.converter.ui.theme.LocalPalette
import com.excelto.pdf.converter.ui.theme.Tint
import com.excelto.pdf.converter.ui.theme.Tints
import com.excelto.pdf.converter.ui.theme.Type
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.Calendar
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.vector.ImageVector

private data class Suggestion(val title: String, val sub: String, val icon: ImageVector, val tint: Tint, val action: () -> Unit)

@Composable
fun HomeScreen(vm: AppViewModel) {
    val p = LocalPalette.current
    val host = LocalHost.current
    val files by vm.files.collectAsState()
    val actionsFor = remember { mutableStateOf<DocFile?>(null) }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        // Header
        Row(Modifier.fillMaxWidth().padding(start = 18.dp, end = 18.dp, top = 16.dp, bottom = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
                Text(if (hour < 12) tr(R.string.home_morning) else if (hour < 17) tr(R.string.home_afternoon) else tr(R.string.home_evening), style = Type.small, color = p.muted)
                Text(tr(R.string.app_title), style = Type.title.copy(fontSize = 21.sp), color = p.text)
            }
            if (vm.isPremium) {
                Text("PRO", style = Type.tiny.copy(fontSize = 12.sp), color = p.primaryText,
                    modifier = Modifier.clip(RoundedCornerShape(20.dp)).background(p.primarySoft).padding(horizontal = 12.dp, vertical = 6.dp))
            } else {
                Row(
                    Modifier.heightIn(min = 40.dp).clip(RoundedCornerShape(20.dp)).background(p.ink)
                        .clickable(role = Role.Button) { host.openPaywall() }.padding(horizontal = 14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                    Icon(AppIcons.star, null, tint = p.onInk, modifier = Modifier.size(14.dp))
                    Text(tr(R.string.home_get_pro), style = Type.tiny.copy(fontSize = 12.sp), color = p.onInk)
                }
            }
        }

        Column(Modifier.padding(start = 14.dp, end = 14.dp, top = 8.dp, bottom = 22.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
            StatsCard(vm, files.size)

            // One row of the four most-used tools; the rest are a tap away in tr(R.string.home_all_tools).
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    SectionTitle(tr(R.string.home_popular), Modifier.weight(1f))
                    TextAction(tr(R.string.home_all_tools), { vm.openTab(Route.Tools) })
                }
                Tool.POPULAR.take(4).chunked(4).forEach { row ->
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        row.forEach { tool ->
                            Box(Modifier.weight(1f)) {
                                Column(
                                    Modifier.fillMaxWidth().heightIn(min = 92.dp).clip(Card16).background(p.surface)
                                        .clickable(role = Role.Button) { vm.openTool(tool) }
                                        .padding(vertical = 8.dp, horizontal = 2.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.spacedBy(6.dp, Alignment.CenterVertically),
                                ) {
                                    IconBadge(tool.icon, tool.tint)
                                    Text(Tool.shortLabel(tool), style = Type.tiny, color = p.text, maxLines = 2,
                                        textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                                }
                                if (tool.proOnly && !vm.isPremium) {
                                    Text("Pro", style = Type.tiny.copy(fontSize = 9.sp), color = p.aiText,
                                        modifier = Modifier.align(Alignment.TopEnd).padding(5.dp).clip(RoundedCornerShape(8.dp))
                                            .background(p.aiSoft).padding(horizontal = 5.dp, vertical = 1.dp))
                                }
                            }
                        }
                    }
                }
            }

            val suggestions = suggestionsFor(files, vm)
            if (suggestions.isNotEmpty()) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    SectionTitle(tr(R.string.home_suggestions))
                    val dir = LocalLayoutDirection.current
                    suggestions.forEach { s ->
                        Row(
                            Modifier.fillMaxWidth().heightIn(min = 64.dp).clip(Card16).background(p.surface)
                                .clickable(role = Role.Button, onClick = s.action).padding(horizontal = 12.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                        ) {
                            IconBadge(s.icon, s.tint, radius = 12.dp)
                            Column(Modifier.weight(1f)) {
                                Text(s.title, style = Type.bodyStrong, color = p.text, maxLines = 2, overflow = TextOverflow.Ellipsis)
                                Text(s.sub, style = Type.small, color = p.muted)
                            }
                            Icon(AppIcons.chevron, null, tint = p.muted, modifier = Modifier.size(16.dp).mirrorInRtl(dir))
                        }
                    }
                }
            }

            // One native ad between the suggestions and the recent files, never at the top.
            com.excelto.pdf.converter.ads.NativeAdCard()

            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    SectionTitle(tr(R.string.home_recent), Modifier.weight(1f))
                    TextAction(tr(R.string.home_see_all), { vm.openTab(Route.Files) })
                }
                if (files.isEmpty()) {
                    Text(
                        if (vm.loadingFiles) tr(R.string.home_looking) else tr(R.string.home_empty),
                        style = Type.small, color = p.muted, modifier = Modifier.padding(vertical = 8.dp),
                    )
                } else {
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        files.take(8).forEach { file -> RecentCard(file) { actionsFor.value = file } }
                    }
                }
            }
        }
    }
    actionsFor.value?.let { FileActionsSheet(vm, it) { actionsFor.value = null } }
}

@Composable
private fun StatsCard(vm: AppViewModel, onPhone: Int) {
    val p = LocalPalette.current
    val week = remember(vm.files.value) { vm.prefs.weekActivity() }
    val max = (week.maxOrNull() ?: 0).coerceAtLeast(1)
    val grow = remember { Animatable(0f) }
    LaunchedEffect(Unit) { grow.animateTo(1f, tween(600)) }
    Column(Modifier.fillMaxWidth().clip(Card22).background(p.ink).padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(tr(R.string.home_activity), style = Type.bodyStrong, color = p.onInk, modifier = Modifier.weight(1f))
            Text(tr(R.string.home_last_7_days), style = Type.tiny, color = p.inkMuted)
        }
        Row(Modifier.padding(top = 10.dp)) {
            listOf(
                vm.prefs.filesDone.toString() to tr(R.string.home_files_done),
                formatSize(vm.prefs.bytesSaved) to tr(R.string.home_space_saved),
                onPhone.toString() to tr(R.string.home_documents),
            ).forEach { (value, label) ->
                Column(Modifier.weight(1f)) {
                    Text(value, style = Type.stat, color = p.mint, maxLines = 1)
                    Text(label, style = Type.tiny.copy(fontSize = 11.sp), color = p.inkMuted)
                }
            }
        }
        Row(Modifier.padding(top = 14.dp).fillMaxWidth().height(54.dp), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.Bottom) {
            week.forEachIndexed { i, count ->
                val fraction = (0.12f + 0.88f * count / max) * grow.value
                Box(
                    Modifier.weight(1f).fillMaxHeight(fraction).clip(RoundedCornerShape(5.dp))
                        .background(if (i == week.lastIndex) p.mint else p.mint.copy(alpha = 0.35f)),
                )
            }
        }
    }
}

@Composable
private fun RecentCard(file: DocFile, onClick: () -> Unit) {
    val p = LocalPalette.current
    val tint = file.type.tint()
    Column(
        Modifier.width(116.dp).clip(Card16).background(p.surface).clickable(role = Role.Button, onClick = onClick).padding(8.dp),
    ) {
        Box(Modifier.fillMaxWidth().height(92.dp).clip(RoundedCornerShape(8.dp)).background(tint.soft), contentAlignment = Alignment.Center) {
            val thumb by produceState<android.graphics.Bitmap?>(null, file.path, file.modified) {
                value = if (file.type == DocType.PDF) withContext(Dispatchers.IO) { PdfPages.render(file.file, 0, 220) } else null
            }
            val bmp = thumb
            if (bmp != null) {
                Image(bmp.asImageBitmap(), null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
            } else {
                Text(file.type.badge, style = Type.tiny.copy(fontSize = 12.sp), color = tint.strong)
            }
        }
        Spacer(Modifier.height(8.dp))
        Text(file.name, style = Type.bodyStrong.copy(fontSize = 12.sp), color = p.text, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Text(formatSize(file.size), style = Type.small.copy(fontSize = 11.sp), color = p.muted)
    }
}

/** Real suggestions from the user's own files. */
private fun suggestionsFor(files: List<DocFile>, vm: AppViewModel): List<Suggestion> {
    val out = mutableListOf<Suggestion>()
    val recent = files.take(30)
    recent.filter { it.type == DocType.PDF && it.size > 3_000_000 && !it.name.contains("_compressed") }.maxByOrNull { it.size }?.let { f ->
        out += Suggestion(tr(R.string.home_sugg_big, f.name, formatSize(f.size)), tr(R.string.home_sugg_compress_hint), AppIcons.compress, Tints.amber) { vm.openTool(Tool.COMPRESS, f) }
    }
    recent.firstOrNull { it.type == DocType.EXCEL }?.let { f ->
        out += Suggestion(tr(R.string.home_sugg_excel, f.name), tr(R.string.home_sugg_excel_hint), AppIcons.excel, Tints.green) { vm.openTool(Tool.EXCEL_TO_PDF, f) }
    }
    recent.firstOrNull { it.type == DocType.PDF && !it.name.contains("_protected") && it.name.contains(Regex("(?i)contract|invoice|statement|salary|bank|agreement")) }?.let { f ->
        out += Suggestion(tr(R.string.home_sugg_private, f.name), tr(R.string.home_sugg_protect_hint), AppIcons.lock, Tints.green) { vm.openTool(Tool.PROTECT, f) }
    }
    return out.take(3)
}

