package com.excelto.pdf.converter.core.engine

import com.excelto.pdf.converter.R
import com.tom_roush.pdfbox.cos.COSName
import com.tom_roush.pdfbox.pdmodel.interactive.form.PDButton
import com.tom_roush.pdfbox.pdmodel.interactive.form.PDCheckBox
import com.tom_roush.pdfbox.pdmodel.interactive.form.PDChoice
import com.tom_roush.pdfbox.pdmodel.interactive.form.PDField
import com.tom_roush.pdfbox.pdmodel.interactive.form.PDRadioButton
import com.tom_roush.pdfbox.pdmodel.interactive.form.PDSignatureField
import com.tom_roush.pdfbox.pdmodel.interactive.form.PDTerminalField
import com.tom_roush.pdfbox.pdmodel.interactive.form.PDTextField
import java.io.File

enum class FieldKind { TEXT, CHECKBOX, CHOICE, SIGNATURE, OTHER }

data class FormField(
    val name: String,
    /** A readable label: the last part of the internal field name. */
    val label: String,
    val kind: FieldKind,
    val value: String,
    /** Allowed values for checkboxes and lists. For a checkbox, the first is "on". */
    val options: List<String>,
)

/** Fills interactive PDF forms (AcroForms). */
object FormEngine {

    private fun kindOf(field: PDField): FieldKind = when (field) {
        is PDTextField -> FieldKind.TEXT
        is PDCheckBox, is PDRadioButton -> FieldKind.CHECKBOX
        is PDChoice -> FieldKind.CHOICE
        is PDSignatureField -> FieldKind.SIGNATURE
        else -> FieldKind.OTHER
    }

    fun read(input: PdfTools.Input): List<FormField> {
        PdfTools.open(input.path, input.password).use { doc ->
            val form = doc.documentCatalog.acroForm ?: return emptyList()
            return form.fieldTree.filterIsInstance<PDTerminalField>().map { field ->
                val name = field.fullyQualifiedName
                val kind = kindOf(field)
                val options = when (field) {
                    is PDButton -> field.onValues.filter { it != "Off" }.sorted()
                    is PDChoice -> field.optionsExportValues.orEmpty()
                    else -> emptyList()
                }
                val label = name.substringAfterLast('.').replace(Regex("\\[\\d+]"), "").replace('_', ' ').trim().ifEmpty { name }
                val value = runCatching {
                    if (field is PDChoice) field.value.joinToString(", ") else field.valueAsString
                }.getOrNull().orEmpty().let { if (field is PDButton && it == "Off") "" else it }
                FormField(name, label, kind, value, options)
            }.filter { it.kind != FieldKind.SIGNATURE && it.kind != FieldKind.OTHER }.sortedBy { it.name }
        }
    }

    /** Writes [values] into the form. With [flatten], the answers become plain page content. */
    fun fill(input: PdfTools.Input, values: Map<String, String>, flatten: Boolean, out: File, progress: Progress) = PdfTools.writing(out) {
        PdfTools.open(input.path, input.password).use { doc ->
            PdfTools.requireOwnerRights(doc, "The owner of this PDF doesn't allow filling it in.")
            val form = doc.documentCatalog.acroForm ?: throw UserFacingException(R.string.err_pdf_no_form_fields, "This PDF has no form fields to fill.")
            val needsFont = values.values.any { v -> v.any { !PdfFonts.isWinAnsi(it.code) && !it.isWhitespace() } }
            val fonts = PdfFonts.FontSet(doc)
            var anyShaped = false
            values.entries.forEachIndexed { i, (name, value) ->
                val field = form.getField(name) ?: return@forEachIndexed
                when (field) {
                    is PDCheckBox -> if (value.isEmpty() || value == "Off") field.unCheck() else field.setValue(value.takeIf { it in field.onValues } ?: field.onValue)
                    is PDRadioButton -> if (value.isEmpty() || value == "Off") field.setValue("Off") else if (value in field.onValues) field.setValue(value)
                    is PDChoice -> setText(field, value, value)
                    is PDTextField -> {
                        // PdfBox draws field text without Arabic shaping, but it does reorder
                        // right-to-left text itself. So the visible text is shaped and stays in
                        // reading order; the stored value is the original text.
                        val visible = PdfText.shapeArabic(value)
                        if (visible != value) anyShaped = true
                        if (needsFont && value.any { !PdfFonts.isWinAnsi(it.code) && !it.isWhitespace() }) {
                            fonts.fullFontFor(visible)?.let { font ->
                                val res = form.defaultResources ?: com.tom_roush.pdfbox.pdmodel.PDResources().also { form.defaultResources = it }
                                val fontName = res.add(font)
                                field.defaultAppearance = "/${fontName.name} 0 Tf 0 g"
                            }
                        }
                        // Flattened: the value no longer matters, so show the display-order text as-is.
                        if (flatten) setText(field, PdfText.visualOrder(visible), PdfText.visualOrder(visible))
                        else setText(field, value, value)
                    }
                    else -> Unit
                }
                progress.step(i + 1, values.size, 5, 80)
            }
            if (flatten) {
                form.needAppearances = false
                form.flatten()
            } else if (anyShaped) {
                // Viewers rebuild the field appearance from the logical value, shaping it properly.
                form.needAppearances = true
            }
            doc.save(out)
        }
        progress.report(100)
    }

    /** Sets a field's text. When PdfBox can't draw it, the value is stored and viewers draw it. */
    private fun setText(field: PDTerminalField, shown: String, stored: String) {
        try {
            when (field) {
                is PDTextField -> field.value = shown
                is PDChoice -> field.setValue(shown)
            }
            if (shown != stored) field.cosObject.setString(COSName.V, stored)
        } catch (e: Exception) {
            field.cosObject.setString(COSName.V, stored)
            field.acroForm.needAppearances = true
        }
    }
}
