package com.excelto.pdf.converter.core.engine

import com.excelto.pdf.converter.R
import java.io.File
import kotlin.math.abs

enum class TableLayout(@androidx.annotation.StringRes private val labelRes: Int) { SHEET_PER_PAGE(R.string.layout_sheet_per_page), ONE_SHEET(R.string.layout_one_sheet); val label: String get() = com.excelto.pdf.converter.language.tr(labelRes) }

/**
 * Rebuilds tables from a PDF's text positions: text on the same baseline becomes a row,
 * and text that starts at the same horizontal position becomes a column. Works well for
 * reports, invoices and statements made by software. Scanned PDFs have no text to read.
 */
object PdfToExcelEngine {

    private class Cell(val x0: Float, var x1: Float, val text: StringBuilder)

    fun convert(input: PdfTools.Input, layout: TableLayout, out: File, progress: Progress): Int {
        val pages = mutableListOf<List<List<String>>>()
        PdfTools.open(input.path, input.password).use { doc ->
            val stripper = ChunkStripper()
            val total = doc.numberOfPages
            for (page in 1..total) {
                progress.check()
                pages += table(stripper.page(doc, page))
                progress.step(page, total, 5, 85)
            }
        }
        val rowCount = pages.sumOf { it.size }
        if (rowCount == 0) {
            throw UserFacingException(R.string.err_pdf_no_selectable_text, "This PDF has no selectable text, so there are no tables to export. If it's a scan, use Scan to PDF with text recognition first.")
        }
        val sheets = when (layout) {
            TableLayout.SHEET_PER_PAGE -> pages.mapIndexedNotNull { i, rows -> if (rows.isEmpty()) null else XlsxWriter.Sheet("Page ${i + 1}", rows) }
            TableLayout.ONE_SHEET -> listOf(XlsxWriter.Sheet("Tables", pages.filter { it.isNotEmpty() }.flatMapIndexed { i, rows ->
                if (i == 0) rows else listOf(emptyList<String>()) + rows
            }))
        }
        PdfTools.writing(out) { XlsxWriter.write(sheets, out) }
        progress.report(100)
        return rowCount
    }

    /** Rows and columns from one page's text chunks. Pure logic, unit tested. */
    fun table(chunks: List<TextChunk>): List<List<String>> {
        if (chunks.isEmpty()) return emptyList()
        // 1. Lines: group chunks whose baselines are within a few points, top to bottom.
        val lines = mutableListOf<MutableList<TextChunk>>()
        for (chunk in chunks.sortedBy { it.baseline }) {
            val line = lines.lastOrNull()
            if (line != null && abs(line.first().baseline - chunk.baseline) <= 3f) line += chunk else lines += mutableListOf(chunk)
        }
        // 2. Cells: join chunks on a line unless the gap is wide enough to be a new column.
        val rows = lines.map { line ->
            val cells = mutableListOf<Cell>()
            for (chunk in line.sortedBy { it.x0 }) {
                val last = cells.lastOrNull()
                val gap = if (last == null) Float.MAX_VALUE else chunk.x0 - last.x1
                if (last != null && gap < chunk.charWidth * 1.6f) {
                    if (gap > chunk.charWidth * 0.25f && !last.text.endsWith(" ") && !chunk.text.startsWith(" ")) last.text.append(' ')
                    last.text.append(chunk.text)
                    last.x1 = maxOf(last.x1, chunk.x1)
                } else {
                    cells += Cell(chunk.x0, chunk.x1, StringBuilder(chunk.text))
                }
            }
            cells
        }
        // 3. Columns: cluster the left edges of every cell on the page.
        val anchors = mutableListOf<Float>()
        for (x in rows.flatten().map { it.x0 }.sorted()) {
            if (anchors.isEmpty() || x - anchors.last() > 14f) anchors += x
        }
        return rows.map { cells ->
            val row = MutableList(anchors.size) { "" }
            for (cell in cells) {
                val column = anchors.indices.minBy { abs(anchors[it] - cell.x0) }
                row[column] = if (row[column].isEmpty()) cell.text.toString().trim() else row[column] + " " + cell.text.toString().trim()
            }
            row.dropLastWhile { it.isEmpty() }
        }.filter { it.isNotEmpty() }
    }
}
