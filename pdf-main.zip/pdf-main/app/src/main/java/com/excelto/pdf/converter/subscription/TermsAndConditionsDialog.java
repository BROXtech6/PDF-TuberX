package com.excelto.pdf.converter.subscription;


import android.app.Dialog;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatDialogFragment;

import com.excelto.pdf.converter.R;


public class TermsAndConditionsDialog extends AppCompatDialogFragment {
    @NonNull
    public Dialog onCreateDialog(Bundle savedInstanceState) {

        LayoutInflater inflater = requireActivity().getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.terms_and_conditions_dialog, null);
        TextView btnOk = dialogView.findViewById(R.id.btn_ok);

        // Create the dialog
        AlertDialog dialog = new AlertDialog.Builder(requireContext()).setView(dialogView).create();
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

        btnOk.setOnClickListener(v -> {
            dialog.dismiss();
        });



        return dialog;
    }
}
