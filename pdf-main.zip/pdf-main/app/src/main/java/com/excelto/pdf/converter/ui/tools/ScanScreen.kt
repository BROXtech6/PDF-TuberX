package com.excelto.pdf.converter.ui.tools

import com.excelto.pdf.converter.R
import com.excelto.pdf.converter.language.tr
import com.excelto.pdf.converter.language.trPlural
import android.app.Activity
import android.graphics.Bitmap
import android.util.Size
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.ui.semantics.Role
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.excelto.pdf.converter.core.engine.OcrScript
import com.excelto.pdf.converter.ui.AppViewModel
import com.excelto.pdf.converter.ui.Route
import com.excelto.pdf.converter.ui.Tool
import com.excelto.pdf.converter.ui.components.ChoiceRow
import com.excelto.pdf.converter.ui.components.SecondaryButton
import com.excelto.pdf.converter.ui.components.ToggleRow
import com.excelto.pdf.converter.ui.theme.LocalPalette
import com.excelto.pdf.converter.ui.theme.Type
import com.google.mlkit.vision.documentscanner.GmsDocumentScanning
import com.google.mlkit.vision.documentscanner.GmsDocumentScannerOptions
import com.google.mlkit.vision.documentscanner.GmsDocumentScanningResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun ScanScreen(vm: AppViewModel, route: Route.ToolScreen) {
    val p = LocalPalette.current
    val context = LocalContext.current
    val pages = route.images
    var ocr by rememberSaveable { mutableStateOf(true) }
    var script by rememberSaveable { mutableIntStateOf(0) }
    var name by rememberSaveable { mutableStateOf("Scan_" + SimpleDateFormat("yyyy-MM-dd_HHmm", Locale.US).format(Date())) }
    var selected by remember { mutableIntStateOf(-1) }

    val scanner = rememberLauncherForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val scanned = GmsDocumentScanningResult.fromActivityResultIntent(result.data)?.pages?.map { it.imageUri }.orEmpty()
            if (scanned.isNotEmpty()) vm.setToolImages(pages + scanned)
        }
    }
    fun startScanner() {
        val activity = context as? Activity ?: return
        // Tablets and Chromebooks without a camera can still install the app.
        if (!activity.packageManager.hasSystemFeature(android.content.pm.PackageManager.FEATURE_CAMERA_ANY)) {
            vm.say(tr(R.string.scan_no_camera))
            return
        }
        val options = GmsDocumentScannerOptions.Builder()
            .setGalleryImportAllowed(true)
            .setPageLimit(50)
            .setResultFormats(GmsDocumentScannerOptions.RESULT_FORMAT_JPEG)
            .setScannerMode(GmsDocumentScannerOptions.SCANNER_MODE_FULL)
            .build()
        GmsDocumentScanning.getClient(options).getStartScanIntent(activity)
            .addOnSuccessListener { scanner.launch(IntentSenderRequest.Builder(it).build()) }
            .addOnFailureListener { vm.say(tr(R.string.scan_unavailable)) }
    }
    LaunchedEffect(Unit) { if (pages.isEmpty()) startScanner() }

    ToolScaffold(vm, route, if (pages.isEmpty()) tr(R.string.scan_first) else trPlural(R.plurals.scan_save, pages.size, pages.size),
        enabled = pages.isNotEmpty() && name.isNotBlank(), showFileCard = false, onStart = {
            vm.runScan(pages, if (ocr) OcrScript.entries[script] else null, name.trim())
        }) {
        if (pages.isNotEmpty()) {
            pages.chunked(3).forEachIndexed { r, row ->
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    row.forEachIndexed { c, uri ->
                        val i = r * 3 + c
                        val thumb by produceState<Bitmap?>(null, uri) {
                            value = withContext(Dispatchers.IO) { runCatching { context.contentResolver.loadThumbnail(uri, Size(300, 400), null) }.getOrNull() }
                        }
                        Box(
                            Modifier.weight(1f).aspectRatio(0.72f).clip(RoundedCornerShape(10.dp)).background(Color.White)
                                .border(2.dp, if (selected == i) p.primaryText else Color.Transparent, RoundedCornerShape(10.dp))
                                .clickable(role = Role.Button) { selected = if (selected == i) -1 else i },
                        ) {
                            thumb?.let { Image(it.asImageBitmap(), tr(R.string.a11y_page, i + 1), contentScale = ContentScale.Fit, modifier = Modifier.fillMaxSize()) }
                            Text("${i + 1}", style = Type.tiny, color = Color.White, modifier = Modifier.align(Alignment.TopStart).padding(6.dp)
                                .clip(RoundedCornerShape(8.dp)).background(Color(0xAA000000)).padding(horizontal = 6.dp, vertical = 2.dp))
                        }
                    }
                    repeat(3 - row.size) { Box(Modifier.weight(1f)) }
                }
            }
            if (selected in pages.indices) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    SecondaryButton(tr(R.string.scan_move_earlier), { if (selected > 0) { vm.setToolImages(pages.toMutableList().apply { add(selected - 1, removeAt(selected)) }); selected-- } }, Modifier.weight(1f))
                    SecondaryButton(tr(R.string.common_remove), { vm.setToolImages(pages.filterIndexed { i, _ -> i != selected }); selected = -1 }, Modifier.weight(1f), textColor = p.danger)
                }
            }
        }
        SecondaryButton(if (pages.isEmpty()) tr(R.string.scan_open) else tr(R.string.scan_more), { startScanner() })
        Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(p.surface)) {
            ToggleRow(tr(R.string.ocr_toggle), tr(R.string.ocr_toggle_hint), ocr, { ocr = it }, showDivider = false)
        }
        if (ocr) {
            Label(tr(R.string.ocr_language))
            ChoiceRow(OcrScript.entries.take(3).map { it.label }, script.takeIf { it < 3 } ?: -1) { script = it }
            ChoiceRow(OcrScript.entries.drop(3).map { it.label }, (script - 3).takeIf { it >= 0 } ?: -1) { script = it + 3 }
            Note(tr(R.string.ocr_rtl_note))
        }
        NameField(name, { name = it }, Tool.SCAN.folder)
    }
}
