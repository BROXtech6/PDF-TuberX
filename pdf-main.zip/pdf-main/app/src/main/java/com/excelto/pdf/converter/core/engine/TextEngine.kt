package com.excelto.pdf.converter.core.engine

import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.text.PDFTextStripper
import com.tom_roush.pdfbox.text.TextPosition
import java.io.Writer
import kotlin.math.abs

/** A line of text on a page with its box, 0..1 from the page's top-left corner. */
data class TextLine(val page: Int, val text: String, val rect: NRect, val fontSize: Float)

/**
 * A run of text with its position in points, measured from the top-left of the
 * visible (crop box) page: x to the right, [baseline] downward.
 */
class TextChunk(
    val x0: Float,
    val x1: Float,
    val baseline: Float,
    val top: Float,
    val bottom: Float,
    val text: String,
    val size: Float = bottom - top,
    val bold: Boolean = false,
    val italic: Boolean = false,
) {
    val charWidth: Float get() = ((x1 - x0) / text.length.coerceAtLeast(1)).coerceAtLeast(1f)
}

/** Collects every word PdfBox finds on one page, with its glyph boxes. */
class ChunkStripper : PDFTextStripper() {
    val chunks = mutableListOf<TextChunk>()

    init {
        sortByPosition = true
    }

    override fun writeString(text: String, textPositions: MutableList<TextPosition>) {
        if (text.isBlank() || textPositions.isEmpty()) return
        // Split at space glyphs, so "Apples      12" becomes two words with a real gap between them.
        val word = mutableListOf<TextPosition>()
        for (tp in textPositions) {
            if (tp.unicode.isNullOrBlank()) {
                add(word); word.clear()
            } else {
                word += tp
            }
        }
        add(word)
    }

    private fun add(word: List<TextPosition>) {
        if (word.isEmpty()) return
        val x0 = word.minOf { it.xDirAdj }
        val x1 = word.maxOf { it.xDirAdj + it.widthDirAdj }
        val baseline = word.first().yDirAdj
        val size = word.maxOf { it.fontSizeInPt.takeIf { s -> s > 0f } ?: it.heightDir }
        val ascent = word.maxOf { it.heightDir }.coerceAtLeast(size * 0.7f)
        val font = word.first().font
        val name = runCatching { font?.name }.getOrNull().orEmpty()
        val descriptor = runCatching { font?.fontDescriptor }.getOrNull()
        val bold = BOLD.containsMatchIn(name) || (descriptor?.fontWeight ?: 0f) >= 600f || descriptor?.isForceBold == true
        val italic = ITALIC.containsMatchIn(name) || (descriptor?.italicAngle ?: 0f) != 0f
        chunks += TextChunk(x0, x1, baseline, baseline - ascent, baseline + size * 0.22f, word.joinToString("") { it.unicode }, size, bold, italic)
    }

    /** Runs the stripper on one page (1-based) and returns its chunks. */
    fun page(doc: PDDocument, page: Int): List<TextChunk> {
        chunks.clear()
        startPage = page
        endPage = page
        writeText(doc, NullWriter)
        return chunks.toList()
    }

    private companion object {
        val BOLD = Regex("(?i)bold|black|heavy|semibold|demi")
        val ITALIC = Regex("(?i)italic|oblique")
    }

    private object NullWriter : Writer() {
        override fun write(cbuf: CharArray, off: Int, len: Int) = Unit
        override fun flush() = Unit
        override fun close() = Unit
    }
}

/** Reading text out of PDFs: plain text per page, and line boxes for the editor. */
object TextEngine {

    /** Plain text of each page. Pages without text (scans) come back empty. */
    fun pages(input: PdfTools.Input, maxPages: Int = Int.MAX_VALUE, progress: Progress = Progress.NONE): List<String> {
        PdfTools.open(input.path, input.password).use { doc ->
            val total = minOf(doc.numberOfPages, maxPages)
            // Sorted by position like iText's default extractor; without it PdfBox splits the
            // first letter off lines on rotated pages ("R\notated").
            val stripper = PDFTextStripper().apply { sortByPosition = true }
            return (1..total).map { page ->
                progress.step(page, total, 5, 60)
                stripper.startPage = page
                stripper.endPage = page
                runCatching { stripper.getText(doc) }.getOrDefault("").trim()
            }
        }
    }

    /**
     * Line boxes on one upright page, used by "Edit text" to cover and replace a line.
     * Returns an empty list for rotated pages, where positions can't be matched reliably.
     */
    fun lines(input: PdfTools.Input, pageIndex: Int): List<TextLine> {
        PdfTools.open(input.path, input.password).use { doc ->
            val page = pageIndex + 1
            if (page > doc.numberOfPages) return emptyList()
            val pdPage = doc.getPage(pageIndex)
            if (pdPage.rotation % 360 != 0) return emptyList()
            val box = pdPage.cropBox
            val chunks = ChunkStripper().page(doc, page)
            return group(chunks, pageIndex, box.width, box.height)
        }
    }

    /** Groups chunks into lines, then splits lines at wide gaps (table columns). Pure logic. */
    fun group(chunks: List<TextChunk>, pageIndex: Int, width: Float, height: Float): List<TextLine> {
        val lines = mutableListOf<MutableList<TextChunk>>()
        for (c in chunks.sortedBy { it.baseline }) {
            val line = lines.lastOrNull()
            if (line != null && abs(line.first().baseline - c.baseline) <= 2.5f) line += c else lines += mutableListOf(c)
        }
        return lines.flatMap { line ->
            val groups = mutableListOf<MutableList<TextChunk>>()
            for (c in line.sortedBy { it.x0 }) {
                val g = groups.lastOrNull()
                if (g != null && c.x0 - g.last().x1 < c.charWidth * 3f) g += c else groups += mutableListOf(c)
            }
            groups.map { g ->
                val text = buildString {
                    g.forEachIndexed { i, c ->
                        if (i > 0 && c.x0 - g[i - 1].x1 > c.charWidth * 0.25f && !endsWith(" ") && !c.text.startsWith(" ")) append(' ')
                        append(c.text)
                    }
                }.trim()
                val left = g.minOf { it.x0 }
                val right = g.maxOf { it.x1 }
                val top = g.minOf { it.top }
                val bottom = g.maxOf { it.bottom }
                TextLine(
                    page = pageIndex,
                    text = text,
                    rect = NRect(left / width, top / height, right / width, bottom / height),
                    fontSize = ((bottom - top) * 0.8f).coerceAtLeast(4f) / height,
                )
            }
        }.filter { it.text.isNotEmpty() }
    }
}
