package com.excelto.pdf.converter.core.engine

/**
 * Joins Arabic, Urdu and Persian letters into their connected forms (Unicode
 * presentation forms), because PdfBox draws characters one by one without OpenType
 * shaping. Works in logical order, before right-to-left reordering.
 *
 * Android's ICU ArabicShaping class isn't part of the public SDK, so this is our own,
 * following the Unicode joining rules: each letter is isolated, initial, medial or
 * final depending on whether its neighbours join to it. Lam + Alef become a ligature.
 * Pure Kotlin, so it is unit tested on the JVM.
 */
object ArabicShaper {

    /** Forms: isolated, final, initial, medial. Right-joining letters have only the first two. */
    private class Forms(val iso: Char, val fin: Char, val ini: Char? = null, val med: Char? = null) {
        val dual get() = ini != null
    }

    private val forms = HashMap<Char, Forms>()

    private fun dual(c: Int, first: Int) {
        forms[c.toChar()] = Forms(first.toChar(), (first + 1).toChar(), (first + 2).toChar(), (first + 3).toChar())
    }

    private fun right(c: Int, first: Int) {
        forms[c.toChar()] = Forms(first.toChar(), (first + 1).toChar())
    }

    init {
        // Arabic (Presentation Forms-B).
        forms['ء'] = Forms('ﺀ', 'ﺀ')
        right(0x0622, 0xFE81); right(0x0623, 0xFE83); right(0x0624, 0xFE85); right(0x0625, 0xFE87)
        dual(0x0626, 0xFE89); right(0x0627, 0xFE8D); dual(0x0628, 0xFE8F); right(0x0629, 0xFE93)
        dual(0x062A, 0xFE95); dual(0x062B, 0xFE99); dual(0x062C, 0xFE9D); dual(0x062D, 0xFEA1)
        dual(0x062E, 0xFEA5); right(0x062F, 0xFEA9); right(0x0630, 0xFEAB); right(0x0631, 0xFEAD)
        right(0x0632, 0xFEAF); dual(0x0633, 0xFEB1); dual(0x0634, 0xFEB5); dual(0x0635, 0xFEB9)
        dual(0x0636, 0xFEBD); dual(0x0637, 0xFEC1); dual(0x0638, 0xFEC5); dual(0x0639, 0xFEC9)
        dual(0x063A, 0xFECD); dual(0x0641, 0xFED1); dual(0x0642, 0xFED5); dual(0x0643, 0xFED9)
        dual(0x0644, 0xFEDD); dual(0x0645, 0xFEE1); dual(0x0646, 0xFEE5); dual(0x0647, 0xFEE9)
        right(0x0648, 0xFEED); right(0x0649, 0xFEEF); dual(0x064A, 0xFEF1)
        // Urdu, Persian and other letters (Presentation Forms-A).
        right(0x0671, 0xFB50); dual(0x067B, 0xFB52); dual(0x067E, 0xFB56); dual(0x0680, 0xFB5A)
        dual(0x067A, 0xFB5E); dual(0x067F, 0xFB62); dual(0x0679, 0xFB66); dual(0x06A4, 0xFB6A)
        dual(0x06A6, 0xFB6E); dual(0x0684, 0xFB72); dual(0x0683, 0xFB76); dual(0x0686, 0xFB7A)
        dual(0x0687, 0xFB7E); right(0x068D, 0xFB82); right(0x068C, 0xFB84); right(0x068E, 0xFB86)
        right(0x0688, 0xFB88); right(0x0698, 0xFB8A); right(0x0691, 0xFB8C); dual(0x06A9, 0xFB8E)
        dual(0x06AF, 0xFB92); dual(0x06B3, 0xFB96); dual(0x06B1, 0xFB9A); right(0x06BA, 0xFB9E)
        dual(0x06BB, 0xFBA0); right(0x06C0, 0xFBA4); dual(0x06C1, 0xFBA6); dual(0x06BE, 0xFBAA)
        right(0x06D2, 0xFBAE); right(0x06D3, 0xFBB0); dual(0x06AD, 0xFBD3); right(0x06C7, 0xFBD7)
        right(0x06C6, 0xFBD9); right(0x06C8, 0xFBDB); right(0x06CB, 0xFBDE); right(0x06C5, 0xFBE0)
        right(0x06C9, 0xFBE2); dual(0x06D0, 0xFBE4); dual(0x06CC, 0xFBFC)
    }

    private const val TATWEEL = 'ـ'
    private const val LAM = 'ل'

    /** Lam + this alef → ligature (isolated, final). */
    private val lamAlef = mapOf(
        'آ' to ('ﻵ' to 'ﻶ'),
        'أ' to ('ﻷ' to 'ﻸ'),
        'إ' to ('ﻹ' to 'ﻺ'),
        'ا' to ('ﻻ' to 'ﻼ'),
    )

    /** Harakat and other marks: they sit on a letter and don't break joining. */
    private fun isTransparent(c: Char) =
        c in 'ؐ'..'ؚ' || c in 'ً'..'ٟ' || c == 'ٰ' || c in 'ۖ'..'ۜ' || c in '۟'..'ۤ' ||
            c in 'ۧ'..'ۨ' || c in '۪'..'ۭ' || c == '‍'

    /** Can this letter connect to the letter after it (to its left)? */
    private fun joinsForward(c: Char) = c == TATWEEL || forms[c]?.dual == true

    /** Can this letter connect to the letter before it (to its right)? */
    private fun joinsBackward(c: Char) = c == TATWEEL || forms.containsKey(c) && c != 'ء'

    fun needsShaping(text: String) = text.any { it in forms || it == TATWEEL }

    fun shape(text: String): String {
        if (!needsShaping(text)) return text
        val chars = text.toCharArray()
        val out = StringBuilder(chars.size)
        fun prevLetter(i: Int): Char? {
            var k = i - 1
            while (k >= 0 && isTransparent(chars[k])) k--
            return if (k >= 0) chars[k] else null
        }
        fun nextIndex(i: Int): Int {
            var k = i + 1
            while (k < chars.size && isTransparent(chars[k])) k++
            return k
        }
        var i = 0
        val skip = BooleanArray(chars.size)
        while (i < chars.size) {
            if (skip[i]) { i++; continue }
            val c = chars[i]
            val f = forms[c]
            if (f == null) { out.append(c); i++; continue }
            val prev = prevLetter(i)
            val joinPrev = prev != null && joinsForward(prev) && joinsBackward(c)
            val n = nextIndex(i)
            val next = chars.getOrNull(n)
            if (c == LAM && next != null && next in lamAlef) {
                val (iso, fin) = lamAlef.getValue(next)
                out.append(if (joinPrev) fin else iso)
                // Marks between lam and alef stay; the alef itself is part of the ligature.
                for (k in i + 1 until n) out.append(chars[k])
                skip[n] = true
                i = n + 1
                continue
            }
            val joinNext = next != null && joinsForward(c) && joinsBackward(next)
            out.append(
                when {
                    joinPrev && joinNext -> f.med ?: f.fin
                    joinPrev -> f.fin
                    joinNext -> f.ini ?: f.iso
                    else -> f.iso
                },
            )
            i++
        }
        return out.toString()
    }
}
