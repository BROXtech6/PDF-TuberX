package com.excelto.pdf.converter.core.engine

import com.excelto.pdf.converter.language.trPlural
import com.excelto.pdf.converter.language.tr
import com.excelto.pdf.converter.R
import android.graphics.Bitmap
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.tom_roush.pdfbox.io.MemoryUsageSetting
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.pdmodel.PDPage
import com.tom_roush.pdfbox.pdmodel.PDPageContentStream
import com.tom_roush.pdfbox.pdmodel.common.PDRectangle
import com.tom_roush.pdfbox.pdmodel.graphics.image.JPEGFactory
import com.tom_roush.pdfbox.text.PDFTextStripper
import java.io.File

// ---- OCR PDF --------------------------------------------------------------------------

object OcrEngine {

    data class Result(val recognized: Int, val alreadyText: Int, val total: Int)

    private const val OCR_DPI = 300f

    /**
     * Makes a scanned PDF searchable. Pages without text are rendered at 300 dpi, read
     * with ML Kit on the phone, and given an invisible text layer over the words. Pages
     * that already have text are left alone.
     */
    fun apply(input: PdfTools.Input, script: OcrScript, out: File, workDir: File, progress: Progress): Result {
        val recognizer = ScanEngine.recognizerFor(script)
        try {
            return PdfTools.writing(out) {
                PdfTools.open(input.path, input.password).use { doc ->
                    PdfTools.requireOwnerRights(doc)
                    val stripper = PDFTextStripper()
                    val total = doc.numberOfPages
                    val needs = (0 until total).filter { i ->
                        stripper.startPage = i + 1; stripper.endPage = i + 1
                        runCatching { stripper.getText(doc) }.getOrDefault("").isBlank()
                    }
                    if (needs.isEmpty()) throw UserFacingException(R.string.err_every_page_already_text, "Every page already has text you can search and copy, so there's nothing to recognize.")
                    progress.report(5)
                    val fonts = PdfFonts.FontSet(doc)
                    var found = 0
                    PdfRaster.open(input, workDir).use { raster ->
                        needs.forEachIndexed { k, i ->
                            progress.check()
                            val bitmap = raster.render(i, OCR_DPI, maxPixels = 16_000_000L)
                            try {
                                val text = runCatching { Tasks.await(recognizer.process(InputImage.fromBitmap(bitmap, 0))) }.getOrNull()
                                val page = doc.getPage(i)
                                val frame = PageFrame(page)
                                val scale = bitmap.width / frame.width
                                val lines = text?.textBlocks?.flatMap { it.lines }.orEmpty()
                                if (lines.isNotEmpty()) {
                                    found++
                                    PDPageContentStream(doc, page, PDPageContentStream.AppendMode.APPEND, true, true).use { cs ->
                                        cs.transform(frame.matrix)
                                        for (line in lines) {
                                            val box = line.boundingBox ?: continue
                                            ScanEngine.invisibleLine(
                                                cs, fonts, line.text.trim(),
                                                box.left / scale, frame.height - box.bottom / scale,
                                                box.width() / scale, box.height() / scale,
                                            )
                                        }
                                    }
                                }
                            } finally {
                                bitmap.recycle()
                            }
                            progress.step(k + 1, needs.size, 5, 92)
                        }
                    }
                    if (found == 0) throw UserFacingException(R.string.err_no_text_was_found, "No text was found on the scanned pages. Check the language, or try a clearer scan.")
                    doc.save(out)
                    progress.report(100)
                    Result(found, total - needs.size, total)
                }
            }
        } finally {
            recognizer.close()
        }
    }
}

// ---- Repair PDF -----------------------------------------------------------------------

object RepairEngine {

    data class Result(val pages: Int, val lost: Int, val rebuiltFromImages: Boolean) {
        val message: String
            get() = when {
                rebuiltFromImages && lost == 0 -> tr(R.string.repair_images)
                rebuiltFromImages -> trPlural(R.plurals.repair_lost_images, lost, lost)
                lost == 0 -> tr(R.string.repair_ok)
                else -> trPlural(R.plurals.repair_lost, lost, lost)
            }
    }

    /**
     * Opens the file with PdfBox, which rebuilds a broken cross-reference table by
     * scanning the file, copies every page it can still read into a clean document, and
     * saves it. If PdfBox can't open it at all, each page Android's renderer can draw is
     * rebuilt as an image instead.
     */
    fun repair(input: PdfTools.Input, out: File, progress: Progress): Result {
        progress.report(5)
        val source = try {
            PDDocument.load(File(input.path), input.password ?: "", MemoryUsageSetting.setupMixed(16L * 1024 * 1024))
        } catch (e: com.tom_roush.pdfbox.pdmodel.encryption.InvalidPasswordException) {
            throw PasswordRequiredException()
        } catch (e: Exception) {
            null
        }
        if (source != null) {
            val viaPdfBox = source.use { src ->
                PdfTools.requireOwnerRights(src)
                runCatching { copyReadablePages(src, out, progress) }.getOrNull()
            }
            if (viaPdfBox != null) return viaPdfBox
            out.delete()
        }
        return runCatching { rebuildFromImages(File(input.path), out, progress) }.getOrElse {
            out.delete()
            throw UserFacingException(R.string.err_file_too_damaged_repair, "This file is too damaged to repair.", it)
        }
    }

    private fun copyReadablePages(src: PDDocument, out: File, progress: Progress): Result? {
        val total = runCatching { src.numberOfPages }.getOrDefault(0)
        if (total == 0) return null
        var lost = 0
        PDDocument(MemoryUsageSetting.setupTempFileOnly()).use { dest ->
            for (i in 0 until total) {
                progress.check()
                val ok = runCatching {
                    val page = src.getPage(i)
                    page.contents?.use { it.readBytes() } // throws if the content stream is broken
                    page.resources
                    dest.importPage(page)
                }.isSuccess
                if (!ok) lost++
                progress.step(i + 1, total, 10, 85)
            }
            if (dest.numberOfPages == 0) return null
            dest.save(out)
            return Result(dest.numberOfPages, lost, rebuiltFromImages = false)
        }
    }

    private fun rebuildFromImages(file: File, out: File, progress: Progress): Result {
        ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY).use { fd ->
            PdfRenderer(fd).use { renderer ->
                val total = renderer.pageCount
                var lost = 0
                PDDocument(MemoryUsageSetting.setupTempFileOnly()).use { dest ->
                    for (i in 0 until total) {
                        progress.check()
                        val ok = runCatching {
                            renderer.openPage(i).use { page ->
                                val scale = 150f / 72f
                                val bmp = Bitmap.createBitmap((page.width * scale).toInt().coerceAtLeast(1), (page.height * scale).toInt().coerceAtLeast(1), Bitmap.Config.ARGB_8888)
                                try {
                                    bmp.eraseColor(android.graphics.Color.WHITE)
                                    page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_PRINT)
                                    val pdPage = PDPage(PDRectangle(page.width.toFloat(), page.height.toFloat()))
                                    dest.addPage(pdPage)
                                    val image = JPEGFactory.createFromImage(dest, bmp, 0.85f)
                                    PDPageContentStream(dest, pdPage).use { it.drawImage(image, 0f, 0f, page.width.toFloat(), page.height.toFloat()) }
                                } finally {
                                    bmp.recycle()
                                }
                            }
                        }.isSuccess
                        if (!ok) lost++
                        progress.step(i + 1, total, 10, 90)
                    }
                    if (dest.numberOfPages == 0) throw UserFacingException(R.string.err_file_too_damaged_repair, "This file is too damaged to repair.")
                    dest.save(out)
                    progress.report(100)
                    return Result(dest.numberOfPages, lost, rebuiltFromImages = true)
                }
            }
        }
    }
}

// ---- PDF to JPG -----------------------------------------------------------------------

enum class ImageFormat(val label: String, val extension: String) { JPG("JPG", "jpg"), PNG("PNG", "png") }

object PdfToImageEngine {

    /**
     * Saves [pages] (0-based) as images in [outDir], one at a time so memory stays low.
     * Very large pages are scaled down to stay under ~24 megapixels.
     */
    fun convert(input: PdfTools.Input, pages: List<Int>, dpi: Float, format: ImageFormat, outDir: File, baseName: String, workDir: File, progress: Progress): List<File> {
        val made = mutableListOf<File>()
        try {
            PdfRaster.open(input, workDir).use { raster ->
                val list = pages.ifEmpty { (0 until raster.pageCount).toList() }
                val digits = maxOf(2, raster.pageCount.toString().length)
                list.forEachIndexed { k, i ->
                    progress.check()
                    if (i !in 0 until raster.pageCount) return@forEachIndexed
                    val bitmap = raster.render(i, dpi)
                    try {
                        val file = File(outDir, "${baseName}_page_${(i + 1).toString().padStart(digits, '0')}.${format.extension}")
                        file.outputStream().use { stream ->
                            bitmap.compress(if (format == ImageFormat.PNG) Bitmap.CompressFormat.PNG else Bitmap.CompressFormat.JPEG, 92, stream)
                        }
                        made += file
                    } finally {
                        bitmap.recycle()
                    }
                    progress.step(k + 1, list.size, 5, 98)
                }
            }
        } catch (e: Throwable) {
            made.forEach { it.delete() }
            if (outDir.list().isNullOrEmpty()) outDir.delete()
            throw e
        }
        progress.report(100)
        return made
    }
}
