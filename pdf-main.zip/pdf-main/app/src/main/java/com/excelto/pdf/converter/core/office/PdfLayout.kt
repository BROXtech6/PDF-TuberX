package com.excelto.pdf.converter.core.office

import com.excelto.pdf.converter.core.engine.PdfFonts
import com.excelto.pdf.converter.core.engine.PdfToExcelEngine
import com.excelto.pdf.converter.core.engine.TextChunk
import kotlin.math.abs

/**
 * Turns one page's text chunks into Word blocks: headings, paragraphs and tables.
 * Lines are grouped by baseline, joined into paragraphs when they share a size, left
 * edge and normal line spacing, and lines with several aligned cells become tables.
 * Pure logic, unit tested.
 */
object PdfLayout {

    /** A block and its top edge on the page, so pictures can be placed in reading order. */
    class Placed(val top: Float, val block: WordDoc.Block)

    private class Cell(var x0: Float, var x1: Float, val chunks: MutableList<TextChunk>)

    private class Line(val cells: List<Cell>) {
        val chunks get() = cells.flatMap { it.chunks }
        val x0 get() = cells.first().x0
        val x1 get() = cells.last().x1
        val top get() = chunks.minOf { it.top }
        val baseline get() = chunks.first().baseline
        val size get() = chunks.map { it.size }.sorted()[chunks.size / 2]
        val text get() = cells.joinToString("   ") { cellText(it) }
    }

    private val LIST_MARKER = Regex("""^\s*([•\-–·▪◦*]|\(?\d{1,3}[.)]|[a-zA-Z][.)])\s""")

    fun rebuild(chunks: List<TextChunk>, pageWidth: Float): List<Placed> {
        if (chunks.isEmpty()) return emptyList()
        val lines = lines(chunks)
        val body = median(lines.map { it.size })
        // The right edge of full-width text: a line that ends well before it ends its paragraph.
        val textLeft = lines.minOf { it.x0 }
        val textRight = lines.maxOf { it.x1 }
        val out = mutableListOf<Placed>()
        var i = 0
        while (i < lines.size) {
            // Tables: two or more consecutive lines, each with two or more cells.
            if (lines[i].cells.size >= 2) {
                var j = i
                while (j < lines.size && lines[j].cells.size >= 2) j++
                if (j - i >= 2) {
                    val rows = PdfToExcelEngine.table(lines.subList(i, j).flatMap { it.chunks })
                    if (rows.isNotEmpty()) {
                        out += Placed(lines[i].top, WordDoc.Table(rows))
                        i = j
                        continue
                    }
                }
            }
            // Paragraphs: join following lines that continue this one.
            val group = mutableListOf(lines[i])
            while (i + group.size < lines.size) {
                val prev = group.last()
                val next = lines[i + group.size]
                val gap = next.baseline - prev.baseline
                val sameSize = abs(next.size - prev.size) <= 0.6f
                val sameLeft = abs(next.x0 - group.first().x0) <= maxOf(4f, prev.size * 0.6f) || abs(next.x0 - prev.x0) <= 4f
                val prevFull = prev.x1 >= textLeft + (textRight - textLeft) * 0.8f || prev.text.endsWith("-")
                if (!prevFull || next.cells.size >= 2 || !sameSize || !sameLeft || gap <= 0f || gap > prev.size * 1.5f || LIST_MARKER.containsMatchIn(next.text)) break
                group += next
            }
            out += Placed(group.first().top, paragraph(group, body, pageWidth))
            i += group.size
        }
        return out
    }

    private fun lines(chunks: List<TextChunk>): List<Line> {
        val groups = mutableListOf<MutableList<TextChunk>>()
        for (c in chunks.sortedBy { it.baseline }) {
            val g = groups.lastOrNull()
            val tolerance = maxOf(2.5f, c.size * 0.35f)
            if (g != null && abs(g.first().baseline - c.baseline) <= tolerance) g += c else groups += mutableListOf(c)
        }
        return groups.map { g ->
            val cells = mutableListOf<Cell>()
            for (c in g.sortedBy { it.x0 }) {
                val last = cells.lastOrNull()
                if (last != null && c.x0 - last.x1 <= c.charWidth * 2.2f) {
                    last.chunks += c; last.x1 = maxOf(last.x1, c.x1)
                } else {
                    cells += Cell(c.x0, c.x1, mutableListOf(c))
                }
            }
            Line(cells)
        }
    }

    private fun cellText(cell: Cell) = buildString {
        cell.chunks.forEachIndexed { i, c ->
            if (i > 0 && c.x0 - cell.chunks[i - 1].x1 > c.charWidth * 0.25f && !endsWith(" ") && !c.text.startsWith(" ")) append(' ')
            append(c.text)
        }
    }.trim()

    private fun paragraph(group: List<Line>, body: Float, pageWidth: Float): WordDoc.Paragraph {
        val size = group.first().size
        val text = group.map { it.text }
        val joinedLength = text.sumOf { it.length }
        val bold = group.all { l -> l.chunks.all { it.bold } }
        val ratio = if (body > 0f) size / body else 1f
        val style = when {
            joinedLength > 120 -> WordDoc.Style.NORMAL
            ratio >= 1.6f -> WordDoc.Style.TITLE
            ratio >= 1.3f -> WordDoc.Style.HEADING1
            ratio >= 1.12f && bold -> WordDoc.Style.HEADING2
            else -> WordDoc.Style.NORMAL
        }
        val rtl = PdfFonts.isRtl(text.joinToString(""))
        val first = group.first()
        val left = first.x0
        val right = pageWidth - first.x1
        val centered = group.size <= 3 && left > pageWidth * 0.15f && abs(left - right) <= pageWidth * 0.06f
        val align = when {
            centered -> WordDoc.Align.CENTER
            rtl -> WordDoc.Align.RIGHT
            else -> WordDoc.Align.LEFT
        }

        // Runs: one per change in bold/italic, with lines joined by spaces and
        // hyphenated line breaks re-joined.
        val runs = mutableListOf<WordDoc.Run>()
        val heading = style != WordDoc.Style.NORMAL
        val runSize = if (heading || abs(size - body) < 0.8f) null else size.coerceIn(4f, 96f)
        fun add(text: String, b: Boolean, it: Boolean) {
            val last = runs.lastOrNull()
            if (last != null && last.bold == b && last.italic == it) runs[runs.lastIndex] = last.copy(text = last.text + text)
            else runs += WordDoc.Run(text, b && !heading, it, runSize)
        }
        group.forEachIndexed { li, line ->
            if (li > 0) {
                val prev = runs.lastOrNull()
                if (prev != null && prev.text.endsWith("-") && prev.text.length > 1 && prev.text[prev.text.length - 2].isLetter()) {
                    runs[runs.lastIndex] = prev.copy(text = prev.text.dropLast(1))
                } else {
                    add(" ", prev?.bold ?: false, prev?.italic ?: false)
                }
            }
            line.cells.forEachIndexed { ci, cell ->
                if (ci > 0) add("\t", false, false)
                cell.chunks.forEachIndexed { k, c ->
                    if (k > 0 && c.x0 - cell.chunks[k - 1].x1 > c.charWidth * 0.25f && !c.text.startsWith(" ")) add(" ", c.bold, c.italic)
                    add(c.text, c.bold, c.italic)
                }
            }
        }
        // Collapse a heading's runs: its style already sets size and weight.
        val finalRuns = if (heading) listOf(WordDoc.Run(runs.joinToString("") { it.text }.trim())) else runs
        return WordDoc.Paragraph(finalRuns, style, align, rtl)
    }

    private fun median(values: List<Float>): Float {
        if (values.isEmpty()) return 0f
        val s = values.sorted()
        return s[s.size / 2]
    }
}
