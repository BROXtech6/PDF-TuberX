package com.excelto.pdf.converter.core.storage

import android.content.Context

enum class ThemeMode { SYSTEM, LIGHT, DARK }

/** Small settings store for the new UI. Premium status stays in the existing "settings" prefs. */
class AppPrefs(context: Context) {

    private val prefs = context.applicationContext.getSharedPreferences("pdf_converter_ui", Context.MODE_PRIVATE)

    var themeMode: ThemeMode
        get() = runCatching { ThemeMode.valueOf(prefs.getString("theme", ThemeMode.SYSTEM.name)!!) }.getOrDefault(ThemeMode.SYSTEM)
        set(value) = prefs.edit().putString("theme", value.name).apply()

    var notifyWhenReady: Boolean
        get() = prefs.getBoolean("notify_ready", true)
        set(value) = prefs.edit().putBoolean("notify_ready", value).apply()

    var appLock: Boolean
        get() = prefs.getBoolean("app_lock", false)
        set(value) = prefs.edit().putBoolean("app_lock", value).apply()

    val favorites: Set<String> get() = prefs.getStringSet("favorites", emptySet())!!.toSet()

    fun toggleFavorite(path: String): Boolean {
        val set = favorites.toMutableSet()
        val nowFavorite = set.add(path) || run { set.remove(path); false }
        prefs.edit().putStringSet("favorites", set).apply()
        return nowFavorite
    }

    val imported: List<String> get() = prefs.getString("imported", "")!!.split('\n').filter { it.isNotBlank() }

    fun addImported(path: String) {
        val list = (listOf(path) + imported).distinct().take(40)
        prefs.edit().putString("imported", list.joinToString("\n")).apply()
    }

    /** Totals for the Home dashboard. */
    var filesDone: Int
        get() = prefs.getInt("stat_files", 0)
        set(value) = prefs.edit().putInt("stat_files", value).apply()

    var bytesSaved: Long
        get() = prefs.getLong("stat_saved", 0L)
        set(value) = prefs.edit().putLong("stat_saved", value).apply()

    /** Jobs finished per day for the last 7 days, oldest first. */
    fun weekActivity(): List<Int> {
        val today = System.currentTimeMillis() / 86_400_000L
        return (6 downTo 0).map { prefs.getInt("day_${today - it}", 0) }
    }

    fun recordJob(savedBytes: Long) {
        val today = System.currentTimeMillis() / 86_400_000L
        prefs.edit()
            .putInt("day_$today", prefs.getInt("day_$today", 0) + 1)
            .putInt("stat_files", filesDone + 1)
            .putLong("stat_saved", bytesSaved + savedBytes.coerceAtLeast(0))
            .remove("day_${today - 8}")
            .apply()
    }
}
