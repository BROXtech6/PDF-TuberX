package com.excelto.pdf.converter.core.engine

import androidx.annotation.StringRes
import com.excelto.pdf.converter.language.tr
import kotlinx.coroutines.Job
import java.util.concurrent.CancellationException

/**
 * Passed to every engine. Engines call [report] with 0..100 and [check] between pages
 * so a long job stops quickly when the user taps Cancel.
 */
class Progress(private val job: Job?, private val onProgress: (Int) -> Unit) {
    private var last = -1

    fun report(percent: Int) {
        check()
        val p = percent.coerceIn(0, 100)
        if (p != last) {
            last = p
            onProgress(p)
        }
    }

    /** Reports step [index] of [total], scaled into the [from]..[to] range. */
    fun step(index: Int, total: Int, from: Int = 5, to: Int = 95) {
        if (total <= 0) return
        report(from + ((to - from) * index) / total)
    }

    fun check() {
        if (job != null && !job.isActive) throw CancellationException("Canceled")
    }

    companion object {
        val NONE = Progress(null) {}
    }
}

/**
 * A problem the user can understand and act on. [message] stays in English (logs, tests);
 * [getLocalizedMessage] is the same text in the app's language, for the screen.
 */
open class UserFacingException(message: String, cause: Throwable? = null) : Exception(message, cause) {
    @StringRes private var textRes = 0
    private var textArgs: Array<out Any?> = emptyArray()

    constructor(@StringRes textRes: Int, english: String, cause: Throwable? = null, vararg args: Any?) : this(english, cause) {
        this.textRes = textRes
        this.textArgs = args
    }

    override fun getLocalizedMessage(): String? =
        if (textRes == 0) message else runCatching { tr(textRes, *textArgs) }.getOrNull() ?: message
}

/** The PDF has no text layer; [path] is the file to send to the OCR tool. */
class NeedsOcrException(@StringRes textRes: Int, english: String, val path: String) : UserFacingException(textRes, english)

/** Thrown when a PDF needs a password to open. */
class PasswordRequiredException : Exception("This file is password protected.")
