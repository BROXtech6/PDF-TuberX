package com.excelto.pdf.converter

import com.excelto.pdf.converter.R
import com.excelto.pdf.converter.language.tr
import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.webkit.MimeTypeMap
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import com.excelto.pdf.converter.core.model.DocFile
import com.excelto.pdf.converter.core.model.Source
import com.excelto.pdf.converter.ui.Tool
import com.excelto.pdf.converter.language.LanguageActivity
import com.excelto.pdf.converter.pdfviewer.PdfViewActivity
import com.excelto.pdf.converter.subscription.SubscriptionActivity
import com.excelto.pdf.converter.ui.AppRoot
import com.excelto.pdf.converter.ui.AppViewModel
import com.excelto.pdf.converter.ui.Host
import com.google.android.play.core.appupdate.AppUpdateManagerFactory
import com.google.android.play.core.appupdate.AppUpdateOptions
import com.google.android.play.core.install.model.AppUpdateType
import com.google.android.play.core.install.model.UpdateAvailability
import java.io.File

/**
 * The single screen that hosts the new Kotlin UI. Splash, language, onboarding and the
 * subscription screen are unchanged and still open this activity by name.
 */
class MainActivity : AppCompatActivity(), Host {

    private val vm: AppViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            private var lastPress = 0L
            private var hint: Toast? = null

            override fun handleOnBackPressed() {
                if (vm.back()) return
                // On Home: press back twice within 2 seconds to leave the app.
                val now = System.currentTimeMillis()
                if (now - lastPress < EXIT_WINDOW_MS) {
                    hint?.cancel()
                    finish()
                } else {
                    lastPress = now
                    hint?.cancel()
                    hint = Toast.makeText(this@MainActivity, R.string.press_back_again_to_exit, Toast.LENGTH_SHORT).also { it.show() }
                }
            }
        })

        setContent { AppRoot(vm, this) }
        // Consent (EU/UK) first, then ads load in the background. Pro users get no ads.
        com.excelto.pdf.converter.ads.Ads.start(this)
        checkForUpdate()
        if (savedInstanceState == null) handleToolIntent(intent)
    }

    override fun onResume() {
        super.onResume()
        vm.refreshStatus()
        vm.refreshFiles()
        resumeUpdate()
    }

    // ---- Host ----------------------------------------------------------------------

    override fun openPaywall() {
        startActivity(Intent(this, SubscriptionActivity::class.java))
    }

    override fun manageSubscription() {
        open(Uri.parse("https://play.google.com/store/account/subscriptions?package=$packageName"))
    }

    override fun openLanguage() {
        startActivity(Intent(this, LanguageActivity::class.java))
    }

    override fun openFile(file: File) {
        if (file.extension.equals("pdf", true)) {
            startActivity(Intent(this, PdfViewActivity::class.java).putExtra("pdf_path", file.absolutePath))
            return
        }
        if (file.extension.lowercase() in setOf("xlsx", "xlsm", "xls", "csv")) {
            startActivity(Intent(this, com.excelto.pdf.converter.excelviewer.ExcelViewActivity::class.java)
                .putExtra(com.excelto.pdf.converter.excelviewer.ExcelViewActivity.EXTRA_PATH, file.absolutePath))
            return
        }
        val uri = FileProvider.getUriForFile(this, "$packageName.provider", file)
        val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(file.extension.lowercase()) ?: "*/*"
        val intent = Intent(Intent.ACTION_VIEW).setDataAndType(uri, mime).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        try {
            startActivity(Intent.createChooser(intent, "Open with"))
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(this, tr(R.string.main_no_app), Toast.LENGTH_SHORT).show()
        }
    }


    override fun share(files: List<File>) {
        if (files.isEmpty()) return
        val uris = ArrayList(files.map { FileProvider.getUriForFile(this, "$packageName.provider", it) })
        val mime = when {
            files.all { it.extension.equals("pdf", true) } -> "application/pdf"
            files.all { it.extension.lowercase() in setOf("jpg", "jpeg", "png") } -> "image/*"
            else -> "*/*"
        }
        val intent = if (uris.size == 1) {
            Intent(Intent.ACTION_SEND).setType(mime).putExtra(Intent.EXTRA_STREAM, uris[0])
        } else {
            Intent(Intent.ACTION_SEND_MULTIPLE).setType(mime).putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris)
        }
        startActivity(Intent.createChooser(intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION), tr(R.string.common_share)))
    }

    override fun canUseAppLock(): Boolean =
        BiometricManager.from(this).canAuthenticate(LOCK_AUTHENTICATORS) == BiometricManager.BIOMETRIC_SUCCESS

    override fun unlockApp() {
        if (!canUseAppLock()) { vm.locked = false; return }
        val prompt = BiometricPrompt(this, ContextCompat.getMainExecutor(this), object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                vm.locked = false
                lastBackground = 0L
            }
        })
        prompt.authenticate(
            BiometricPrompt.PromptInfo.Builder()
                .setTitle(tr(R.string.main_unlock_title))
                .setAllowedAuthenticators(LOCK_AUTHENTICATORS)
                .build(),
        )
    }

    override fun onStart() {
        super.onStart()
        val away = lastBackground == 0L || System.currentTimeMillis() - lastBackground > LOCK_AFTER_MS
        if (vm.appLock && away && !vm.locked) {
            vm.locked = true
            unlockApp()
        }
    }

    override fun onStop() {
        super.onStop()
        if (!isChangingConfigurations) lastBackground = System.currentTimeMillis()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleToolIntent(intent)
    }

    /** Opens a tool when another screen (like the viewer) asks for one. */
    private fun handleToolIntent(intent: Intent?) {
        val toolName = intent?.getStringExtra(EXTRA_TOOL) ?: return
        val file = intent.getStringExtra(EXTRA_PATH)?.let { File(it) }?.takeIf { it.exists() }
        val url = intent.getStringExtra(EXTRA_URL)
        val sheet = intent.getIntExtra(EXTRA_SHEET, -1).takeIf { it >= 0 }
        intent.removeExtra(EXTRA_TOOL)
        val tool = runCatching { Tool.valueOf(toolName) }.getOrNull() ?: return
        if (file == null && url == null) return
        vm.openTab(com.excelto.pdf.converter.ui.Route.Home)
        vm.openTool(tool, file?.let { DocFile.from(it, Source.IMPORTED) }, text = url, sheet = sheet)
    }

    override fun requestAllFilesAccess() {
        val intent = Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:$packageName"))
        try { startActivity(intent) } catch (e: ActivityNotFoundException) {
            startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
        }
    }

    override fun rateApp() = open(Uri.parse("https://play.google.com/store/apps/details?id=$packageName"))

    override fun shareApp() {
        val text = "Convert Excel to PDF and edit PDFs on your phone: https://play.google.com/store/apps/details?id=$packageName"
        startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text), "Share app"))
    }

    override fun openPrivacy() { startActivity(Intent(this, com.excelto.pdf.converter.legal.PrivacyActivity::class.java)) }

    override fun afterJob(then: () -> Unit) = com.excelto.pdf.converter.ads.Ads.afterJob(this, then)

    override fun watchRewarded(onReward: () -> Unit, onUnavailable: () -> Unit) =
        com.excelto.pdf.converter.ads.Ads.showRewarded(this, onReward, onUnavailable)

    override fun adPrivacyRequired() = com.excelto.pdf.converter.ads.Ads.privacyOptionsRequired(this)

    override fun openAdPrivacy() = com.excelto.pdf.converter.ads.Ads.showPrivacyOptions(this)

    private fun open(uri: Uri) {
        try { startActivity(Intent(Intent.ACTION_VIEW, uri)) } catch (e: ActivityNotFoundException) {
            Toast.makeText(this, tr(R.string.main_no_browser), Toast.LENGTH_SHORT).show()
        }
    }

    // ---- Google Play in-app updates ---------------------------------------------------------

    private val updates by lazy { AppUpdateManagerFactory.create(this) }

    /** Shows the "Update ready" bar once a background (flexible) update has downloaded. */
    private val installListener = com.google.android.play.core.install.InstallStateUpdatedListener { state ->
        if (state.installStatus() == com.google.android.play.core.install.model.InstallStatus.DOWNLOADED) vm.updateReady = true
    }

    private val updateLauncher = registerForActivityResult(androidx.activity.result.contract.ActivityResultContracts.StartIntentSenderForResult()) { result ->
        // "No thanks" on the flexible prompt: don't ask again for a few days.
        if (result.resultCode != RESULT_OK) {
            getSharedPreferences("updates", MODE_PRIVATE).edit().putLong("declined_at", System.currentTimeMillis()).apply()
        }
    }

    /**
     * Offers the newest version from Google Play to anyone on an older one.
     * Urgent updates (priority 4–5 set in Play) or users 14+ days behind get the full-screen
     * update; everyone else gets a small prompt and keeps working while it downloads.
     */
    private fun checkForUpdate() {
        updates.registerListener(installListener)
        updates.appUpdateInfo.addOnSuccessListener { info ->
            if (info.installStatus() == com.google.android.play.core.install.model.InstallStatus.DOWNLOADED) { vm.updateReady = true; return@addOnSuccessListener }
            if (info.updateAvailability() != UpdateAvailability.UPDATE_AVAILABLE) return@addOnSuccessListener
            val staleDays = info.clientVersionStalenessDays() ?: 0
            val urgent = info.updatePriority() >= 4 || staleDays >= 14
            val type = when {
                urgent && info.isUpdateTypeAllowed(AppUpdateType.IMMEDIATE) -> AppUpdateType.IMMEDIATE
                info.isUpdateTypeAllowed(AppUpdateType.FLEXIBLE) -> AppUpdateType.FLEXIBLE
                else -> return@addOnSuccessListener
            }
            if (type == AppUpdateType.FLEXIBLE) {
                val declinedAt = getSharedPreferences("updates", MODE_PRIVATE).getLong("declined_at", 0L)
                if (System.currentTimeMillis() - declinedAt < 3 * 24 * 60 * 60 * 1000L) return@addOnSuccessListener
            }
            runCatching { updates.startUpdateFlowForResult(info, updateLauncher, AppUpdateOptions.newBuilder(type).build()) }
        }
    }

    /** Resumes a full-screen update the user left, and re-shows "Update ready" after a restart. */
    private fun resumeUpdate() {
        updates.appUpdateInfo.addOnSuccessListener { info ->
            when {
                info.installStatus() == com.google.android.play.core.install.model.InstallStatus.DOWNLOADED -> vm.updateReady = true
                info.updateAvailability() == UpdateAvailability.DEVELOPER_TRIGGERED_UPDATE_IN_PROGRESS ->
                    runCatching { updates.startUpdateFlowForResult(info, updateLauncher, AppUpdateOptions.newBuilder(AppUpdateType.IMMEDIATE).build()) }
            }
        }
    }

    override fun installUpdate() {
        vm.updateReady = false
        updates.completeUpdate()
    }

    override fun onDestroy() {
        runCatching { updates.unregisterListener(installListener) }
        super.onDestroy()
    }

    companion object {
        private const val EXIT_WINDOW_MS = 2000L
        const val EXTRA_TOOL = "open_tool"
        const val EXTRA_PATH = "open_path"
        const val EXTRA_URL = "open_url"
        const val EXTRA_SHEET = "open_sheet"
        private const val LOCK_AFTER_MS = 30_000L
        private const val LOCK_AUTHENTICATORS = BiometricManager.Authenticators.BIOMETRIC_WEAK or BiometricManager.Authenticators.DEVICE_CREDENTIAL

        /** When the app last went to the background; 0 means a fresh start. */
        private var lastBackground = 0L
    }
}
