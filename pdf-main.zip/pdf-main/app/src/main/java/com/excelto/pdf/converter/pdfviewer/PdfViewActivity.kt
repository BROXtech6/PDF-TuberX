package com.excelto.pdf.converter.pdfviewer

import com.excelto.pdf.converter.language.tr
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.compose.ui.focus.focusRequester
import androidx.compose.material3.Icon
import androidx.compose.foundation.layout.size
import androidx.activity.OnBackPressedCallback
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.requiredWidth
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.lifecycleScope
import com.excelto.pdf.converter.MainActivity
import com.excelto.pdf.converter.R
import com.excelto.pdf.converter.app.App
import com.excelto.pdf.converter.core.engine.PdfTools
import com.excelto.pdf.converter.core.engine.Progress
import com.excelto.pdf.converter.core.render.PdfPages
import com.excelto.pdf.converter.core.storage.AppPrefs
import com.excelto.pdf.converter.core.storage.OutputFiles
import com.excelto.pdf.converter.ui.InnerHeader
import com.excelto.pdf.converter.ui.Tool
import com.excelto.pdf.converter.ui.sheets.AppSheet
import com.excelto.pdf.converter.ui.sheets.appTextFieldColors
import com.excelto.pdf.converter.ui.theme.AppIcons
import com.excelto.pdf.converter.ui.theme.AppTheme
import com.excelto.pdf.converter.ui.theme.LocalPalette
import com.excelto.pdf.converter.ui.theme.Type
import com.excelto.pdf.converter.ui.tools.IconButtonSmall
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

/**
 * PDF viewer, in Kotlin. Keeps the old class name and manifest entry, so PDFs opened
 * from other apps ("Open with") and older code still land here.
 *
 * Extras: "pdf_path" (a file path) or the intent's data URI; optional "page" (1-based).
 */
class PdfViewActivity : AppCompatActivity() {

    private var source by mutableStateOf<File?>(null)
    private var renderable by mutableStateOf<File?>(null)
    private var needsPassword by mutableStateOf(false)
    private var wrongPassword by mutableStateOf(false)
    private var error by mutableStateOf<String?>(null)
    private val fromOtherApp get() = intent?.data != null

    private val prefs by lazy { getSharedPreferences("viewer", MODE_PRIVATE) }
    /** Remembers the last page per file, so reopening continues where the reader stopped. */
    private val positionKey: String? get() = intent.getStringExtra("pdf_path") ?: intent.data?.toString()

    /** Night reading: pages drawn in inverted colors on a dark background. */
    private var night by mutableStateOf(false)

    private var searching by mutableStateOf(false)
    private var hits by mutableStateOf<List<ViewerText.Hit>>(emptyList())
    private var hitIndex by androidx.compose.runtime.mutableIntStateOf(0)
    private var searchedPages by androidx.compose.runtime.mutableIntStateOf(0)
    private var searchTotal by androidx.compose.runtime.mutableIntStateOf(0)
    private var searchJob: kotlinx.coroutines.Job? = null

    /** Read aloud with the phone's own voice: free and offline. */
    private var tts: android.speech.tts.TextToSpeech? = null
    private var ttsReady = false
    private var speakingPage by mutableStateOf<Int?>(null)
    private var pageTotal = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        night = prefs.getBoolean("night", false)
        val startPage = intent.getIntExtra("page", 1)
        loadSource()
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() = leave()
        })
        setContent {
            AppTheme(if (night) com.excelto.pdf.converter.core.storage.ThemeMode.DARK else AppPrefs(this).themeMode) {
                ViewerScreen(startPage)
            }
        }
    }

    private fun loadSource() {
        lifecycleScope.launch {
            val file = withContext(Dispatchers.IO) {
                intent.getStringExtra("pdf_path")?.let { File(it) }
                    ?: intent.data?.let { uri -> copyIn(uri) }
            }
            if (file == null || !file.exists()) { error = tr(R.string.viewer_open_failed); return@launch }
            source = file
            prepare(file, null)
        }
    }

    private fun copyIn(uri: Uri): File? = runCatching {
        if (uri.scheme == "file") return@runCatching File(uri.path!!)
        val target = File(OutputFiles.cache(this, "viewer"), "opened_${System.currentTimeMillis()}.pdf")
        contentResolver.openInputStream(uri)!!.use { input -> target.outputStream().use { input.copyTo(it) } }
        target
    }.getOrNull()

    /** Android's renderer can't read password-protected files, so those are unlocked into the cache first. */
    private fun prepare(file: File, password: String?) {
        lifecycleScope.launch {
            val ready = withContext(Dispatchers.IO) {
                if (PdfPages.pageCount(file) != null) return@withContext file
                if (!PdfTools.isPasswordProtected(file.path)) return@withContext null
                if (password == null) return@withContext NEEDS_PASSWORD
                runCatching {
                    val out = File(OutputFiles.cache(this@PdfViewActivity, "viewer"), "unlocked_${System.currentTimeMillis()}.pdf")
                    PdfTools.unlock(PdfTools.Input(file.path, password), out, Progress.NONE)
                    out
                }.getOrElse { WRONG_PASSWORD }
            }
            when {
                ready == NEEDS_PASSWORD -> needsPassword = true
                ready == WRONG_PASSWORD -> { needsPassword = true; wrongPassword = true }
                ready == null -> error = tr(R.string.viewer_damaged)
                else -> { needsPassword = false; wrongPassword = false; renderable = ready }
            }
        }
    }

    private fun share() {
        val file = source ?: return
        val uri = androidx.core.content.FileProvider.getUriForFile(this, "$packageName.provider", file)
        startActivity(Intent.createChooser(
            Intent(Intent.ACTION_SEND).setType("application/pdf").putExtra(Intent.EXTRA_STREAM, uri).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION),
            tr(R.string.common_share),
        ))
    }

    private fun openTool(tool: Tool) {
        val file = source ?: return
        startActivity(Intent(this, MainActivity::class.java).putExtra(MainActivity.EXTRA_TOOL, tool.name).putExtra(MainActivity.EXTRA_PATH, file.absolutePath))
        finish()
    }

    // ---- Search -------------------------------------------------------------------------

    private fun runSearch(query: String) {
        val file = renderable ?: return
        searchJob?.cancel()
        hits = emptyList(); hitIndex = 0; searchedPages = 0
        if (query.isBlank()) return
        searchJob = lifecycleScope.launch(Dispatchers.IO) {
            val job = coroutineContext[kotlinx.coroutines.Job]
            ViewerText.search(file.path, query, isActive = { job?.isActive == true }) { page, total, found ->
                runOnUiThread {
                    searchTotal = total
                    searchedPages = page + 1
                    if (found.isNotEmpty()) hits = hits + found
                }
            }
        }
    }

    // ---- Read aloud ---------------------------------------------------------------------

    private fun toggleReading(currentPage: Int) {
        if (speakingPage != null) { stopReading(); return }
        val engine = tts
        if (engine == null) {
            tts = android.speech.tts.TextToSpeech(this) { status ->
                ttsReady = status == android.speech.tts.TextToSpeech.SUCCESS
                if (ttsReady) {
                    tts?.setOnUtteranceProgressListener(object : android.speech.tts.UtteranceProgressListener() {
                        override fun onStart(id: String?) = Unit
                        override fun onError(id: String?) = runOnUiThread { stopReading() }
                        override fun onDone(id: String?) {
                            // "p<page>_last" marks the end of a page: go on to the next one.
                            val page = id?.removePrefix("p")?.substringBefore("_last", "")?.toIntOrNull() ?: return
                            runOnUiThread { if (speakingPage == page) readPage(page + 1, first = false) }
                        }
                    })
                    runOnUiThread { readPage(currentPage, first = true) }
                } else {
                    runOnUiThread { Toast.makeText(this, tr(R.string.viewer_tts_unavailable), Toast.LENGTH_SHORT).show() }
                }
            }
        } else if (ttsReady) {
            readPage(currentPage, first = true)
        }
    }

    private fun readPage(page: Int, first: Boolean) {
        val file = renderable ?: return
        if (page >= pageTotal) { stopReading(); return }
        speakingPage = page
        lifecycleScope.launch {
            val text = withContext(Dispatchers.IO) { ViewerText.pageText(file.path, page) }
            if (speakingPage != page) return@launch
            if (text.isBlank()) {
                if (first) {
                    Toast.makeText(this@PdfViewActivity, tr(R.string.viewer_no_text), Toast.LENGTH_LONG).show()
                    stopReading()
                } else {
                    readPage(page + 1, first = false)
                }
                return@launch
            }
            val engine = tts ?: return@launch
            engine.language = localeFor(text)
            val parts = ViewerText.chunks(text)
            parts.forEachIndexed { i, part ->
                val id = if (i == parts.lastIndex) "p${page}_last" else "p${page}_$i"
                engine.speak(part, if (i == 0) android.speech.tts.TextToSpeech.QUEUE_FLUSH else android.speech.tts.TextToSpeech.QUEUE_ADD, null, id)
            }
        }
    }

    /** Picks a voice language from the text's script, so Arabic or Hindi pages aren't read in English. */
    private fun localeFor(text: String): java.util.Locale {
        val sample = text.take(400)
        fun has(block: Character.UnicodeBlock) = sample.any { Character.UnicodeBlock.of(it) == block }
        return when {
            has(Character.UnicodeBlock.ARABIC) -> java.util.Locale("ar")
            has(Character.UnicodeBlock.DEVANAGARI) -> java.util.Locale("hi")
            has(Character.UnicodeBlock.CJK_UNIFIED_IDEOGRAPHS) -> java.util.Locale.CHINESE
            has(Character.UnicodeBlock.HEBREW) -> java.util.Locale("he")
            else -> java.util.Locale.getDefault()
        }
    }

    private fun stopReading() {
        speakingPage = null
        tts?.stop()
    }

    override fun onDestroy() {
        tts?.shutdown()
        tts = null
        super.onDestroy()
    }

    /** When opened from another app, leaving goes to the home screen. */
    private fun leave() {
        if (fromOtherApp) startActivity(Intent(this, MainActivity::class.java))
        finish()
    }

    @Composable
    private fun ViewerScreen(startPage: Int) {
        val p = LocalPalette.current
        var menu by remember { mutableStateOf(false) }
        val list = rememberLazyListState()
        val scope = rememberCoroutineScope()
        Column(Modifier.fillMaxSize().background(if (night) Color(0xFF0E1013) else p.viewer).windowInsetsPadding(WindowInsets.safeDrawing)) {
            if (searching) {
                SearchBar(list) { searching = false; searchJob?.cancel(); hits = emptyList() }
            } else {
                InnerHeader(source?.name ?: "PDF", onBack = { leave() }) {
                    val ready = renderable != null
                    IconButtonSmall(AppIcons.search, tr(R.string.viewer_search), enabled = ready) { searching = true }
                    IconButtonSmall(if (speakingPage != null) AppIcons.stop else AppIcons.speaker, if (speakingPage != null) tr(R.string.viewer_stop_reading) else tr(R.string.viewer_read_aloud), enabled = ready) {
                        toggleReading(list.firstVisibleItemIndex)
                    }
                    IconButtonSmall(AppIcons.moon, if (night) tr(R.string.viewer_day) else tr(R.string.viewer_night), enabled = ready) {
                        night = !night
                        prefs.edit().putBoolean("night", night).apply()
                    }
                    IconButtonSmall(AppIcons.more, tr(R.string.common_more), enabled = source != null) { menu = true }
                }
            }
            val file = renderable
            Box(Modifier.weight(1f)) {
                when {
                    error != null -> Text(error!!, style = Type.body, color = p.text, modifier = Modifier.padding(24.dp))
                    file == null -> Text(if (needsPassword) "" else tr(R.string.viewer_opening), style = Type.body, color = p.muted, modifier = Modifier.padding(24.dp))
                    else -> Pages(file, startPage, list)
                }
            }
            speakingPage?.let { page ->
                Row(
                    Modifier.fillMaxWidth().background(p.surface).padding(horizontal = 16.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Icon(AppIcons.speaker, null, tint = p.primaryText, modifier = Modifier.size(20.dp))
                    Text("  " + tr(R.string.viewer_reading_page, page + 1), style = Type.bodyStrong, color = p.text, modifier = Modifier.weight(1f))
                    Text(tr(R.string.viewer_stop), style = Type.bodyStrong, color = p.danger,
                        modifier = Modifier.heightIn(min = 44.dp).clip(RoundedCornerShape(10.dp)).clickable(role = Role.Button) { stopReading() }
                            .padding(horizontal = 12.dp, vertical = 12.dp))
                }
                LaunchedEffect(page) { if (list.firstVisibleItemIndex != page) scope.launch { list.animateScrollToItem(page) } }
            }
        }
        if (needsPassword) PasswordAsk()
        if (menu) {
            AppSheet(onDismiss = { menu = false }) {
                Text(tr(R.string.viewer_do_more), style = Type.section.copy(fontSize = 16.sp), color = p.text)
                Text(tr(R.string.common_share), style = Type.bodyStrong.copy(fontSize = 14.sp), color = p.text,
                    modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp).clip(RoundedCornerShape(12.dp))
                        .clickable(role = Role.Button) { menu = false; share() }.padding(horizontal = 8.dp, vertical = 14.dp))
                listOf(Tool.EDIT, Tool.SIGN, Tool.ANNOTATE, Tool.COMPRESS, Tool.PROTECT).forEach { tool ->
                    Text(tool.label, style = Type.bodyStrong.copy(fontSize = 14.sp), color = p.text,
                        modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp).clip(RoundedCornerShape(12.dp))
                            .clickable(role = Role.Button) { menu = false; openTool(tool) }.padding(horizontal = 8.dp, vertical = 14.dp))
                }
            }
        }
    }

    @Composable
    private fun PasswordAsk() {
        val p = LocalPalette.current
        var pw by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { finish() },
            containerColor = p.surface,
            title = { Text(tr(R.string.password_title), style = Type.section.copy(fontSize = 17.sp), color = p.text) },
            text = {
                OutlinedTextField(pw, { pw = it }, singleLine = true, colors = appTextFieldColors(), label = { Text(tr(R.string.password_label)) },
                    isError = wrongPassword, supportingText = { if (wrongPassword) Text(tr(R.string.viewer_pw_wrong)) },
                    visualTransformation = PasswordVisualTransformation(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password))
            },
            confirmButton = { Text(tr(R.string.common_open), style = Type.bodyStrong, color = p.primaryText, modifier = Modifier.clickable(role = Role.Button) { source?.let { prepare(it, pw) } }.padding(12.dp)) },
            dismissButton = { Text(tr(R.string.common_cancel), style = Type.bodyStrong, color = p.text, modifier = Modifier.clickable(role = Role.Button) { finish() }.padding(12.dp)) },
        )
    }

    @Composable
    private fun SearchBar(list: androidx.compose.foundation.lazy.LazyListState, onClose: () -> Unit) {
        val p = LocalPalette.current
        val scope = rememberCoroutineScope()
        var query by remember { mutableStateOf("") }
        fun show(i: Int) {
            if (hits.isEmpty()) return
            hitIndex = (i + hits.size) % hits.size
            scope.launch { list.animateScrollToItem(hits[hitIndex].page) }
        }
        // Jump to the first match as soon as it's found.
        LaunchedEffect(hits.isNotEmpty()) { if (hits.isNotEmpty()) show(0) }
        // Open with the cursor in the box and the keyboard up.
        val focus = remember { androidx.compose.ui.focus.FocusRequester() }
        LaunchedEffect(Unit) { focus.requestFocus() }
        Row(Modifier.fillMaxWidth().background(p.surface).padding(horizontal = 4.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButtonSmall(AppIcons.back, tr(R.string.viewer_close_search)) { onClose() }
            OutlinedTextField(
                query, { query = it }, singleLine = true, colors = appTextFieldColors(),
                placeholder = { Text(tr(R.string.viewer_search)) },
                keyboardOptions = KeyboardOptions(imeAction = androidx.compose.ui.text.input.ImeAction.Search),
                keyboardActions = androidx.compose.foundation.text.KeyboardActions(onSearch = { runSearch(query) }),
                modifier = Modifier.weight(1f).focusRequester(focus),
            )
            val status = when {
                hits.isNotEmpty() -> "${hitIndex + 1}/${hits.size}"
                searchTotal > 0 && searchedPages < searchTotal -> "…"
                searchTotal > 0 && query.isNotBlank() -> "0"
                else -> ""
            }
            Text(status, style = Type.small, color = p.muted, modifier = Modifier.padding(horizontal = 6.dp))
            IconButtonSmall(AppIcons.up, tr(R.string.viewer_prev_match), enabled = hits.isNotEmpty()) { show(hitIndex - 1) }
            IconButtonSmall(AppIcons.down, tr(R.string.viewer_next_match), enabled = hits.isNotEmpty()) { show(hitIndex + 1) }
        }
    }

    @Composable
    private fun Pages(file: File, startPage: Int, list: androidx.compose.foundation.lazy.LazyListState) {
        val p = LocalPalette.current
        val count by produceState<Int?>(null, file) { value = withContext(Dispatchers.IO) { PdfPages.pageCount(file) } }
        val scope = rememberCoroutineScope()
        var scale by remember { mutableFloatStateOf(1f) }
        var jumping by remember { mutableStateOf(false) }
        // Read the saved page before anything can overwrite it, and only start saving
        // once the restore has happened.
        val saved = remember { positionKey?.let { prefs.getInt("pos:$it", 0) } ?: 0 }
        var restored by remember { mutableStateOf(false) }
        LaunchedEffect(count) {
            val n = count ?: return@LaunchedEffect
            pageTotal = n
            // An explicit page wins; otherwise continue where this file was last read.
            val target = if (startPage > 1) startPage - 1 else saved
            if (target in 1 until n) {
                list.scrollToItem(target)
                if (startPage <= 1) Toast.makeText(this@PdfViewActivity, tr(R.string.viewer_continuing, target + 1), Toast.LENGTH_SHORT).show()
            }
            restored = true
        }
        LaunchedEffect(restored) {
            if (!restored) return@LaunchedEffect
            androidx.compose.runtime.snapshotFlow { list.firstVisibleItemIndex }.collect { i ->
                positionKey?.let { prefs.edit().putInt("pos:$it", i).apply() }
            }
        }
        val total = count ?: return
        BoxWithConstraints(
            Modifier.fillMaxSize().pointerInput(Unit) {
                // Two-finger pinch zooms; one finger keeps scrolling the pages.
                awaitEachGesture {
                    awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
                    do {
                        val event = awaitPointerEvent(PointerEventPass.Initial)
                        if (event.changes.count { it.pressed } >= 2) {
                            scale = (scale * event.calculateZoom()).coerceIn(1f, 4f)
                            event.changes.forEach { it.consume() }
                        }
                    } while (event.changes.any { it.pressed })
                }
            },
        ) {
            val width = maxWidth
            val density = LocalDensity.current
            Box(Modifier.fillMaxSize().horizontalScroll(rememberScrollState(), enabled = scale > 1.01f)) {
                LazyColumn(
                    Modifier.requiredWidth(width * scale).fillMaxSize(),
                    state = list,
                    contentPadding = PaddingValues(vertical = 12.dp, horizontal = 10.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    items(total) { index ->
                        val px = with(density) { (width * scale).toPx() }.toInt().coerceIn(400, 2400)
                        val bucket = (px / 200) * 200
                        val bmp by produceState<Bitmap?>(null, file, index, bucket) {
                            value = withContext(Dispatchers.IO) { PdfPages.render(file, index, bucket) }
                        }
                        val b = bmp
                        Box(
                            Modifier.fillMaxWidth().aspectRatio(b?.let { it.width.toFloat() / it.height } ?: 0.707f)
                                .background(if (night) Color.Black else Color.White)
                                .semantics { contentDescription = tr(R.string.page_of, index + 1, total) },
                        ) {
                            if (b != null) Image(
                                b.asImageBitmap(), null, contentScale = ContentScale.FillBounds, modifier = Modifier.fillMaxSize(),
                                colorFilter = if (night) NIGHT_FILTER else null,
                            )
                            // Search matches on this page: yellow, the current one orange.
                            val pageHits = hits.withIndex().filter { it.value.page == index && it.value.rect != null }
                            if (pageHits.isNotEmpty()) {
                                androidx.compose.foundation.Canvas(Modifier.fillMaxSize()) {
                                    for ((i, h) in pageHits) {
                                        val r = h.rect!!
                                        drawRect(
                                            color = if (i == hitIndex) Color(0x88FF8A00) else Color(0x66FFD400),
                                            topLeft = androidx.compose.ui.geometry.Offset(r.left * size.width - 2f, r.top * size.height - 2f),
                                            size = androidx.compose.ui.geometry.Size((r.right - r.left) * size.width + 4f, (r.bottom - r.top) * size.height + 4f),
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
            Text(
                "${list.firstVisibleItemIndex + 1} / $total",
                style = Type.bodyStrong, color = Color.White,
                modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 16.dp).clip(RoundedCornerShape(16.dp))
                    .background(Color(0xCC1B222B)).clickable(role = Role.Button, onClickLabel = tr(R.string.viewer_go_to_page)) { jumping = true }
                    .padding(horizontal = 14.dp, vertical = 8.dp),
            )
        }
        if (jumping) {
            var text by remember { mutableStateOf("") }
            AlertDialog(
                onDismissRequest = { jumping = false },
                containerColor = p.surface,
                title = { Text(tr(R.string.viewer_go_to_page), style = Type.section.copy(fontSize = 17.sp), color = p.text) },
                text = { OutlinedTextField(text, { text = it.filter(Char::isDigit).take(5) }, singleLine = true, colors = appTextFieldColors(), label = { Text(tr(R.string.viewer_range, total)) }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)) },
                confirmButton = {
                    Text(tr(R.string.viewer_go), style = Type.bodyStrong, color = p.primaryText, modifier = Modifier.clickable(role = Role.Button) {
                        text.toIntOrNull()?.takeIf { it in 1..total }?.let { n -> scope.launch { list.scrollToItem(n - 1) } }
                        jumping = false
                    }.padding(12.dp))
                },
            )
        }
    }

    companion object {
        private val NEEDS_PASSWORD = File("/needs-password")
        private val WRONG_PASSWORD = File("/wrong-password")

        /** Inverts page colors for night reading: white paper becomes black, text becomes light. */
        private val NIGHT_FILTER = androidx.compose.ui.graphics.ColorFilter.colorMatrix(
            androidx.compose.ui.graphics.ColorMatrix(
                floatArrayOf(
                    -0.85f, 0f, 0f, 0f, 235f,
                    0f, -0.85f, 0f, 0f, 235f,
                    0f, 0f, -0.85f, 0f, 235f,
                    0f, 0f, 0f, 1f, 0f,
                ),
            ),
        )
    }
}
