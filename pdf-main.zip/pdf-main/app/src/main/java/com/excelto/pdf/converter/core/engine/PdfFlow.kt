package com.excelto.pdf.converter.core.engine

import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.pdmodel.PDPage
import com.tom_roush.pdfbox.pdmodel.PDPageContentStream
import com.tom_roush.pdfbox.pdmodel.common.PDRectangle

/**
 * Lays out paragraphs top to bottom on A4 pages, starting a new page when one is full.
 * Right-to-left paragraphs are right-aligned. Call [close] before saving.
 */
class PdfFlow(
    private val doc: PDDocument,
    private val margin: Float = 50f,
    private val pageSize: PDRectangle = PDRectangle.A4,
    /** Called once for each new page, to draw headers or footers. */
    private val decorate: (PDPageContentStream, pageNumber: Int) -> Unit = { _, _ -> },
) {
    private val regular = PdfText(doc)
    private val bold = PdfText(doc, bold = true)
    private var cs: PDPageContentStream? = null
    private var y = 0f
    var pageCount = 0
        private set

    private val width get() = pageSize.width - margin * 2

    fun newPage() {
        cs?.close()
        val page = PDPage(pageSize)
        doc.addPage(page)
        pageCount++
        cs = PDPageContentStream(doc, page).also { decorate(it, pageCount) }
        y = pageSize.height - margin
    }

    /** Adds a paragraph. Long paragraphs continue on the next page. */
    fun paragraph(text: String, size: Float, color: Int = 0xFF1F2733.toInt(), isBold: Boolean = false, leading: Float = size * 1.36f, spaceAfter: Float = 0f) {
        val writer = if (isBold) bold else regular
        for (paragraph in text.replace("\r\n", "\n").split('\n')) {
            val rtl = PdfText.isRtlParagraph(paragraph)
            for (line in writer.wrap(paragraph, size, width)) {
                if (cs == null || y - leading < margin) newPage()
                y -= leading
                if (rtl) writer.drawLine(cs!!, line, pageSize.width - margin, y, size, color, TextAlign.RIGHT)
                else writer.drawLine(cs!!, line, margin, y, size, color)
            }
        }
        y -= spaceAfter
    }

    /** Draws a line of text at a fixed spot on the current page (for footers). */
    fun label(cs: PDPageContentStream, text: String, x: Float, y: Float, size: Float, color: Int, align: TextAlign) =
        regular.drawLine(cs, text, x, y, size, color, align)

    fun close() {
        if (cs == null) newPage()
        cs?.close()
        cs = null
    }
}
