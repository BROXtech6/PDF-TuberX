package com.excelto.pdf.converter.excelviewer

import com.excelto.pdf.converter.R
import com.excelto.pdf.converter.language.tr
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.webkit.MimeTypeMap
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.lifecycleScope
import com.excelto.pdf.converter.MainActivity
import com.excelto.pdf.converter.core.engine.ExcelEngine
import com.excelto.pdf.converter.core.engine.UserFacingException
import com.excelto.pdf.converter.core.excel.ExcelSheet
import com.excelto.pdf.converter.core.excel.ExcelWorkbook
import com.excelto.pdf.converter.core.excel.GridGeometry
import com.excelto.pdf.converter.core.excel.formulaKey
import com.excelto.pdf.converter.core.storage.AppPrefs
import com.excelto.pdf.converter.core.storage.OutputFiles
import com.excelto.pdf.converter.ui.InnerHeader
import com.excelto.pdf.converter.ui.Tool
import com.excelto.pdf.converter.ui.components.PrimaryButton
import com.excelto.pdf.converter.ui.components.TextAction
import com.excelto.pdf.converter.ui.sheets.AppSheet
import com.excelto.pdf.converter.ui.sheets.appTextFieldColors
import com.excelto.pdf.converter.ui.theme.AppIcons
import com.excelto.pdf.converter.ui.theme.AppTheme
import com.excelto.pdf.converter.ui.theme.LocalPalette
import com.excelto.pdf.converter.ui.theme.Type
import com.excelto.pdf.converter.ui.tools.IconButtonSmall
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

/**
 * Opens .xlsx, .xls and .csv files inside the app: frozen headers and panes, cell
 * formatting, formulas on long-press, sheet tabs, pinch zoom, find, and a shortcut to
 * Excel to PDF. Large sheets load with progress and can be canceled.
 */
class ExcelViewActivity : AppCompatActivity() {

    private var file by mutableStateOf<File?>(null)
    private var sheets by mutableStateOf<List<ExcelEngine.SheetRef>>(emptyList())
    private var current by mutableIntStateOf(0)
    private var loaded by mutableStateOf<Loaded?>(null)
    private var loading by mutableStateOf(true)
    private var error by mutableStateOf<String?>(null)
    private var loadJob: Job? = null
    private val fromOtherApp get() = intent?.data != null

    class Loaded(val workbook: ExcelWorkbook, val sheet: ExcelSheet, val geometry: GridGeometry, val state: GridState)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() = leave()
        })
        open()
        setContent {
            AppTheme(AppPrefs(this).themeMode) { Screen() }
        }
    }

    private fun open() {
        lifecycleScope.launch {
            val f = withContext(Dispatchers.IO) {
                intent.getStringExtra(EXTRA_PATH)?.let { File(it) } ?: intent.data?.let { copyIn(it) }
            }
            if (f == null || !f.exists()) { error = tr(R.string.viewer_open_failed); loading = false; return@launch }
            file = f
            try {
                sheets = withContext(Dispatchers.IO) { ExcelEngine.sheets(f.path) }
                if (sheets.isEmpty()) { error = tr(R.string.xl_no_sheets); loading = false; return@launch }
                load(0)
            } catch (e: UserFacingException) {
                error = e.localizedMessage; loading = false
            }
        }
    }

    /** Files from other apps are copied into the cache with their real name. */
    private fun copyIn(uri: Uri): File? = runCatching {
        if (uri.scheme == "file") return@runCatching File(uri.path!!)
        val name = contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) c.getString(0) else null
        } ?: run {
            val ext = MimeTypeMap.getSingleton().getExtensionFromMimeType(contentResolver.getType(uri)) ?: "xlsx"
            "Spreadsheet.$ext"
        }
        val safe = name.replace(Regex("[\\\\/:*?\"<>|]"), "_")
        val dir = File(OutputFiles.cache(this, "viewer"), System.currentTimeMillis().toString()).apply { mkdirs() }
        val target = File(dir, safe)
        contentResolver.openInputStream(uri)!!.use { input -> target.outputStream().use { input.copyTo(it) } }
        target
    }.getOrNull()

    private fun load(index: Int) {
        val f = file ?: return
        val ref = sheets.getOrNull(index) ?: return
        loadJob?.cancel()
        current = index
        loading = true
        error = null
        loadJob = lifecycleScope.launch {
            try {
                val result = withContext(Dispatchers.IO) {
                    val (wb, sheet) = ExcelEngine.readSheet(f.path, ref.workbookIndex) { ensureActive() }
                    Loaded(wb, sheet, GridGeometry(sheet, wb), GridState())
                }
                loaded = result
            } catch (e: CancellationException) {
                throw e
            } catch (e: UserFacingException) {
                error = e.localizedMessage
            } catch (e: OutOfMemoryError) {
                error = tr(R.string.xl_too_large)
            } finally {
                loading = false
            }
        }
    }

    private fun cancelLoading() {
        loadJob?.cancel()
        loading = false
        if (loaded == null) leave()
    }

    private fun share() {
        val f = file ?: return
        val uri = androidx.core.content.FileProvider.getUriForFile(this, "$packageName.provider", f)
        startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType(mime(f)).putExtra(Intent.EXTRA_STREAM, uri).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION), tr(R.string.common_share)))
    }

    private fun openElsewhere() {
        val f = file ?: return
        val uri = androidx.core.content.FileProvider.getUriForFile(this, "$packageName.provider", f)
        runCatching {
            startActivity(Intent.createChooser(Intent(Intent.ACTION_VIEW).setDataAndType(uri, mime(f)).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION), "Open with"))
        }.onFailure { Toast.makeText(this, tr(R.string.xl_no_app), Toast.LENGTH_SHORT).show() }
    }

    private fun mime(f: File) = MimeTypeMap.getSingleton().getMimeTypeFromExtension(f.extension.lowercase()) ?: "application/octet-stream"

    private fun convert() {
        val f = file ?: return
        startActivity(
            Intent(this, MainActivity::class.java)
                .putExtra(MainActivity.EXTRA_TOOL, Tool.EXCEL_TO_PDF.name)
                .putExtra(MainActivity.EXTRA_PATH, f.absolutePath)
                .putExtra(MainActivity.EXTRA_SHEET, current),
        )
        finish()
    }

    private fun leave() {
        if (fromOtherApp) startActivity(Intent(this, MainActivity::class.java))
        finish()
    }

    // ---- UI -------------------------------------------------------------------------------

    @Composable
    private fun Screen() {
        val p = LocalPalette.current
        var menu by remember { mutableStateOf(false) }
        var searching by remember { mutableStateOf(false) }
        var formulaFor by remember { mutableStateOf<Pair<Int, Int>?>(null) }
        Column(Modifier.fillMaxSize().background(p.bg).windowInsetsPadding(WindowInsets.safeDrawing)) {
            InnerHeader(file?.name ?: tr(R.string.xl_spreadsheet), onBack = { leave() }) {
                IconButtonSmall(AppIcons.search, tr(R.string.xl_find), enabled = loaded != null) { searching = !searching }
                IconButtonSmall(AppIcons.share, tr(R.string.common_share), enabled = file != null) { share() }
                IconButtonSmall(AppIcons.more, tr(R.string.common_more), enabled = file != null) { menu = true }
            }
            val l = loaded
            if (searching && l != null) SearchBar(l) { searching = false }
            Box(Modifier.weight(1f).fillMaxWidth()) {
                when {
                    error != null -> Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.spacedBy(12.dp, Alignment.CenterVertically), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(error!!, style = Type.body, color = p.text)
                        PrimaryButton(tr(R.string.common_go_back), { leave() })
                    }
                    l != null -> {
                        SheetGrid(l, onLongPress = { r, c -> formulaFor = r to c })
                        CellBar(l, Modifier.align(Alignment.BottomCenter))
                    }
                }
                if (loading) Column(
                    Modifier.fillMaxSize().background(p.bg.copy(alpha = if (l == null) 1f else 0.85f)),
                    verticalArrangement = Arrangement.spacedBy(14.dp, Alignment.CenterVertically),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    CircularProgressIndicator(color = p.primaryText)
                    Text(if (sheets.isEmpty()) tr(R.string.viewer_opening) else tr(R.string.xl_reading, sheets.getOrNull(current)?.name ?: tr(R.string.xl_sheet)), style = Type.body, color = p.text)
                    TextAction(tr(R.string.common_cancel), { cancelLoading() }, color = p.danger)
                }
            }
            if (sheets.size > 1) SheetTabs()
        }
        if (menu) AppSheet(onDismiss = { menu = false }) {
            Text(tr(R.string.xl_do_more), style = Type.section.copy(fontSize = 16.sp), color = p.text)
            MenuItem(tr(R.string.cat_to_pdf)) { menu = false; convert() }
            MenuItem(tr(R.string.xl_open_other)) { menu = false; openElsewhere() }
            MenuItem(tr(R.string.common_share)) { menu = false; share() }
        }
        formulaFor?.let { (r, c) -> loaded?.let { FormulaDialog(it, r, c) { formulaFor = null } } }
    }

    @Composable
    private fun MenuItem(label: String, onClick: () -> Unit) {
        val p = LocalPalette.current
        Text(label, style = Type.bodyStrong.copy(fontSize = 14.sp), color = p.text,
            modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp).clip(RoundedCornerShape(12.dp))
                .clickable(role = Role.Button, onClick = onClick).padding(horizontal = 8.dp, vertical = 14.dp))
    }

    @Composable
    private fun SheetTabs() {
        val p = LocalPalette.current
        Row(
            Modifier.fillMaxWidth().background(p.surface).horizontalScroll(rememberScrollState()).padding(horizontal = 8.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            sheets.forEachIndexed { i, s ->
                val on = i == current
                Box(
                    Modifier.heightIn(min = 44.dp).widthIn(min = 64.dp).clip(RoundedCornerShape(10.dp))
                        .background(if (on) p.primarySoft else p.bg)
                        .border(1.dp, if (on) p.primaryText else p.line, RoundedCornerShape(10.dp))
                        .clickable(role = Role.Tab) { if (!on) load(i) }
                        .semantics { selected = on }
                        .padding(horizontal = 14.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    Text(s.name, style = Type.bodyStrong, color = if (on) p.primaryText else p.text, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }
        }
    }

    /** The selected cell's name and value, like Excel's formula bar. */
    @Composable
    private fun CellBar(l: Loaded, modifier: Modifier) {
        val p = LocalPalette.current
        val sel = l.state.selected ?: return
        val (r, c) = sel
        val row = l.sheet.rows[r]
        val i = row?.indexOf(c) ?: -1
        val value = if (row != null && i >= 0) l.workbook.display(row, i).text else ""
        val formula = l.sheet.formulas[formulaKey(r, c)]
        Row(
            modifier.fillMaxWidth().padding(10.dp).clip(RoundedCornerShape(12.dp)).background(p.surface).border(1.dp, p.line, RoundedCornerShape(12.dp))
                .padding(horizontal = 12.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(GridGeometry.name(r, c), style = Type.bodyStrong, color = p.primaryText)
            Text(if (formula != null) "=$formula" else value.ifEmpty { tr(R.string.xl_empty) }, style = Type.body, color = if (value.isEmpty() && formula == null) p.muted else p.text,
                maxLines = 2, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
        }
        if (l.sheet.chartCount > 0) Unit
    }

    @Composable
    private fun FormulaDialog(l: Loaded, r: Int, c: Int, onDismiss: () -> Unit) {
        val p = LocalPalette.current
        val row = l.sheet.rows[r]
        val i = row?.indexOf(c) ?: -1
        val value = if (row != null && i >= 0) l.workbook.display(row, i).text else ""
        val formula = l.sheet.formulas[formulaKey(r, c)]
        val copyText = formula?.let { "=$it" } ?: value
        AlertDialog(
            onDismissRequest = onDismiss,
            containerColor = p.surface,
            title = { Text(tr(R.string.xl_cell, GridGeometry.name(r, c)), style = Type.section.copy(fontSize = 17.sp), color = p.text) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (formula != null) {
                        Text(tr(R.string.xl_formula), style = Type.small, color = p.muted)
                        Text("=$formula", style = Type.bodyStrong, color = p.text)
                    }
                    Text(tr(R.string.xl_value), style = Type.small, color = p.muted)
                    Text(value.ifEmpty { tr(R.string.xl_empty) }, style = Type.body, color = p.text)
                }
            },
            confirmButton = {
                Text(tr(R.string.xl_copy), style = Type.bodyStrong, color = p.primaryText, modifier = Modifier.clickable(role = Role.Button) {
                    getSystemService(ClipboardManager::class.java)?.setPrimaryClip(ClipData.newPlainText("Cell", copyText))
                    onDismiss()
                }.padding(12.dp))
            },
            dismissButton = { Text(tr(R.string.common_close), style = Type.bodyStrong, color = p.text, modifier = Modifier.clickable(role = Role.Button, onClick = onDismiss).padding(12.dp)) },
        )
    }

    @Composable
    private fun SearchBar(l: Loaded, onClose: () -> Unit) {
        val p = LocalPalette.current
        val s = l.state
        var query by remember(l) { mutableStateOf(s.query) }
        fun run() {
            s.query = query
            lifecycleScope.launch {
                val found = withContext(Dispatchers.Default) { SheetSearch.find(l.workbook, l.sheet, query) }
                s.results = found
                s.resultIndex = 0
                found.firstOrNull()?.let { s.reveal(it.first, it.second, l.geometry) }
                if (found.isEmpty() && query.isNotBlank()) Toast.makeText(this@ExcelViewActivity, tr(R.string.xl_no_matches), Toast.LENGTH_SHORT).show()
            }
        }
        fun step(d: Int) {
            if (s.results.isEmpty()) return
            s.resultIndex = (s.resultIndex + d + s.results.size) % s.results.size
            val (r, c) = s.results[s.resultIndex]
            s.reveal(r, c, l.geometry)
        }
        Row(Modifier.fillMaxWidth().background(p.surface).padding(horizontal = 8.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                query, { query = it }, singleLine = true, colors = appTextFieldColors(),
                placeholder = { Text(tr(R.string.xl_find_in_sheet)) },
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                keyboardActions = KeyboardActions(onSearch = { run() }),
                modifier = Modifier.weight(1f),
            )
            Text(
                if (s.results.isEmpty()) "" else "${s.resultIndex + 1}/${s.results.size}",
                style = Type.small, color = p.muted, modifier = Modifier.padding(horizontal = 6.dp),
            )
            IconButtonSmall(AppIcons.up, tr(R.string.viewer_prev_match), enabled = s.results.isNotEmpty()) { step(-1) }
            IconButtonSmall(AppIcons.down, tr(R.string.viewer_next_match), enabled = s.results.isNotEmpty()) { step(1) }
            IconButtonSmall(AppIcons.close, tr(R.string.xl_close_find)) { s.results = emptyList(); onClose() }
        }
    }

    companion object {
        const val EXTRA_PATH = "sheet_path"
    }
}
