package com.excelto.pdf.converter.app

import android.app.Application
import android.content.Context
import android.content.SharedPreferences
import android.util.Log
import com.android.billingclient.api.BillingClient
import com.android.billingclient.api.BillingClientStateListener
import com.android.billingclient.api.BillingResult
import com.android.billingclient.api.Purchase
import com.android.billingclient.api.QueryProductDetailsParams
import com.android.billingclient.api.QueryPurchasesParams
import com.google.firebase.FirebaseApp
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader

/**
 * Application class. Same names as the Java version, so the subscription screen and
 * other code keep calling App.getInstance().isSubscribed() unchanged.
 */
class App : Application() {

    private lateinit var billingClient: BillingClient
    private lateinit var premiumPreferences: SharedPreferences

    override fun onCreate() {
        super.onCreate()
        context = this
        instance = this
        com.excelto.pdf.converter.language.AppLanguage.migrate(this)
        FirebaseApp.initializeApp(this)
        PDFBoxResourceLoader.init(applicationContext)
        premiumPreferences = getSharedPreferences("settings", Context.MODE_PRIVATE)

        billingClient = BillingClient.newBuilder(this)
            .enablePendingPurchases(com.android.billingclient.api.PendingPurchasesParams.newBuilder().enableOneTimeProducts().build())
            .setListener { _, _ -> }
            .build()
        startBillingConnection()
    }

    private fun startBillingConnection() {
        billingClient.startConnection(object : BillingClientStateListener {
            override fun onBillingSetupFinished(result: BillingResult) {
                if (result.responseCode == BillingClient.BillingResponseCode.OK) {
                    queryPurchases()
                    querySubscriptionPrices()
                } else {
                    Log.e("App", "Billing setup failed: ${result.debugMessage}")
                }
            }

            override fun onBillingServiceDisconnected() = Unit
        })
    }

    private fun querySubscriptionPrices() {
        val products = listOf("weekly_sub", "monthly_sub").map {
            QueryProductDetailsParams.Product.newBuilder().setProductId(it).setProductType(BillingClient.ProductType.SUBS).build()
        }
        val params = QueryProductDetailsParams.newBuilder().setProductList(products).build()
        billingClient.queryProductDetailsAsync(params) { result, details ->
            if (result.responseCode != BillingClient.BillingResponseCode.OK) return@queryProductDetailsAsync
            for (d in details.productDetailsList) {
                val price = d.subscriptionOfferDetails?.firstOrNull()?.pricingPhases?.pricingPhaseList?.firstOrNull()?.formattedPrice ?: continue
                premiumPreferences.edit().putString("sub_price", price).apply()
            }
        }
    }

    /**
     * Restores Pro from Google Play. Checks subscriptions AND the one-time "life_time"
     * purchase. The Java version only checked subscriptions, so lifetime buyers lost
     * Pro on every app start.
     */
    private fun queryPurchases() {
        val subs = QueryPurchasesParams.newBuilder().setProductType(BillingClient.ProductType.SUBS).build()
        billingClient.queryPurchasesAsync(subs) { subsResult, subsPurchases ->
            val inApp = QueryPurchasesParams.newBuilder().setProductType(BillingClient.ProductType.INAPP).build()
            billingClient.queryPurchasesAsync(inApp) { inAppResult, inAppPurchases ->
                if (subsResult.responseCode != BillingClient.BillingResponseCode.OK || inAppResult.responseCode != BillingClient.BillingResponseCode.OK) {
                    // Keep the saved status when Play can't be reached, so Pro users aren't downgraded offline.
                    Log.e("App", "Query purchases failed: ${subsResult.debugMessage} ${inAppResult.debugMessage}")
                    return@queryPurchasesAsync
                }
                val owned = (subsPurchases + inAppPurchases).filter { it.purchaseState == Purchase.PurchaseState.PURCHASED }
                val match = owned.firstOrNull { p -> p.products.any { it in PLANS } }
                val plan = match?.products?.firstOrNull { it in PLANS }?.let { PLANS[it] } ?: ""
                if (match != null) IS_PREMIUM = true
                premiumPreferences.edit()
                    .putBoolean("is_premium", match != null)
                    .putString("subscription_plan", plan)
                    .putLong("purchase_time", match?.purchaseTime ?: 0L)
                    .apply()
            }
        }
    }

    val purchaseTime: Long get() = premiumPreferences.getLong("purchase_time", 0)
    val subPrice: String get() = premiumPreferences.getString("sub_price", "") ?: ""
    val subscriptionPlan: String get() = premiumPreferences.getString("subscription_plan", "") ?: ""
    val isSubscribed: Boolean get() = premiumPreferences.getBoolean("is_premium", false)

    companion object {
        private val PLANS = mapOf("weekly_sub" to "Weekly Plan", "monthly_sub" to "Monthly Plan", "life_time" to "Lifetime")

        @JvmField var IS_PREMIUM = false
        @JvmField var context: Context? = null
        private lateinit var instance: App

        @JvmStatic fun getInstance(): App = instance
        @JvmStatic fun getContext(): Context? = context
    }
}
