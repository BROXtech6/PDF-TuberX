package com.excelto.pdf.converter.language

import android.os.Bundle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.intl.LocaleList
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.excelto.pdf.converter.R
import com.excelto.pdf.converter.StartActivity
import com.excelto.pdf.converter.core.storage.AppPrefs
import com.excelto.pdf.converter.ui.InnerHeader
import com.excelto.pdf.converter.ui.components.PrimaryButton
import com.excelto.pdf.converter.ui.theme.AppIcons
import com.excelto.pdf.converter.ui.theme.AppTheme
import com.excelto.pdf.converter.ui.theme.LocalPalette
import com.excelto.pdf.converter.ui.theme.Type

/**
 * Pick the app's language. On first launch it comes before the paywall, with the phone's
 * language already selected; from Settings it changes the language of every screen.
 * The title and button preview the selected language as the user taps.
 */
class LanguageActivity : AppCompatActivity() {

    private val firstRun get() = intent.getBooleanExtra(EXTRA_FIRST_RUN, false)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { AppTheme(AppPrefs(this).themeMode) { Screen() } }
    }

    private fun choose(language: AppLanguage.Language) {
        // Applied first, so the next screen opens in this language. Screens already open
        // (Home, when coming from Settings) reopen in it by themselves.
        if (firstRun || language != AppLanguage.current(this)) AppLanguage.apply(language)
        if (firstRun) {
            StartActivity.markLanguageAsked(this)
            StartActivity.openNext(this)
        }
        finish()
    }

    @Composable
    private fun Screen() {
        val p = LocalPalette.current
        val context = LocalContext.current
        val phone = remember { AppLanguage.phone(context) }
        val languages = remember {
            // The phone's language first, so most people only tap Continue.
            phone?.let { listOf(it) + (AppLanguage.ALL - it) } ?: AppLanguage.ALL
        }
        var tag by rememberSaveable { mutableStateOf(AppLanguage.current(context).tag) }
        val selected = AppLanguage.ALL.first { it.tag == tag }
        val res = remember(tag) { AppLanguage.resources(context, selected) }

        Column(Modifier.fillMaxSize().background(p.bg).windowInsetsPadding(WindowInsets.safeDrawing)) {
            if (firstRun) {
                Column(Modifier.fillMaxWidth().padding(start = 20.dp, end = 20.dp, top = 28.dp, bottom = 8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(res.getString(R.string.language_title), style = Type.title.copy(fontSize = 24.sp), color = p.text)
                    Text(res.getString(R.string.language_subtitle), style = Type.body, color = p.muted)
                }
            } else {
                InnerHeader(res.getString(R.string.language_title), onBack = { finish() })
            }
            LazyColumn(
                Modifier.weight(1f).fillMaxWidth(),
                contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                items(languages, key = { it.tag }) { language ->
                    LanguageRow(language, on = language.tag == tag, isPhone = language == phone, phoneLabel = res.getString(R.string.language_phone)) { tag = language.tag }
                }
            }
            Box(Modifier.fillMaxWidth().background(p.bg).padding(16.dp)) {
                PrimaryButton(res.getString(if (firstRun) R.string.language_continue else R.string.language_save), { choose(selected) })
            }
        }
    }

    @Composable
    private fun LanguageRow(language: AppLanguage.Language, on: Boolean, isPhone: Boolean, phoneLabel: String, onClick: () -> Unit) {
        val p = LocalPalette.current
        val shape = RoundedCornerShape(14.dp)
        Row(
            Modifier.fillMaxWidth().heightIn(min = 60.dp).clip(shape)
                .background(if (on) p.primarySoft else p.surface)
                .border(if (on) 2.dp else 1.dp, if (on) p.primaryText else p.line, shape)
                .selectable(selected = on, role = Role.RadioButton, onClick = onClick)
                .padding(horizontal = 16.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(Modifier.weight(1f)) {
                // Each name is shown in its own script, whatever the app's language.
                Text(
                    language.native, style = Type.bodyStrong.copy(fontSize = 16.sp, localeList = LocaleList(language.tag)),
                    color = p.text,
                )
                val sub = listOfNotNull(language.english.takeIf { it != language.native }, phoneLabel.takeIf { isPhone }).joinToString(" · ")
                if (sub.isNotEmpty()) Text(sub, style = Type.small, color = p.muted)
            }
            if (on) {
                Box(Modifier.size(24.dp).clip(CircleShape).background(p.primary), contentAlignment = Alignment.Center) {
                    Icon(AppIcons.check, null, tint = p.onPrimary, modifier = Modifier.size(14.dp))
                }
            }
        }
    }

    companion object {
        const val EXTRA_FIRST_RUN = "first_run"
    }
}
