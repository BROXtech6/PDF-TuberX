package com.excelto.pdf.converter.core.office

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.text.Layout
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.StaticLayout
import android.text.TextDirectionHeuristics
import android.text.TextPaint
import android.text.style.AbsoluteSizeSpan
import android.text.style.ForegroundColorSpan
import android.text.style.StrikethroughSpan
import android.text.style.StyleSpan
import android.text.style.SubscriptSpan
import android.text.style.SuperscriptSpan
import android.text.style.TypefaceSpan
import android.text.style.UnderlineSpan
import com.excelto.pdf.converter.core.engine.Progress
import java.io.File
import java.io.FileOutputStream
import kotlin.math.min

/** Draws [Deck.Presentation] slides into a PDF, one page per slide, with real text. */
class SlideRenderer(private val deck: Deck.Presentation, private val progress: Progress) {

    fun render(out: File): Int {
        val pdf = PdfDocument()
        try {
            val w = deck.widthPt
            val h = deck.heightPt
            deck.slides.forEachIndexed { i, slide ->
                progress.check()
                val page = pdf.startPage(PdfDocument.PageInfo.Builder(w.toInt().coerceAtLeast(1), h.toInt().coerceAtLeast(1), i + 1).create())
                val c = page.canvas
                c.clipRect(0f, 0f, w, h)
                slide.background?.let { c.drawColor(it) }
                slide.backgroundPicture?.let { drawPicture(c, it, RectF(0f, 0f, w, h)) }
                for (e in slide.elements) runCatching { draw(c, e) }
                pdf.finishPage(page)
                progress.step(i + 1, deck.slides.size, 20, 92)
            }
            FileOutputStream(out).use { pdf.writeTo(it) }
            return deck.slides.size
        } finally {
            pdf.close()
        }
    }

    private fun draw(c: Canvas, e: Deck.Element) {
        val b = e.box
        c.save()
        if (b.rotation != 0f) c.rotate(b.rotation, b.x + b.w / 2, b.y + b.h / 2)
        when (e) {
            is Deck.Shape -> shape(c, e)
            is Deck.Pic -> {
                val r = RectF(b.x, b.y, b.x + b.w, b.y + b.h)
                if (e.geometry == "ellipse" || e.geometry == "roundRect") {
                    c.save()
                    c.clipPath(path(e.geometry, r, null))
                    drawPicture(c, e.picture, r, b.flipH, b.flipV)
                    c.restore()
                } else {
                    drawPicture(c, e.picture, r, b.flipH, b.flipV)
                }
                e.line?.let { stroke(c, path(e.geometry, r, null), it, e.lineWidth, false) }
            }
            is Deck.Table -> table(c, e)
        }
        c.restore()
    }

    // ---- Shapes -----------------------------------------------------------------------------

    private fun shape(c: Canvas, s: Deck.Shape) {
        val b = s.box
        val r = RectF(b.x, b.y, b.x + b.w, b.y + b.h)
        if (s.geometry == "line" || s.geometry.startsWith("straightConnector") || s.geometry.contains("Connector")) {
            val line = s.line ?: return
            val x1 = if (b.flipH) r.right else r.left
            val x2 = if (b.flipH) r.left else r.right
            val y1 = if (b.flipV) r.bottom else r.top
            val y2 = if (b.flipV) r.top else r.bottom
            c.drawLine(x1, y1, x2, y2, strokePaint(line, s.lineWidth, s.dashed))
            return
        }
        val p = path(s.geometry, r, s.adjust)
        s.fill?.let { c.drawPath(p, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = it; style = Paint.Style.FILL }) }
        s.fillPicture?.let { pic -> c.save(); c.clipPath(p); drawPicture(c, pic, r); c.restore() }
        s.line?.let { stroke(c, p, it, s.lineWidth, s.dashed) }
        s.text?.let { text(c, it, r) }
    }

    private fun strokePaint(color: Int, width: Float, dashed: Boolean) = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        this.color = color
        style = Paint.Style.STROKE
        strokeWidth = width.coerceAtLeast(0.25f)
        if (dashed) pathEffect = DashPathEffect(floatArrayOf(width * 4, width * 3), 0f)
    }

    private fun stroke(c: Canvas, p: Path, color: Int, width: Float, dashed: Boolean) = c.drawPath(p, strokePaint(color, width, dashed))

    /** The outline of common preset shapes; others fall back to their bounding rectangle. */
    private fun path(geom: String, r: RectF, adjust: Float?): Path = Path().apply {
        val w = r.width(); val h = r.height()
        when (geom) {
            "ellipse", "flowChartConnector" -> addOval(r, Path.Direction.CW)
            "roundRect", "flowChartAlternateProcess" -> {
                val rad = min(w, h) * (adjust ?: 0.16667f)
                addRoundRect(r, rad, rad, Path.Direction.CW)
            }
            "triangle", "flowChartExtract" -> { moveTo(r.left + w * (adjust ?: 0.5f), r.top); lineTo(r.right, r.bottom); lineTo(r.left, r.bottom); close() }
            "rtTriangle" -> { moveTo(r.left, r.top); lineTo(r.right, r.bottom); lineTo(r.left, r.bottom); close() }
            "diamond", "flowChartDecision" -> { moveTo(r.centerX(), r.top); lineTo(r.right, r.centerY()); lineTo(r.centerX(), r.bottom); lineTo(r.left, r.centerY()); close() }
            "parallelogram", "flowChartInputOutput" -> { val o = min(w, h) * (adjust ?: 0.25f); moveTo(r.left + o, r.top); lineTo(r.right, r.top); lineTo(r.right - o, r.bottom); lineTo(r.left, r.bottom); close() }
            "trapezoid" -> { val o = min(w, h) * (adjust ?: 0.25f); moveTo(r.left + o, r.top); lineTo(r.right - o, r.top); lineTo(r.right, r.bottom); lineTo(r.left, r.bottom); close() }
            "hexagon" -> { val o = min(w, h) * (adjust ?: 0.25f); moveTo(r.left + o, r.top); lineTo(r.right - o, r.top); lineTo(r.right, r.centerY()); lineTo(r.right - o, r.bottom); lineTo(r.left + o, r.bottom); lineTo(r.left, r.centerY()); close() }
            "pentagon", "homePlate" -> { val o = min(w, h) * (adjust ?: 0.5f); moveTo(r.left, r.top); lineTo(r.right - o, r.top); lineTo(r.right, r.centerY()); lineTo(r.right - o, r.bottom); lineTo(r.left, r.bottom); close() }
            "chevron" -> { val o = min(w, h) * (adjust ?: 0.5f); moveTo(r.left, r.top); lineTo(r.right - o, r.top); lineTo(r.right, r.centerY()); lineTo(r.right - o, r.bottom); lineTo(r.left, r.bottom); lineTo(r.left + o, r.centerY()); close() }
            "rightArrow" -> { val head = min(w * 0.5f, h); val t = h * 0.25f; moveTo(r.left, r.top + t); lineTo(r.right - head, r.top + t); lineTo(r.right - head, r.top); lineTo(r.right, r.centerY()); lineTo(r.right - head, r.bottom); lineTo(r.right - head, r.bottom - t); lineTo(r.left, r.bottom - t); close() }
            "leftArrow" -> { val head = min(w * 0.5f, h); val t = h * 0.25f; moveTo(r.right, r.top + t); lineTo(r.left + head, r.top + t); lineTo(r.left + head, r.top); lineTo(r.left, r.centerY()); lineTo(r.left + head, r.bottom); lineTo(r.left + head, r.bottom - t); lineTo(r.right, r.bottom - t); close() }
            "snip1Rect" -> { val o = min(w, h) * (adjust ?: 0.16667f); moveTo(r.left, r.top); lineTo(r.right - o, r.top); lineTo(r.right, r.top + o); lineTo(r.right, r.bottom); lineTo(r.left, r.bottom); close() }
            "round2SameRect" -> { val rad = min(w, h) * (adjust ?: 0.16667f); addRoundRect(r, floatArrayOf(rad, rad, rad, rad, 0f, 0f, 0f, 0f), Path.Direction.CW) }
            else -> addRect(r, Path.Direction.CW)
        }
    }

    // ---- Pictures ---------------------------------------------------------------------------

    private fun drawPicture(c: Canvas, pic: Deck.Picture, r: RectF, flipH: Boolean = false, flipV: Boolean = false) {
        val bmp = pic.bytes?.let { decode(it, r.width(), r.height()) }
        if (bmp == null) {
            c.drawRect(r, Paint().apply { color = 0xFFF1F3F4.toInt() })
            c.drawRect(r, Paint().apply { color = 0xFFBDC1C6.toInt(); style = Paint.Style.STROKE; strokeWidth = 0.75f })
            val tp = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { textSize = (min(r.width(), r.height()) / 8f).coerceIn(6f, 16f); color = 0xFF5F6368.toInt(); textAlign = Paint.Align.CENTER }
            c.drawText(pic.note ?: "Picture", r.centerX(), r.centerY() + tp.textSize / 3, tp)
            return
        }
        val src = pic.crop?.let { k ->
            Rect(
                (bmp.width * k[0]).toInt().coerceIn(0, bmp.width - 1),
                (bmp.height * k[1]).toInt().coerceIn(0, bmp.height - 1),
                (bmp.width * (1 - k[2])).toInt().coerceIn(1, bmp.width),
                (bmp.height * (1 - k[3])).toInt().coerceIn(1, bmp.height),
            ).takeIf { it.width() > 0 && it.height() > 0 }
        }
        c.save()
        if (flipH || flipV) c.scale(if (flipH) -1f else 1f, if (flipV) -1f else 1f, r.centerX(), r.centerY())
        c.drawBitmap(bmp, src, r, Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG))
        c.restore()
        bmp.recycle()
    }

    private fun decode(bytes: ByteArray, wPt: Float, hPt: Float): Bitmap? = runCatching {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
        if (bounds.outWidth <= 0) return null
        val tw = (wPt * 220f / 72f).coerceAtLeast(1f)
        val th = (hPt * 220f / 72f).coerceAtLeast(1f)
        var sample = 1
        while (bounds.outWidth / (sample * 2) >= tw && bounds.outHeight / (sample * 2) >= th) sample *= 2
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, BitmapFactory.Options().apply { inSampleSize = sample })
    }.getOrNull()

    // ---- Text -------------------------------------------------------------------------------

    private class Line(val layout: StaticLayout, val x: Float, val before: Float, val after: Float, val bullet: String?, val bulletPaint: TextPaint?, val bulletX: Float)

    private fun layouts(t: Deck.Text, width: Float, scale: Float): List<Line> = t.paras.map { p ->
        val sb = SpannableStringBuilder()
        for (r in p.runs) {
            val s = sb.length
            sb.append(r.text)
            val e = sb.length
            if (s == e) continue
            fun span(o: Any) = sb.setSpan(o, s, e, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            span(AbsoluteSizeSpan((r.sizePt * scale * (if (r.baseline != 0) 0.7f else 1f)).toInt().coerceAtLeast(1)))
            span(ForegroundColorSpan(r.color))
            when {
                r.bold && r.italic -> span(StyleSpan(Typeface.BOLD_ITALIC))
                r.bold -> span(StyleSpan(Typeface.BOLD))
                r.italic -> span(StyleSpan(Typeface.ITALIC))
            }
            if (r.underline) span(UnderlineSpan())
            if (r.strike) span(StrikethroughSpan())
            span(TypefaceSpan(FlowRenderer.family(r.font)))
            if (r.baseline > 0) span(SuperscriptSpan()) else if (r.baseline < 0) span(SubscriptSpan())
        }
        if (sb.isEmpty()) {
            sb.append(" ")
            sb.setSpan(AbsoluteSizeSpan((p.endSize * scale).toInt().coerceAtLeast(1)), 0, 1, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        }
        val left = p.marginLeft * scale
        val boxW = (width - left).coerceAtLeast(10f)
        val paint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { textSize = p.endSize * scale }
        fun build(mult: Float) = StaticLayout.Builder.obtain(sb, 0, sb.length, paint, boxW.toInt().coerceAtLeast(1))
            // PowerPoint's left/right are physical sides; Android's are start/end.
            .setAlignment(when {
                p.align == Deck.Align.CENTER -> Layout.Alignment.ALIGN_CENTER
                (p.align == Deck.Align.RIGHT) != p.rtl -> Layout.Alignment.ALIGN_OPPOSITE
                else -> Layout.Alignment.ALIGN_NORMAL
            })
            .setTextDirection(if (p.rtl) TextDirectionHeuristics.RTL else TextDirectionHeuristics.FIRSTSTRONG_LTR)
            .setJustificationMode(if (p.align == Deck.Align.JUSTIFY) Layout.JUSTIFICATION_MODE_INTER_WORD else Layout.JUSTIFICATION_MODE_NONE)
            .setLineSpacing(0f, mult)
            .setIncludePad(false)
            .setMaxLines(if (t.wrap) Int.MAX_VALUE else Int.MAX_VALUE)
            .build()
        var layout = build(p.lineSpacing.coerceIn(0.5f, 4f) * 0.98f)
        p.lineExact?.let { exact ->
            val natural = layout.height.toFloat() / layout.lineCount.coerceAtLeast(1)
            if (natural > 0f) layout = build((exact * scale / natural).coerceIn(0.4f, 6f))
        }
        var bulletPaint: TextPaint? = null
        var bulletX = 0f
        if (p.bullet != null) {
            val first = p.runs.firstOrNull { it.text.isNotBlank() }
            bulletPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
                textSize = (first?.sizePt ?: p.endSize) * scale
                color = p.bulletColor ?: first?.color ?: 0xFF000000.toInt()
                typeface = Typeface.create(FlowRenderer.family(first?.font), Typeface.NORMAL)
            }
            bulletX = (p.marginLeft + p.indent) * scale
        }
        Line(layout, left, p.spaceBefore * scale, p.spaceAfter * scale, p.bullet, bulletPaint, bulletX)
    }

    private fun text(c: Canvas, t: Deck.Text, r: RectF) {
        if (t.paras.isEmpty()) return
        val vertical = t.vertical
        val boxW = (if (vertical) r.height() else r.width()) - t.left - t.right
        val boxH = (if (vertical) r.width() else r.height()) - t.top - t.bottom
        if (boxW <= 2f) return
        val width = if (t.wrap) boxW else 10_000f
        var scale = 1f
        var lines = layouts(t, width, scale)
        fun height(ls: List<Line>) = ls.foldIndexed(0f) { i, acc, l -> acc + (if (i > 0) l.before else 0f) + l.layout.height + (if (i < ls.lastIndex) l.after else 0f) }
        var total = height(lines)
        // Shrink-on-overflow boxes that still overflow (fonts differ from PowerPoint's) are fitted.
        if (t.shrinkOnOverflow && total > boxH && boxH > 0f) {
            var tries = 0
            while (total > boxH && tries++ < 8) {
                scale *= (boxH / total).coerceIn(0.6f, 0.95f)
                lines = layouts(t, width, scale)
                total = height(lines)
            }
        }
        c.save()
        if (vertical) {
            c.rotate(90f, r.left, r.top)
            c.translate(0f, -r.width())
        }
        val ox = r.left + t.left
        var y = r.top + t.top + when (t.anchor) {
            Deck.Anchor.TOP -> 0f
            Deck.Anchor.MIDDLE -> (boxH - total) / 2
            Deck.Anchor.BOTTOM -> boxH - total
        }
        val xShift = if (!t.wrap) when (t.paras.first().align) {
            Deck.Align.CENTER -> -(width - boxW) / 2
            Deck.Align.RIGHT -> -(width - boxW)
            else -> 0f
        } else 0f
        lines.forEachIndexed { i, l ->
            if (i > 0) y += l.before
            c.save()
            c.translate(ox + l.x + xShift, y)
            l.layout.draw(c)
            c.restore()
            if (l.bullet != null && l.bulletPaint != null) {
                c.drawText(l.bullet, ox + l.bulletX + xShift, y + l.layout.getLineBaseline(0), l.bulletPaint)
            }
            y += l.layout.height + l.after
        }
        c.restore()
    }

    // ---- Tables -----------------------------------------------------------------------------

    private fun table(c: Canvas, t: Deck.Table) {
        val b = t.box
        val colX = FloatArray(t.columns.size + 1)
        colX[0] = b.x
        val sum = t.columns.sum().takeIf { it > 0f } ?: 1f
        val scaleX = if (sum > 0f && b.w > 0f) b.w / sum else 1f
        for (i in t.columns.indices) colX[i + 1] = colX[i] + t.columns[i] * scaleX
        // Rows grow to fit their text, like PowerPoint.
        val heights = t.rows.map { row ->
            var col = 0
            var need = row.height
            for (cell in row.cells) {
                val end = (col + cell.span).coerceAtMost(t.columns.size)
                if (!cell.merged && cell.rowSpan == 1 && end > col) {
                    val w = colX[end] - colX[col] - cell.text.left - cell.text.right
                    if (w > 2f) {
                        val ls = layouts(cell.text, w, 1f)
                        val h = ls.sumOf { (it.layout.height + it.before + it.after).toDouble() }.toFloat() + cell.text.top + cell.text.bottom
                        need = maxOf(need, h)
                    }
                }
                col = end
            }
            need
        }
        val rowY = FloatArray(t.rows.size + 1)
        rowY[0] = b.y
        for (i in t.rows.indices) rowY[i + 1] = rowY[i] + heights[i]
        val border = t.borders?.let { strokePaint(it, if (it == 0xFFFFFFFF.toInt()) 1f else 0.75f, false) }
        t.rows.forEachIndexed { ri, row ->
            var col = 0
            for (cell in row.cells) {
                if (col >= t.columns.size) break
                val end = (col + cell.span).coerceAtMost(t.columns.size)
                val bottomRow = (ri + cell.rowSpan).coerceAtMost(t.rows.size)
                val r = RectF(colX[col], rowY[ri], colX[end], rowY[bottomRow])
                if (!cell.merged) {
                    cell.fill?.let { c.drawRect(r, Paint().apply { color = it }) }
                    text(c, cell.text, r)
                    border?.let { c.drawRect(r, it) }
                }
                col = end
            }
        }
    }
}
