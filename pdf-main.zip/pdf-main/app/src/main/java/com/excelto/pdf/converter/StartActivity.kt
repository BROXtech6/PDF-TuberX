package com.excelto.pdf.converter

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import com.excelto.pdf.converter.app.App
import com.excelto.pdf.converter.language.LanguageActivity
import com.excelto.pdf.converter.subscription.SubscriptionActivity
import com.github.ybq.android.spinkit.SpinKitView
import com.github.ybq.android.spinkit.style.ThreeBounce

/**
 * Splash screen. Moves on as soon as the first frame is drawn. On the very first launch
 * the user picks a language (the phone's is preselected), then free users see the
 * paywall once, in that language; after that the paywall only appears for Pro tools or
 * when they tap Get Pro. People updating from an earlier version skip both.
 */
class StartActivity : AppCompatActivity() {

    private var moved = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        WindowCompat.getInsetsController(window, window.decorView).isAppearanceLightStatusBars = true
        setContentView(R.layout.activity_start)
        val root = findViewById<android.view.View>(R.id.main)
        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(bars.left, bars.top, bars.right, bars.bottom)
            insets
        }
        findViewById<SpinKitView>(R.id.spinKit).setIndeterminateDrawable(ThreeBounce())
        root.post { moveNextActivity() }
    }

    private fun moveNextActivity() {
        if (moved || isFinishing) return
        moved = true
        val prefs = getSharedPreferences(PREFS, MODE_PRIVATE)
        val firstLaunch = !prefs.getBoolean(KEY_PAYWALL_SHOWN, false)
        if (firstLaunch && !prefs.getBoolean(KEY_LANGUAGE_ASKED, false)) {
            startActivity(Intent(this, LanguageActivity::class.java).putExtra(LanguageActivity.EXTRA_FIRST_RUN, true))
        } else {
            openNext(this)
        }
        finish()
    }

    companion object {
        private const val PREFS = "start_prefs"
        private const val KEY_PAYWALL_SHOWN = "first_paywall_shown"
        private const val KEY_LANGUAGE_ASKED = "first_language_asked"

        fun markLanguageAsked(context: Context) {
            context.getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean(KEY_LANGUAGE_ASKED, true).apply()
        }

        /** Opens the paywall on the first launch (free users, online), else Home. */
        fun openNext(activity: Activity) {
            val prefs = activity.getSharedPreferences(PREFS, MODE_PRIVATE)
            val firstLaunch = !prefs.getBoolean(KEY_PAYWALL_SHOWN, false)
            val showPaywall = firstLaunch && !App.getInstance().isSubscribed && NoInternetActivity.isNetworkAvailable(activity)
            if (firstLaunch) prefs.edit().putBoolean(KEY_PAYWALL_SHOWN, true).apply()
            val next = if (showPaywall) {
                Intent(activity, SubscriptionActivity::class.java).putExtra("sub", "start_activity")
            } else {
                Intent(activity, MainActivity::class.java)
            }
            activity.startActivity(next)
        }
    }
}
