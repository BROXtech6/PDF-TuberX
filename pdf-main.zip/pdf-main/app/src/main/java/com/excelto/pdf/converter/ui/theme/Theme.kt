package com.excelto.pdf.converter.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import com.excelto.pdf.converter.R
import com.excelto.pdf.converter.core.storage.ThemeMode

/** Color tokens, matching the Advanced prototype exactly. */
@Immutable
data class Palette(
    val bg: Color,
    val surface: Color,
    val text: Color,
    val muted: Color,
    val line: Color,
    val primary: Color,
    val onPrimary: Color,
    val primaryText: Color,
    val primarySoft: Color,
    val danger: Color,
    val viewer: Color,
    val ink: Color,
    val onInk: Color,
    val inkMuted: Color,
    val mint: Color,
    val ai: Color,
    val aiText: Color,
    val aiSoft: Color,
    val aiLine: Color,
    val isDark: Boolean,
)

val LightPalette = Palette(
    bg = Color(0xFFF3F5F4), surface = Color(0xFFFFFFFF), text = Color(0xFF1F2733), muted = Color(0xFF5F6670),
    line = Color(0xFFE2E6E4), primary = Color(0xFF217346), onPrimary = Color(0xFFFFFFFF), primaryText = Color(0xFF217346),
    primarySoft = Color(0xFFE6F4EA), danger = Color(0xFFB3261E), viewer = Color(0xFFDCE0E4), ink = Color(0xFF0F2A1D),
    onInk = Color(0xFFFFFFFF), inkMuted = Color(0xFFB9CDC1), mint = Color(0xFF7BD99A), ai = Color(0xFF6A35A8),
    aiText = Color(0xFF5B2C93), aiSoft = Color(0xFFF1EAFA), aiLine = Color(0xFFD9C7F0), isDark = false,
)

val DarkPalette = Palette(
    bg = Color(0xFF0F1419), surface = Color(0xFF1A2129), text = Color(0xFFEEF1F4), muted = Color(0xFFA8B0BA),
    line = Color(0xFF2E3843), primary = Color(0xFF7BD99A), onPrimary = Color(0xFF0E2A18), primaryText = Color(0xFF7BD99A),
    primarySoft = Color(0xFF1C3527), danger = Color(0xFFFF9B93), viewer = Color(0xFF0A0E12), ink = Color(0xFF14271D),
    onInk = Color(0xFFFFFFFF), inkMuted = Color(0xFFA9C2B3), mint = Color(0xFF7BD99A), ai = Color(0xFF8B5CD0),
    aiText = Color(0xFFCDB4F2), aiSoft = Color(0xFF261C35), aiLine = Color(0xFF46356A), isDark = true,
)

/** Tool icon tints: soft background + strong foreground, same in light and dark. */
@Immutable
data class Tint(val soft: Color, val strong: Color)

object Tints {
    val violet = Tint(Color(0xFFEDE3F8), Color(0xFF6A35A8))
    val green = Tint(Color(0xFFDDF2E3), Color(0xFF217346))
    val blue = Tint(Color(0xFFDCE8FA), Color(0xFF1D5FBF))
    val red = Tint(Color(0xFFFBE3E1), Color(0xFFB3261E))
    val amber = Tint(Color(0xFFF7EFD2), Color(0xFF7A5F00))
    val teal = Tint(Color(0xFFDDEFF2), Color(0xFF14788A))
    val orange = Tint(Color(0xFFFCE5D6), Color(0xFFB7472A))
    val navy = Tint(Color(0xFFDDE3F2), Color(0xFF1F3A6E))
}

val Inter = FontFamily(
    Font(R.font.inter_regular, FontWeight.Normal),
    Font(R.font.inter_medium, FontWeight.Medium),
    Font(R.font.inter_semibold, FontWeight.SemiBold),
    Font(R.font.inter_bold, FontWeight.Bold),
    Font(R.font.inter_black, FontWeight.ExtraBold),
)

/** Text sizes used in the prototype. */
object Type {
    val title = TextStyle(fontFamily = Inter, fontWeight = FontWeight.ExtraBold, fontSize = 22.sp, letterSpacing = (-0.2).sp)
    val hero = TextStyle(fontFamily = Inter, fontWeight = FontWeight.ExtraBold, fontSize = 24.sp, lineHeight = 30.sp)
    val section = TextStyle(fontFamily = Inter, fontWeight = FontWeight.Bold, fontSize = 14.sp)
    val bodyStrong = TextStyle(fontFamily = Inter, fontWeight = FontWeight.Bold, fontSize = 13.sp)
    val body = TextStyle(fontFamily = Inter, fontWeight = FontWeight.Normal, fontSize = 13.sp, lineHeight = 18.sp)
    val small = TextStyle(fontFamily = Inter, fontWeight = FontWeight.Normal, fontSize = 12.sp, lineHeight = 16.sp)
    val tiny = TextStyle(fontFamily = Inter, fontWeight = FontWeight.Bold, fontSize = 11.sp)
    val button = TextStyle(fontFamily = Inter, fontWeight = FontWeight.Bold, fontSize = 15.sp)
    val stat = TextStyle(fontFamily = Inter, fontWeight = FontWeight.ExtraBold, fontSize = 22.sp)
}

val LocalPalette = staticCompositionLocalOf { LightPalette }

@Composable
fun AppTheme(mode: ThemeMode, content: @Composable () -> Unit) {
    val dark = when (mode) {
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
        ThemeMode.LIGHT -> false
        ThemeMode.DARK -> true
    }
    val p = if (dark) DarkPalette else LightPalette
    val scheme = if (dark) {
        darkColorScheme(primary = p.primary, onPrimary = p.onPrimary, background = p.bg, surface = p.surface, onSurface = p.text, onBackground = p.text, error = p.danger, outline = p.line)
    } else {
        lightColorScheme(primary = p.primary, onPrimary = p.onPrimary, background = p.bg, surface = p.surface, onSurface = p.text, onBackground = p.text, error = p.danger, outline = p.line)
    }
    CompositionLocalProvider(LocalPalette provides p) {
        MaterialTheme(colorScheme = scheme, typography = MaterialTheme.typography.let { t ->
            t.copy(
                bodyLarge = t.bodyLarge.copy(fontFamily = Inter),
                bodyMedium = t.bodyMedium.copy(fontFamily = Inter),
                labelLarge = t.labelLarge.copy(fontFamily = Inter),
                titleLarge = t.titleLarge.copy(fontFamily = Inter),
                titleMedium = t.titleMedium.copy(fontFamily = Inter),
                headlineSmall = t.headlineSmall.copy(fontFamily = Inter),
            )
        }, content = content)
    }
}
