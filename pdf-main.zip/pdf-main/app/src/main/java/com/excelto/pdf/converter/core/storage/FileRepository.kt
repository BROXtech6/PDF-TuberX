package com.excelto.pdf.converter.core.storage

import android.content.Context
import android.net.Uri
import android.os.Environment
import android.provider.MediaStore
import android.provider.OpenableColumns
import com.excelto.pdf.converter.core.model.DocFile
import com.excelto.pdf.converter.core.model.DocType
import com.excelto.pdf.converter.core.model.Source
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

/**
 * Finds the user's documents: files this app made (Documents/ExcelToPdf) plus PDFs and
 * spreadsheets elsewhere on the phone when "All files access" is allowed. Files from
 * Google Drive, Dropbox or OneDrive come in through the system picker ([import]).
 */
class FileRepository(private val context: Context, private val prefs: AppPrefs) {

    private val mimeTypes = arrayOf(
        "application/pdf",
        "application/vnd.ms-excel",
        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        "text/csv",
        "application/msword",
        "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        "application/vnd.ms-powerpoint",
        "application/vnd.openxmlformats-officedocument.presentationml.presentation",
        "text/html",
    )

    fun hasAllFilesAccess(): Boolean = Environment.isExternalStorageManager()

    suspend fun scan(): List<DocFile> = withContext(Dispatchers.IO) {
        val favorites = prefs.favorites
        val byPath = LinkedHashMap<String, DocFile>()

        OutputFiles.root.takeIf { it.exists() }?.walkTopDown()?.forEach { file ->
            if (file.isFile && DocType.of(file.name) != DocType.OTHER) {
                byPath[file.absolutePath] = DocFile.from(file, Source.CREATED, file.absolutePath in favorites)
            }
        }

        if (hasAllFilesAccess()) {
            val placeholders = mimeTypes.joinToString(",") { "?" }
            runCatching {
                context.contentResolver.query(
                    MediaStore.Files.getContentUri("external"),
                    arrayOf(MediaStore.Files.FileColumns.DATA),
                    "${MediaStore.Files.FileColumns.MIME_TYPE} IN ($placeholders)",
                    mimeTypes,
                    "${MediaStore.Files.FileColumns.DATE_MODIFIED} DESC",
                )?.use { cursor ->
                    val column = cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns.DATA)
                    while (cursor.moveToNext()) {
                        val path = cursor.getString(column) ?: continue
                        if (path in byPath) continue
                        val file = File(path)
                        if (file.isFile && file.length() > 0) byPath[path] = DocFile.from(file, Source.PHONE, path in favorites)
                    }
                }
            }
        }

        prefs.imported.mapNotNull { path -> File(path).takeIf { it.isFile } }.forEach { file ->
            if (file.absolutePath !in byPath) byPath[file.absolutePath] = DocFile.from(file, Source.IMPORTED, file.absolutePath in favorites)
        }

        byPath.values.sortedByDescending { it.modified }
    }

    /** Copies a file picked from another app or a cloud drive so the tools can read it. */
    suspend fun import(uri: Uri): DocFile = withContext(Dispatchers.IO) {
        val resolver = context.contentResolver
        val name = resolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) c.getString(0) else null
        } ?: "Document_${System.currentTimeMillis()}.pdf"
        val dir = OutputFiles.cache(context, "imports/${System.currentTimeMillis()}")
        val target = File(dir, OutputFiles.sanitize(name))
        resolver.openInputStream(uri)?.use { input -> target.outputStream().use { input.copyTo(it) } }
            ?: throw IllegalStateException("Couldn't open that file")
        prefs.addImported(target.absolutePath)
        DocFile.from(target, Source.IMPORTED)
    }

    fun rename(file: DocFile, newName: String): DocFile? {
        val clean = OutputFiles.sanitize(newName).ifBlank { return null }
        val withExt = if (clean.contains('.')) clean else "$clean.${file.name.substringAfterLast('.')}"
        val target = File(file.file.parentFile, withExt)
        if (target.exists() || !file.file.renameTo(target)) return null
        OutputFiles.publish(context, listOf(target))
        if (file.favorite) { prefs.toggleFavorite(file.path); prefs.toggleFavorite(target.absolutePath) }
        return DocFile.from(target, file.source, file.favorite)
    }

    fun delete(file: DocFile): Boolean {
        val ok = file.file.delete()
        if (ok) {
            OutputFiles.publish(context, listOf(file.file))
            if (file.favorite) prefs.toggleFavorite(file.path)
        }
        return ok
    }
}
