package com.excelto.pdf.converter.core.excel

import java.math.BigDecimal
import java.math.MathContext
import java.math.RoundingMode
import java.time.LocalDate
import java.time.format.TextStyle
import java.util.Locale
import kotlin.math.abs
import kotlin.math.floor
import kotlin.math.log10
import kotlin.math.pow
import kotlin.math.roundToLong

/**
 * Formats cell values the way Excel shows them, from the cell's number format code.
 * Supports General, digit placeholders (0 # ?), thousands separators and scaling,
 * percent, scientific, simple fractions, currency and literal text, up to four
 * sections (positive;negative;zero;text), conditions, color tags, and dates and times
 * (including elapsed [h]:mm). Pure Kotlin: no Android classes, unit tested on the JVM.
 */
object NumberFormatter {

    /** The text to show and an optional color from a tag like [Red] (ARGB). */
    data class Result(val text: String, val color: Int? = null)

    private val builtIns = mapOf(
        0 to "General", 1 to "0", 2 to "0.00", 3 to "#,##0", 4 to "#,##0.00",
        5 to "\$#,##0_);(\$#,##0)", 6 to "\$#,##0_);[Red](\$#,##0)",
        7 to "\$#,##0.00_);(\$#,##0.00)", 8 to "\$#,##0.00_);[Red](\$#,##0.00)",
        9 to "0%", 10 to "0.00%", 11 to "0.00E+00", 12 to "# ?/?", 13 to "# ??/??",
        14 to "m/d/yyyy", 15 to "d-mmm-yy", 16 to "d-mmm", 17 to "mmm-yy",
        18 to "h:mm AM/PM", 19 to "h:mm:ss AM/PM", 20 to "h:mm", 21 to "h:mm:ss", 22 to "m/d/yyyy h:mm",
        37 to "#,##0 ;(#,##0)", 38 to "#,##0 ;[Red](#,##0)", 39 to "#,##0.00;(#,##0.00)", 40 to "#,##0.00;[Red](#,##0.00)",
        41 to "_(* #,##0_);_(* (#,##0);_(* \"-\"_);_(@_)",
        42 to "_(\"\$\"* #,##0_);_(\"\$\"* (#,##0);_(\"\$\"* \"-\"_);_(@_)",
        43 to "_(* #,##0.00_);_(* (#,##0.00);_(* \"-\"??_);_(@_)",
        44 to "_(\"\$\"* #,##0.00_);_(\"\$\"* (#,##0.00);_(\"\$\"* \"-\"??_);_(@_)",
        45 to "mm:ss", 46 to "[h]:mm:ss", 47 to "mm:ss.0", 48 to "##0.0E+0", 49 to "@",
    )

    /** The format code for a built-in number format id, or null if unknown. */
    fun builtIn(id: Int): String? = builtIns[id] ?: when (id) {
        in 27..36, in 50..58 -> "m/d/yyyy" // East Asian locale dates
        else -> null
    }

    // ---- Tokens ------------------------------------------------------------------

    private sealed interface Tok
    private data class Lit(val text: String) : Tok
    private data class Digit(val kind: Char) : Tok
    private data object Dot : Tok
    private data object Comma : Tok
    private data object Percent : Tok
    private data class Exp(val plus: Boolean) : Tok
    private data object TextAt : Tok
    private data object Slash : Tok
    private data object GeneralTok : Tok
    private data class DatePart(var kind: Char, val count: Int, val elapsed: Boolean = false) : Tok
    private data class FracSec(val digits: Int) : Tok
    private data class AmPm(val full: Boolean, val lower: Boolean) : Tok

    private class Section(val tokens: List<Tok>, val color: Int?, val condition: Pair<String, Double>?) {
        val isDate = tokens.any { it is DatePart || it is AmPm || it is FracSec }
        val hasText = tokens.any { it is TextAt }
        val hasDigits = tokens.any { it is Digit || it is GeneralTok }
    }

    private val colorNames = mapOf(
        "black" to 0xFF000000.toInt(), "blue" to 0xFF0000FF.toInt(), "cyan" to 0xFF00FFFF.toInt(),
        "green" to 0xFF00FF00.toInt(), "magenta" to 0xFFFF00FF.toInt(), "red" to 0xFFFF0000.toInt(),
        "white" to 0xFFFFFFFF.toInt(), "yellow" to 0xFFFFFF00.toInt(),
    )

    private val cache = object : LinkedHashMap<String, List<Section>>(64, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, List<Section>>?) = size > 256
    }

    private fun sections(code: String): List<Section> = synchronized(cache) {
        cache.getOrPut(code) { splitSections(code).map { parseSection(it) } }
    }

    private fun splitSections(code: String): List<String> {
        val out = mutableListOf<String>()
        val sb = StringBuilder()
        var quoted = false
        var bracket = false
        var i = 0
        while (i < code.length) {
            val c = code[i]
            when {
                c == '\\' && !quoted && i + 1 < code.length -> { sb.append(c).append(code[i + 1]); i++ }
                c == '"' -> { quoted = !quoted; sb.append(c) }
                c == '[' && !quoted -> { bracket = true; sb.append(c) }
                c == ']' && !quoted -> { bracket = false; sb.append(c) }
                c == ';' && !quoted && !bracket -> { out += sb.toString(); sb.setLength(0) }
                else -> sb.append(c)
            }
            i++
        }
        out += sb.toString()
        return out
    }

    private fun parseSection(s: String): Section {
        val tokens = mutableListOf<Tok>()
        var color: Int? = null
        var condition: Pair<String, Double>? = null
        var i = 0
        fun run(ch: Char): Int {
            var n = 0
            while (i + n < s.length && s[i + n].equals(ch, ignoreCase = true)) n++
            return n
        }
        while (i < s.length) {
            val c = s[i]
            when {
                c == '"' -> {
                    val end = s.indexOf('"', i + 1).let { if (it < 0) s.length else it }
                    tokens += Lit(s.substring(i + 1, end)); i = end + 1
                }
                c == '\\' -> { if (i + 1 < s.length) tokens += Lit(s[i + 1].toString()); i += 2 }
                c == '_' -> { tokens += Lit(" "); i += 2 }
                c == '*' -> i += 2 // fill character: ignored
                c == '[' -> {
                    val end = s.indexOf(']', i).let { if (it < 0) s.length else it }
                    val inner = s.substring(i + 1, end)
                    val lower = inner.lowercase()
                    when {
                        lower in colorNames -> color = colorNames[lower]
                        lower.startsWith("color") -> lower.removePrefix("color").toIntOrNull()?.let { color = ExcelColors.indexed(it + 7) }
                        inner.startsWith("$") -> tokens += Lit(inner.substring(1).substringBefore('-'))
                        Regex("^(<=|>=|<>|<|>|=)\\s*(-?[\\d.]+)$").matches(inner) -> {
                            val m = Regex("^(<=|>=|<>|<|>|=)\\s*(-?[\\d.]+)$").find(inner)!!
                            condition = m.groupValues[1] to m.groupValues[2].toDouble()
                        }
                        Regex("^[hH]+$").matches(inner) -> tokens += DatePart('h', inner.length, elapsed = true)
                        Regex("^[mM]+$").matches(inner) -> tokens += DatePart('n', inner.length, elapsed = true)
                        Regex("^[sS]+$").matches(inner) -> tokens += DatePart('s', inner.length, elapsed = true)
                        else -> Unit // locale and other tags
                    }
                    i = end + 1
                }
                c == '0' || c == '#' || c == '?' -> { tokens += Digit(c); i++ }
                c == '.' -> {
                    val lastDate = tokens.lastOrNull { it is DatePart || it is Digit }
                    if (lastDate is DatePart && lastDate.kind == 's' && i + 1 < s.length && s[i + 1] == '0') {
                        var n = 0
                        while (i + 1 + n < s.length && s[i + 1 + n] == '0') n++
                        tokens += FracSec(n); i += 1 + n
                    } else { tokens += Dot; i++ }
                }
                c == ',' -> { tokens += Comma; i++ }
                c == '%' -> { tokens += Percent; i++ }
                (c == 'E' || c == 'e') && i + 1 < s.length && (s[i + 1] == '+' || s[i + 1] == '-') -> { tokens += Exp(s[i + 1] == '+'); i += 2 }
                c == '@' -> { tokens += TextAt; i++ }
                s.regionMatches(i, "General", 0, 7, ignoreCase = true) -> { tokens += GeneralTok; i += 7 }
                s.regionMatches(i, "AM/PM", 0, 5, ignoreCase = true) -> { tokens += AmPm(true, s[i] == 'a'); i += 5 }
                s.regionMatches(i, "A/P", 0, 3, ignoreCase = true) -> { tokens += AmPm(false, s[i] == 'a'); i += 3 }
                c.lowercaseChar() in "ymdhs" -> {
                    val n = run(c)
                    tokens += DatePart(c.lowercaseChar(), n); i += n
                }
                c == '/' -> { tokens += Slash; i++ }
                else -> { tokens += Lit(c.toString()); i++ }
            }
        }
        // "m" is minutes after an hour or before a second.
        val parts = tokens.filterIsInstance<DatePart>()
        parts.forEachIndexed { k, p ->
            if (p.kind != 'm' || p.elapsed) return@forEachIndexed
            val before = parts.getOrNull(k - 1)
            val after = parts.getOrNull(k + 1)
            if (before?.kind == 'h' || after?.kind == 's') p.kind = 'n'
        }
        return Section(tokens, color, condition)
    }

    private fun matches(cond: Pair<String, Double>, v: Double) = when (cond.first) {
        "<" -> v < cond.second
        "<=" -> v <= cond.second
        ">" -> v > cond.second
        ">=" -> v >= cond.second
        "=" -> v == cond.second
        "<>" -> v != cond.second
        else -> false
    }

    // ---- Public API --------------------------------------------------------------

    fun isDateFormat(code: String): Boolean = sections(code).firstOrNull()?.isDate == true

    /** Formats a number. [date1904] picks the Mac 1904 date system. */
    fun format(value: Double, code: String, date1904: Boolean = false): Result {
        if (value.isNaN() || value.isInfinite()) return Result("#NUM!")
        val secs = sections(code.ifBlank { "General" })
        val numeric = secs.take(3)
        val (section, signed) = pick(numeric, value)
        if (section == null) return Result(general(value))
        val shown = if (signed) value else abs(value)
        val text = when {
            section.isDate -> formatDate(section, value, date1904)
            !section.hasDigits && section.tokens.none { it is GeneralTok } -> literalOnly(section, if (signed && value < 0) "-" else "")
            else -> formatNumber(section, shown)
        }
        return Result(text, section.color)
    }

    /** Formats text with the format's text section (the 4th, or a section with @). */
    fun formatText(text: String, code: String): Result {
        val secs = sections(code.ifBlank { "General" })
        val section = when {
            secs.size >= 4 -> secs[3]
            secs.size == 1 && secs[0].hasText -> secs[0]
            else -> return Result(text)
        }
        val out = StringBuilder()
        for (t in section.tokens) when (t) {
            is Lit -> out.append(t.text)
            is TextAt -> out.append(text)
            else -> Unit
        }
        return Result(out.toString(), section.color)
    }

    private fun pick(secs: List<Section>, v: Double): Pair<Section?, Boolean> {
        if (secs.any { it.condition != null }) {
            for ((i, s) in secs.withIndex()) {
                val c = s.condition ?: continue
                if (matches(c, v)) return s to (i == 0 || v >= 0)
            }
            val rest = secs.firstOrNull { it.condition == null } ?: return secs.first() to true
            return rest to (v >= 0 || secs.indexOf(rest) == 0)
        }
        return when {
            secs.size == 1 -> secs[0] to true
            secs.size == 2 -> if (v >= 0) secs[0] to true else secs[1] to false
            else -> when {
                v > 0 -> secs[0] to true
                v < 0 -> secs[1] to false
                else -> secs[2] to true
            }
        }
    }

    private fun literalOnly(section: Section, sign: String): String {
        val sb = StringBuilder(sign)
        for (t in section.tokens) if (t is Lit) sb.append(t.text) else if (t is Comma) sb.append(',') else if (t is Slash) sb.append('/')
        return sb.toString()
    }

    // ---- General ------------------------------------------------------------------

    /** Excel's General format: up to 11 significant digits, scientific for very large or small numbers. */
    fun general(value: Double, significant: Int = 11): String {
        if (value == 0.0) return "0"
        val a = abs(value)
        if (a >= 1e11 || a < 1e-9) return scientific(value, (significant - 6).coerceIn(0, 5).let { maxOf(it, 5) })
        val bd = BigDecimal(value).round(MathContext(significant, RoundingMode.HALF_UP)).stripTrailingZeros()
        val s = bd.toPlainString()
        return if (s == "-0") "0" else s
    }

    /** "1.23457E+11" style, with up to [decimals] decimals and trailing zeros removed. */
    fun scientific(value: Double, decimals: Int = 5): String {
        if (value == 0.0) return "0"
        var exp = floor(log10(abs(value))).toInt()
        var mantissa = BigDecimal(value).divide(BigDecimal.TEN.pow(exp, MathContext.DECIMAL128), MathContext.DECIMAL128)
            .setScale(decimals, RoundingMode.HALF_UP)
        if (mantissa.abs() >= BigDecimal.TEN) {
            exp++
            mantissa = mantissa.divide(BigDecimal.TEN).setScale(decimals, RoundingMode.HALF_UP)
        }
        val m = mantissa.stripTrailingZeros().toPlainString()
        val e = abs(exp).toString().padStart(2, '0')
        return "${m}E${if (exp < 0) "-" else "+"}$e"
    }

    // ---- Numbers ------------------------------------------------------------------

    private fun formatNumber(section: Section, value: Double): String {
        val tokens = section.tokens
        if (tokens.any { it is GeneralTok }) {
            val sb = StringBuilder()
            for (t in tokens) when (t) {
                is GeneralTok -> sb.append(general(value))
                is Lit -> sb.append(t.text)
                else -> Unit
            }
            return sb.toString()
        }
        val slash = tokens.indexOfFirst { it is Slash }
        if (slash > 0 && tokens.subList(0, slash).any { it is Digit }) return formatFraction(tokens, slash, value)

        var v = value
        repeat(tokens.count { it is Percent }) { v *= 100 }
        val negative = v < 0
        v = abs(v)

        val firstDigit = tokens.indexOfFirst { it is Digit || it is Dot }
        val lastDigit = tokens.indexOfLast { it is Digit }
        val expIndex = tokens.indexOfFirst { it is Exp }
        val numberEnd = if (expIndex >= 0) expIndex else lastDigit
        val dotIndex = tokens.withIndex().indexOfFirst { (i, t) -> t is Dot && i in firstDigit..maxOf(firstDigit, numberEnd) }
        val intEnd = if (dotIndex >= 0) dotIndex else numberEnd + 1
        val intTokens = tokens.subList(firstDigit.coerceAtLeast(0), intEnd.coerceAtLeast(firstDigit.coerceAtLeast(0)))

        // Commas right after the last placeholder (or just before the point) divide by 1000;
        // commas between placeholders turn on thousands separators.
        var scaleCommas = 0
        run {
            var k = lastDigit + 1
            while (k < tokens.size && tokens[k] is Comma) { scaleCommas++; k++ }
            if (dotIndex > 0) {
                k = dotIndex - 1
                while (k >= 0 && tokens[k] is Comma) { scaleCommas++; k-- }
            }
        }
        val grouping = intTokens.dropLastWhile { it is Comma }.let { list ->
            val firstD = list.indexOfFirst { it is Digit }
            firstD >= 0 && list.drop(firstD).any { it is Comma }
        }
        repeat(scaleCommas) { v /= 1000 }

        val decTokens = if (dotIndex >= 0) tokens.subList(dotIndex + 1, (if (expIndex >= 0) expIndex else lastDigit + 1).coerceAtLeast(dotIndex + 1)) else emptyList()
        val decimals = decTokens.count { it is Digit }

        var exponentText = ""
        if (expIndex >= 0) {
            val intPlaces = intTokens.count { it is Digit }.coerceAtLeast(1)
            var exp = if (v == 0.0) 0 else floor(log10(v)).toInt()
            if (intPlaces > 1 && intTokens.firstOrNull { it is Digit } == Digit('#')) {
                exp = Math.floorDiv(exp, intPlaces) * intPlaces // engineering notation
            } else {
                exp -= intPlaces - 1
            }
            var mant = if (v == 0.0) BigDecimal.ZERO else BigDecimal(v).divide(BigDecimal.TEN.pow(exp, MathContext.DECIMAL128), MathContext.DECIMAL128)
            mant = mant.setScale(decimals, RoundingMode.HALF_UP)
            if (mant >= BigDecimal.TEN.pow(intPlaces)) {
                mant = mant.divide(BigDecimal.TEN).setScale(decimals, RoundingMode.HALF_UP)
                exp++
            }
            v = mant.toDouble()
            val expTok = tokens[expIndex] as Exp
            val expDigits = tokens.drop(expIndex + 1).takeWhile { it is Digit }.size.coerceAtLeast(1)
            val sign = if (exp < 0) "-" else if (expTok.plus) "+" else ""
            exponentText = "E" + sign + abs(exp).toString().padStart(expDigits, '0')
        }

        val rounded = BigDecimal(v.toString()).setScale(decimals, RoundingMode.HALF_UP)
        val intPart = rounded.toBigInteger().toString()
        val fracPart = rounded.toPlainString().substringAfter('.', "").padEnd(decimals, '0')
        val isZero = rounded.signum() == 0

        val out = StringBuilder()
        if (negative && !isZero) out.append('-')
        // Text before the number.
        for (t in tokens.subList(0, firstDigit.coerceAtLeast(0))) appendLiteral(out, t)
        out.append(integerText(intTokens, if (intPart == "0") "" else intPart, grouping))
        if (dotIndex >= 0) {
            out.append('.')
            out.append(decimalText(decTokens, fracPart))
        }
        out.append(exponentText)
        // Text after the number (after the last placeholder, the point or the exponent digits).
        val expEnd = if (expIndex >= 0) expIndex + 1 + tokens.drop(expIndex + 1).takeWhile { it is Digit }.size else 0
        val end = maxOf(lastDigit + 1, dotIndex + 1, expEnd)
        for (t in tokens.drop(end)) {
            if (t is Comma) continue
            appendLiteral(out, t)
        }
        return out.toString()
    }

    private fun appendLiteral(out: StringBuilder, t: Tok) {
        when (t) {
            is Lit -> out.append(t.text)
            is Percent -> out.append('%')
            is Slash -> out.append('/')
            is Comma -> out.append(',')
            else -> Unit
        }
    }

    private fun integerText(tokens: List<Tok>, digits: String, grouping: Boolean): String {
        val placeholders = tokens.filterIsInstance<Digit>()
        if (placeholders.isEmpty()) return digits
        val hasInnerLiterals = tokens.any { it is Lit || it is Percent }
        if (grouping || !hasInnerLiterals) {
            // Minimum digits: placeholders from the first 0 or ? to the right.
            val firstFixed = placeholders.indexOfFirst { it.kind == '0' || it.kind == '?' }
            val sb = StringBuilder(digits)
            if (firstFixed >= 0) {
                val minDigits = placeholders.size - firstFixed
                var k = sb.length
                while (k < minDigits) {
                    val kind = placeholders[placeholders.size - 1 - k].kind
                    sb.insert(0, if (kind == '?') ' ' else '0')
                    k++
                }
            }
            return if (grouping) group(sb.toString()) else sb.toString()
        }
        // Literals between placeholders (like 000-00-0000): fill from the right.
        val out = StringBuilder()
        var d = digits.length - 1
        val firstPlaceholder = tokens.indexOfFirst { it is Digit }
        for (k in tokens.indices.reversed()) {
            when (val t = tokens[k]) {
                is Digit -> {
                    if (d >= 0) { out.insert(0, digits[d]); d-- } else when (t.kind) {
                        '0' -> out.insert(0, '0')
                        '?' -> out.insert(0, ' ')
                        else -> Unit
                    }
                    if (k == firstPlaceholder && d >= 0) { out.insert(0, digits.substring(0, d + 1)); d = -1 }
                }
                is Lit -> out.insert(0, t.text)
                else -> Unit
            }
        }
        return out.toString()
    }

    private fun group(digits: String): String {
        val lead = digits.takeWhile { it == ' ' }
        val body = digits.drop(lead.length)
        val sb = StringBuilder()
        body.reversed().forEachIndexed { i, c -> if (i > 0 && i % 3 == 0) sb.append(','); sb.append(c) }
        return lead + sb.reverse().toString()
    }

    private fun decimalText(tokens: List<Tok>, frac: String): String {
        val lastNonZero = frac.indexOfLast { it != '0' }
        val out = StringBuilder()
        var j = 0
        for (t in tokens) when (t) {
            is Digit -> {
                val ch = frac.getOrElse(j) { '0' }
                if (j <= lastNonZero) out.append(ch) else when (t.kind) {
                    '0' -> out.append('0')
                    '?' -> out.append(' ')
                    else -> Unit
                }
                j++
            }
            is Lit -> out.append(t.text)
            is Percent -> out.append('%')
            else -> Unit
        }
        return out.toString()
    }

    private fun formatFraction(tokens: List<Tok>, slash: Int, value: Double): String {
        val negative = value < 0
        val v = abs(value)
        // Numerator: placeholders just before the slash. Whole part: placeholders before that.
        var k = slash - 1
        while (k >= 0 && tokens[k] is Digit) k--
        val numStart = k + 1
        val numPlaces = slash - numStart
        val wholeTokens = tokens.subList(0, numStart)
        val hasWhole = wholeTokens.any { it is Digit }
        val after = tokens.drop(slash + 1)
        val denPlaces = after.takeWhile { it is Digit }.size
        val fixedDen = if (denPlaces == 0) after.takeWhile { it is Lit && it.text.all(Char::isDigit) }.joinToString("") { (it as Lit).text }.toIntOrNull() else null
        val whole = if (hasWhole) floor(v).toLong() else 0L
        val frac = v - whole
        var num: Long
        var den: Long
        if (fixedDen != null && fixedDen > 0) {
            den = fixedDen.toLong(); num = (frac * den).roundToLong()
        } else {
            val maxDen = (10.0.pow(denPlaces.coerceAtLeast(1)) - 1).toLong()
            den = 1; num = frac.roundToLong()
            var best = abs(frac - num)
            for (d in 1..maxDen) {
                val n = (frac * d).roundToLong()
                val err = abs(frac - n.toDouble() / d)
                if (err < best - 1e-12) { best = err; num = n; den = d }
            }
        }
        var w = whole
        if (hasWhole && num == den) { w++; num = 0 }
        val sb = StringBuilder()
        if (negative && (w != 0L || num != 0L)) sb.append('-')
        for (t in wholeTokens.takeWhile { it !is Digit }) appendLiteral(sb, t)
        val denText = if (fixedDen != null) fixedDen.toString() else den.toString().padEnd(denPlaces, ' ')
        if (num == 0L && hasWhole) {
            sb.append(w.toString())
            sb.append(" ".repeat(numPlaces + 1 + denText.length))
        } else {
            if (hasWhole && w > 0) sb.append(w).append(' ') else if (hasWhole) sb.append(' ')
            sb.append(num.toString().padStart(numPlaces, ' ')).append('/').append(denText)
        }
        for (t in after.drop(if (fixedDen != null) after.takeWhile { it is Lit && it.text.all(Char::isDigit) }.size else denPlaces)) appendLiteral(sb, t)
        return sb.toString().let { if (!hasWhole) it.trimStart() else it }.trimEnd().ifEmpty { "0" }
    }

    // ---- Dates --------------------------------------------------------------------

    /** Date and time parts of an Excel serial, following Excel's 1900 leap-year bug. */
    class DateParts(
        val year: Int, val month: Int, val day: Int, val weekday: Int, // weekday: 0 = Sunday
        val hour: Int, val minute: Int, val second: Int, val millis: Int,
    )

    fun dateParts(serial: Double, date1904: Boolean, roundToSecond: Boolean = true): DateParts? {
        if (serial < 0 || serial > 2958465.999999) return null
        var days = floor(serial).toLong()
        var ms = ((serial - days) * 86_400_000.0).roundToLong()
        if (roundToSecond) ms = ((ms + 500) / 1000) * 1000
        if (ms >= 86_400_000L) { days++; ms -= 86_400_000L }
        val time = ms.toInt()
        val h = time / 3_600_000
        val m = time / 60_000 % 60
        val s = time / 1000 % 60
        val milli = time % 1000
        if (date1904) {
            val d = LocalDate.of(1904, 1, 1).plusDays(days)
            return DateParts(d.year, d.monthValue, d.dayOfMonth, d.dayOfWeek.value % 7, h, m, s, milli)
        }
        val weekday = ((days + 6) % 7).toInt()
        return when {
            days == 0L -> DateParts(1900, 1, 0, weekday, h, m, s, milli)
            days == 60L -> DateParts(1900, 2, 29, weekday, h, m, s, milli) // the day that doesn't exist
            days < 60L -> LocalDate.of(1899, 12, 31).plusDays(days).let { DateParts(it.year, it.monthValue, it.dayOfMonth, weekday, h, m, s, milli) }
            else -> LocalDate.of(1899, 12, 30).plusDays(days).let { DateParts(it.year, it.monthValue, it.dayOfMonth, weekday, h, m, s, milli) }
        }
    }

    private val monthNames = (1..12).map { java.time.Month.of(it).getDisplayName(TextStyle.FULL, Locale.US) }
    private val dayNames = listOf(7, 1, 2, 3, 4, 5, 6).map { java.time.DayOfWeek.of(it).getDisplayName(TextStyle.FULL, Locale.US) }

    private fun formatDate(section: Section, serial: Double, date1904: Boolean): String {
        val fracDigits = section.tokens.filterIsInstance<FracSec>().maxOfOrNull { it.digits } ?: 0
        val p = dateParts(serial, date1904, roundToSecond = fracDigits == 0) ?: return "#".repeat(10)
        val twelve = section.tokens.any { it is AmPm }
        val sb = StringBuilder()
        val totalSeconds = (serial * 86400.0).let { if (fracDigits == 0) Math.round(it).toDouble() else it }
        for (t in section.tokens) when (t) {
            is Lit -> sb.append(t.text)
            is Comma -> sb.append(',')
            is Slash -> sb.append('/')
            is Dot -> sb.append('.')
            is Percent -> sb.append('%')
            is Digit -> if (t.kind == '0') sb.append('0')
            is DatePart -> sb.append(
                if (t.elapsed) {
                    val total = when (t.kind) {
                        'h' -> floor(totalSeconds / 3600).toLong()
                        'n' -> floor(totalSeconds / 60).toLong()
                        else -> floor(totalSeconds).toLong()
                    }
                    total.toString().padStart(t.count, '0')
                } else when (t.kind) {
                    'y' -> if (t.count <= 2) (p.year % 100).toString().padStart(2, '0') else p.year.toString()
                    'm' -> when (t.count) {
                        1 -> p.month.toString()
                        2 -> p.month.toString().padStart(2, '0')
                        3 -> monthNames[p.month - 1].take(3)
                        5 -> monthNames[p.month - 1].take(1)
                        else -> monthNames[p.month - 1]
                    }
                    'n' -> if (t.count >= 2) p.minute.toString().padStart(2, '0') else p.minute.toString()
                    'd' -> when (t.count) {
                        1 -> p.day.toString()
                        2 -> p.day.toString().padStart(2, '0')
                        3 -> dayNames[p.weekday].take(3)
                        else -> dayNames[p.weekday]
                    }
                    'h' -> {
                        val hour = if (twelve) (p.hour % 12).let { if (it == 0) 12 else it } else p.hour
                        if (t.count >= 2) hour.toString().padStart(2, '0') else hour.toString()
                    }
                    's' -> if (t.count >= 2) p.second.toString().padStart(2, '0') else p.second.toString()
                    else -> ""
                },
            )
            is FracSec -> {
                val frac = (p.millis / 1000.0)
                val text = BigDecimal(frac).setScale(t.digits, RoundingMode.HALF_UP).toPlainString().substringAfter('.', "").padEnd(t.digits, '0').take(t.digits)
                sb.append('.').append(text)
            }
            is AmPm -> {
                val am = p.hour < 12
                val text = if (t.full) (if (am) "AM" else "PM") else (if (am) "A" else "P")
                sb.append(if (t.lower) text.lowercase() else text)
            }
            else -> Unit
        }
        return sb.toString()
    }
}
