package com.excelto.pdf.converter.ui.tools

import com.excelto.pdf.converter.R
import com.excelto.pdf.converter.language.tr
import com.excelto.pdf.converter.language.trPlural
import android.graphics.Bitmap
import android.net.Uri
import android.util.Size
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.OutlinedTextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.stateDescription
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.excelto.pdf.converter.core.engine.PageChoice
import com.excelto.pdf.converter.core.engine.PageSpec
import com.excelto.pdf.converter.core.engine.WatermarkOptions
import com.excelto.pdf.converter.core.engine.WatermarkPosition
import com.excelto.pdf.converter.core.model.DocFile
import com.excelto.pdf.converter.core.render.PdfPages
import com.excelto.pdf.converter.ui.AppViewModel
import com.excelto.pdf.converter.ui.Route
import com.excelto.pdf.converter.ui.Tool
import com.excelto.pdf.converter.ui.components.ChoiceRow
import com.excelto.pdf.converter.ui.components.SecondaryButton
import com.excelto.pdf.converter.ui.components.ToggleRow
import com.excelto.pdf.converter.ui.sheets.appTextFieldColors
import com.excelto.pdf.converter.ui.theme.AppIcons
import com.excelto.pdf.converter.ui.theme.LocalPalette
import com.excelto.pdf.converter.ui.theme.Type
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
internal fun PdfThumb(file: DocFile, index: Int, rotation: Int = 0, modifier: Modifier = Modifier) {
    val bitmap by produceState<Bitmap?>(null, file.path, index) {
        value = withContext(Dispatchers.IO) { PdfPages.render(file.file, index, 300) }
    }
    Box(modifier.background(Color.White), contentAlignment = Alignment.Center) {
        val bmp = bitmap
        if (bmp != null) {
            Image(bmp.asImageBitmap(), null, contentScale = ContentScale.Fit, modifier = Modifier.fillMaxSize().rotate(rotation.toFloat()))
        } else {
            Text("${index + 1}", style = Type.section, color = Color(0xFF5F6670))
        }
    }
}

// ---- Images to PDF ----------------------------------------------------------------

@Composable
fun ImagesToPdfScreen(vm: AppViewModel, route: Route.ToolScreen) {
    val p = LocalPalette.current
    val context = LocalContext.current
    val images = route.images
    var selected by remember { mutableIntStateOf(-1) }
    var page by rememberSaveable { mutableIntStateOf(PageChoice.A4.ordinal) }
    var name by rememberSaveable { mutableStateOf("Images_" + SimpleDateFormat("yyyy-MM-dd_HHmm", Locale.US).format(Date())) }
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.PickMultipleVisualMedia(100)) { uris ->
        if (uris.isNotEmpty()) vm.setToolImages(images + uris)
    }
    LaunchedEffect(Unit) { if (images.isEmpty()) pick.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) }

    ToolScaffold(vm, route, if (images.isEmpty()) tr(R.string.img_add_first) else trPlural(R.plurals.img_create_n, images.size, images.size),
        enabled = images.isNotEmpty() && name.isNotBlank(), showFileCard = false, onStart = {
            vm.runImagesToPdf(images, PageChoice.entries[page], name.trim())
        }) {
        if (images.isNotEmpty()) {
            Note(tr(R.string.img_tap))
            images.chunked(3).forEachIndexed { rowIndex, row ->
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    row.forEachIndexed { col, uri ->
                        val i = rowIndex * 3 + col
                        val thumb by produceState<Bitmap?>(null, uri) {
                            value = withContext(Dispatchers.IO) { runCatching { context.contentResolver.loadThumbnail(uri, Size(300, 300), null) }.getOrNull() }
                        }
                        Box(
                            Modifier.weight(1f).aspectRatio(0.8f).clip(RoundedCornerShape(10.dp)).background(p.surface)
                                .border(2.dp, if (selected == i) p.primaryText else Color.Transparent, RoundedCornerShape(10.dp))
                                .clickable(role = Role.Button) { selected = if (selected == i) -1 else i }
                                .semantics { contentDescription = tr(R.string.a11y_photo, i + 1); stateDescription = if (selected == i) tr(R.string.a11y_selected) else "" },
                        ) {
                            thumb?.let { Image(it.asImageBitmap(), null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize()) }
                            Text("${i + 1}", style = Type.tiny, color = Color.White,
                                modifier = Modifier.align(Alignment.TopStart).padding(6.dp).clip(RoundedCornerShape(8.dp)).background(Color(0xAA000000)).padding(horizontal = 6.dp, vertical = 2.dp))
                        }
                    }
                    repeat(3 - row.size) { Box(Modifier.weight(1f)) }
                }
            }
            if (selected in images.indices) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    SecondaryButton(tr(R.string.scan_move_earlier), {
                        if (selected > 0) { vm.setToolImages(images.toMutableList().apply { add(selected - 1, removeAt(selected)) }); selected-- }
                    }, Modifier.weight(1f))
                    SecondaryButton(tr(R.string.common_remove), { vm.setToolImages(images.filterIndexed { i, _ -> i != selected }); selected = -1 }, Modifier.weight(1f), textColor = p.danger)
                }
            }
        }
        SecondaryButton(tr(R.string.img_add), { pick.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) })
        Label(tr(R.string.opt_page_size))
        ChoiceRow(PageChoice.entries.map { if (it == PageChoice.ORIGINAL) tr(R.string.img_fit) else it.label }, page) { page = it }
        NameField(name, { name = it }, Tool.IMAGE_TO_PDF.folder)
    }
}

// ---- Organize ---------------------------------------------------------------------

@Composable
fun OrganizeScreen(vm: AppViewModel, route: Route.ToolScreen) {
    val p = LocalPalette.current
    val file = route.files.firstOrNull()
    val count = rememberPageCount(vm, file)
    val pages = remember(file?.path, count) { mutableStateListOf<PageSpec>().apply { if (count != null) addAll((1..count).map { PageSpec(it) }) } }
    var selected by remember(file?.path) { mutableIntStateOf(0) }
    val changed = count != null && (pages.size != count || pages.withIndex().any { (i, s) -> s.originalPage != i + 1 || s.extraRotation % 360 != 0 })

    ToolScaffold(vm, route, tr(R.string.org_save), enabled = changed && pages.isNotEmpty(), onStart = {
        vm.runOrganize(file!!, pages.toList())
    }) {
        if (count == null) {
            Note(tr(R.string.pages_loading))
        } else {
            Note(tr(R.string.org_tap))
            pages.chunked(3).forEachIndexed { rowIndex, row ->
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    row.forEachIndexed { col, spec ->
                        val i = rowIndex * 3 + col
                        Column(
                            Modifier.weight(1f).clip(RoundedCornerShape(12.dp))
                                .border(2.dp, if (i == selected) p.primaryText else Color.Transparent, RoundedCornerShape(12.dp))
                                .background(p.surface).clickable(role = Role.Button) { selected = i }
                                .semantics { contentDescription = tr(R.string.a11y_page_from, i + 1, spec.originalPage); stateDescription = if (i == selected) tr(R.string.a11y_selected) else "" }
                                .padding(6.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                        ) {
                            PdfThumb(file!!, spec.originalPage - 1, spec.extraRotation, Modifier.fillMaxWidth().aspectRatio(0.72f))
                            Text(tr(R.string.a11y_page, i + 1), style = Type.tiny.copy(fontSize = 12.sp), color = p.text, modifier = Modifier.padding(top = 4.dp))
                        }
                    }
                    repeat(3 - row.size) { Box(Modifier.weight(1f)) }
                }
            }
            if (selected in pages.indices) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    SecondaryButton(tr(R.string.org_rotate), { pages[selected] = pages[selected].let { it.copy(extraRotation = (it.extraRotation + 90) % 360) } }, Modifier.weight(1f))
                    SecondaryButton(tr(R.string.org_earlier), { if (selected > 0) { pages.add(selected - 1, pages.removeAt(selected)); selected-- } }, Modifier.weight(1f))
                    SecondaryButton(tr(R.string.org_later), { if (selected < pages.lastIndex) { pages.add(selected + 1, pages.removeAt(selected)); selected++ } }, Modifier.weight(1f))
                    SecondaryButton(tr(R.string.common_delete), {
                        if (pages.size > 1) { pages.removeAt(selected); selected = selected.coerceAtMost(pages.lastIndex) } else vm.say(tr(R.string.org_keep_one))
                    }, Modifier.weight(1f), textColor = p.danger)
                }
            }
        }
    }
}

// ---- Watermark --------------------------------------------------------------------

@Composable
fun WatermarkScreen(vm: AppViewModel, route: Route.ToolScreen) {
    val p = LocalPalette.current
    val file = route.files.firstOrNull()
    var text by rememberSaveable { mutableStateOf(tr(R.string.wm_default)) }
    var opacity by rememberSaveable { mutableFloatStateOf(0.25f) }
    var position by rememberSaveable { mutableIntStateOf(0) }
    var pageNumbers by rememberSaveable { mutableStateOf(true) }
    val pos = WatermarkPosition.entries[position]

    ToolScaffold(vm, route, tr(R.string.wm_apply), enabled = text.isNotBlank() || pageNumbers, onStart = {
        vm.runWatermark(file!!, WatermarkOptions(text.trim(), opacity, pos, pageNumbers))
    }) {
        Box(Modifier.fillMaxWidth().heightIn(max = 320.dp).aspectRatio(0.75f).clip(RoundedCornerShape(4.dp)).background(Color.White)) {
            if (file != null) PdfThumb(file, 0, modifier = Modifier.fillMaxSize())
            Box(
                Modifier.fillMaxSize().padding(bottom = if (pos == WatermarkPosition.FOOTER) 26.dp else 0.dp),
                contentAlignment = if (pos == WatermarkPosition.FOOTER) Alignment.BottomCenter else Alignment.Center,
            ) {
                Text(text, color = Color(0xFFB3261E).copy(alpha = opacity), maxLines = 1,
                    style = Type.title.copy(fontSize = if (pos == WatermarkPosition.FOOTER) 12.sp else 30.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 2.sp),
                    modifier = Modifier.rotate(if (pos == WatermarkPosition.DIAGONAL) -45f else 0f))
            }
            if (pageNumbers) Text(tr(R.string.a11y_page, 1), style = Type.small.copy(fontSize = 9.sp), color = Color(0xFF5F6670), modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 6.dp))
        }
        OutlinedTextField(text, { text = it }, singleLine = true, colors = appTextFieldColors(), label = { Text(tr(R.string.wm_text)) }, modifier = Modifier.fillMaxWidth())
        Label(tr(R.string.wm_opacity, (opacity * 100).toInt()))
        Slider(opacity, { opacity = it }, valueRange = 0.1f..0.7f, steps = 11,
            colors = SliderDefaults.colors(thumbColor = p.primaryText, activeTrackColor = p.primaryText, inactiveTrackColor = p.line))
        Label(tr(R.string.opt_position))
        ChoiceRow(listOf(tr(R.string.wm_diagonal), tr(R.string.wm_center), tr(R.string.wm_footer)), position) { position = it }
        Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(p.surface)) {
            ToggleRow(tr(R.string.tool_page_numbers), tr(R.string.wm_numbers_hint), pageNumbers, { pageNumbers = it }, showDivider = false)
        }
    }
}
