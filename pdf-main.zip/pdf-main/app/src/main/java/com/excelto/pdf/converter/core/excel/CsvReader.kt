package com.excelto.pdf.converter.core.excel

import java.io.BufferedReader
import java.io.File
import java.io.InputStream
import java.io.InputStreamReader
import java.io.PushbackInputStream

/**
 * Reads CSV (RFC 4180): quoted fields, doubled quotes inside quotes, and line breaks
 * inside quoted fields. The delimiter (comma, semicolon or tab) is detected from the
 * first lines, and a UTF-8 byte order mark is skipped. Pure Kotlin.
 */
object CsvReader {

    private val plainNumber = Regex("^-?(\\d+\\.?\\d*|\\.\\d+)([eE][-+]?\\d+)?$")

    fun read(file: File): ExcelWorkbook = file.inputStream().use { read(it, file.nameWithoutExtension) }

    fun read(input: InputStream, name: String = "Sheet1"): ExcelWorkbook {
        val rows = parse(input)
        val sheet = ExcelSheet(name = name.take(31).ifBlank { "Sheet1" })
        val widths = HashMap<Int, Float>()
        rows.forEachIndexed { r, fields ->
            val row = RowData()
            fields.forEachIndexed { c, raw ->
                if (raw.isEmpty()) return@forEachIndexed
                // Numbers like Excel would read them; leading zeros stay text (IDs, phone numbers).
                val isNumber = plainNumber.matches(raw) && !(raw.length > 1 && raw.startsWith("0") && !raw.startsWith("0."))
                if (isNumber) row.put(c, CellKind.NUMBER, raw.toDouble()) else row.put(c, CellKind.STRING, str = raw)
                widths[c] = maxOf(widths[c] ?: 0f, raw.length.toFloat())
            }
            if (row.size > 0) sheet.rows[r] = row
        }
        // Columns sized to their content, like Excel's AutoFit when a CSV is opened.
        val sized = ExcelSheet(
            name = sheet.name,
            rows = sheet.rows,
            colWidths = widths.mapValues { (_, w) -> SheetUnits.storedWidth((w + 1f).coerceIn(8.43f, 60f)) },
        )
        return ExcelWorkbook(listOf(sized), listOf(CellStyle.DEFAULT))
    }

    /** All records as lists of fields. */
    fun parse(input: InputStream): List<List<String>> {
        val stream = PushbackInputStream(input, 3)
        val bom = ByteArray(3)
        val n = stream.read(bom, 0, 3)
        if (!(n == 3 && bom[0] == 0xEF.toByte() && bom[1] == 0xBB.toByte() && bom[2] == 0xBF.toByte()) && n > 0) stream.unread(bom, 0, n)
        val text = BufferedReader(InputStreamReader(stream, Charsets.UTF_8)).readText()
        return parse(text, detectDelimiter(text))
    }

    /** Picks the delimiter that splits the first lines most consistently. */
    fun detectDelimiter(text: String): Char {
        val sample = text.lineSequence().filter { it.isNotBlank() }.take(10).toList()
        if (sample.isEmpty()) return ','
        return listOf(',', ';', '\t').maxBy { d ->
            val counts = sample.map { line -> countOutsideQuotes(line, d) }
            val first = counts.first()
            if (first == 0) -1 else counts.count { it == first } * 100 + first
        }
    }

    private fun countOutsideQuotes(line: String, d: Char): Int {
        var quoted = false
        var n = 0
        for (c in line) {
            if (c == '"') quoted = !quoted else if (c == d && !quoted) n++
        }
        return n
    }

    fun parse(text: String, delimiter: Char): List<List<String>> {
        val records = mutableListOf<List<String>>()
        var fields = mutableListOf<String>()
        val field = StringBuilder()
        var quoted = false
        var i = 0
        var atStart = true // nothing read yet in this record
        while (i < text.length) {
            val c = text[i]
            if (quoted) {
                if (c == '"') {
                    if (i + 1 < text.length && text[i + 1] == '"') { field.append('"'); i++ } else quoted = false
                } else field.append(c)
            } else when (c) {
                '"' -> if (field.isEmpty()) quoted = true else field.append(c)
                delimiter -> { fields += field.toString(); field.setLength(0) }
                '\r' -> Unit
                '\n' -> {
                    fields += field.toString(); field.setLength(0)
                    records += fields; fields = mutableListOf()
                    atStart = true
                    i++
                    continue
                }
                else -> field.append(c)
            }
            atStart = false
            i++
        }
        if (!atStart || field.isNotEmpty() || fields.isNotEmpty()) {
            fields += field.toString()
            records += fields
        }
        return records
    }
}
