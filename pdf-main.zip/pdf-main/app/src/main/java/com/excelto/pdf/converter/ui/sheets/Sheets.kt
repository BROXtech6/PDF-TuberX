package com.excelto.pdf.converter.ui.sheets

import com.excelto.pdf.converter.R
import com.excelto.pdf.converter.language.tr
import com.excelto.pdf.converter.language.trPlural
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.excelto.pdf.converter.core.model.DocFile
import com.excelto.pdf.converter.core.model.DocType
import com.excelto.pdf.converter.ui.AppViewModel
import com.excelto.pdf.converter.ui.LocalHost
import com.excelto.pdf.converter.ui.PasswordPrompt
import com.excelto.pdf.converter.ui.Tool
import com.excelto.pdf.converter.ui.components.FileRow
import com.excelto.pdf.converter.ui.components.IconBadge
import com.excelto.pdf.converter.ui.components.PrimaryButton
import com.excelto.pdf.converter.ui.components.SecondaryButton
import com.excelto.pdf.converter.ui.components.formatDate
import com.excelto.pdf.converter.ui.components.formatSize
import com.excelto.pdf.converter.ui.theme.AppIcons
import com.excelto.pdf.converter.ui.theme.LocalPalette
import com.excelto.pdf.converter.ui.theme.Tint
import com.excelto.pdf.converter.ui.theme.Tints
import com.excelto.pdf.converter.ui.theme.Type

@Composable
fun appTextFieldColors() = LocalPalette.current.let { p ->
    OutlinedTextFieldDefaults.colors(
        focusedTextColor = p.text, unfocusedTextColor = p.text,
        focusedBorderColor = p.primaryText, unfocusedBorderColor = p.line,
        focusedContainerColor = p.surface, unfocusedContainerColor = p.surface,
        cursorColor = p.primaryText, focusedLabelColor = p.primaryText, unfocusedLabelColor = p.muted,
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppSheet(onDismiss: () -> Unit, content: @Composable () -> Unit) {
    val p = LocalPalette.current
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        containerColor = p.surface,
        shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp),
    ) {
        Column(Modifier.verticalScroll(rememberScrollState()).padding(start = 16.dp, end = 16.dp, bottom = 18.dp).navigationBarsPadding(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            content()
        }
    }
}

@Composable
private fun SheetAction(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, tint: Tint, textColor: Color? = null, onClick: () -> Unit) {
    val p = LocalPalette.current
    Row(
        Modifier.fillMaxWidth().heightIn(min = 52.dp).clip(RoundedCornerShape(12.dp)).clickable(role = Role.Button, onClick = onClick).padding(horizontal = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        IconBadge(icon, tint, size = 36.dp, iconSize = 18.dp, radius = 11.dp)
        Text(label, style = Type.bodyStrong.copy(fontSize = 14.sp), color = textColor ?: p.text)
    }
}

/** Actions for one file: open, the tools that fit its type, favorite, rename, share, delete. */
@Composable
fun FileActionsSheet(vm: AppViewModel, file: DocFile, onDismiss: () -> Unit) {
    val p = LocalPalette.current
    val host = LocalHost.current
    var renaming by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }
    AppSheet(onDismiss) {
        Text(file.name, style = Type.bodyStrong.copy(fontSize = 15.sp), color = p.text)
        Text("${formatDate(file.modified)} · ${formatSize(file.size)} · ${file.source.label}", style = Type.small, color = p.muted, modifier = Modifier.padding(bottom = 6.dp))
        SheetAction(tr(R.string.common_open), AppIcons.eye, Tints.blue) { onDismiss(); host.openFile(file.file) }
        val tools = Tool.forType(file.type)
        if (tools.size <= 3) {
            tools.forEach { tool -> SheetAction(tool.label, tool.icon, tool.tint) { onDismiss(); vm.openTool(tool, file) } }
        } else {
            ToolGrid(tools) { tool -> onDismiss(); vm.openTool(tool, file) }
        }
        SheetAction(if (file.favorite) tr(R.string.files_unfavorite) else tr(R.string.files_favorite_add), AppIcons.star, Tints.amber) { vm.toggleFavorite(file); onDismiss() }
        SheetAction(tr(R.string.common_rename), AppIcons.pen, Tints.teal) { renaming = true }
        SheetAction(tr(R.string.common_share), AppIcons.share, Tints.blue) { onDismiss(); host.share(listOf(file.file)) }
        SheetAction(tr(R.string.common_delete), AppIcons.trash, Tints.red, p.danger) { confirmDelete = true }
    }
    if (renaming) {
        var name by remember { mutableStateOf(file.stem) }
        AlertDialog(
            onDismissRequest = { renaming = false },
            containerColor = p.surface,
            title = { Text(tr(R.string.sheet_rename_title), style = Type.section.copy(fontSize = 17.sp), color = p.text) },
            text = { OutlinedTextField(name, { name = it }, singleLine = true, colors = appTextFieldColors(), label = { Text(tr(R.string.sheet_file_name)) }) },
            confirmButton = { Text(tr(R.string.language_save), style = Type.bodyStrong, color = p.primaryText, modifier = Modifier.clickable(role = Role.Button) { renaming = false; onDismiss(); vm.rename(file, name) }.padding(12.dp)) },
            dismissButton = { Text(tr(R.string.common_cancel), style = Type.bodyStrong, color = p.text, modifier = Modifier.clickable(role = Role.Button) { renaming = false }.padding(12.dp)) },
        )
    }
    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            containerColor = p.surface,
            title = { Text(tr(R.string.sheet_delete_title, file.name), style = Type.section.copy(fontSize = 17.sp), color = p.text) },
            text = { Text(tr(R.string.sheet_delete_body), style = Type.body, color = p.muted) },
            confirmButton = { Text(tr(R.string.common_delete), style = Type.bodyStrong, color = p.danger, modifier = Modifier.clickable(role = Role.Button) { confirmDelete = false; onDismiss(); vm.delete(file) }.padding(12.dp)) },
            dismissButton = { Text(tr(R.string.common_cancel), style = Type.bodyStrong, color = p.text, modifier = Modifier.clickable(role = Role.Button) { confirmDelete = false }.padding(12.dp)) },
        )
    }
}

/**
 * Lets the user choose files for a tool from their documents, or from any app or cloud
 * drive through the system picker.
 */
@Composable
fun FilePickerSheet(vm: AppViewModel, tool: Tool, alreadyChosen: List<DocFile>, onChosen: (List<DocFile>) -> Unit, onDismiss: () -> Unit) {
    val p = LocalPalette.current
    val files by vm.files.collectAsState()
    val multi = tool.needs == com.excelto.pdf.converter.ui.Needs.MANY_PDFS
    val matching = files.filter { it.type == tool.acceptedType }
    val chosen = remember { mutableStateListOf<DocFile>().apply { addAll(alreadyChosen) } }
    val browse = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty()) vm.importAndUse(if (multi) uris else uris.take(1)) { imported ->
            if (multi) { chosen.addAll(imported) } else { onChosen(imported); onDismiss() }
        }
    }
    AppSheet(onDismiss) {
        Text(if (multi) tr(R.string.picker_choose_files) else tr(R.string.picker_choose_file), style = Type.section.copy(fontSize = 16.sp), color = p.text)
        Row(
            Modifier.fillMaxWidth().heightIn(min = 52.dp).clip(RoundedCornerShape(14.dp)).border(1.dp, p.muted, RoundedCornerShape(14.dp))
                .clickable(role = Role.Button) { browse.launch(tool.pickerMimeTypes) }.padding(horizontal = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Icon(AppIcons.cloud, null, tint = p.primaryText, modifier = Modifier.size(20.dp))
            Text(tr(R.string.picker_browse), style = Type.bodyStrong, color = p.text)
        }
        if (matching.isEmpty()) {
            Text(when (tool.acceptedType) { DocType.EXCEL -> tr(R.string.picker_none_sheets); DocType.WORD -> tr(R.string.picker_none_word); DocType.POWERPOINT -> tr(R.string.picker_none_ppt); DocType.HTML -> tr(R.string.picker_none_html); else -> tr(R.string.picker_none_pdf) }, style = Type.small, color = p.muted, modifier = Modifier.padding(vertical = 10.dp))
        }
        LazyColumn(Modifier.heightIn(max = 420.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(matching, key = { it.path }) { file ->
                val on = chosen.any { it.path == file.path }
                FileRow(file, selected = on, onClick = {
                    if (multi) { if (on) chosen.removeAll { it.path == file.path } else chosen.add(file) }
                    else { onChosen(listOf(file)); onDismiss() }
                }, modifier = Modifier.background(p.bg, RoundedCornerShape(16.dp)))
            }
        }
        if (multi) {
            PrimaryButton(if (chosen.isEmpty()) tr(R.string.picker_choose_files) else trPlural(R.plurals.picker_use, chosen.size, chosen.size), { onChosen(chosen.toList()); onDismiss() }, enabled = chosen.isNotEmpty())
        }
    }
}

@Composable
fun PasswordDialog(prompt: PasswordPrompt, onSubmit: (String) -> Unit, onDismiss: () -> Unit) {
    val p = LocalPalette.current
    var password by remember(prompt.file.path) { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = p.surface,
        icon = { Box(Modifier.size(44.dp).clip(RoundedCornerShape(14.dp)).background(p.primarySoft), contentAlignment = Alignment.Center) { Icon(AppIcons.lock, null, tint = p.primaryText) } },
        title = { Text(tr(R.string.password_title), style = Type.section.copy(fontSize = 17.sp), color = p.text) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(tr(R.string.password_body, prompt.file.name), style = Type.body, color = p.muted)
                OutlinedTextField(
                    password, { password = it }, singleLine = true, colors = appTextFieldColors(),
                    label = { Text(tr(R.string.password_label)) }, isError = prompt.wrongPassword,
                    supportingText = { if (prompt.wrongPassword) Text(tr(R.string.password_wrong), color = p.danger) },
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                )
            }
        },
        confirmButton = { Text(tr(R.string.common_unlock), style = Type.bodyStrong, color = p.primaryText, modifier = Modifier.clickable(role = Role.Button) { if (password.isNotEmpty()) onSubmit(password) }.padding(12.dp)) },
        dismissButton = { Text(tr(R.string.common_cancel), style = Type.bodyStrong, color = p.text, modifier = Modifier.clickable(role = Role.Button, onClick = onDismiss).padding(12.dp)) },
    )
}

@Composable
fun ConfirmSheet(title: String, body: String, confirm: String, danger: Boolean, onConfirm: () -> Unit, onDismiss: () -> Unit) {
    val p = LocalPalette.current
    AppSheet(onDismiss) {
        Text(title, style = Type.section.copy(fontSize = 17.sp), color = p.text)
        Text(body, style = Type.body, color = p.muted, modifier = Modifier.padding(bottom = 8.dp))
        PrimaryButton(confirm, { onDismiss(); onConfirm() }, color = if (danger) p.danger else null)
        SecondaryButton(tr(R.string.common_cancel), onDismiss)
    }
}

/** Tools grouped by section as a compact grid of icon + label, for files with many tools. */
@Composable
private fun ToolGrid(tools: List<Tool>, onPick: (Tool) -> Unit) {
    val p = LocalPalette.current
    com.excelto.pdf.converter.ui.ToolCategory.entries.forEach { category ->
        val inGroup = tools.filter { it.category == category }
        if (inGroup.isEmpty()) return@forEach
        Text(category.label, style = Type.tiny.copy(fontSize = 12.sp), color = p.muted, modifier = Modifier.padding(top = 8.dp, start = 4.dp))
        inGroup.chunked(4).forEach { row ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                row.forEach { tool ->
                    Column(
                        Modifier.weight(1f).heightIn(min = 76.dp).clip(RoundedCornerShape(12.dp))
                            .clickable(role = Role.Button) { onPick(tool) }.padding(vertical = 6.dp, horizontal = 2.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(4.dp),
                    ) {
                        IconBadge(tool.icon, tool.tint, size = 36.dp, iconSize = 18.dp, radius = 11.dp)
                        Text(tool.label, style = Type.small.copy(fontSize = 11.sp), color = p.text, maxLines = 2,
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                    }
                }
                repeat(4 - row.size) { Box(Modifier.weight(1f)) }
            }
        }
    }
}
