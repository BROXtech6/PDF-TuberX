package com.excelto.pdf.converter.ui.screens

import com.excelto.pdf.converter.R
import com.excelto.pdf.converter.language.tr
import com.excelto.pdf.converter.language.trPlural
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.excelto.pdf.converter.BuildConfig
import com.excelto.pdf.converter.core.model.DocFile
import com.excelto.pdf.converter.core.model.DocType
import com.excelto.pdf.converter.core.storage.ThemeMode
import com.excelto.pdf.converter.ui.AppViewModel
import com.excelto.pdf.converter.ui.LocalHost
import com.excelto.pdf.converter.ui.Tool
import com.excelto.pdf.converter.ui.ToolCategory
import com.excelto.pdf.converter.ui.components.Card18
import com.excelto.pdf.converter.ui.components.Chip
import com.excelto.pdf.converter.ui.components.FileRow
import com.excelto.pdf.converter.ui.components.IconBadge
import com.excelto.pdf.converter.ui.components.LinkRow
import com.excelto.pdf.converter.ui.components.PrimaryButton
import com.excelto.pdf.converter.ui.components.Segmented
import com.excelto.pdf.converter.ui.sheets.FileActionsSheet
import com.excelto.pdf.converter.ui.theme.AppIcons
import com.excelto.pdf.converter.ui.theme.LocalPalette
import com.excelto.pdf.converter.ui.theme.Type

@Composable
private fun TabTitle(text: String) {
    Text(text, style = Type.title, color = LocalPalette.current.text, modifier = Modifier.padding(start = 18.dp, end = 18.dp, top = 18.dp, bottom = 8.dp))
}

// ---- Tools ------------------------------------------------------------------------

@Composable
fun ToolsScreen(vm: AppViewModel) {
    val p = LocalPalette.current
    val host = LocalHost.current
    // One category at a time, starting with the everyday tools.
    var category by rememberSaveable { mutableStateOf(POPULAR_KEY) }
    val sections: List<Pair<String, List<Tool>>> =
        if (category == POPULAR_KEY) listOf(tr(R.string.tabs_popular) to Tool.POPULAR)
        else ToolCategory.entries.filter { it.name == category }.map { g -> g.label to Tool.entries.filter { it.category == g } }
    Column(Modifier.fillMaxSize()) {
        TabTitle(tr(R.string.tabs_tools))
        Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 14.dp, vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Chip(tr(R.string.tabs_popular), category == POPULAR_KEY) { category = POPULAR_KEY }
            ToolCategory.entries.filter { c -> Tool.entries.any { it.category == c } }.forEach { c ->
                Chip(c.label, category == c.name) { category = c.name }
            }
        }
        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            contentPadding = PaddingValues(14.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.weight(1f),
        ) {
          sections.forEachIndexed { si, (title, tools) ->
            item(key = "header_$title", span = { androidx.compose.foundation.lazy.grid.GridItemSpan(maxLineSpan) }) {
                Text(title, style = Type.section.copy(fontSize = 15.sp), color = p.text,
                    modifier = Modifier.padding(top = if (si == 0) 0.dp else 8.dp, start = 2.dp)
                        .semantics { heading() })
            }
            items(tools, key = { "${title}_${it.name}" }) { tool ->
                Box(
                    Modifier.heightIn(min = 118.dp).clip(Card18).background(p.surface)
                        .clickable(role = Role.Button) { vm.openTool(tool) }
                        .padding(12.dp),
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        IconBadge(tool.icon, tool.tint)
                        Column {
                            Text(tool.label, style = Type.bodyStrong, color = p.text)
                            Text(tool.description, style = Type.small.copy(fontSize = 11.sp), color = p.muted)
                        }
                    }
                    tool.badge?.let { badge ->
                        Text(badge, style = Type.tiny.copy(fontSize = 10.sp), color = p.aiText,
                            modifier = Modifier.align(Alignment.TopEnd).clip(RoundedCornerShape(10.dp)).background(p.aiSoft).padding(horizontal = 8.dp, vertical = 2.dp))
                    }
                }
            }
          }
        }
    }
}

private const val POPULAR_KEY = "POPULAR"

// ---- Files ------------------------------------------------------------------------

@Composable
fun FilesScreen(vm: AppViewModel) {
    val p = LocalPalette.current
    val host = LocalHost.current
    val files by vm.files.collectAsState()
    var filter by rememberSaveable { mutableStateOf("All") }
    var query by rememberSaveable { mutableStateOf("") }
    var actionsFor by remember { mutableStateOf<DocFile?>(null) }
    val browse = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty()) vm.importAndUse(uris) { imported -> if (imported.size == 1) actionsFor = imported.first() else vm.say(trPlural(R.plurals.files_added, imported.size, imported.size)) }
    }
    val visible = files.filter { f ->
        when (filter) {
            "Favorites" -> f.favorite
            "PDF" -> f.type == DocType.PDF
            "Excel" -> f.type == DocType.EXCEL
            "Word" -> f.type == DocType.WORD
            "PowerPoint" -> f.type == DocType.POWERPOINT
            "HTML" -> f.type == DocType.HTML
            else -> true
        } && (query.isBlank() || f.name.contains(query.trim(), ignoreCase = true))
    }

    Column(Modifier.fillMaxSize()) {
        TabTitle(tr(R.string.tabs_files))
        LazyColumn(contentPadding = PaddingValues(start = 14.dp, end = 14.dp, top = 4.dp, bottom = 22.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item {
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("All", "Favorites", "PDF", "Excel", "Word", "PowerPoint", "HTML").forEach { Chip(fileFilterLabel(it), filter == it) { filter = it } }
                }
            }
            item {
                Row(
                    Modifier.fillMaxWidth().heightIn(min = 46.dp).clip(RoundedCornerShape(14.dp)).background(p.surface).padding(horizontal = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    Icon(AppIcons.search, null, tint = p.muted, modifier = Modifier.size(18.dp))
                    Box(Modifier.weight(1f)) {
                        if (query.isEmpty()) Text(tr(R.string.files_search), style = Type.body.copy(fontSize = 14.sp), color = p.muted)
                        BasicTextField(
                            value = query, onValueChange = { query = it }, singleLine = true,
                            textStyle = Type.body.copy(fontSize = 14.sp, color = p.text), cursorBrush = SolidColor(p.primaryText),
                            modifier = Modifier.fillMaxWidth().semantics { contentDescription = tr(R.string.files_search) },
                        )
                    }
                }
            }
            item {
                Row(
                    Modifier.fillMaxWidth().heightIn(min = 48.dp).clip(RoundedCornerShape(14.dp))
                        .border(1.dp, p.muted, RoundedCornerShape(14.dp))
                        .clickable(role = Role.Button) {
                            browse.launch(arrayOf("application/pdf", "application/vnd.ms-excel", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "text/csv"))
                        }.padding(horizontal = 14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    Icon(AppIcons.cloud, null, tint = p.primaryText, modifier = Modifier.size(20.dp))
                    Column(Modifier.weight(1f)) {
                        Text(tr(R.string.files_open_cloud), style = Type.bodyStrong, color = p.text)
                        Text(tr(R.string.files_cloud_hint), style = Type.small, color = p.muted)
                    }
                }
            }
            if (!vm.hasAllFilesAccess) {
                item {
                    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(p.primarySoft).padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(tr(R.string.files_see_all), style = Type.bodyStrong, color = p.text)
                        Text(tr(R.string.files_access_hint), style = Type.small, color = p.muted)
                        PrimaryButton(tr(R.string.files_allow), { host.requestAllFilesAccess() })
                    }
                }
            }
            item { Text(if (vm.loadingFiles) tr(R.string.common_loading) else trPlural(R.plurals.files_count, visible.size, visible.size), style = Type.small, color = p.muted) }
            if (!vm.loadingFiles && visible.isEmpty()) {
                item { Text(tr(R.string.files_none), style = Type.body, color = p.muted, modifier = Modifier.fillMaxWidth().padding(vertical = 40.dp)) }
            }
            visible.forEachIndexed { index, file ->
                // One native ad after the 5th file, then every 15 files, in its own row.
                if (index == 5 || (index > 5 && (index - 5) % 15 == 0)) {
                    item(key = "ad_$index") { com.excelto.pdf.converter.ads.NativeAdCard() }
                }
                item(key = file.path) {
                FileRow(file, onClick = { actionsFor = file }) {
                    Box(
                        Modifier.size(44.dp).clip(RoundedCornerShape(22.dp)).clickable(role = Role.Button, onClickLabel = if (file.favorite) tr(R.string.files_unfavorite) else tr(R.string.files_favorite_add)) { vm.toggleFavorite(file) },
                        contentAlignment = Alignment.Center,
                    ) {
                        Icon(AppIcons.star, if (file.favorite) tr(R.string.files_favorite) else tr(R.string.files_not_favorite), tint = if (file.favorite) androidx.compose.ui.graphics.Color(0xFFA87400) else p.line, modifier = Modifier.size(20.dp))
                    }
                }
                }
            }
        }
    }
    actionsFor?.let { FileActionsSheet(vm, it) { actionsFor = null } }
}

// ---- Settings ---------------------------------------------------------------------

@Composable
fun SettingsScreen(vm: AppViewModel) {
    val p = LocalPalette.current
    val host = LocalHost.current
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        TabTitle(tr(R.string.tabs_settings))
        Column(Modifier.padding(start = 14.dp, end = 14.dp, top = 4.dp, bottom = 22.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(
                Modifier.fillMaxWidth().clip(Card18).background(p.ink).padding(16.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Column(Modifier.weight(1f)) {
                    Text(if (vm.isPremium) tr(R.string.settings_pro) else tr(R.string.settings_free), style = Type.bodyStrong.copy(fontSize = 14.sp), color = p.onInk)
                    Text(if (vm.isPremium) tr(R.string.settings_pro_hint) else tr(R.string.settings_free_hint), style = Type.small, color = p.inkMuted)
                }
                Box(
                    Modifier.heightIn(min = 42.dp).clip(RoundedCornerShape(21.dp)).background(p.mint)
                        .clickable(role = Role.Button) { if (vm.isPremium) host.manageSubscription() else host.openPaywall() }
                        .padding(horizontal = 16.dp),
                    contentAlignment = Alignment.Center,
                ) { Text(if (vm.isPremium) tr(R.string.settings_manage) else tr(R.string.home_get_pro), style = Type.tiny.copy(fontSize = 12.sp), color = androidx.compose.ui.graphics.Color(0xFF0E2A18)) }
            }

            Text(tr(R.string.settings_appearance), style = Type.bodyStrong, color = p.text, modifier = Modifier.padding(top = 6.dp))
            Segmented(listOf(tr(R.string.settings_system), tr(R.string.settings_light), tr(R.string.settings_dark)), vm.themeMode.ordinal) { vm.setTheme(ThemeMode.entries[it]) }

            Column(Modifier.fillMaxWidth().clip(Card18).background(p.surface)) {
                com.excelto.pdf.converter.ui.components.ToggleRow(tr(R.string.settings_app_lock), tr(R.string.settings_app_lock_hint), vm.appLock, {
                    if (it && !host.canUseAppLock()) vm.say(tr(R.string.settings_set_lock)) else vm.setAppLockEnabled(it)
                })
                LinkRow(tr(R.string.settings_language), tr(R.string.settings_language_hint)) { host.openLanguage() }
                LinkRow(tr(R.string.settings_file_access), if (vm.hasAllFilesAccess) tr(R.string.settings_access_all) else tr(R.string.settings_access_limited)) { host.requestAllFilesAccess() }
                LinkRow(tr(R.string.settings_rate), null) { host.rateApp() }
                LinkRow(tr(R.string.settings_share), null) { host.shareApp() }
                LinkRow(tr(R.string.settings_privacy), null) { host.openPrivacy() }
                // Required by Google for users in the EU/UK: change the ad consent choice.
                if (!vm.isPremium && remember { host.adPrivacyRequired() }) {
                    LinkRow(tr(R.string.settings_ad_privacy), null) { host.openAdPrivacy() }
                }
            }
            Spacer(Modifier.height(2.dp))
            Text("PDF Converter v${BuildConfig.VERSION_NAME}", style = Type.small, color = p.muted, modifier = Modifier.padding(horizontal = 4.dp))
        }
    }
}

/** Filter chips keep English keys; only the words are translated (file types stay as they are). */
private fun fileFilterLabel(key: String) = when (key) {
    "All" -> tr(R.string.files_all)
    "Favorites" -> tr(R.string.files_favorites)
    else -> key
}
