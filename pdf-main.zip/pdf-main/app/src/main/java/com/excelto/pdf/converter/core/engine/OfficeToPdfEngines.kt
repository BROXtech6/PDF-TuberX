package com.excelto.pdf.converter.core.engine

import com.excelto.pdf.converter.R
import com.excelto.pdf.converter.core.office.DocReader
import com.excelto.pdf.converter.core.office.DocxReader
import com.excelto.pdf.converter.core.office.FlowRenderer
import java.io.File

object WordToPdfEngine {

    class Result(val pages: Int, val notes: List<String>)

    /** Converts .docx (and older .doc files) into a PDF with real, selectable text. */
    fun convert(path: String, out: File, progress: Progress): Result = PdfTools.writing(out) {
        val file = File(path)
        progress.report(3)
        val doc = try {
            if (DocxReader.isOle(file)) DocReader.read(file) else DocxReader().read(file)
        } catch (e: UserFacingException) {
            throw e
        } catch (e: OutOfMemoryError) {
            throw e
        } catch (e: Exception) {
            throw UserFacingException(R.string.err_word_file_couldnt_read, "This Word file couldn't be read. It may be damaged.", e)
        }
        progress.report(20)
        val pages = FlowRenderer(doc, progress).render(out)
        progress.report(100)
        Result(pages, doc.notes)
    }
}

object PowerPointToPdfEngine {

    class Result(val slides: Int, val notes: List<String>)

    /** Converts a .pptx into a PDF with one page per slide; hidden slides are skipped unless asked. */
    fun convert(path: String, includeHidden: Boolean, out: File, progress: Progress): Result = PdfTools.writing(out) {
        progress.report(3)
        val deck = try {
            com.excelto.pdf.converter.core.office.PptxReader().read(File(path), includeHidden) { progress.check() }
        } catch (e: UserFacingException) {
            throw e
        } catch (e: OutOfMemoryError) {
            throw e
        } catch (e: Exception) {
            throw UserFacingException(R.string.err_presentation_couldnt_read_may, "This presentation couldn't be read. It may be damaged.", e)
        }
        if (deck.slides.isEmpty()) throw UserFacingException(R.string.err_every_slide_presentation_hidden, "Every slide in this presentation is hidden. Turn on \"Include hidden slides\" to convert them.")
        progress.report(20)
        val slides = com.excelto.pdf.converter.core.office.SlideRenderer(deck, progress).render(out)
        progress.report(100)
        Result(slides, deck.notes)
    }
}
