package com.excelto.pdf.converter.ui.tools

import com.excelto.pdf.converter.R
import com.excelto.pdf.converter.language.tr
import com.excelto.pdf.converter.language.trPlural
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.stateDescription
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.excelto.pdf.converter.core.engine.CropEngine
import com.excelto.pdf.converter.core.engine.ImageFormat
import com.excelto.pdf.converter.core.engine.NRect
import com.excelto.pdf.converter.core.engine.NumberFormat
import com.excelto.pdf.converter.core.engine.NumberPosition
import com.excelto.pdf.converter.core.engine.OcrScript
import com.excelto.pdf.converter.core.engine.PageNumberEngine
import com.excelto.pdf.converter.core.engine.PageNumberOptions
import com.excelto.pdf.converter.core.engine.PageRanges
import com.excelto.pdf.converter.core.model.DocFile
import com.excelto.pdf.converter.core.render.PdfPages
import com.excelto.pdf.converter.ui.AppViewModel
import com.excelto.pdf.converter.ui.Route
import com.excelto.pdf.converter.ui.components.ChoiceRow
import com.excelto.pdf.converter.ui.components.SecondaryButton
import com.excelto.pdf.converter.ui.components.ToggleRow
import com.excelto.pdf.converter.ui.sheets.appTextFieldColors
import com.excelto.pdf.converter.ui.theme.AppIcons
import com.excelto.pdf.converter.ui.theme.LocalPalette
import com.excelto.pdf.converter.ui.theme.Type
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.roundToInt

// ---- Shared pieces ----------------------------------------------------------------------

/** A collapsible tr(R.string.more_options) section for settings most people never change. */
@Composable
fun MoreOptions(content: @Composable ColumnScope.() -> Unit) {
    val p = LocalPalette.current
    var open by rememberSaveable { mutableStateOf(false) }
    Row(
        Modifier.fillMaxWidth().heightIn(min = 44.dp).clip(RoundedCornerShape(12.dp)).clickable(role = Role.Button) { open = !open }
            .semantics { stateDescription = if (open) tr(R.string.a11y_expanded) else tr(R.string.a11y_collapsed) },
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(tr(R.string.more_options), style = Type.bodyStrong, color = p.primaryText, modifier = Modifier.weight(1f))
        Icon(if (open) AppIcons.up else AppIcons.down, null, tint = p.primaryText, modifier = Modifier.size(20.dp))
    }
    if (open) Column(verticalArrangement = Arrangement.spacedBy(12.dp), content = content)
}

/** How a page tile marks a chosen page. */
enum class PageMark { REMOVE, KEEP }

/** A grid of page thumbnails. Tapping a page calls [onTap]; [marked] pages show [mark]. */
@Composable
fun PageGrid(file: DocFile, count: Int, marked: Set<Int>, mark: PageMark, rotations: Map<Int, Int> = emptyMap(), onTap: (Int) -> Unit) {
    val p = LocalPalette.current
    (0 until count).chunked(3).forEach { row ->
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            row.forEach { i ->
                val on = i in marked
                val color = if (mark == PageMark.REMOVE) p.danger else p.primaryText
                Column(
                    Modifier.weight(1f).clip(RoundedCornerShape(12.dp))
                        .border(2.dp, if (on) color else Color.Transparent, RoundedCornerShape(12.dp))
                        .background(p.surface).clickable(role = Role.Button) { onTap(i) }
                        .semantics {
                            contentDescription = tr(R.string.a11y_page, i + 1)
                            stateDescription = if (on) (if (mark == PageMark.REMOVE) tr(R.string.pages_will_remove) else tr(R.string.a11y_selected)) else ""
                        }
                        .padding(6.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Box(Modifier.fillMaxWidth().aspectRatio(0.72f)) {
                        PdfThumb(file, i, rotations[i] ?: 0, Modifier.fillMaxSize())
                        if (on) {
                            Box(Modifier.fillMaxSize().background(color.copy(alpha = if (mark == PageMark.REMOVE) 0.18f else 0.10f)))
                            Box(
                                Modifier.align(Alignment.TopEnd).padding(4.dp).size(24.dp).clip(CircleShape).background(color),
                                contentAlignment = Alignment.Center,
                            ) { Icon(if (mark == PageMark.REMOVE) AppIcons.close else AppIcons.check, null, tint = Color.White, modifier = Modifier.size(14.dp)) }
                        }
                    }
                    Text("${i + 1}", style = Type.tiny.copy(fontSize = 12.sp), color = p.text, modifier = Modifier.padding(top = 4.dp))
                }
            }
            repeat(3 - row.size) { Box(Modifier.weight(1f)) }
        }
    }
}

// ---- Remove pages ---------------------------------------------------------------------

@Composable
fun RemovePagesScreen(vm: AppViewModel, route: Route.ToolScreen) {
    val file = route.files.firstOrNull()
    val count = rememberPageCount(vm, file)
    val chosen = remember(file?.path) { mutableStateMapOf<Int, Boolean>() }
    val n = chosen.size
    val all = count != null && n >= count
    ToolScaffold(vm, route, if (n == 0) tr(R.string.remove_choose) else trPlural(R.plurals.remove_n, n, n), enabled = n > 0 && !all, onStart = {
        vm.runRemovePages(file!!, count!!, chosen.keys.toSet())
    }) {
        if (count == null) Note(tr(R.string.pages_loading)) else {
            Note(if (all) tr(R.string.remove_keep_one) else tr(R.string.remove_tap))
            PageGrid(file!!, count, chosen.keys, PageMark.REMOVE) { i -> if (chosen.remove(i) == null) chosen[i] = true }
        }
    }
}

// ---- Extract pages --------------------------------------------------------------------

@Composable
fun ExtractPagesScreen(vm: AppViewModel, route: Route.ToolScreen) {
    val file = route.files.firstOrNull()
    val count = rememberPageCount(vm, file)
    val chosen = remember(file?.path) { mutableStateMapOf<Int, Boolean>() }
    var separate by rememberSaveable { mutableStateOf(false) }
    val n = chosen.size
    ToolScaffold(vm, route, if (n == 0) tr(R.string.extract_choose) else if (separate) trPlural(R.plurals.extract_separate_n, n, n) else trPlural(R.plurals.extract_one_n, n, n),
        enabled = n > 0, onStart = { vm.runExtractPages(file!!, chosen.keys.toList(), separate) }) {
        if (count == null) Note(tr(R.string.pages_loading)) else {
            Note(tr(R.string.extract_tap))
            PageGrid(file!!, count, chosen.keys, PageMark.KEEP) { i -> if (chosen.remove(i) == null) chosen[i] = true }
            Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(LocalPalette.current.surface)) {
                ToggleRow(tr(R.string.extract_separate), null, separate, { separate = it }, showDivider = false)
            }
        }
    }
}

// ---- Rotate ---------------------------------------------------------------------------

@Composable
fun RotateScreen(vm: AppViewModel, route: Route.ToolScreen) {
    val file = route.files.firstOrNull()
    val count = rememberPageCount(vm, file)
    val rotations = remember(file?.path) { mutableStateMapOf<Int, Int>() }
    val chosen = remember(file?.path) { mutableStateMapOf<Int, Boolean>() }
    var scope by rememberSaveable { mutableIntStateOf(0) } // 0 = all pages, 1 = chosen pages
    val changed = rotations.values.any { it % 360 != 0 }
    fun turn(by: Int) {
        val pages = if (scope == 0) (0 until (count ?: 0)).toList() else chosen.keys.toList()
        pages.forEach { i -> rotations[i] = ((rotations[i] ?: 0) + by + 360) % 360 }
    }
    ToolScaffold(vm, route, tr(R.string.rotate_save), enabled = changed, onStart = { vm.runRotate(file!!, count!!, rotations.toMap()) }) {
        if (count == null) Note(tr(R.string.pages_loading)) else {
            ChoiceRow(listOf(tr(R.string.pages_all), tr(R.string.pages_choose)), scope) { scope = it }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                SecondaryButton(tr(R.string.rotate_left), { turn(-90) }, Modifier.weight(1f))
                SecondaryButton(tr(R.string.rotate_right), { turn(90) }, Modifier.weight(1f))
                SecondaryButton("180°", { turn(180) }, Modifier.weight(1f))
            }
            if (scope == 1) Note(if (chosen.isEmpty()) tr(R.string.rotate_tap) else trPlural(R.plurals.pages_chosen, chosen.size, chosen.size))
            PageGrid(file!!, count, if (scope == 1) chosen.keys else emptySet(), PageMark.KEEP, rotations) { i ->
                if (scope == 1) { if (chosen.remove(i) == null) chosen[i] = true }
            }
            if (changed) SecondaryButton(tr(R.string.common_reset), { rotations.clear() })
        }
    }
}

// ---- Page numbers ---------------------------------------------------------------------

private val numberColors get() = listOf(tr(R.string.color_dark) to 0xFF333333.toInt(), tr(R.string.color_gray) to 0xFF7A7A7A.toInt(), tr(R.string.color_blue) to 0xFF1D5FBF.toInt(), tr(R.string.color_red) to 0xFFB3261E.toInt())

@Composable
fun PageNumbersScreen(vm: AppViewModel, route: Route.ToolScreen) {
    val p = LocalPalette.current
    val file = route.files.firstOrNull()
    val count = rememberPageCount(vm, file)
    var position by rememberSaveable { mutableIntStateOf(NumberPosition.BOTTOM_CENTER.ordinal) }
    var format by rememberSaveable { mutableIntStateOf(NumberFormat.PAGE_OF.ordinal) }
    var start by rememberSaveable { mutableStateOf("1") }
    var first by rememberSaveable { mutableStateOf("1") }
    var size by rememberSaveable { mutableFloatStateOf(11f) }
    var color by rememberSaveable { mutableIntStateOf(0) }
    val options = PageNumberOptions(
        NumberPosition.entries[position], NumberFormat.entries[format],
        start.toIntOrNull()?.coerceAtLeast(0) ?: 1, first.toIntOrNull()?.coerceAtLeast(1) ?: 1, size, numberColors[color].second,
    )
    val firstOk = count == null || options.firstPage <= count
    ToolScaffold(vm, route, tr(R.string.tool_page_numbers), enabled = firstOk && start.toIntOrNull() != null, onStart = { vm.runPageNumbers(file!!, options) }) {
        // Live preview on the first numbered page.
        val previewIndex = (options.firstPage - 1).coerceIn(0, ((count ?: 1) - 1).coerceAtLeast(0))
        val last = options.startNumber + (count ?: 1) - options.firstPage
        val label = PageNumberEngine.label(options.format, options.startNumber, last)
        Box(Modifier.fillMaxWidth().heightIn(max = 340.dp).aspectRatio(0.72f).clip(RoundedCornerShape(4.dp)).background(Color.White).semantics { contentDescription = tr(R.string.a11y_preview, label) }) {
            if (file != null) PdfThumb(file, previewIndex, modifier = Modifier.fillMaxSize())
            val align = when (options.position) {
                NumberPosition.TOP_LEFT -> Alignment.TopStart
                NumberPosition.TOP_CENTER -> Alignment.TopCenter
                NumberPosition.TOP_RIGHT -> Alignment.TopEnd
                NumberPosition.BOTTOM_LEFT -> Alignment.BottomStart
                NumberPosition.BOTTOM_CENTER -> Alignment.BottomCenter
                NumberPosition.BOTTOM_RIGHT -> Alignment.BottomEnd
            }
            Text(label, color = Color(numberColors[color].second), style = Type.small.copy(fontSize = (size * 0.55f).sp),
                modifier = Modifier.align(align).padding(10.dp))
        }
        Label(tr(R.string.opt_position))
        NumberPosition.entries.chunked(3).forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                row.forEach { pos -> com.excelto.pdf.converter.ui.components.ChoiceBox(pos.label, position == pos.ordinal, { position = pos.ordinal }, Modifier.weight(1f)) }
            }
        }
        Label(tr(R.string.opt_format))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            NumberFormat.entries.forEach { f -> com.excelto.pdf.converter.ui.components.ChoiceBox(f.sample, format == f.ordinal, { format = f.ordinal }, Modifier.weight(1f)) }
        }
        MoreOptions {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(start, { start = it.filter(Char::isDigit).take(5) }, singleLine = true, colors = appTextFieldColors(),
                    label = { Text(tr(R.string.numbers_start)) }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.weight(1f))
                OutlinedTextField(first, { first = it.filter(Char::isDigit).take(5) }, singleLine = true, colors = appTextFieldColors(),
                    label = { Text(tr(R.string.numbers_first)) }, isError = !firstOk, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.weight(1f))
            }
            if (!firstOk) Note(tr(R.string.numbers_only_pages, count))
            Label(tr(R.string.numbers_font_size, size.roundToInt()))
            Slider(size, { size = it.roundToInt().toFloat() }, valueRange = 7f..24f,
                colors = SliderDefaults.colors(thumbColor = p.primaryText, activeTrackColor = p.primaryText, inactiveTrackColor = p.line))
            Label(tr(R.string.opt_color))
            ChoiceRow(numberColors.map { it.first }, color) { color = it }
        }
    }
}

// ---- Crop -----------------------------------------------------------------------------

@Composable
fun CropScreen(vm: AppViewModel, route: Route.ToolScreen) {
    val p = LocalPalette.current
    val file = route.files.firstOrNull()
    val count = rememberPageCount(vm, file)
    var page by rememberSaveable { mutableIntStateOf(0) }
    var area by remember(file?.path) { mutableStateOf(NRect(0.05f, 0.05f, 0.95f, 0.95f)) }
    var scope by rememberSaveable { mutableIntStateOf(0) } // 0 = all pages, 1 = this page
    var removeTrimmed by rememberSaveable { mutableStateOf(false) }
    val scopeCo = rememberCoroutineScope()
    ToolScaffold(vm, route, if (scope == 0) tr(R.string.crop_all) else tr(R.string.crop_page_n, page + 1), enabled = count != null, onStart = {
        vm.runCrop(file!!, area, if (scope == 0) null else page, removeTrimmed)
    }) {
        if (count == null) Note(tr(R.string.pages_loading)) else {
            Note(tr(R.string.crop_drag))
            CropEditor(file!!, page, area) { area = it }
            if (count > 1) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    SecondaryButton(tr(R.string.common_previous), { if (page > 0) page-- }, Modifier.weight(1f))
                    Text(tr(R.string.page_of, page + 1, count), style = Type.bodyStrong, color = p.text)
                    SecondaryButton(tr(R.string.common_next), { if (page < count - 1) page++ }, Modifier.weight(1f))
                }
            }
            SecondaryButton(tr(R.string.crop_auto), {
                scopeCo.launch {
                    val found = withContext(Dispatchers.IO) { PdfPages.render(file.file, page, 600)?.let { CropEngine.contentBounds(it) } }
                    if (found != null) area = found else vm.say(tr(R.string.crop_blank))
                }
            })
            Label(tr(R.string.crop_apply_to))
            ChoiceRow(listOf(tr(R.string.pages_all), tr(R.string.crop_this_page)), scope) { scope = it }
            MoreOptions {
                Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(p.surface)) {
                    ToggleRow(tr(R.string.crop_remove), tr(R.string.crop_remove_hint), removeTrimmed, { removeTrimmed = it }, showDivider = false)
                }
            }
        }
    }
}

/** A page preview with a crop frame; each of the 4 edges has a handle you can drag. */
@Composable
private fun CropEditor(file: DocFile, page: Int, area: NRect, onChange: (NRect) -> Unit) {
    val p = LocalPalette.current
    val density = LocalDensity.current
    var size by remember { mutableStateOf(IntSize.Zero) }
    val current by androidx.compose.runtime.rememberUpdatedState(area)
    BoxWithConstraints(Modifier.fillMaxWidth().heightIn(max = 420.dp).aspectRatio(0.72f).background(Color.White).onSizeChanged { size = it }) {
        PdfThumb(file, page, modifier = Modifier.fillMaxSize())
        if (size.width > 0) {
            val w = size.width.toFloat(); val h = size.height.toFloat()
            val l = area.left * w; val t = area.top * h; val r = area.right * w; val b = area.bottom * h
            val shade = Color(0x88000000)
            with(density) {
                Box(Modifier.offset { IntOffset(0, 0) }.size(w.toDp(), t.toDp()).background(shade))
                Box(Modifier.offset { IntOffset(0, b.toInt()) }.size(w.toDp(), (h - b).toDp()).background(shade))
                Box(Modifier.offset { IntOffset(0, t.toInt()) }.size(l.toDp(), (b - t).toDp()).background(shade))
                Box(Modifier.offset { IntOffset(r.toInt(), t.toInt()) }.size((w - r).toDp(), (b - t).toDp()).background(shade))
                Box(Modifier.offset { IntOffset(l.toInt(), t.toInt()) }.size((r - l).toDp(), (b - t).toDp()).border(2.dp, p.primary))
                val handle = 44.dp.toPx()
                @Composable fun handleAt(cx: Float, cy: Float, edge: Int, label: String) = Box(
                    Modifier.offset { IntOffset((cx - handle / 2).toInt(), (cy - handle / 2).toInt()) }.size(44.dp)
                        .semantics { contentDescription = label }
                        .pointerInput(edge, size) {
                            detectDragGestures { change, drag ->
                                change.consume()
                                val a = current
                                val minGap = 0.05f
                                onChange(
                                    when (edge) {
                                        0 -> a.copy(left = (a.left + drag.x / w).coerceIn(0f, a.right - minGap))
                                        1 -> a.copy(top = (a.top + drag.y / h).coerceIn(0f, a.bottom - minGap))
                                        2 -> a.copy(right = (a.right + drag.x / w).coerceIn(a.left + minGap, 1f))
                                        else -> a.copy(bottom = (a.bottom + drag.y / h).coerceIn(a.top + minGap, 1f))
                                    },
                                )
                            }
                        },
                    contentAlignment = Alignment.Center,
                ) { Box(Modifier.size(16.dp).clip(CircleShape).background(p.primary).border(2.dp, Color.White, CircleShape)) }
                handleAt(l, (t + b) / 2, 0, tr(R.string.crop_left))
                handleAt((l + r) / 2, t, 1, tr(R.string.crop_top))
                handleAt(r, (t + b) / 2, 2, tr(R.string.crop_right))
                handleAt((l + r) / 2, b, 3, tr(R.string.crop_bottom))
            }
        }
    }
}

// ---- Repair, OCR, PDF to JPG ----------------------------------------------------------------

@Composable
fun RepairScreen(vm: AppViewModel, route: Route.ToolScreen) {
    ToolScaffold(vm, route, tr(R.string.tool_repair), enabled = true, onStart = { vm.runRepair(route.files.first()) }) {
        InfoCard(tr(R.string.repair_title), tr(R.string.repair_body))
    }
}

@Composable
fun OcrScreen(vm: AppViewModel, route: Route.ToolScreen) {
    var script by rememberSaveable { mutableIntStateOf(0) }
    ToolScaffold(vm, route, tr(R.string.ocr_go), enabled = true, onStart = { vm.runOcr(route.files.first(), OcrScript.entries[script]) }) {
        InfoCard(tr(R.string.ocr_title), tr(R.string.ocr_body))
        Label(tr(R.string.ocr_language))
        OcrScript.entries.chunked(2).forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                row.forEach { s -> com.excelto.pdf.converter.ui.components.ChoiceBox(s.label, script == s.ordinal, { script = s.ordinal }, Modifier.weight(1f)) }
                if (row.size == 1) Box(Modifier.weight(1f))
            }
        }
        Note(tr(R.string.ocr_rtl_short))
    }
}

@Composable
fun PdfToJpgScreen(vm: AppViewModel, route: Route.ToolScreen) {
    val file = route.files.firstOrNull()
    val count = rememberPageCount(vm, file)
    var which by rememberSaveable { mutableIntStateOf(0) } // 0 = all, 1 = chosen
    var ranges by rememberSaveable { mutableStateOf("") }
    var quality by rememberSaveable { mutableIntStateOf(0) }
    var format by rememberSaveable { mutableIntStateOf(0) }
    val parsed = if (which == 1 && count != null) PageRanges.parse(ranges, count) else null
    val pages = parsed?.flatMap { it.toList() }?.distinct()?.map { it - 1 }.orEmpty()
    val n = if (which == 0) count ?: 0 else pages.size
    ToolScaffold(vm, route, if (n == 0) tr(R.string.pages_choose) else trPlural(R.plurals.images_save_n, n, n), enabled = count != null && n > 0, onStart = {
        vm.runPdfToImages(file!!, if (which == 0) emptyList() else pages, if (quality == 0) 150f else 300f, ImageFormat.entries[format])
    }) {
        Label(tr(R.string.opt_pages))
        ChoiceRow(listOf(tr(R.string.pages_all), tr(R.string.pages_choose)), which) { which = it }
        if (which == 1) {
            OutlinedTextField(ranges, { ranges = it }, singleLine = true, colors = appTextFieldColors(), isError = ranges.isNotBlank() && parsed == null,
                label = { Text(tr(R.string.jpg_pages_hint)) }, supportingText = { Text(if (count != null) tr(R.string.pdf_has_pages, count) else "") }, modifier = Modifier.fillMaxWidth())
        }
        Label(tr(R.string.opt_quality))
        ChoiceRow(listOf(tr(R.string.jpg_normal), tr(R.string.jpg_high)), quality) { quality = it }
        MoreOptions {
            Label(tr(R.string.opt_format))
            ChoiceRow(ImageFormat.entries.map { it.label }, format) { format = it }
        }
        Note(tr(R.string.jpg_folder_note))
    }
}
