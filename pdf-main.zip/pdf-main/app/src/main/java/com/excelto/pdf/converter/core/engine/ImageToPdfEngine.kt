package com.excelto.pdf.converter.core.engine

import com.excelto.pdf.converter.R
import android.content.ContentResolver
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.net.Uri
import androidx.exifinterface.media.ExifInterface
import com.tom_roush.pdfbox.io.MemoryUsageSetting
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.pdmodel.PDPage
import com.tom_roush.pdfbox.pdmodel.PDPageContentStream
import com.tom_roush.pdfbox.pdmodel.common.PDRectangle
import com.tom_roush.pdfbox.pdmodel.graphics.image.JPEGFactory
import java.io.File

enum class PageChoice(@androidx.annotation.StringRes private val labelRes: Int) { ORIGINAL(R.string.compare_original), A4(R.string.page_a4), LETTER(R.string.page_letter); val label: String get() = com.excelto.pdf.converter.language.tr(labelRes) }

object ImageToPdfEngine {

    private const val MAX_EDGE = 2480 // about 300 dpi on A4

    fun convert(resolver: ContentResolver, images: List<Uri>, page: PageChoice, margin: Float, out: File, progress: Progress) {
        require(images.isNotEmpty()) { "Choose at least one image" }
        PdfTools.writing(out) {
            PDDocument(MemoryUsageSetting.setupTempFileOnly()).use { doc ->
                images.forEachIndexed { index, uri ->
                    progress.check()
                    val bitmap = load(resolver, uri) ?: throw UserFacingException(R.string.err_one_images_couldnt_opened, "One of the images couldn't be opened.")
                    val landscape = bitmap.width > bitmap.height
                    val size = when (page) {
                        PageChoice.A4 -> if (landscape) PDRectangle(PDRectangle.A4.height, PDRectangle.A4.width) else PDRectangle.A4
                        PageChoice.LETTER -> if (landscape) PDRectangle(PDRectangle.LETTER.height, PDRectangle.LETTER.width) else PDRectangle.LETTER
                        PageChoice.ORIGINAL -> {
                            // Long edge of 842 pt (A4 height), keeping the photo's shape.
                            val ratio = 842f / maxOf(bitmap.width, bitmap.height)
                            PDRectangle(bitmap.width * ratio, bitmap.height * ratio)
                        }
                    }
                    val image = try { JPEGFactory.createFromImage(doc, bitmap, 0.88f) } finally { bitmap.recycle() }
                    val pdPage = PDPage(size)
                    doc.addPage(pdPage)
                    val inset = if (page == PageChoice.ORIGINAL) 0f else margin
                    val fit = minOf((size.width - inset * 2) / image.width, (size.height - inset * 2) / image.height)
                    val w = image.width * fit
                    val h = image.height * fit
                    PDPageContentStream(doc, pdPage).use { cs ->
                        cs.drawImage(image, (size.width - w) / 2, (size.height - h) / 2, w, h)
                    }
                    progress.step(index + 1, images.size)
                }
                doc.save(out)
            }
        }
        progress.report(100)
    }

    /** Decodes a photo at a sensible size and turns it upright using its EXIF data. */
    fun load(resolver: ContentResolver, uri: Uri): Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        if (bounds.outWidth <= 0) return null
        var sample = 1
        while (maxOf(bounds.outWidth, bounds.outHeight) / (sample * 2) >= MAX_EDGE) sample *= 2
        val bitmap = resolver.openInputStream(uri)?.use {
            BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = sample })
        } ?: return null
        val orientation = runCatching {
            resolver.openInputStream(uri)?.use { ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL) }
        }.getOrNull() ?: ExifInterface.ORIENTATION_NORMAL
        val degrees = when (orientation) {
            ExifInterface.ORIENTATION_ROTATE_90 -> 90f
            ExifInterface.ORIENTATION_ROTATE_180 -> 180f
            ExifInterface.ORIENTATION_ROTATE_270 -> 270f
            else -> 0f
        }
        if (degrees == 0f) return bitmap
        val rotated = Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, Matrix().apply { postRotate(degrees) }, true)
        if (rotated !== bitmap) bitmap.recycle()
        return rotated
    }
}
