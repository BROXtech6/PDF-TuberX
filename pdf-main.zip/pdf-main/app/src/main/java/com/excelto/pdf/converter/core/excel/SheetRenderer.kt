package com.excelto.pdf.converter.core.excel

import com.excelto.pdf.converter.R
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import com.tom_roush.pdfbox.io.MemoryUsageSetting
import com.tom_roush.pdfbox.multipdf.PDFMergerUtility
import java.io.File
import kotlin.math.floor

/**
 * Draws worksheets into a PDF with Android's PdfDocument and Canvas, so text stays
 * real text and Android shapes Arabic, Hebrew and CJK correctly.
 *
 * Pages are written in chunks of [CHUNK] and joined with PdfBox at the end, so long
 * sheets (50,000+ rows) never keep every page in memory.
 */
class SheetRenderer(
    private val workbook: ExcelWorkbook,
    private val options: PrintOptions,
    private val workDir: File,
    private val onPage: (done: Int, total: Int) -> Unit = { _, _ -> },
    private val check: () -> Unit = {},
) {
    class Result(val pages: Int, val notes: List<String>)

    private val fill = Paint().apply { style = Paint.Style.FILL }
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val text = TextPaint(Paint.ANTI_ALIAS_FLAG or Paint.SUBPIXEL_TEXT_FLAG)
    private var undecodable = 0

    /** Renders [sheets] (indexes into the workbook) to [out]. */
    fun render(sheets: List<Int>, out: File): Result {
        val layouts = sheets.mapNotNull { i ->
            val sheet = workbook.sheets[i]
            val range = sheet.printArea ?: sheet.usedRange(workbook) ?: return@mapNotNull null
            SheetLayout(sheet, range, options)
        }
        val total = layouts.sumOf { it.pages.size }
        if (total == 0) throw com.excelto.pdf.converter.core.engine.UserFacingException(R.string.err_chosen_sheets_are_empty, "The chosen sheets are empty, so there's nothing to print.")

        val chunks = mutableListOf<File>()
        var doc = PdfDocument()
        var inChunk = 0
        var done = 0
        try {
            for (layout in layouts) {
                for ((colBand, rowBand) in layout.pages) {
                    check()
                    val w = layout.pageWidth.toInt()
                    val h = layout.pageHeight.toInt()
                    val page = doc.startPage(PdfDocument.PageInfo.Builder(w, h, done + 1).create())
                    drawPage(page.canvas, layout, colBand, rowBand)
                    doc.finishPage(page)
                    done++
                    inChunk++
                    onPage(done, total)
                    if (inChunk == CHUNK) {
                        chunks += flush(doc, chunks.size)
                        doc = PdfDocument()
                        inChunk = 0
                    }
                }
            }
            if (inChunk > 0) chunks += flush(doc, chunks.size) else doc.close()
            if (chunks.size == 1) {
                chunks[0].copyTo(out, overwrite = true)
            } else {
                PDFMergerUtility().apply {
                    chunks.forEach { addSource(it) }
                    destinationFileName = out.absolutePath
                }.mergeDocuments(MemoryUsageSetting.setupTempFileOnly())
            }
        } finally {
            chunks.forEach { it.delete() }
        }
        val notes = mutableListOf<String>()
        val charts = sheets.sumOf { workbook.sheets[it].chartCount }
        if (charts > 0) notes += runCatching { com.excelto.pdf.converter.language.tr(com.excelto.pdf.converter.R.string.note_no_charts) }.getOrDefault("Charts aren't included.")
        if (undecodable > 0) notes += runCatching { com.excelto.pdf.converter.language.tr(com.excelto.pdf.converter.R.string.note_no_emf) }.getOrDefault("Some pictures (EMF/WMF) aren't included.")
        return Result(total, notes)
    }

    private fun flush(doc: PdfDocument, index: Int): File {
        val file = File(workDir, "excel_chunk_${System.nanoTime()}_$index.pdf")
        try {
            file.outputStream().use { doc.writeTo(it) }
        } finally {
            doc.close()
        }
        return file
    }

    // ---- One page ------------------------------------------------------------------

    private class Box(val left: Float, val top: Float, val right: Float, val bottom: Float) {
        val width get() = right - left
        val height get() = bottom - top
    }

    private fun drawPage(canvas: Canvas, l: SheetLayout, colBand: IntRange, rowBand: IntRange) {
        val sheet = l.sheet
        val x0 = l.colX[colBand.first]
        val y0 = l.rowY[rowBand.first]
        val bandW = l.colX[colBand.last + 1] - x0
        val bandH = l.rowY[rowBand.last + 1] - y0
        val rtl = sheet.rightToLeft

        canvas.save()
        canvas.translate(if (rtl) l.pageWidth - l.marginLeft - bandW * l.scale else l.marginLeft, l.marginTop)
        canvas.scale(l.scale, l.scale)
        canvas.clipRect(0f, 0f, bandW, bandH)

        // Page coordinates of a sheet rectangle (mirrored for right-to-left sheets).
        fun box(xs: Float, ys: Float, xe: Float, ye: Float): Box =
            if (rtl) Box(bandW - (xe - x0), ys - y0, bandW - (xs - x0), ye - y0) else Box(xs - x0, ys - y0, xe - x0, ye - y0)

        val mergeAt = HashMap<Long, CellRange>() // top-left cell → range
        val inMerge = HashMap<Long, CellRange>()
        for (m in sheet.merges) {
            if (m.lastRow < l.rows[rowBand.first] || m.firstRow > l.rows[rowBand.last] || m.lastCol < l.cols[colBand.first] || m.firstCol > l.cols[colBand.last]) continue
            mergeAt[key(m.firstRow, m.firstCol)] = m
            for (r in m.firstRow..m.lastRow) for (c in m.firstCol..m.lastCol) inMerge[key(r, c)] = m
        }
        fun mergeBox(m: CellRange) = box(l.xOf(m.firstCol), l.yOf(m.firstRow), l.xOf(m.lastCol + 1).let { if (l.colPos(m.lastCol) >= 0) l.colX[l.colPos(m.lastCol) + 1] else it }, if (l.rowPos(m.lastRow) >= 0) l.rowY[l.rowPos(m.lastRow) + 1] else l.yOf(m.lastRow + 1))
        fun cellBox(ri: Int, ci: Int) = box(l.colX[ci], l.rowY[ri], l.colX[ci + 1], l.rowY[ri + 1])
        fun styleAt(r: Int, c: Int): CellStyle {
            val row = sheet.rows[r]
            val i = row?.indexOf(c) ?: -1
            return if (i >= 0) workbook.style(row!!.styles[i]) else sheet.colStyles[c]?.let { workbook.style(it) } ?: CellStyle.DEFAULT
        }

        // 1. Fills.
        val drawnMerges = HashSet<CellRange>()
        for (ri in rowBand) for (ci in colBand) {
            val r = l.rows[ri]; val c = l.cols[ci]
            val m = inMerge[key(r, c)]
            if (m != null) {
                if (drawnMerges.add(m)) styleAt(m.firstRow, m.firstCol).fill?.let { color -> fillRect(canvas, mergeBox(m), color) }
                continue
            }
            styleAt(r, c).fill?.let { fillRect(canvas, cellBox(ri, ci), it) }
        }

        // 2. Gridlines (only when asked), not through merged cells.
        if (options.printGridlines || sheet.pageSetup.printGridlines) {
            line.color = 0xFFBFBFBF.toInt(); line.strokeWidth = 0.5f / l.scale.coerceAtLeast(0.5f); line.pathEffect = null
            for (ri in rowBand) for (ci in colBand) {
                val m = inMerge[key(l.rows[ri], l.cols[ci])]
                val b = cellBox(ri, ci)
                if (m == null || l.rows[ri] == m.lastRow) canvas.drawLine(b.left, b.bottom, b.right, b.bottom, line)
                if (m == null || l.cols[ci] == m.lastCol) canvas.drawLine(if (rtl) b.left else b.right, b.top, if (rtl) b.left else b.right, b.bottom, line)
                if (ri == rowBand.first) canvas.drawLine(b.left, b.top, b.right, b.top, line)
                if (ci == colBand.first) canvas.drawLine(if (rtl) b.right else b.left, b.top, if (rtl) b.right else b.left, b.bottom, line)
            }
        }

        // 3. Borders: each cell's own sides, except sides inside a merged block.
        for (ri in rowBand) for (ci in colBand) {
            val r = l.rows[ri]; val c = l.cols[ci]
            val s = styleAt(r, c)
            if (s.left == null && s.right == null && s.top == null && s.bottom == null) continue
            val m = inMerge[key(r, c)]
            val b = cellBox(ri, ci)
            val (startX, endX) = if (rtl) b.right to b.left else b.left to b.right
            if (s.left != null && (m == null || c == m.firstCol)) border(canvas, s.left, startX, b.top, startX, b.bottom, true)
            if (s.right != null && (m == null || c == m.lastCol)) border(canvas, s.right, endX, b.top, endX, b.bottom, true)
            if (s.top != null && (m == null || r == m.firstRow)) border(canvas, s.top, b.left, b.top, b.right, b.top, false)
            if (s.bottom != null && (m == null || r == m.lastRow)) border(canvas, s.bottom, b.left, b.bottom, b.right, b.bottom, false)
        }

        // 4. Text.
        for (ri in rowBand) {
            val r = l.rows[ri]
            val row = sheet.rows[r] ?: continue
            for (k in 0 until row.size) {
                val c = row.cols[k]
                val ci = l.colPos(c)
                if (ci < 0 || !row.hasValue(k)) continue
                val m = mergeAt[key(r, c)]
                if (m == null && inMerge.containsKey(key(r, c))) continue // covered by a merge
                if (m == null && ci !in colBand) continue // on another page (spills are handled below)
                drawCellText(canvas, l, row, k, r, ci, ri, m, colBand, inMerge, ::box)
            }
            // Text that spills in from a cell just left/right of this page's column band.
            spillFromNeighbours(canvas, l, row, r, ri, colBand, inMerge, ::box)
        }

        // 5. Pictures.
        for (img in sheet.images) drawImage(canvas, l, img, ::box, bandW, bandH)

        canvas.restore()
    }

    private fun key(r: Int, c: Int): Long = (r.toLong() shl 20) or c.toLong()

    private fun fillRect(canvas: Canvas, b: Box, color: Int) {
        fill.color = color
        canvas.drawRect(b.left, b.top, b.right, b.bottom, fill)
    }

    private fun border(canvas: Canvas, b: BorderLine, x1: Float, y1: Float, x2: Float, y2: Float, vertical: Boolean) {
        line.color = b.color
        line.strokeWidth = b.style.width
        line.pathEffect = b.style.dash?.let { DashPathEffect(it, 0f) }
        if (b.style.double) {
            val d = 1f
            if (vertical) {
                canvas.drawLine(x1 - d, y1, x2 - d, y2, line); canvas.drawLine(x1 + d, y1, x2 + d, y2, line)
            } else {
                canvas.drawLine(x1, y1 - d, x2, y2 - d, line); canvas.drawLine(x1, y1 + d, x2, y2 + d, line)
            }
        } else {
            canvas.drawLine(x1, y1, x2, y2, line)
        }
        line.pathEffect = null
    }

    private fun setFont(font: CellFont, color: Int?) {
        val family = when {
            font.name.contains("mono", true) || font.name.contains("courier", true) || font.name.contains("consolas", true) -> Typeface.MONOSPACE
            font.name.contains("times", true) || font.name.contains("cambria", true) || font.name.contains("georgia", true) ||
                font.name.contains("serif", true) && !font.name.contains("sans", true) -> Typeface.SERIF
            else -> Typeface.SANS_SERIF
        }
        val style = when {
            font.bold && font.italic -> Typeface.BOLD_ITALIC
            font.bold -> Typeface.BOLD
            font.italic -> Typeface.ITALIC
            else -> Typeface.NORMAL
        }
        text.typeface = Typeface.create(family, style)
        text.textSize = font.size
        text.color = color ?: font.color
        text.isUnderlineText = font.underline
        text.isStrikeThruText = font.strike
        // Excel's widths are measured in Calibri, about 10% narrower than Android's sans font.
        // Match its digit width so text that fits in Excel fits here too (instead of "####").
        text.textScaleX = 1f
        if (family == Typeface.SANS_SERIF && narrowFonts.any { font.name.contains(it, ignoreCase = true) }) {
            val digit = text.measureText("0")
            if (digit > 0f) text.textScaleX = (CALIBRI_DIGIT_EM * font.size / digit).coerceIn(0.8f, 1f)
        }
    }

    private val narrowFonts = listOf("Calibri", "Aptos", "Candara", "Corbel", "Segoe", "Carlito")

    private fun startsRtl(s: String): Boolean {
        for (ch in s) {
            when (Character.getDirectionality(ch)) {
                Character.DIRECTIONALITY_RIGHT_TO_LEFT, Character.DIRECTIONALITY_RIGHT_TO_LEFT_ARABIC -> return true
                Character.DIRECTIONALITY_LEFT_TO_RIGHT -> return false
            }
        }
        return false
    }

    private enum class Side { LEFT, CENTER, RIGHT }

    private fun drawCellText(
        canvas: Canvas, l: SheetLayout, row: RowData, k: Int, r: Int, ci: Int, ri: Int,
        merge: CellRange?, colBand: IntRange, inMerge: Map<Long, CellRange>,
        box: (Float, Float, Float, Float) -> Box,
    ) {
        val style = workbook.style(row.styles[k])
        val shown = workbook.display(row, k)
        var value = shown.text
        if (value.isEmpty()) return
        setFont(style.font, shown.color)
        val kind = row.kinds[k]
        val isNumber = kind == CellKind.NUMBER

        val cell: Box = if (merge != null) {
            val lastC = l.colPos(merge.lastCol).let { if (it >= 0) l.colX[it + 1] else l.xOf(merge.lastCol + 1) }
            val lastR = l.rowPos(merge.lastRow).let { if (it >= 0) l.rowY[it + 1] else l.yOf(merge.lastRow + 1) }
            box(l.xOf(merge.firstCol), l.yOf(merge.firstRow), lastC, lastR)
        } else box(l.colX[ci], l.rowY[ri], l.colX[ci + 1], l.rowY[ri + 1])

        val pad = 2f
        val indent = style.indent * 9f
        val sheetRtl = l.sheet.rightToLeft
        val textRtl = if (isNumber) false else startsRtl(value)
        // Which side the text starts from, in page terms.
        val side = when (style.hAlign) {
            HAlign.LEFT -> if (sheetRtl) Side.RIGHT else Side.LEFT
            HAlign.RIGHT -> if (sheetRtl) Side.LEFT else Side.RIGHT
            HAlign.CENTER, HAlign.CENTER_CONTINUOUS, HAlign.DISTRIBUTED -> Side.CENTER
            HAlign.FILL, HAlign.JUSTIFY -> if (sheetRtl || textRtl) Side.RIGHT else Side.LEFT
            HAlign.GENERAL -> when {
                kind == CellKind.BOOL || kind == CellKind.ERROR -> Side.CENTER
                isNumber -> if (sheetRtl) Side.LEFT else Side.RIGHT
                textRtl != sheetRtl -> Side.RIGHT.takeIf { textRtl } ?: Side.LEFT
                else -> if (sheetRtl) Side.RIGHT else Side.LEFT
            }
        }
        val wrap = style.wrap || style.hAlign == HAlign.JUSTIFY || style.hAlign == HAlign.DISTRIBUTED || style.vAlign == VAlign.JUSTIFY || '\n' in value

        if (wrap && !isNumber) {
            val width = (cell.width - pad * 2 - indent).toInt().coerceAtLeast(1)
            val align = when (side) {
                Side.LEFT -> if (textRtl) Layout.Alignment.ALIGN_OPPOSITE else Layout.Alignment.ALIGN_NORMAL
                Side.RIGHT -> if (textRtl) Layout.Alignment.ALIGN_NORMAL else Layout.Alignment.ALIGN_OPPOSITE
                Side.CENTER -> Layout.Alignment.ALIGN_CENTER
            }
            val layout = StaticLayout.Builder.obtain(value, 0, value.length, text, width)
                .setAlignment(align).setIncludePad(false).build()
            val top = when (style.vAlign) {
                VAlign.TOP -> cell.top + 1f
                VAlign.CENTER, VAlign.JUSTIFY, VAlign.DISTRIBUTED -> cell.top + (cell.height - layout.height) / 2
                VAlign.BOTTOM -> cell.bottom - layout.height - 1f
            }
            canvas.save()
            canvas.clipRect(cell.left, cell.top, cell.right, cell.bottom)
            canvas.translate(cell.left + pad + (if (side == Side.LEFT) indent else 0f), top)
            layout.draw(canvas)
            canvas.restore()
            return
        }

        // One line. Numbers that don't fit become shorter (General) or ####.
        val avail = cell.width - pad * 2 - indent
        var width = text.measureText(value)
        if (isNumber && width > avail) {
            val fmt = style.numFmt
            var fitted: String? = null
            if (fmt.equals("General", true) || fmt.isBlank()) {
                for (digits in 10 downTo 1) {
                    val s = NumberFormatter.general(row.nums[k], digits)
                    if (text.measureText(s) <= avail) { fitted = s; break }
                }
                if (fitted == null) {
                    val s = NumberFormatter.scientific(row.nums[k], 0)
                    if (text.measureText(s) <= avail) fitted = s
                }
            }
            value = fitted ?: "#".repeat(floor(avail / text.measureText("#")).toInt().coerceAtLeast(1))
            width = text.measureText(value)
        }
        if (style.hAlign == HAlign.FILL && width > 0 && width < avail) {
            val times = floor(avail / width).toInt().coerceAtLeast(1)
            value = value.repeat(times)
            width = text.measureText(value)
        }

        // Text that doesn't fit spills into empty neighbours (not numbers, not merged cells).
        var clipLeft = cell.left
        var clipRight = cell.right
        if (!isNumber && merge == null && width > avail) {
            val needRight = side == Side.LEFT || side == Side.CENTER
            val needLeft = side == Side.RIGHT || side == Side.CENTER
            val extra = width - avail
            if (needRight) clipRight = spill(l, row, r, ri, ci, extra / (if (side == Side.CENTER) 2 else 1), +1, inMerge, box, cell)
            if (needLeft) clipLeft = spill(l, row, r, ri, ci, extra / (if (side == Side.CENTER) 2 else 1), -1, inMerge, box, cell)
        }

        val fm = text.fontMetrics
        val baseline = when (style.vAlign) {
            VAlign.TOP -> cell.top - fm.ascent + 1f
            VAlign.CENTER, VAlign.JUSTIFY, VAlign.DISTRIBUTED -> cell.top + (cell.height - (fm.descent - fm.ascent)) / 2 - fm.ascent
            VAlign.BOTTOM -> cell.bottom - fm.descent - 1f
        }
        val x = when (side) {
            Side.LEFT -> cell.left + pad + indent
            Side.RIGHT -> cell.right - pad - indent - width
            Side.CENTER -> cell.left + (cell.width - width) / 2
        }
        canvas.save()
        canvas.clipRect(clipLeft, cell.top, clipRight, cell.bottom)
        canvas.drawText(value, x, baseline, text)
        canvas.restore()
    }

    /**
     * How far text can spill from column position [ci] in [dir] (+1 = to the next column
     * in sheet order). Returns the page x where the spill stops.
     */
    private fun spill(
        l: SheetLayout, row: RowData, r: Int, ri: Int, ci: Int, need: Float, dir: Int,
        inMerge: Map<Long, CellRange>, box: (Float, Float, Float, Float) -> Box, cell: Box,
    ): Float {
        var used = 0f
        var j = ci + dir
        var edgeSheetX = if (dir > 0) l.colX[ci + 1] else l.colX[ci]
        while (used < need && j in l.cols.indices) {
            val c = l.cols[j]
            val idx = row.indexOf(c)
            if ((idx >= 0 && row.hasValue(idx)) || inMerge.containsKey(key(r, c))) break
            val w = l.colX[j + 1] - l.colX[j]
            used += w
            edgeSheetX = if (dir > 0) l.colX[j + 1] else l.colX[j]
            j += dir
        }
        // Convert the sheet x to page x through the same mapping as the cell.
        val b = box(minOf(edgeSheetX, l.colX[ci]), l.rowY[ri], maxOf(edgeSheetX, l.colX[ci + 1]), l.rowY[ri + 1])
        val growsRight = (dir > 0) != l.sheet.rightToLeft
        return if (growsRight) maxOf(b.right, cell.right) else minOf(b.left, cell.left)
    }

    /** Draws text from cells just outside this page's columns that spill into it. */
    private fun spillFromNeighbours(
        canvas: Canvas, l: SheetLayout, row: RowData, r: Int, ri: Int, colBand: IntRange,
        inMerge: Map<Long, CellRange>, box: (Float, Float, Float, Float) -> Box,
    ) {
        for (k in 0 until row.size) {
            val ci = l.colPos(row.cols[k])
            if (ci < 0 || ci in colBand || !row.hasValue(k) || row.kinds[k] == CellKind.NUMBER) continue
            if (inMerge.containsKey(key(r, row.cols[k]))) continue
            val style = workbook.style(row.styles[k])
            if (style.wrap) continue
            // Only the nearest text cell on each side can reach this page; drawing it clipped is enough.
            val nearLeft = ci == colBand.first - 1 || (ci < colBand.first && (ci + 1 until colBand.first).all { j -> row.indexOf(l.cols[j]).let { it < 0 || !row.hasValue(it) } })
            val nearRight = ci == colBand.last + 1 || (ci > colBand.last && (colBand.last + 1 until ci).all { j -> row.indexOf(l.cols[j]).let { it < 0 || !row.hasValue(it) } })
            if (!nearLeft && !nearRight) continue
            val firstEmpty = if (nearLeft) colBand.first else colBand.last
            val idx = row.indexOf(l.cols[firstEmpty])
            if (idx >= 0 && row.hasValue(idx)) continue
            drawCellText(canvas, l, row, k, r, ci, ri, null, colBand, inMerge, box)
        }
    }

    private fun drawImage(canvas: Canvas, l: SheetLayout, img: SheetImage, box: (Float, Float, Float, Float) -> Box, bandW: Float, bandH: Float) {
        val xs = l.xOf(img.fromCol) + img.fromColOffset
        val ys = l.yOf(img.fromRow) + img.fromRowOffset
        val xe = if (img.toCol != null) l.xOf(img.toCol) + img.toColOffset else xs + img.widthPt
        val ye = if (img.toRow != null) l.yOf(img.toRow) + img.toRowOffset else ys + img.heightPt
        if (xe <= xs || ye <= ys) return
        val b = box(xs, ys, xe, ye)
        if (b.right < 0 || b.left > bandW || b.bottom < 0 || b.top > bandH) return
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(img.bytes, 0, img.bytes.size, bounds)
        if (bounds.outWidth <= 0) { undecodable++; return }
        // About 200 dpi at the printed size is plenty.
        val wantPx = (b.width * l.scale / 72f * 200f).coerceAtLeast(1f)
        var sample = 1
        while (bounds.outWidth / (sample * 2) >= wantPx) sample *= 2
        val bitmap: Bitmap = BitmapFactory.decodeByteArray(img.bytes, 0, img.bytes.size, BitmapFactory.Options().apply { inSampleSize = sample })
            ?: run { undecodable++; return }
        try {
            canvas.drawBitmap(bitmap, null, RectF(b.left, b.top, b.right, b.bottom), Paint(Paint.FILTER_BITMAP_FLAG))
        } finally {
            bitmap.recycle()
        }
    }

    companion object {
        const val CHUNK = 100

        /** Calibri's digit advance: 1038/2048 em. */
        private const val CALIBRI_DIGIT_EM = 0.5068f
    }
}
