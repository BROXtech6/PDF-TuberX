package com.excelto.pdf.converter

import com.excelto.pdf.converter.R
import com.excelto.pdf.converter.language.tr
import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity

class NoInternetActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_no_internet)
        findViewById<Button>(R.id.btn_retry).setOnClickListener {
            if (isNetworkAvailable(this)) {
                Toast.makeText(this, tr(R.string.net_connected), Toast.LENGTH_SHORT).show()
                finish()
            } else {
                Toast.makeText(this, tr(R.string.net_offline), Toast.LENGTH_SHORT).show()
            }
        }
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (!isNetworkAvailable(this@NoInternetActivity)) finishAffinity() else finish()
            }
        })
    }

    companion object {
        @JvmStatic
        fun isNetworkAvailable(context: Context): Boolean {
            val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager ?: return false
            val caps = cm.getNetworkCapabilities(cm.activeNetwork) ?: return false
            return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
        }

        @JvmStatic
        fun launch(context: Context) {
            context.startActivity(Intent(context, NoInternetActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
    }
}
