package com.excelto.pdf.converter.firebase

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.util.Log
import android.widget.RemoteViews
import androidx.core.app.NotificationCompat
import com.excelto.pdf.converter.MainActivity
import com.excelto.pdf.converter.R
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage

/** Shows push notifications sent from Firebase, with the same custom layout as before. */
class FirebaseNotification : FirebaseMessagingService() {

    override fun onNewToken(token: String) {
        Log.d("FirebaseNotification", "Refreshed token")
    }

    override fun onMessageReceived(message: RemoteMessage) {
        message.notification?.let { show(it.title, it.body) }
    }

    private fun show(title: String?, body: String?) {
        val channelId = "notification_channel"
        val intent = Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
        val pending = PendingIntent.getActivity(this, 0, intent, PendingIntent.FLAG_ONE_SHOT or PendingIntent.FLAG_IMMUTABLE)
        val views = RemoteViews(packageName, R.layout.firebase_notification).apply {
            setTextViewText(R.id.notification_title, title)
            setTextViewText(R.id.notification_message, body)
            setImageViewResource(R.id.notification_icon, R.drawable.main_icon)
        }
        val builder = NotificationCompat.Builder(applicationContext, channelId)
            .setSmallIcon(R.drawable.main_icon)
            .setAutoCancel(true)
            .setVibrate(longArrayOf(1000, 1000, 1000, 1000, 1000))
            .setOnlyAlertOnce(true)
            .setContentIntent(pending)
            .setContent(views)
        val manager = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        manager.createNotificationChannel(NotificationChannel(channelId, "web_app", NotificationManager.IMPORTANCE_HIGH))
        manager.notify(0, builder.build())
    }
}
