package com.excelto.pdf.converter.ui.components

import com.excelto.pdf.converter.R
import com.excelto.pdf.converter.language.tr
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.stateDescription
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.graphics.graphicsLayer
import com.excelto.pdf.converter.core.model.DocFile
import com.excelto.pdf.converter.core.model.DocType
import com.excelto.pdf.converter.ui.theme.AppIcons
import com.excelto.pdf.converter.ui.theme.LocalPalette
import com.excelto.pdf.converter.ui.theme.Tint
import com.excelto.pdf.converter.ui.theme.Tints
import com.excelto.pdf.converter.ui.theme.Type
import java.text.DateFormat
import java.util.Date

val Card16 = RoundedCornerShape(16.dp)
val Card18 = RoundedCornerShape(18.dp)
val Card22 = RoundedCornerShape(22.dp)

fun DocType.tint(): Tint = when (this) {
    DocType.PDF -> Tints.red
    DocType.EXCEL -> Tints.green
    DocType.WORD -> Tints.blue
    DocType.POWERPOINT -> Tints.orange
    DocType.HTML -> Tints.amber
    DocType.IMAGE -> Tints.amber
    DocType.OTHER -> Tints.teal
}

fun formatSize(bytes: Long): String = when {
    bytes >= 1_000_000 -> String.format("%.1f MB", bytes / 1_000_000.0)
    bytes >= 1_000 -> "${bytes / 1_000} KB"
    else -> "$bytes B"
}

fun formatDate(time: Long): String = DateFormat.getDateInstance(DateFormat.MEDIUM).format(Date(time))

/** Mirrors arrows and chevrons in right-to-left languages. */
fun Modifier.mirrorInRtl(dir: LayoutDirection) = graphicsLayer { scaleX = if (dir == LayoutDirection.Rtl) -1f else 1f }

@Composable
fun IconBadge(icon: ImageVector, tint: Tint, size: Dp = 40.dp, iconSize: Dp = 20.dp, radius: Dp = 13.dp) {
    Box(
        Modifier.size(size).clip(RoundedCornerShape(radius)).background(tint.soft),
        contentAlignment = Alignment.Center,
    ) { Icon(icon, contentDescription = null, tint = tint.strong, modifier = Modifier.size(iconSize)) }
}

@Composable
fun FileBadge(type: DocType, width: Dp = 40.dp, height: Dp = 48.dp) {
    val tint = type.tint()
    Box(
        Modifier.width(width).heightIn(min = height).clip(RoundedCornerShape(6.dp)).background(tint.soft),
        contentAlignment = Alignment.Center,
    ) { Text(type.badge, style = Type.tiny.copy(fontSize = 10.sp), color = tint.strong) }
}

@Composable
fun PrimaryButton(text: String, onClick: () -> Unit, modifier: Modifier = Modifier, enabled: Boolean = true, color: Color? = null) {
    val p = LocalPalette.current
    val bg = if (enabled) (color ?: p.primary) else p.line
    Box(
        modifier.fillMaxWidth().heightIn(min = 52.dp).clip(RoundedCornerShape(14.dp)).background(bg)
            .clickable(enabled = enabled, role = Role.Button, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) { Text(text, style = Type.button, color = if (enabled) (if (color != null) Color.White else p.onPrimary) else p.muted) }
}

@Composable
fun SecondaryButton(text: String, onClick: () -> Unit, modifier: Modifier = Modifier, textColor: Color? = null) {
    val p = LocalPalette.current
    Box(
        modifier.fillMaxWidth().heightIn(min = 50.dp).clip(RoundedCornerShape(14.dp)).background(p.surface)
            .border(1.dp, p.line, RoundedCornerShape(14.dp)).clickable(role = Role.Button, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) { Text(text, style = Type.button.copy(fontSize = 14.sp), color = textColor ?: p.text) }
}

@Composable
fun TextAction(text: String, onClick: () -> Unit, color: Color? = null) {
    val p = LocalPalette.current
    Box(Modifier.heightIn(min = 44.dp).clip(RoundedCornerShape(8.dp)).clickable(role = Role.Button, onClick = onClick).padding(horizontal = 6.dp), contentAlignment = Alignment.Center) {
        Text(text, style = Type.bodyStrong, color = color ?: p.primaryText)
    }
}

@Composable
fun SectionTitle(text: String, modifier: Modifier = Modifier) {
    Text(text, style = Type.section, color = LocalPalette.current.text, modifier = modifier)
}

@Composable
fun Surface(modifier: Modifier = Modifier, shape: RoundedCornerShape = Card16, onClick: (() -> Unit)? = null, content: @Composable () -> Unit) {
    val p = LocalPalette.current
    Box(
        modifier.clip(shape).background(p.surface).let { if (onClick != null) it.clickable(role = Role.Button, onClick = onClick) else it },
    ) { content() }
}

/** Two-option pill switcher, like "Changes only / Side by side". */
@Composable
fun Segmented(options: List<String>, selected: Int, onSelect: (Int) -> Unit) {
    val p = LocalPalette.current
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(p.surface).padding(4.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp),
    ) {
        options.forEachIndexed { i, label ->
            val on = i == selected
            Box(
                Modifier.weight(1f).heightIn(min = 40.dp).clip(RoundedCornerShape(10.dp))
                    .background(if (on) p.primary else Color.Transparent)
                    .clickable(role = Role.Tab) { onSelect(i) }
                    .semantics { stateDescription = if (on) tr(R.string.a11y_selected) else "" },
                contentAlignment = Alignment.Center,
            ) { Text(label, style = Type.bodyStrong, color = if (on) p.onPrimary else p.text) }
        }
    }
}

/** A row of equal-width choices with a green outline on the selected one. */
@Composable
fun ChoiceRow(options: List<String>, selected: Int, onSelect: (Int) -> Unit) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        options.forEachIndexed { i, label -> ChoiceBox(label, i == selected, { onSelect(i) }, Modifier.weight(1f)) }
    }
}

@Composable
fun ChoiceBox(label: String, on: Boolean, onClick: () -> Unit, modifier: Modifier = Modifier, sub: String? = null) {
    val p = LocalPalette.current
    val border by animateColorAsState(if (on) p.primaryText else p.line, label = "border")
    Column(
        modifier.heightIn(min = 48.dp).clip(RoundedCornerShape(12.dp)).border(2.dp, border, RoundedCornerShape(12.dp))
            .background(if (on) p.primarySoft else p.surface)
            .clickable(role = Role.RadioButton, onClick = onClick)
            .semantics { stateDescription = if (on) tr(R.string.a11y_selected) else tr(R.string.a11y_not_selected) }
            .padding(horizontal = 8.dp, vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Text(label, style = Type.bodyStrong.copy(fontSize = 12.sp), color = p.text, maxLines = 2)
        if (sub != null) Text(sub, style = Type.small, color = p.muted)
    }
}

@Composable
fun ToggleRow(label: String, sub: String? = null, checked: Boolean, onToggle: (Boolean) -> Unit, showDivider: Boolean = true) {
    val p = LocalPalette.current
    val offset by animateFloatAsState(if (checked) 1f else 0f, tween(180), label = "toggle")
    val track by animateColorAsState(if (checked) p.primaryText else Color(0xFF7A8087), label = "track")
    Row(
        Modifier.fillMaxWidth().heightIn(min = 58.dp)
            .clickable(role = Role.Switch) { onToggle(!checked) }
            .semantics { stateDescription = if (checked) tr(R.string.a11y_on) else tr(R.string.a11y_off) }
            .padding(horizontal = 14.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(label, style = Type.bodyStrong, color = p.text)
            if (sub != null) Text(sub, style = Type.small, color = p.muted)
        }
        Spacer(Modifier.width(12.dp))
        Box(Modifier.width(44.dp).size(44.dp, 26.dp).clip(RoundedCornerShape(13.dp)).background(track).padding(3.dp)) {
            Box(Modifier.padding(start = (18 * offset).dp).size(20.dp).clip(CircleShape).background(Color.White))
        }
    }
    if (showDivider) Box(Modifier.fillMaxWidth().padding(start = 14.dp).heightIn(1.dp).background(p.line))
}

@Composable
fun LinkRow(label: String, sub: String? = null, onClick: () -> Unit) {
    val p = LocalPalette.current
    val dir = LocalLayoutDirection.current
    Row(
        Modifier.fillMaxWidth().heightIn(min = 58.dp).clickable(role = Role.Button, onClick = onClick).padding(horizontal = 14.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(label, style = Type.bodyStrong, color = p.text)
            if (sub != null) Text(sub, style = Type.small, color = p.muted)
        }
        Icon(AppIcons.chevron, null, tint = p.muted, modifier = Modifier.size(16.dp).mirrorInRtl(dir))
    }
    Box(Modifier.fillMaxWidth().padding(start = 14.dp).heightIn(1.dp).background(p.line))
}

@Composable
fun FileRow(file: DocFile, onClick: () -> Unit, modifier: Modifier = Modifier, selected: Boolean = false, trailing: @Composable RowScope.() -> Unit = {}) {
    val p = LocalPalette.current
    Row(
        modifier.fillMaxWidth().heightIn(min = 68.dp).clip(Card16).background(p.surface)
            .border(2.dp, if (selected) p.primaryText else Color.Transparent, Card16)
            .clickable(role = Role.Button, onClick = onClick).padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        FileBadge(file.type)
        Column(Modifier.weight(1f)) {
            Text(file.name, style = Type.bodyStrong, color = p.text, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text("${formatDate(file.modified)} · ${formatSize(file.size)} · ${file.source.label}", style = Type.small, color = p.muted, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        trailing()
    }
}

@Composable
fun Chip(label: String, on: Boolean, onClick: () -> Unit) {
    val p = LocalPalette.current
    Box(
        Modifier.heightIn(min = 40.dp).clip(RoundedCornerShape(20.dp))
            .background(if (on) p.primary else p.surface)
            .border(BorderStroke(1.dp, if (on) p.primary else p.line), RoundedCornerShape(20.dp))
            .clickable(role = Role.Tab, onClick = onClick)
            .semantics { stateDescription = if (on) tr(R.string.a11y_selected) else "" }
            .padding(horizontal = 14.dp),
        contentAlignment = Alignment.Center,
    ) { Text(label, style = Type.bodyStrong, color = if (on) p.onPrimary else p.text) }
}

@Composable
fun ProgressRing(percent: Int, size: Dp, stroke: Dp, track: Color, color: Color, modifier: Modifier = Modifier, label: @Composable () -> Unit = {}) {
    val sweep by animateFloatAsState(percent / 100f * 360f, tween(150), label = "ring")
    Box(modifier.size(size).semantics { contentDescription = tr(R.string.a11y_percent, percent) }, contentAlignment = Alignment.Center) {
        Canvas(Modifier.size(size)) {
            val w = stroke.toPx()
            drawArc(track, 0f, 360f, false, style = Stroke(w))
            drawArc(color, -90f, sweep, false, style = Stroke(w, cap = StrokeCap.Round))
        }
        label()
    }
}

@Composable
fun Divider() {
    Box(Modifier.fillMaxWidth().heightIn(1.dp).background(LocalPalette.current.line))
}
