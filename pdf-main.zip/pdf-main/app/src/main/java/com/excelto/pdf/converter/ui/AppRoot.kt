package com.excelto.pdf.converter.ui

import com.excelto.pdf.converter.R
import com.excelto.pdf.converter.language.tr
import android.app.Activity
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Snackbar
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat
import com.excelto.pdf.converter.core.jobs.JobCenter
import com.excelto.pdf.converter.core.jobs.JobState
import com.excelto.pdf.converter.ui.components.mirrorInRtl
import com.excelto.pdf.converter.ui.screens.FilesScreen
import com.excelto.pdf.converter.ui.screens.HomeScreen
import com.excelto.pdf.converter.ui.screens.ProgressScreen
import com.excelto.pdf.converter.ui.screens.ResultScreen
import com.excelto.pdf.converter.ui.screens.SettingsScreen
import com.excelto.pdf.converter.ui.screens.ToolsScreen
import com.excelto.pdf.converter.ui.sheets.PasswordDialog
import com.excelto.pdf.converter.ui.theme.AppIcons
import com.excelto.pdf.converter.ui.theme.AppTheme
import com.excelto.pdf.converter.ui.theme.LocalPalette
import com.excelto.pdf.converter.ui.theme.Type
import com.excelto.pdf.converter.ui.tools.ToolScreenContent
import java.io.File

/** Everything the UI needs from the activity: other screens, sharing, app lock. */
interface Host {
    fun openPaywall()
    fun manageSubscription()
    fun openLanguage()
    fun openFile(file: File)
    fun share(files: List<File>)
    fun unlockApp()
    fun canUseAppLock(): Boolean
    fun requestAllFilesAccess()
    fun rateApp()
    fun shareApp()
    fun openPrivacy()
    /** Shows an interstitial if one is due (see Ads), then runs [then]. */
    fun afterJob(then: () -> Unit)
    /** Plays the opt-in rewarded video. */
    fun watchRewarded(onReward: () -> Unit, onUnavailable: () -> Unit)
    fun adPrivacyRequired(): Boolean
    fun openAdPrivacy()
    /** Installs a downloaded Google Play update (restarts the app). */
    fun installUpdate()
}

val LocalHost = staticCompositionLocalOf<Host> { error("Host not provided") }

@Composable
fun AppRoot(vm: AppViewModel, host: Host) {
    AppTheme(vm.themeMode) {
        val p = LocalPalette.current
        val view = LocalView.current
        SideEffect {
            val window = (view.context as? Activity)?.window ?: return@SideEffect
            WindowCompat.getInsetsController(window, view).apply {
                isAppearanceLightStatusBars = !p.isDark
                isAppearanceLightNavigationBars = !p.isDark
            }
        }
        val snackbar = remember { SnackbarHostState() }
        LaunchedEffect(Unit) { vm.messageFlow.collect { snackbar.showSnackbar(it) } }
        LaunchedEffect(vm.paywallRequests) { if (vm.paywallRequests > 0) host.openPaywall() }

        CompositionLocalProvider(LocalHost provides host) {
            Box(Modifier.fillMaxSize().background(p.bg)) {
                Column(Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.safeDrawing)) {
                    val route = vm.current
                    if (route.isTab && vm.updateReady) UpdateBanner { host.installUpdate() }
                    if (route.isTab) JobBanner(vm)
                    Box(Modifier.weight(1f)) {
                        AnimatedContent(
                            targetState = route,
                            contentKey = { r -> if (r is Route.ToolScreen) "tool-${r.tool}" else r.toString() },
                            transitionSpec = {
                                (fadeIn(tween(220)) + slideInVertically(tween(260)) { it / 24 }) togetherWith fadeOut(tween(120))
                            },
                            label = "screen",
                        ) { r ->
                            when (r) {
                                Route.Home -> HomeScreen(vm)
                                Route.Tools -> ToolsScreen(vm)
                                Route.Files -> FilesScreen(vm)
                                Route.Settings -> SettingsScreen(vm)
                                Route.Progress -> ProgressScreen(vm)
                                Route.Result -> ResultScreen(vm)
                                is Route.ToolScreen -> ToolScreenContent(vm, (vm.current as? Route.ToolScreen) ?: r)
                            }
                        }
                    }
                    if (route.isTab) BottomNav(route) { vm.openTab(it) }
                }
                SnackbarHost(snackbar, Modifier.align(Alignment.BottomCenter).windowInsetsPadding(WindowInsets.safeDrawing).padding(bottom = 76.dp)) {
                    Snackbar(it, containerColor = Color(0xFF1B222B), contentColor = Color.White, shape = RoundedCornerShape(14.dp))
                }
                vm.passwordPrompt?.let { PasswordDialog(it, onSubmit = vm::submitPassword, onDismiss = vm::dismissPassword) }
                vm.proOffer?.let { offer -> com.excelto.pdf.converter.ui.sheets.ProOfferSheet(vm, offer) }
                if (vm.locked) LockScreen { host.unlockApp() }
            }
        }
    }
}

@Composable
private fun JobBanner(vm: AppViewModel) {
    val p = LocalPalette.current
    val state by JobCenter.state.collectAsState()
    val s = state
    val (text, action) = when {
        s is JobState.Running -> "${s.title} · ${s.percent}%" to tr(R.string.common_view)
        s is JobState.Done && !s.seen -> tr(R.string.job_ready) to tr(R.string.common_open)
        s is JobState.Failed -> tr(R.string.job_failed_title, s.title) to tr(R.string.common_details)
        else -> return
    }
    Row(
        Modifier.padding(start = 14.dp, end = 14.dp, top = 8.dp, bottom = 4.dp).fillMaxWidth().heightIn(min = 52.dp)
            .clip(RoundedCornerShape(14.dp)).background(p.primarySoft)
            .clickable(role = Role.Button) {
                if (s is JobState.Done) JobCenter.markSeen()
                vm.push(if (s is JobState.Done) Route.Result else Route.Progress)
            }
            .padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
    ) {
        Text(text, style = Type.bodyStrong, color = p.text, modifier = Modifier.weight(1f))
        Text(action, style = Type.bodyStrong, color = p.primaryText)
    }
}

/** A downloaded Google Play update, waiting for one tap to restart into the new version. */
@Composable
private fun UpdateBanner(onRestart: () -> Unit) {
    val p = LocalPalette.current
    Row(
        Modifier.padding(start = 14.dp, end = 14.dp, top = 8.dp, bottom = 4.dp).fillMaxWidth().heightIn(min = 52.dp)
            .clip(RoundedCornerShape(14.dp)).background(p.ink)
            .clickable(role = Role.Button, onClick = onRestart)
            .padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
    ) {
        Text(tr(R.string.update_ready), style = Type.bodyStrong, color = p.onInk, modifier = Modifier.weight(1f))
        Text(tr(R.string.update_restart), style = Type.bodyStrong, color = p.mint)
    }
}

private data class NavItem(val route: Route, val label: String, val icon: ImageVector)

@Composable
private fun BottomNav(current: Route, onSelect: (Route) -> Unit) {
    val p = LocalPalette.current
    val items = listOf(
        NavItem(Route.Home, tr(R.string.nav_home), AppIcons.home),
        NavItem(Route.Tools, tr(R.string.tabs_tools), AppIcons.tools),
        NavItem(Route.Files, tr(R.string.tabs_files), AppIcons.folder),
        NavItem(Route.Settings, tr(R.string.tabs_settings), AppIcons.settings),
    )
    Column {
        Box(Modifier.fillMaxWidth().height(1.dp).background(p.line))
        Row(Modifier.fillMaxWidth().height(70.dp).background(p.surface)) {
            items.forEach { item ->
                val on = item.route == current
                Column(
                    Modifier.weight(1f).fillMaxSize().clickable(role = Role.Tab) { onSelect(item.route) }.semantics { selected = on },
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center,
                ) {
                    Box(
                        Modifier.width(52.dp).height(30.dp).clip(RoundedCornerShape(15.dp)).background(if (on) p.primarySoft else Color.Transparent),
                        contentAlignment = Alignment.Center,
                    ) { Icon(item.icon, null, tint = if (on) p.primaryText else p.muted, modifier = Modifier.size(21.dp)) }
                    Text(item.label, style = Type.tiny, color = if (on) p.primaryText else p.muted)
                }
            }
        }
    }
}

/** Header for screens inside a tool: back arrow, title and optional actions. */
@Composable
fun InnerHeader(title: String, onBack: () -> Unit, actions: @Composable () -> Unit = {}) {
    val p = LocalPalette.current
    val dir = LocalLayoutDirection.current
    Column {
        Row(
            Modifier.fillMaxWidth().height(60.dp).background(p.surface).padding(horizontal = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box(
                Modifier.size(44.dp).clip(RoundedCornerShape(22.dp)).clickable(role = Role.Button, onClickLabel = tr(R.string.common_back), onClick = onBack),
                contentAlignment = Alignment.Center,
            ) { Icon(AppIcons.back, tr(R.string.common_back), tint = p.text, modifier = Modifier.size(22.dp).mirrorInRtl(dir)) }
            Text(title, style = Type.section.copy(fontSize = 16.sp), color = p.text, maxLines = 1, modifier = Modifier.weight(1f).padding(start = 4.dp))
            actions()
        }
        Box(Modifier.fillMaxWidth().height(1.dp).background(p.line))
    }
}

/** Covers the app until fingerprint, face or screen lock confirms it's the owner. */
@Composable
private fun LockScreen(onUnlock: () -> Unit) {
    val p = LocalPalette.current
    Column(
        Modifier.fillMaxSize().background(p.bg).clickable(enabled = false) {}.windowInsetsPadding(WindowInsets.safeDrawing).padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp, Alignment.CenterVertically),
    ) {
        Box(Modifier.size(72.dp).clip(RoundedCornerShape(24.dp)).background(p.primarySoft), contentAlignment = Alignment.Center) {
            Icon(AppIcons.lock, null, tint = p.primaryText, modifier = Modifier.size(34.dp))
        }
        Text(tr(R.string.lock_title), style = Type.section.copy(fontSize = 18.sp), color = p.text)
        com.excelto.pdf.converter.ui.components.PrimaryButton(tr(R.string.common_unlock), onUnlock)
    }
}
