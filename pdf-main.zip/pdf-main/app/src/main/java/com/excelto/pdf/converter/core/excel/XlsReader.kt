package com.excelto.pdf.converter.core.excel

import com.excelto.pdf.converter.R
import com.excelto.pdf.converter.core.engine.UserFacingException
import org.apache.poi.EncryptedDocumentException
import org.apache.poi.hssf.OldExcelFormatException
import org.apache.poi.hssf.usermodel.HSSFCell
import org.apache.poi.hssf.usermodel.HSSFCellStyle
import org.apache.poi.hssf.usermodel.HSSFPicture
import org.apache.poi.hssf.usermodel.HSSFSheet
import org.apache.poi.hssf.usermodel.HSSFWorkbook
import org.apache.poi.ss.usermodel.BorderStyle
import org.apache.poi.ss.usermodel.CellType
import org.apache.poi.ss.usermodel.FillPatternType
import org.apache.poi.ss.usermodel.FormulaError
import org.apache.poi.ss.usermodel.HorizontalAlignment
import org.apache.poi.ss.usermodel.Sheet
import org.apache.poi.ss.usermodel.VerticalAlignment
import java.io.File

/**
 * Reads old .xls files (Excel 97–2003) with Apache POI's HSSF and maps them into the
 * same model as .xlsx. Colors come straight from the workbook's palette record so POI's
 * color classes (which need java.awt, missing on Android) are never loaded.
 */
object XlsReader {

    fun read(file: File, onlySheets: Set<Int>? = null, check: () -> Unit = {}): ExcelWorkbook {
        val wb = open(file)
        wb.use {
            val palette = palette(wb)
            val styles = (0 until wb.numCellStyles).map { style(wb, wb.getCellStyleAt(it), palette) }
            val date1904 = wb.internalWorkbook.isUsing1904DateWindowing
            val sheets = (0 until wb.numberOfSheets).map { i ->
                check()
                val hidden = wb.isSheetHidden(i) || wb.isSheetVeryHidden(i)
                if (onlySheets != null && i !in onlySheets) ExcelSheet(wb.getSheetName(i), hidden)
                else sheet(wb, wb.getSheetAt(i), i, hidden, check)
            }
            return ExcelWorkbook(sheets, styles, date1904)
        }
    }

    fun sheetNames(file: File): List<Pair<String, Boolean>> = open(file).use { wb ->
        (0 until wb.numberOfSheets).map { wb.getSheetName(it) to (wb.isSheetHidden(it) || wb.isSheetVeryHidden(it)) }
    }

    private fun open(file: File): HSSFWorkbook = try {
        file.inputStream().use { HSSFWorkbook(it) }
    } catch (e: EncryptedDocumentException) {
        throw UserFacingException(R.string.err_spreadsheet_password_protected_remove, "This spreadsheet is password protected. Remove the password in Excel and try again.", e)
    } catch (e: OldExcelFormatException) {
        throw UserFacingException(R.string.err_spreadsheet_uses_very_old, "This spreadsheet uses a very old Excel format (Excel 95 or earlier). Save it as .xlsx in Excel and try again.", e)
    } catch (e: Exception) {
        throw UserFacingException(R.string.err_spreadsheet_couldnt_opened_may, "This spreadsheet couldn't be opened. It may be damaged or in an unsupported format.", e)
    }

    /** Custom colors from the PALETTE record (indexes 8..63). */
    private fun palette(wb: HSSFWorkbook): Map<Int, Int> {
        val record = wb.internalWorkbook.customPalette ?: return emptyMap()
        val out = HashMap<Int, Int>()
        for (i in 8..63) {
            val rgb = runCatching { record.getColor(i) }.getOrNull() ?: continue
            if (rgb.size >= 3) out[i] = (0xFF shl 24) or ((rgb[0].toInt() and 0xFF) shl 16) or ((rgb[1].toInt() and 0xFF) shl 8) or (rgb[2].toInt() and 0xFF)
        }
        return out
    }

    private fun style(wb: HSSFWorkbook, s: HSSFCellStyle, palette: Map<Int, Int>): CellStyle {
        val f = s.getFont(wb)
        fun color(index: Short): Int? = ExcelColors.indexed(index.toInt(), palette)
        fun border(style: BorderStyle, color: Short): BorderLine? {
            val line = when (style) {
                BorderStyle.NONE -> return null
                BorderStyle.THIN -> LineStyle.THIN
                BorderStyle.MEDIUM -> LineStyle.MEDIUM
                BorderStyle.DASHED -> LineStyle.DASHED
                BorderStyle.DOTTED -> LineStyle.DOTTED
                BorderStyle.THICK -> LineStyle.THICK
                BorderStyle.DOUBLE -> LineStyle.DOUBLE
                BorderStyle.HAIR -> LineStyle.HAIR
                BorderStyle.MEDIUM_DASHED -> LineStyle.MEDIUM_DASHED
                BorderStyle.DASH_DOT -> LineStyle.DASH_DOT
                BorderStyle.MEDIUM_DASH_DOT -> LineStyle.MEDIUM_DASH_DOT
                BorderStyle.DASH_DOT_DOT -> LineStyle.DASH_DOT_DOT
                BorderStyle.MEDIUM_DASH_DOT_DOT -> LineStyle.MEDIUM_DASH_DOT_DOT
                BorderStyle.SLANTED_DASH_DOT -> LineStyle.SLANT_DASH_DOT
                else -> LineStyle.THIN
            }
            return BorderLine(line, color(color) ?: 0xFF000000.toInt())
        }
        val fill = when (s.fillPatternEnum) {
            FillPatternType.NO_FILL, null -> null
            else -> color(s.fillForegroundColor) ?: color(s.fillBackgroundColor)
        }
        return CellStyle(
            font = CellFont(
                name = f.fontName ?: "Arial",
                size = f.fontHeightInPoints.toFloat().takeIf { it > 0 } ?: 10f,
                bold = f.bold,
                italic = f.italic,
                underline = f.underline.toInt() != 0,
                strike = f.strikeout,
                color = color(f.color)?.takeIf { f.color.toInt() != 0x7FFF } ?: 0xFF000000.toInt(),
            ),
            fill = fill,
            left = border(s.borderLeftEnum, s.leftBorderColor),
            right = border(s.borderRightEnum, s.rightBorderColor),
            top = border(s.borderTopEnum, s.topBorderColor),
            bottom = border(s.borderBottomEnum, s.bottomBorderColor),
            hAlign = when (s.alignmentEnum) {
                HorizontalAlignment.LEFT -> HAlign.LEFT
                HorizontalAlignment.CENTER -> HAlign.CENTER
                HorizontalAlignment.RIGHT -> HAlign.RIGHT
                HorizontalAlignment.FILL -> HAlign.FILL
                HorizontalAlignment.JUSTIFY -> HAlign.JUSTIFY
                HorizontalAlignment.CENTER_SELECTION -> HAlign.CENTER_CONTINUOUS
                HorizontalAlignment.DISTRIBUTED -> HAlign.DISTRIBUTED
                else -> HAlign.GENERAL
            },
            vAlign = when (s.verticalAlignmentEnum) {
                VerticalAlignment.TOP -> VAlign.TOP
                VerticalAlignment.CENTER -> VAlign.CENTER
                VerticalAlignment.JUSTIFY -> VAlign.JUSTIFY
                VerticalAlignment.DISTRIBUTED -> VAlign.DISTRIBUTED
                else -> VAlign.BOTTOM
            },
            wrap = s.wrapText,
            indent = s.indention.toInt(),
            numFmt = s.getDataFormatString(wb.internalWorkbook) ?: "General",
        )
    }

    private fun sheet(wb: HSSFWorkbook, sh: HSSFSheet, index: Int, hidden: Boolean, check: () -> Unit): ExcelSheet {
        val rows = java.util.TreeMap<Int, RowData>()
        val heights = HashMap<Int, Float>()
        val hiddenRows = HashSet<Int>()
        var maxCol = 0
        var count = 0
        val formulas = HashMap<Long, String>()
        for (r in sh) {
            if (++count % 500 == 0) check()
            val data = RowData()
            if (r.zeroHeight) hiddenRows += r.rowNum
            if (r.height.toInt() != sh.defaultRowHeight.toInt()) heights[r.rowNum] = r.heightInPoints
            for (c in r) {
                val cell = c as HSSFCell
                val style = cell.cellStyle.index.toInt()
                maxCol = maxOf(maxCol, cell.columnIndex)
                if (cell.cellTypeEnum == CellType.FORMULA) runCatching { cell.cellFormula }.getOrNull()?.let { formulas[formulaKey(r.rowNum, cell.columnIndex)] = it }
                val type = cell.cellTypeEnum.let { if (it == CellType.FORMULA) cell.cachedFormulaResultTypeEnum else it }
                when (type) {
                    CellType.NUMERIC -> data.put(cell.columnIndex, CellKind.NUMBER, cell.numericCellValue, style = style)
                    CellType.STRING -> data.put(cell.columnIndex, CellKind.STRING, str = cell.richStringCellValue?.string.orEmpty(), style = style)
                    CellType.BOOLEAN -> data.put(cell.columnIndex, CellKind.BOOL, if (cell.booleanCellValue) 1.0 else 0.0, style = style)
                    CellType.ERROR -> data.put(cell.columnIndex, CellKind.ERROR, str = runCatching { FormulaError.forInt(cell.errorCellValue).string }.getOrDefault("#ERROR"), style = style)
                    else -> data.put(cell.columnIndex, CellKind.BLANK, style = style)
                }
            }
            if (data.size > 0) rows[r.rowNum] = data
        }
        val lastCol = maxOf(maxCol, 0) + 1
        val widths = HashMap<Int, Float>()
        val hiddenCols = HashSet<Int>()
        for (c in 0..lastCol) {
            widths[c] = sh.getColumnWidth(c) / 256f
            if (sh.isColumnHidden(c)) hiddenCols += c
        }
        val merges = sh.mergedRegions.map { CellRange(it.firstRow, it.firstColumn, it.lastRow, it.lastColumn) }
        val ps = sh.printSetup
        val setup = PageSetup(
            landscape = if (ps.validSettings) ps.landscape else null,
            paperSize = ps.paperSize.toInt().takeIf { ps.validSettings && it > 0 },
            fitToPage = sh.fitToPage,
            fitWidth = ps.fitWidth.toInt(),
            fitHeight = ps.fitHeight.toInt(),
            scale = ps.scale.toInt().takeIf { it in 10..400 } ?: 100,
            marginLeft = sh.getMargin(Sheet.LeftMargin).toFloat(),
            marginRight = sh.getMargin(Sheet.RightMargin).toFloat(),
            marginTop = sh.getMargin(Sheet.TopMargin).toFloat(),
            marginBottom = sh.getMargin(Sheet.BottomMargin).toFloat(),
            printGridlines = sh.isPrintGridlines,
        )
        val printArea = wb.getPrintArea(index)?.substringBefore(',')?.substringAfterLast('!')?.let { CellRange.parse(it) }
        val defaultRow = sh.defaultRowHeightInPoints.takeIf { it > 0 } ?: 12.75f

        fun colWidthPt(c: Int) = SheetUnits.columnPoints(widths[c] ?: (sh.defaultColumnWidth + 5f / 7f))
        fun rowHeightPt(r: Int) = heights[r] ?: defaultRow
        val images = mutableListOf<SheetImage>()
        runCatching {
            sh.drawingPatriarch?.children?.forEach { shape ->
                val pic = shape as? HSSFPicture ?: return@forEach
                val a = pic.clientAnchor ?: return@forEach
                val bytes = pic.pictureData?.data ?: return@forEach
                images += SheetImage(
                    fromCol = a.col1.toInt(), fromColOffset = a.dx1 / 1024f * colWidthPt(a.col1.toInt()),
                    fromRow = a.row1, fromRowOffset = a.dy1 / 256f * rowHeightPt(a.row1),
                    toCol = a.col2.toInt(), toColOffset = a.dx2 / 1024f * colWidthPt(a.col2.toInt()),
                    toRow = a.row2, toRowOffset = a.dy2 / 256f * rowHeightPt(a.row2),
                    widthPt = 0f, heightPt = 0f, bytes = bytes,
                )
            }
        }
        return ExcelSheet(
            name = sh.sheetName, hidden = hidden, rightToLeft = sh.isRightToLeft, rows = rows,
            colWidths = widths, defaultColWidth = sh.defaultColumnWidth + 5f / 7f,
            rowHeights = heights, defaultRowHeight = defaultRow,
            hiddenRows = hiddenRows, hiddenCols = hiddenCols, merges = merges,
            printArea = printArea, pageSetup = setup, images = images,
            formulas = formulas,
            freezeRows = runCatching { sh.paneInformation?.takeIf { it.isFreezePane }?.horizontalSplitPosition?.toInt() }.getOrNull() ?: 0,
            freezeCols = runCatching { sh.paneInformation?.takeIf { it.isFreezePane }?.verticalSplitPosition?.toInt() }.getOrNull() ?: 0,
        )
    }
}
