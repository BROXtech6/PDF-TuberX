package com.excelto.pdf.converter.core.engine

import com.tom_roush.pdfbox.pdmodel.PDPage
import com.tom_roush.pdfbox.pdmodel.common.PDRectangle
import com.tom_roush.pdfbox.util.Matrix

/**
 * A page as the reader sees it: the crop box, turned by the page's /Rotate. Drawing
 * code works in "display points" (origin bottom-left of the visible page, y up) and
 * [matrix] maps those to the page's own coordinates.
 */
class PageFrame(page: PDPage) {
    private val box: PDRectangle = page.cropBox
    val rotation: Int = ((page.rotation % 360) + 360) % 360
    private val sideways = rotation == 90 || rotation == 270

    /** Visible width and height in points. */
    val width: Float = if (sideways) box.height else box.width
    val height: Float = if (sideways) box.width else box.height

    /** Display points to page coordinates. */
    val matrix: Matrix = when (rotation) {
        90 -> Matrix(0f, 1f, -1f, 0f, box.lowerLeftX + box.width, box.lowerLeftY)
        180 -> Matrix(-1f, 0f, 0f, -1f, box.upperRightX, box.upperRightY)
        270 -> Matrix(0f, -1f, 1f, 0f, box.lowerLeftX, box.upperRightY)
        else -> Matrix(1f, 0f, 0f, 1f, box.lowerLeftX, box.lowerLeftY)
    }

    /** Display x from a 0..1 value measured from the left. */
    fun x(nx: Float) = nx * width

    /** Display y (from the bottom) from a 0..1 value measured from the top. */
    fun y(ny: Float) = (1f - ny) * height

    /** Page coordinates of a display point. */
    fun toPage(x: Float, y: Float): Pair<Float, Float> {
        val p = matrix.transformPoint(x, y)
        return p.x to p.y
    }

    /** A rectangle in page coordinates covering the display rectangle (for annotations). */
    fun pageRect(left: Float, bottom: Float, right: Float, top: Float): PDRectangle {
        val pts = listOf(toPage(left, bottom), toPage(right, bottom), toPage(left, top), toPage(right, top))
        val minX = pts.minOf { it.first }
        val minY = pts.minOf { it.second }
        return PDRectangle(minX, minY, pts.maxOf { it.first } - minX, pts.maxOf { it.second } - minY)
    }
}
