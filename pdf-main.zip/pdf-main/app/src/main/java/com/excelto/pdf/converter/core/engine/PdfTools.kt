package com.excelto.pdf.converter.core.engine

import com.excelto.pdf.converter.R
import com.tom_roush.pdfbox.io.MemoryUsageSetting
import com.tom_roush.pdfbox.multipdf.PDFMergerUtility
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.pdmodel.PDPage
import com.tom_roush.pdfbox.pdmodel.encryption.AccessPermission
import com.tom_roush.pdfbox.pdmodel.encryption.InvalidPasswordException
import com.tom_roush.pdfbox.pdmodel.encryption.StandardProtectionPolicy
import java.io.File
import java.io.IOException
import java.util.UUID

/** One page in the Organize screen: which original page, and how much to rotate it. */
data class PageSpec(val originalPage: Int, val extraRotation: Int = 0)

/** Merge, split, organize, protect and unlock, built on PdfBox-Android. */
object PdfTools {

    /** Big files use a temp file instead of memory for PdfBox's scratch data. */
    private fun memory(): MemoryUsageSetting = MemoryUsageSetting.setupMixed(16L * 1024 * 1024)

    fun open(path: String, password: String? = null): PDDocument = try {
        PDDocument.load(File(path), password ?: "", memory())
    } catch (e: InvalidPasswordException) {
        throw PasswordRequiredException()
    } catch (e: IOException) {
        throw UserFacingException(R.string.err_file_isnt_valid_pdf, "This file isn't a valid PDF or is damaged.", e)
    }

    fun isPasswordProtected(path: String): Boolean = try {
        PDDocument.load(File(path), "", memory()).close(); false
    } catch (e: InvalidPasswordException) {
        true
    } catch (e: Exception) {
        false
    }

    fun pageCount(path: String, password: String? = null): Int = open(path, password).use { it.numberOfPages }

    /** True when the file was opened with full rights (not encrypted, or opened with the owner password). */
    fun hasOwnerRights(doc: PDDocument): Boolean = !doc.isEncrypted || doc.currentAccessPermission.isOwnerPermission

    /** Refuses to change a PDF whose owner restricted changes, like the previous engine did. */
    fun requireOwnerRights(doc: PDDocument, message: String = "The owner of this PDF doesn't allow changes to it.") {
        if (!hasOwnerRights(doc)) throw UserFacingException(message)
    }

    /** Wraps writes so a half-written file is deleted. */
    inline fun <T> writing(out: File, block: () -> T): T = try {
        block()
    } catch (e: Throwable) {
        out.delete()
        throw e
    }

    data class Input(val path: String, val password: String? = null)

    fun merge(inputs: List<Input>, out: File, progress: Progress) = writing(out) {
        require(inputs.size >= 2) { "Choose at least two files" }
        val sources = mutableListOf<PDDocument>()
        try {
            PDDocument(MemoryUsageSetting.setupTempFileOnly()).use { merged ->
                val merger = PDFMergerUtility()
                inputs.forEachIndexed { index, input ->
                    progress.check()
                    val source = open(input.path, input.password)
                    sources += source
                    requireOwnerRights(source)
                    source.isAllSecurityToBeRemoved = true
                    merger.appendDocument(merged, source)
                    progress.step(index + 1, inputs.size, 5, 85)
                }
                // Sources stay open until the merged file is saved: their pages are read while saving.
                merged.save(out)
            }
        } finally {
            sources.forEach { runCatching { it.close() } }
        }
        progress.report(100)
    }

    /** Splits [input] into one file per page range. [outFor] names each part. */
    fun split(input: Input, ranges: List<IntRange>, outFor: (Int) -> File, progress: Progress): List<File> {
        val made = mutableListOf<File>()
        open(input.path, input.password).use { source ->
            requireOwnerRights(source)
            try {
                ranges.forEachIndexed { index, range ->
                    val out = outFor(index)
                    writing(out) {
                        PDDocument(MemoryUsageSetting.setupTempFileOnly()).use { part ->
                            for (page in range) {
                                progress.check()
                                part.importPage(source.getPage(page - 1))
                            }
                            part.save(out)
                        }
                    }
                    made += out
                    progress.step(index + 1, ranges.size)
                }
            } catch (e: Throwable) {
                made.forEach { it.delete() }
                throw e
            }
        }
        progress.report(100)
        return made
    }

    fun everyPage(count: Int): List<IntRange> = (1..count).map { it..it }

    fun halves(count: Int): List<IntRange> =
        if (count < 2) listOf(1..count) else listOf(1..(count + 1) / 2, ((count + 1) / 2 + 1)..count)

    /** Parses "1-3, 5, 8-10" into page ranges. Returns null when the text is invalid. */
    fun parseRanges(text: String, count: Int): List<IntRange>? = PageRanges.parse(text, count)

    /** Reorders, rotates and removes pages in one pass. */
    fun organize(input: Input, pages: List<PageSpec>, out: File, progress: Progress) = writing(out) {
        require(pages.isNotEmpty()) { "Keep at least one page" }
        open(input.path, input.password).use { doc ->
            requireOwnerRights(doc)
            val originals = (0 until doc.numberOfPages).map { doc.getPage(it) }
            // Copy inherited values onto each page so they survive leaving the page tree.
            for (p in originals) {
                p.resources = p.resources
                p.mediaBox = p.mediaBox
                p.cropBox = p.cropBox
                p.rotation = p.rotation
            }
            val used = HashSet<PDPage>()
            val ordered = pages.mapIndexed { index, spec ->
                progress.step(index + 1, pages.size, 5, 60)
                val original = originals[spec.originalPage - 1]
                // A page used twice needs its own copy in the page tree.
                val page = if (used.add(original)) original else PDPage(com.tom_roush.pdfbox.cos.COSDictionary(original.cosObject))
                if (spec.extraRotation % 360 != 0) page.rotation = ((page.rotation + spec.extraRotation) % 360 + 360) % 360
                page
            }
            val tree = doc.pages
            while (tree.count > 0) tree.remove(0)
            ordered.forEach { tree.add(it) }
            progress.report(80)
            doc.save(out)
        }
        progress.report(100)
    }

    /**
     * Adds a password with AES-256. When printing or copying is restricted, the owner
     * password is random so the limits hold for everyone who opens the file.
     */
    fun protect(
        input: Input,
        password: String,
        allowPrinting: Boolean,
        allowCopying: Boolean,
        out: File,
        progress: Progress,
    ) = writing(out) {
        require(password.length >= 6) { "Use at least 6 characters" }
        open(input.path, input.password).use { doc ->
            requireOwnerRights(doc)
            progress.report(20)
            val restricted = !(allowPrinting && allowCopying)
            val owner = if (restricted) UUID.randomUUID().toString() else password
            val permissions = AccessPermission().apply {
                setCanPrint(allowPrinting)
                setCanPrintFaithful(allowPrinting)
                setCanExtractContent(allowCopying)
                setCanExtractForAccessibility(true)
                setCanModify(!restricted)
                setCanFillInForm(!restricted)
                setCanModifyAnnotations(!restricted)
                setCanAssembleDocument(!restricted)
            }
            doc.isAllSecurityToBeRemoved = false
            val policy = StandardProtectionPolicy(owner, password, permissions).apply { encryptionKeyLength = 256 }
            doc.protect(policy)
            progress.report(70)
            doc.save(out)
        }
        progress.report(100)
    }

    /** Saves an unlocked copy. Needs the password that opens the file. */
    fun unlock(input: Input, out: File, progress: Progress) = writing(out) {
        open(input.path, input.password).use { doc ->
            if (!hasOwnerRights(doc)) {
                throw UserFacingException(R.string.err_password_opens_file_but, "This password opens the file but doesn't allow removing its protection.")
            }
            doc.isAllSecurityToBeRemoved = true
            progress.report(50)
            doc.save(out)
        }
        progress.report(100)
    }
}

/** Page-range text such as "1-3, 5, 8-10". Kept free of Android and PdfBox for unit tests. */
object PageRanges {
    fun parse(text: String, count: Int): List<IntRange>? {
        val parts = text.split(',').map { it.trim() }.filter { it.isNotEmpty() }
        if (parts.isEmpty()) return null
        return parts.map { part ->
            val bounds = part.split('-').map { it.trim().toIntOrNull() ?: return null }
            val range = when (bounds.size) {
                1 -> bounds[0]..bounds[0]
                2 -> bounds[0]..bounds[1]
                else -> return null
            }
            if (range.first < 1 || range.last > count || range.first > range.last) return null
            range
        }
    }
}
