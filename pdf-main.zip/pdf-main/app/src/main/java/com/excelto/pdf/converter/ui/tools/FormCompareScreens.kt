package com.excelto.pdf.converter.ui.tools

import com.excelto.pdf.converter.R
import com.excelto.pdf.converter.language.tr
import com.excelto.pdf.converter.language.trPlural
import androidx.annotation.StringRes
import android.graphics.Bitmap
import android.graphics.Paint
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.excelto.pdf.converter.core.engine.Change
import com.excelto.pdf.converter.core.engine.ChangeKind
import com.excelto.pdf.converter.core.engine.FieldKind
import com.excelto.pdf.converter.core.engine.FormField
import com.excelto.pdf.converter.core.engine.PdfTools
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import com.excelto.pdf.converter.ui.AppViewModel
import com.excelto.pdf.converter.ui.InnerHeader
import com.excelto.pdf.converter.ui.Route
import com.excelto.pdf.converter.ui.Tool
import com.excelto.pdf.converter.ui.components.ChoiceRow
import com.excelto.pdf.converter.ui.components.PrimaryButton
import com.excelto.pdf.converter.ui.components.SecondaryButton
import com.excelto.pdf.converter.ui.components.Segmented
import com.excelto.pdf.converter.ui.components.ToggleRow
import com.excelto.pdf.converter.ui.sheets.AppSheet
import com.excelto.pdf.converter.ui.sheets.FilePickerSheet
import com.excelto.pdf.converter.ui.sheets.appTextFieldColors
import com.excelto.pdf.converter.ui.theme.LocalPalette
import com.excelto.pdf.converter.ui.theme.Type
import java.io.File
import java.io.FileOutputStream

// ---- Signature pad ----------------------------------------------------------------

/** Draw a signature with a finger. It is saved once and reused for later documents. */
@Composable
fun SignaturePadSheet(target: File, onSaved: (Bitmap) -> Unit, onDismiss: () -> Unit) {
    val p = LocalPalette.current
    val strokes = remember { mutableStateListOf<List<Offset>>() }
    val current = remember { mutableStateListOf<Offset>() }
    var area by remember { mutableStateOf(IntSize.Zero) }
    val ink = Color(0xFF1D3F8F)
    AppSheet(onDismiss) {
        Text(tr(R.string.sign_draw), style = Type.section.copy(fontSize = 17.sp), color = p.text)
        Text(tr(R.string.sign_saved), style = Type.small, color = p.muted)
        Box(
            Modifier.fillMaxWidth().height(200.dp).clip(RoundedCornerShape(14.dp)).background(Color.White)
                .border(1.dp, p.line, RoundedCornerShape(14.dp)).onSizeChanged { area = it }
                .semantics { contentDescription = tr(R.string.sign_area) },
        ) {
            Canvas(Modifier.fillMaxSize().pointerInput(Unit) {
                detectDragGestures(
                    onDragStart = { current.clear(); current += it },
                    onDrag = { change, _ -> change.consume(); current += change.position },
                    onDragEnd = { if (current.size > 1) strokes += current.toList(); current.clear() },
                )
            }) {
                (strokes + listOf(current.toList())).forEach { pts ->
                    if (pts.size < 2) return@forEach
                    val path = Path().apply { moveTo(pts[0].x, pts[0].y); pts.drop(1).forEach { lineTo(it.x, it.y) } }
                    drawPath(path, ink, style = Stroke(6f, cap = StrokeCap.Round, join = StrokeJoin.Round))
                }
                drawLine(Color(0xFFCBD2CE), Offset(24f, size.height * 0.78f), Offset(size.width - 24f, size.height * 0.78f), 2f)
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            SecondaryButton(tr(R.string.sign_clear), { strokes.clear() }, Modifier.weight(1f))
            PrimaryButton(tr(R.string.sign_use), {
                val bmp = renderSignature(strokes, area, ink.toArgbInt())
                if (bmp != null) {
                    FileOutputStream(target).use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
                    onSaved(bmp)
                }
            }, Modifier.weight(1f), enabled = strokes.isNotEmpty())
        }
    }
}

private fun Color.toArgbInt(): Int = android.graphics.Color.argb((alpha * 255).toInt(), (red * 255).toInt(), (green * 255).toInt(), (blue * 255).toInt())

/** Draws the strokes onto a transparent bitmap cropped tightly around the signature. */
private fun renderSignature(strokes: List<List<Offset>>, area: IntSize, color: Int): Bitmap? {
    val points = strokes.flatten()
    if (points.isEmpty() || area.width == 0) return null
    val pad = 12f
    val left = (points.minOf { it.x } - pad).coerceAtLeast(0f)
    val top = (points.minOf { it.y } - pad).coerceAtLeast(0f)
    val right = (points.maxOf { it.x } + pad).coerceAtMost(area.width.toFloat())
    val bottom = (points.maxOf { it.y } + pad).coerceAtMost(area.height.toFloat())
    val bmp = Bitmap.createBitmap((right - left).toInt().coerceAtLeast(1) * 2, (bottom - top).toInt().coerceAtLeast(1) * 2, Bitmap.Config.ARGB_8888)
    val canvas = android.graphics.Canvas(bmp)
    val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        this.color = color; style = Paint.Style.STROKE; strokeWidth = 12f
        strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
    }
    for (s in strokes) {
        val path = android.graphics.Path()
        s.forEachIndexed { i, pt ->
            val x = (pt.x - left) * 2; val y = (pt.y - top) * 2
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        canvas.drawPath(path, paint)
    }
    return bmp
}

// ---- Fill form --------------------------------------------------------------------

@Composable
fun FillFormScreen(vm: AppViewModel, route: Route.ToolScreen) {
    val p = LocalPalette.current
    val file = route.files.firstOrNull()
    var attempt by remember { mutableIntStateOf(0) }
    val fields by produceState<List<FormField>?>(null, file?.path, attempt) {
        value = null
        if (file == null) return@produceState
        val read = vm.formFields(file)
        val locked = read == null && vm.passwordFor(file) == null &&
            withContext(Dispatchers.IO) { PdfTools.isPasswordProtected(file.path) }
        if (locked) vm.withPasswords(listOf(file)) { attempt++ } else value = read ?: emptyList()
    }
    val values = remember(file?.path) { mutableStateMapOf<String, String>() }
    LaunchedEffect(fields) { fields?.forEach { if (it.name !in values) values[it.name] = it.value } }
    var flatten by remember { mutableStateOf(false) }
    val list = fields
    val changed = list?.filter { values[it.name] != it.value }.orEmpty()

    ToolScaffold(vm, route, if (list.isNullOrEmpty()) tr(R.string.language_save) else tr(R.string.form_save), enabled = !list.isNullOrEmpty() && (changed.isNotEmpty() || flatten), onStart = {
        vm.runFill(file!!, list!!.associate { it.name to (values[it.name] ?: "") }, flatten)
    }) {
        when {
            list == null -> Note(tr(R.string.form_reading))
            list.isEmpty() -> {
                InfoCard(tr(R.string.form_none_title), tr(R.string.form_none))
                SecondaryButton(tr(R.string.form_open_edit), { vm.back(); vm.openTool(Tool.EDIT, file) })
            }
            else -> {
                Note(trPlural(R.plurals.form_fields, list.size, list.size))
                list.forEach { f ->
                    when (f.kind) {
                        FieldKind.TEXT -> OutlinedTextField(
                            values[f.name].orEmpty(), { values[f.name] = it }, colors = appTextFieldColors(),
                            label = { Text(f.label) }, modifier = Modifier.fillMaxWidth(),
                        )
                        FieldKind.CHECKBOX -> Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(p.surface)) {
                            val on = values[f.name].let { it != null && it != "Off" && it.isNotEmpty() }
                            ToggleRow(f.label, null, on, { values[f.name] = if (it) f.options.firstOrNull() ?: "Yes" else "Off" }, showDivider = false)
                        }
                        FieldKind.CHOICE -> Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Label(f.label)
                            f.options.chunked(3).forEach { row ->
                                ChoiceRow(row, row.indexOf(values[f.name])) { values[f.name] = row[it] }
                            }
                        }
                        else -> Unit
                    }
                }
                Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(p.surface)) {
                    ToggleRow(tr(R.string.form_lock), tr(R.string.form_lock_hint), flatten, { flatten = it }, showDivider = false)
                }
            }
        }
    }
}

// ---- Compare ----------------------------------------------------------------------

@Composable
fun CompareScreen(vm: AppViewModel, route: Route.ToolScreen) {
    val p = LocalPalette.current
    var original by remember { mutableStateOf(route.files.getOrNull(0)) }
    var revised by remember { mutableStateOf(route.files.getOrNull(1)) }
    var picking by remember { mutableStateOf<Int?>(null) }
    var view by remember { mutableIntStateOf(0) }
    val result = vm.comparison
    LaunchedEffect(original?.path, revised?.path) { vm.clearComparison() }

    Column(Modifier.fillMaxSize()) {
        InnerHeader(route.tool.label, onBack = { vm.clearComparison(); vm.back() })
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Label(tr(R.string.compare_original))
            FileCard(original) { picking = 0 }
            Label(tr(R.string.compare_new))
            FileCard(revised) { picking = 1 }
            if (vm.comparing) Note(tr(R.string.compare_running))
            if (result != null) {
                Text(if (result.isEmpty()) tr(R.string.compare_none) else trPlural(R.plurals.compare_found, result.size, result.size), style = Type.section, color = p.text)
                if (result.isNotEmpty()) {
                    Segmented(listOf(tr(R.string.compare_changes_only), tr(R.string.compare_side)), view) { view = it }
                    result.take(300).forEach { c -> ChangeCard(c, sideBySide = view == 1) }
                    if (result.size > 300) Note(tr(R.string.compare_first_300))
                }
            }
        }
        Column(Modifier.background(p.bg).padding(start = 14.dp, end = 14.dp, top = 8.dp, bottom = 12.dp)) {
            if (result != null && result.isNotEmpty()) {
                PrimaryButton(tr(R.string.compare_save), { vm.saveComparison(original!!, revised!!, result) })
                Text(tr(R.string.compare_text_only), style = Type.small, color = p.muted, modifier = Modifier.padding(top = 6.dp))
            } else {
                PrimaryButton(tr(R.string.compare_go), { vm.compare(original!!, revised!!) }, enabled = original != null && revised != null && original?.path != revised?.path && !vm.comparing)
            }
        }
    }
    picking?.let { slot ->
        FilePickerSheet(vm, Tool.COMPARE, emptyList(), onChosen = { chosen ->
            if (slot == 0) original = chosen.firstOrNull() else revised = chosen.firstOrNull()
        }, onDismiss = { picking = null })
    }
}

@Composable
private fun ChangeCard(c: Change, sideBySide: Boolean) {
    val p = LocalPalette.current
    val (bg, fg) = when (c.kind) {
        ChangeKind.CHANGED -> Color(0xFFF7EFD2) to Color(0xFF6B5300)
        ChangeKind.ADDED -> Color(0xFFDDF2E3) to Color(0xFF185734)
        ChangeKind.REMOVED -> Color(0xFFFBE3E1) to Color(0xFF8F1E17)
    }
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(p.surface).padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Row {
            Text(c.kind.label, style = Type.tiny, color = fg, modifier = Modifier.clip(RoundedCornerShape(10.dp)).background(bg).padding(horizontal = 10.dp, vertical = 2.dp))
            Text(
                listOfNotNull(c.pageBefore?.let { tr(R.string.a11y_page, it) }, c.pageAfter?.takeIf { it != c.pageBefore }?.let { tr(R.string.compare_new_page, it) }).joinToString(" → "),
                style = Type.small, color = p.muted, modifier = Modifier.weight(1f).padding(start = 8.dp),
            )
        }
        if (sideBySide) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(c.before.ifEmpty { "—" }, style = Type.small, color = Color(0xFF28303F), modifier = Modifier.weight(1f).clip(RoundedCornerShape(6.dp)).background(Color(0xFFFFF4F2)).padding(8.dp))
                Text(c.after.ifEmpty { "—" }, style = Type.small, color = Color(0xFF28303F), modifier = Modifier.weight(1f).clip(RoundedCornerShape(6.dp)).background(Color(0xFFF0FAF3)).padding(8.dp))
            }
        } else {
            if (c.before.isNotEmpty()) Text(if (c.kind == ChangeKind.CHANGED) tr(R.string.compare_before, c.before) else c.before, style = Type.small, color = p.muted)
            if (c.after.isNotEmpty()) Text(if (c.kind == ChangeKind.CHANGED) tr(R.string.compare_after, c.after) else c.after, style = Type.body, color = p.text)
        }
    }
}
