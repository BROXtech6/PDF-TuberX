package com.excelto.pdf.converter.core.engine

import com.excelto.pdf.converter.R
import android.graphics.Bitmap
import com.tom_roush.pdfbox.pdmodel.PDPageContentStream
import com.tom_roush.pdfbox.pdmodel.common.PDRectangle
import java.io.File

// ---- Page numbers ---------------------------------------------------------------------

enum class NumberPosition(@androidx.annotation.StringRes private val labelRes: Int, val top: Boolean, val align: TextAlign) {
    TOP_LEFT(R.string.pos_top_left, true, TextAlign.LEFT), TOP_CENTER(R.string.pos_top_center, true, TextAlign.CENTER), TOP_RIGHT(R.string.pos_top_right, true, TextAlign.RIGHT),
    BOTTOM_LEFT(R.string.pos_bottom_left, false, TextAlign.LEFT), BOTTOM_CENTER(R.string.pos_bottom_center, false, TextAlign.CENTER), BOTTOM_RIGHT(R.string.pos_bottom_right, false, TextAlign.RIGHT); val label: String get() = com.excelto.pdf.converter.language.tr(labelRes)
}

enum class NumberFormat(val sample: String) { PLAIN("1"), PAGE("Page 1"), PAGE_OF("Page 1 of N"), SLASH("1 / N") }

data class PageNumberOptions(
    val position: NumberPosition = NumberPosition.BOTTOM_CENTER,
    val format: NumberFormat = NumberFormat.PAGE_OF,
    /** The number printed on the first numbered page. */
    val startNumber: Int = 1,
    /** 1-based: pages before this one (a cover, say) get no number. */
    val firstPage: Int = 1,
    val fontSize: Float = 11f,
    val color: Int = 0xFF333333.toInt(),
)

object PageNumberEngine {

    /** The text for one page. [last] is the number printed on the last page. Pure, unit tested. */
    fun label(format: NumberFormat, number: Int, last: Int): String = when (format) {
        NumberFormat.PLAIN -> "$number"
        NumberFormat.PAGE -> "Page $number"
        NumberFormat.PAGE_OF -> "Page $number of $last"
        NumberFormat.SLASH -> "$number / $last"
    }

    /** The number for page [index] (0-based), or null when it isn't numbered. Pure, unit tested. */
    fun numberFor(index: Int, options: PageNumberOptions): Int? =
        if (index + 1 < options.firstPage) null else options.startNumber + index - (options.firstPage - 1)

    fun apply(input: PdfTools.Input, options: PageNumberOptions, out: File, progress: Progress) = PdfTools.writing(out) {
        PdfTools.open(input.path, input.password).use { doc ->
            PdfTools.requireOwnerRights(doc)
            val total = doc.numberOfPages
            if (options.firstPage > total) throw UserFacingException(R.string.err_first_page_too_high, "This PDF has only $total pages, so page ${options.firstPage} can't be the first numbered page.", null, total, options.firstPage)
            val last = options.startNumber + total - options.firstPage
            val text = PdfText(doc)
            val margin = 24f
            for (i in 0 until total) {
                progress.check()
                val number = numberFor(i, options) ?: continue
                val page = doc.getPage(i)
                val frame = PageFrame(page)
                PDPageContentStream(doc, page, PDPageContentStream.AppendMode.APPEND, true, true).use { cs ->
                    cs.transform(frame.matrix)
                    val x = when (options.position.align) {
                        TextAlign.LEFT -> margin
                        TextAlign.CENTER -> frame.width / 2
                        TextAlign.RIGHT -> frame.width - margin
                    }
                    val y = if (options.position.top) frame.height - margin - options.fontSize else margin
                    text.drawLine(cs, label(options.format, number, last), x, y, options.fontSize, options.color, options.position.align)
                }
                progress.step(i + 1, total, 5, 90)
            }
            doc.save(out)
        }
        progress.report(100)
    }
}

// ---- Crop -----------------------------------------------------------------------------

object CropEngine {

    /**
     * Crops pages to [area] (0..1 of the visible page, from the top-left). [pageIndex]
     * limits it to one page. With [removeTrimmed] the MediaBox is set too, so the
     * trimmed area is gone rather than just hidden.
     */
    fun apply(input: PdfTools.Input, area: NRect, pageIndex: Int?, removeTrimmed: Boolean, out: File, progress: Progress) = PdfTools.writing(out) {
        val r = area.normalized()
        if (r.width < 0.02f || r.height < 0.02f) throw UserFacingException(R.string.err_crop_area_too_small, "The crop area is too small.")
        PdfTools.open(input.path, input.password).use { doc ->
            PdfTools.requireOwnerRights(doc)
            val pages = if (pageIndex != null) listOf(pageIndex) else (0 until doc.numberOfPages).toList()
            pages.forEachIndexed { k, i ->
                progress.check()
                val page = doc.getPage(i)
                val frame = PageFrame(page)
                val box = frame.pageRect(frame.x(r.left), frame.y(r.bottom), frame.x(r.right), frame.y(r.top))
                page.cropBox = box
                if (removeTrimmed) page.mediaBox = PDRectangle(box.lowerLeftX, box.lowerLeftY, box.width, box.height)
                progress.step(k + 1, pages.size, 5, 90)
            }
            doc.save(out)
        }
        progress.report(100)
    }

    /**
     * Finds the content on a rendered page: the smallest box holding every pixel that
     * isn't near-white, with a small margin. Returns null for a blank page.
     */
    fun contentBounds(bitmap: Bitmap, threshold: Int = 245, marginFraction: Float = 0.01f): NRect? {
        val w = bitmap.width
        val h = bitmap.height
        val row = IntArray(w)
        var top = -1; var bottom = -1; var left = w; var right = -1
        for (y in 0 until h) {
            bitmap.getPixels(row, 0, w, 0, y, w, 1)
            var any = false
            for (x in 0 until w) {
                val c = row[x]
                val r = c shr 16 and 0xFF; val g = c shr 8 and 0xFF; val b = c and 0xFF
                if (r < threshold || g < threshold || b < threshold) {
                    any = true
                    if (x < left) left = x
                    if (x > right) right = x
                }
            }
            if (any) { if (top < 0) top = y; bottom = y }
        }
        if (top < 0) return null
        val m = marginFraction
        return NRect(
            (left.toFloat() / w - m).coerceAtLeast(0f), (top.toFloat() / h - m).coerceAtLeast(0f),
            ((right + 1).toFloat() / w + m).coerceAtMost(1f), ((bottom + 1).toFloat() / h + m).coerceAtMost(1f),
        )
    }
}
