package com.excelto.pdf.converter

import com.excelto.pdf.converter.R
import com.excelto.pdf.converter.language.tr
import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import com.excelto.pdf.converter.core.engine.HtmlToPdfEngine
import com.excelto.pdf.converter.ui.Tool

/** Receives links shared from a browser ("Save as PDF") and opens HTML to PDF with the link filled in. */
class ShareLinkActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val url = HtmlToPdfEngine.findUrl(intent?.getStringExtra(Intent.EXTRA_TEXT))
        if (url == null) {
            Toast.makeText(this, tr(R.string.share_no_link), Toast.LENGTH_SHORT).show()
        } else {
            startActivity(
                Intent(this, MainActivity::class.java)
                    .putExtra(MainActivity.EXTRA_TOOL, Tool.HTML_TO_PDF.name)
                    .putExtra(MainActivity.EXTRA_URL, url)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            )
        }
        finish()
    }
}
