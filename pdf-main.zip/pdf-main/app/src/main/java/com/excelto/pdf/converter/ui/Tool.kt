package com.excelto.pdf.converter.ui

import androidx.annotation.StringRes
import androidx.compose.ui.graphics.vector.ImageVector
import com.excelto.pdf.converter.R
import com.excelto.pdf.converter.core.model.DocType
import com.excelto.pdf.converter.language.tr
import com.excelto.pdf.converter.ui.theme.AppIcons
import com.excelto.pdf.converter.ui.theme.Tint
import com.excelto.pdf.converter.ui.theme.Tints

/** The tool groups, in the order the Tools tab shows them (same as iLovePDF). */
enum class ToolCategory(@StringRes private val labelRes: Int) {
    ORGANIZE(R.string.cat_organize),
    OPTIMIZE(R.string.cat_optimize),
    TO_PDF(R.string.cat_to_pdf),
    FROM_PDF(R.string.cat_from_pdf),
    EDIT(R.string.cat_edit),
    SECURITY(R.string.cat_security),
    ;

    val label: String get() = tr(labelRes)
}

/** What a tool needs before it can start. */
enum class Needs { ONE_PDF, MANY_PDFS, TWO_PDFS, ONE_SPREADSHEET, ONE_WORD, ONE_POWERPOINT, HTML, IMAGES, NOTHING }

enum class Tool(
    @StringRes private val labelRes: Int,
    @StringRes private val descriptionRes: Int,
    val category: ToolCategory,
    val icon: ImageVector,
    val tint: Tint,
    val needs: Needs,
    /** Saved under Documents/ExcelToPdf/<folder>/, the same folders as earlier versions. */
    val folder: String,
    val badge: String? = null,
    val proOnly: Boolean = false,
) {
    // Organize PDF
    MERGE(R.string.tool_merge, R.string.tool_merge_desc, ToolCategory.ORGANIZE, AppIcons.merge, Tints.red, Needs.MANY_PDFS, "Merge"),
    SPLIT(R.string.tool_split, R.string.tool_split_desc, ToolCategory.ORGANIZE, AppIcons.split, Tints.teal, Needs.ONE_PDF, "SplitPDFs"),
    REMOVE_PAGES(R.string.tool_remove_pages, R.string.tool_remove_pages_desc, ToolCategory.ORGANIZE, AppIcons.removePages, Tints.red, Needs.ONE_PDF, "RemovedPages"),
    EXTRACT_PAGES(R.string.tool_extract_pages, R.string.tool_extract_pages_desc, ToolCategory.ORGANIZE, AppIcons.extractPages, Tints.teal, Needs.ONE_PDF, "ExtractedPages"),
    ORGANIZE(R.string.tool_organize, R.string.tool_organize_desc, ToolCategory.ORGANIZE, AppIcons.organize, Tints.violet, Needs.ONE_PDF, "Organize"),
    SCAN(R.string.tool_scan, R.string.tool_scan_desc, ToolCategory.ORGANIZE, AppIcons.scan, Tints.teal, Needs.NOTHING, "ScanToPdf"),

    // Optimize PDF
    COMPRESS(R.string.tool_compress, R.string.tool_compress_desc, ToolCategory.OPTIMIZE, AppIcons.compress, Tints.green, Needs.ONE_PDF, "Compress"),
    REPAIR(R.string.tool_repair, R.string.tool_repair_desc, ToolCategory.OPTIMIZE, AppIcons.repair, Tints.amber, Needs.ONE_PDF, "Repaired"),
    OCR(R.string.tool_ocr, R.string.tool_ocr_desc, ToolCategory.OPTIMIZE, AppIcons.ocr, Tints.teal, Needs.ONE_PDF, "OCR"),

    // Convert to PDF
    IMAGE_TO_PDF(R.string.tool_image_to_pdf, R.string.tool_image_to_pdf_desc, ToolCategory.TO_PDF, AppIcons.jpg, Tints.amber, Needs.IMAGES, "ConvertedImagePdf"),
    WORD_TO_PDF(R.string.tool_word_to_pdf, R.string.tool_word_to_pdf_desc, ToolCategory.TO_PDF, AppIcons.word, Tints.blue, Needs.ONE_WORD, "WordToPdf", badge = "Pro", proOnly = true),
    POWERPOINT_TO_PDF(R.string.tool_powerpoint_to_pdf, R.string.tool_powerpoint_to_pdf_desc, ToolCategory.TO_PDF, AppIcons.slides, Tints.orange, Needs.ONE_POWERPOINT, "PowerPointToPdf", badge = "Pro", proOnly = true),
    EXCEL_TO_PDF(R.string.tool_excel_to_pdf, R.string.tool_excel_to_pdf_desc, ToolCategory.TO_PDF, AppIcons.excel, Tints.green, Needs.ONE_SPREADSHEET, "ConvertedPdf"),
    HTML_TO_PDF(R.string.tool_html_to_pdf, R.string.tool_html_to_pdf_desc, ToolCategory.TO_PDF, AppIcons.html, Tints.amber, Needs.HTML, "HtmlToPdf"),

    // Convert from PDF
    PDF_TO_JPG(R.string.tool_pdf_to_jpg, R.string.tool_pdf_to_jpg_desc, ToolCategory.FROM_PDF, AppIcons.jpg, Tints.amber, Needs.ONE_PDF, "PdfToJpg"),
    PDF_TO_WORD(R.string.tool_pdf_to_word, R.string.tool_pdf_to_word_desc, ToolCategory.FROM_PDF, AppIcons.word, Tints.blue, Needs.ONE_PDF, "PdfToWord", badge = "Pro", proOnly = true),
    PDF_TO_POWERPOINT(R.string.tool_pdf_to_powerpoint, R.string.tool_pdf_to_powerpoint_desc, ToolCategory.FROM_PDF, AppIcons.slides, Tints.orange, Needs.ONE_PDF, "PdfToPowerPoint", badge = "Pro", proOnly = true),
    PDF_TO_EXCEL(R.string.tool_pdf_to_excel, R.string.tool_pdf_to_excel_desc, ToolCategory.FROM_PDF, AppIcons.table, Tints.green, Needs.ONE_PDF, "PdfToExcel"),
    PDF_TO_PDFA(R.string.tool_pdf_to_pdfa, R.string.tool_pdf_to_pdfa_desc, ToolCategory.FROM_PDF, AppIcons.archive, Tints.navy, Needs.ONE_PDF, "PdfA"),

    // Edit PDF
    ROTATE(R.string.tool_rotate, R.string.tool_rotate_desc, ToolCategory.EDIT, AppIcons.rotate, Tints.violet, Needs.ONE_PDF, "Rotated"),
    PAGE_NUMBERS(R.string.tool_page_numbers, R.string.tool_page_numbers_desc, ToolCategory.EDIT, AppIcons.numbers, Tints.blue, Needs.ONE_PDF, "PageNumbers"),
    WATERMARK(R.string.tool_watermark, R.string.tool_watermark_desc, ToolCategory.EDIT, AppIcons.stamp, Tints.red, Needs.ONE_PDF, "Watermark"),
    CROP(R.string.tool_crop, R.string.tool_crop_desc, ToolCategory.EDIT, AppIcons.crop, Tints.teal, Needs.ONE_PDF, "Cropped"),
    EDIT(R.string.tool_edit, R.string.tool_edit_desc, ToolCategory.EDIT, AppIcons.pen, Tints.blue, Needs.ONE_PDF, "Edited"),
    ANNOTATE(R.string.tool_annotate, R.string.tool_annotate_desc, ToolCategory.EDIT, AppIcons.marker, Tints.amber, Needs.ONE_PDF, "Annotated"),
    FILL_FORM(R.string.tool_fill_form, R.string.tool_fill_form_desc, ToolCategory.EDIT, AppIcons.form, Tints.teal, Needs.ONE_PDF, "Filled"),

    // PDF Security
    UNLOCK(R.string.tool_unlock, R.string.tool_unlock_desc, ToolCategory.SECURITY, AppIcons.unlock, Tints.blue, Needs.ONE_PDF, "Unlocked"),
    PROTECT(R.string.tool_protect, R.string.tool_protect_desc, ToolCategory.SECURITY, AppIcons.lock, Tints.green, Needs.ONE_PDF, "Protected"),
    SIGN(R.string.tool_sign, R.string.tool_sign_desc, ToolCategory.SECURITY, AppIcons.sign, Tints.blue, Needs.ONE_PDF, "Signed"),
    REDACT(R.string.tool_redact, R.string.tool_redact_desc, ToolCategory.SECURITY, AppIcons.redact, Tints.red, Needs.ONE_PDF, "Redacted", badge = "Pro", proOnly = true),
    COMPARE(R.string.tool_compare, R.string.tool_compare_desc, ToolCategory.SECURITY, AppIcons.compare, Tints.teal, Needs.TWO_PDFS, "Compared"),
    ;

    /** The tool's name and one-line description, in the app's language. */
    val label: String get() = tr(labelRes)
    val description: String get() = tr(descriptionRes)

    /** The tool works on exactly one chosen file. */
    val needsOneFile: Boolean
        get() = needs == Needs.ONE_PDF || needs == Needs.ONE_SPREADSHEET || needs == Needs.ONE_WORD || needs == Needs.ONE_POWERPOINT

    val acceptedType: DocType?
        get() = when (needs) {
            Needs.ONE_PDF, Needs.MANY_PDFS, Needs.TWO_PDFS -> DocType.PDF
            Needs.ONE_SPREADSHEET -> DocType.EXCEL
            Needs.ONE_WORD -> DocType.WORD
            Needs.ONE_POWERPOINT -> DocType.POWERPOINT
            Needs.HTML -> DocType.HTML
            else -> null
        }

    val pickerMimeTypes: Array<String>
        get() = when (needs) {
            Needs.ONE_SPREADSHEET -> arrayOf(
                "application/vnd.ms-excel",
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                "text/csv", "text/comma-separated-values",
            )
            Needs.ONE_WORD -> arrayOf("application/vnd.openxmlformats-officedocument.wordprocessingml.document", "application/msword")
            Needs.ONE_POWERPOINT -> arrayOf("application/vnd.openxmlformats-officedocument.presentationml.presentation")
            Needs.HTML -> arrayOf("text/html")
            else -> arrayOf("application/pdf")
        }

    companion object {
        /** The tools people use most every day (edit, compress, merge, Word, photos, scan,
         *  sign), shown first on Home and in the Tools tab. */
        val POPULAR = listOf(EDIT, COMPRESS, MERGE, PDF_TO_WORD, WORD_TO_PDF, IMAGE_TO_PDF, SCAN, SIGN)

        /** Short names for small tiles. */
        fun shortLabel(tool: Tool) = when (tool) {
            EDIT -> tr(R.string.tool_short_edit); COMPRESS -> tr(R.string.tool_short_compress); MERGE -> tr(R.string.tool_short_merge)
            PDF_TO_WORD -> tr(R.string.tool_pdf_to_word); WORD_TO_PDF -> tr(R.string.tool_word_to_pdf)
            IMAGE_TO_PDF -> tr(R.string.tool_image_to_pdf); SCAN -> tr(R.string.tool_short_scan); SIGN -> tr(R.string.tool_short_sign)
            else -> tool.label
        }

        /** Tools offered in a file's actions sheet, by file type. */
        fun forType(type: DocType): List<Tool> = when (type) {
            DocType.PDF -> entries.filter {
                it.needs == Needs.ONE_PDF &&
                    it.category in setOf(ToolCategory.FROM_PDF, ToolCategory.ORGANIZE, ToolCategory.OPTIMIZE, ToolCategory.EDIT, ToolCategory.SECURITY)
            }
            DocType.EXCEL -> listOf(EXCEL_TO_PDF)
            DocType.WORD -> listOf(WORD_TO_PDF)
            DocType.POWERPOINT -> listOf(POWERPOINT_TO_PDF)
            DocType.HTML -> listOf(HTML_TO_PDF)
            DocType.IMAGE -> listOf(IMAGE_TO_PDF)
            DocType.OTHER -> emptyList()
        }
    }
}
