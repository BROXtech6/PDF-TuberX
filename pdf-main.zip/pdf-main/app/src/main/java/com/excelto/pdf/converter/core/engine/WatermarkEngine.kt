package com.excelto.pdf.converter.core.engine

import com.tom_roush.pdfbox.pdmodel.PDPageContentStream
import com.tom_roush.pdfbox.pdmodel.graphics.state.PDExtendedGraphicsState
import java.io.File
import kotlin.math.min

enum class WatermarkPosition { DIAGONAL, CENTER, FOOTER }

data class WatermarkOptions(
    val text: String,
    val opacity: Float = 0.25f,
    val position: WatermarkPosition = WatermarkPosition.DIAGONAL,
    val pageNumbers: Boolean = false,
)

object WatermarkEngine {

    private const val RED = 0xFFB3261E.toInt()
    private const val DARK_GRAY = 0xFF404040.toInt()

    fun apply(input: PdfTools.Input, options: WatermarkOptions, out: File, progress: Progress) = PdfTools.writing(out) {
        PdfTools.open(input.path, input.password).use { doc ->
            PdfTools.requireOwnerRights(doc)
            val bold = PdfText(doc, bold = true)
            val plain = PdfText(doc)
            val total = doc.numberOfPages
            for (index in 0 until total) {
                val page = doc.getPage(index)
                val frame = PageFrame(page)
                PDPageContentStream(doc, page, PDPageContentStream.AppendMode.APPEND, true, true).use { cs ->
                    cs.transform(frame.matrix)
                    val centerX = frame.width / 2
                    if (options.text.isNotBlank()) {
                        val size = when (options.position) {
                            WatermarkPosition.FOOTER -> 14f
                            else -> (min(frame.width, frame.height) / 9f).coerceIn(18f, 72f)
                        }
                        val (y, rotation) = when (options.position) {
                            WatermarkPosition.DIAGONAL -> frame.height / 2 to 45f
                            WatermarkPosition.CENTER -> frame.height / 2 to 0f
                            WatermarkPosition.FOOTER -> 36f to 0f
                        }
                        cs.saveGraphicsState()
                        cs.setGraphicsStateParameters(PDExtendedGraphicsState().apply {
                            nonStrokingAlphaConstant = options.opacity.coerceIn(0.05f, 1f)
                        })
                        // Centered on the point, like the old engine (baseline through the middle, lifted by a third of the size).
                        bold.drawLine(cs, options.text, centerX, y - size / 3f, size, RED, TextAlign.CENTER, rotation)
                        cs.restoreGraphicsState()
                    }
                    if (options.pageNumbers) {
                        plain.drawLine(cs, "Page ${index + 1} of $total", centerX, 16f, 9f, DARK_GRAY, TextAlign.CENTER)
                    }
                }
                progress.step(index + 1, total, 5, 90)
            }
            doc.save(out)
        }
        progress.report(100)
    }
}
