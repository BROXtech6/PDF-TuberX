package com.excelto.pdf.converter.core.office

import com.excelto.pdf.converter.core.office.OfficeZip.Companion.XML_HEADER
import com.excelto.pdf.converter.core.office.OfficeZip.Companion.emu
import com.excelto.pdf.converter.core.office.OfficeZip.Companion.esc
import java.io.File

/** The content model for a Word document we write. */
object WordDoc {
    data class Run(val text: String, val bold: Boolean = false, val italic: Boolean = false, val sizePt: Float? = null)

    sealed interface Block
    data class Paragraph(
        val runs: List<Run>,
        val style: Style = Style.NORMAL,
        val align: Align = Align.LEFT,
        val rtl: Boolean = false,
    ) : Block {
        val text: String get() = runs.joinToString("") { it.text }
    }
    data class Table(val rows: List<List<String>>) : Block
    class Image(val bytes: ByteArray, val isPng: Boolean, val widthPt: Float, val heightPt: Float) : Block
    data object PageBreak : Block

    enum class Style(val id: String?) { NORMAL(null), TITLE("Title"), HEADING1("Heading1"), HEADING2("Heading2") }
    enum class Align(val value: String) { LEFT("left"), CENTER("center"), RIGHT("right"), BOTH("both") }

    data class Page(val widthPt: Float = 595f, val heightPt: Float = 842f, val marginPt: Float = 54f)
}

/**
 * Writes a .docx with real paragraphs, headings, tables and pictures, so the result can
 * be edited in Word, Google Docs or LibreOffice. Pure Kotlin, unit tested.
 */
object DocxWriter {

    private const val NS_W = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
    private const val NS_R = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
    private const val REL = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"

    private fun twips(pt: Float) = (pt * 20f).toInt()

    fun write(out: File, blocks: List<WordDoc.Block>, page: WordDoc.Page = WordDoc.Page(), title: String = "Document") {
        OfficeZip(out).use { z ->
            val images = mutableListOf<WordDoc.Image>()
            val contentWidth = page.widthPt - page.marginPt * 2
            val body = StringBuilder()
            for (b in blocks) {
                when (b) {
                    is WordDoc.Paragraph -> body.append(paragraph(b))
                    is WordDoc.Table -> body.append(table(b, contentWidth))
                    is WordDoc.Image -> {
                        images += b
                        body.append(image(b, images.size, contentWidth, page.heightPt - page.marginPt * 2))
                    }
                    WordDoc.PageBreak -> body.append("""<w:p><w:r><w:br w:type="page"/></w:r></w:p>""")
                }
            }
            val landscape = page.widthPt > page.heightPt
            val m = twips(page.marginPt)
            body.append("""<w:sectPr><w:pgSz w:w="${twips(page.widthPt)}" w:h="${twips(page.heightPt)}"${if (landscape) """ w:orient="landscape"""" else ""}/>""")
            body.append("""<w:pgMar w:top="$m" w:right="$m" w:bottom="$m" w:left="$m" w:header="708" w:footer="708" w:gutter="0"/></w:sectPr>""")

            z.text("word/document.xml", buildString {
                append(XML_HEADER)
                append("""<w:document xmlns:w="$NS_W" xmlns:r="$NS_R" xmlns:wp="http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing" xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" xmlns:pic="http://schemas.openxmlformats.org/drawingml/2006/picture"><w:body>""")
                append(body)
                append("</w:body></w:document>")
            })
            images.forEachIndexed { i, img -> z.bytes("word/media/image${i + 1}.${if (img.isPng) "png" else "jpeg"}", img.bytes) }
            z.text("word/styles.xml", stylesXml())
            z.text("word/settings.xml", """$XML_HEADER<w:settings xmlns:w="$NS_W"><w:defaultTabStop w:val="720"/><w:compat><w:compatSetting w:name="compatibilityMode" w:uri="http://schemas.microsoft.com/office/word" w:val="15"/></w:compat></w:settings>""")
            z.text("word/_rels/document.xml.rels", buildString {
                append(XML_HEADER).append("""<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">""")
                append("""<Relationship Id="rIdStyles" Type="$REL/styles" Target="styles.xml"/>""")
                append("""<Relationship Id="rIdSettings" Type="$REL/settings" Target="settings.xml"/>""")
                images.forEachIndexed { i, img ->
                    append("""<Relationship Id="rIdImg${i + 1}" Type="$REL/image" Target="media/image${i + 1}.${if (img.isPng) "png" else "jpeg"}"/>""")
                }
                append("</Relationships>")
            })
            z.text("_rels/.rels", """$XML_HEADER<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="$REL/officeDocument" Target="word/document.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/></Relationships>""")
            z.text("docProps/core.xml", OfficeParts.coreXml(title))
            z.text("[Content_Types].xml", buildString {
                append(XML_HEADER).append("""<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">""")
                append("""<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>""")
                append("""<Default Extension="xml" ContentType="application/xml"/>""")
                if (images.any { !it.isPng }) append("""<Default Extension="jpeg" ContentType="image/jpeg"/>""")
                if (images.any { it.isPng }) append("""<Default Extension="png" ContentType="image/png"/>""")
                val wml = "application/vnd.openxmlformats-officedocument.wordprocessingml"
                append("""<Override PartName="/word/document.xml" ContentType="$wml.document.main+xml"/>""")
                append("""<Override PartName="/word/styles.xml" ContentType="$wml.styles+xml"/>""")
                append("""<Override PartName="/word/settings.xml" ContentType="$wml.settings+xml"/>""")
                append("""<Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/>""")
                append("</Types>")
            })
        }
    }

    private fun paragraph(p: WordDoc.Paragraph) = buildString {
        append("<w:p><w:pPr>")
        p.style.id?.let { append("""<w:pStyle w:val="$it"/>""") }
        if (p.rtl) append("<w:bidi/>")
        if (p.align != WordDoc.Align.LEFT) append("""<w:jc w:val="${p.align.value}"/>""")
        append("</w:pPr>")
        for (r in p.runs) {
            if (r.text.isEmpty()) continue
            append("<w:r>")
            if (r.bold || r.italic || r.sizePt != null || p.rtl) {
                append("<w:rPr>")
                if (r.bold) append("<w:b/><w:bCs/>")
                if (r.italic) append("<w:i/><w:iCs/>")
                if (p.rtl) append("<w:rtl/>")
                r.sizePt?.let { val hp = (it * 2).toInt().coerceIn(2, 3276); append("""<w:sz w:val="$hp"/><w:szCs w:val="$hp"/>""") }
                append("</w:rPr>")
            }
            val parts = r.text.split('\n')
            parts.forEachIndexed { i, line ->
                if (i > 0) append("<w:br/>")
                val tabs = line.split('\t')
                tabs.forEachIndexed { j, t ->
                    if (j > 0) append("<w:tab/>")
                    if (t.isNotEmpty()) append("""<w:t xml:space="preserve">${esc(t)}</w:t>""")
                }
            }
            append("</w:r>")
        }
        append("</w:p>")
    }

    private fun table(t: WordDoc.Table, contentWidth: Float) = buildString {
        val cols = t.rows.maxOfOrNull { it.size } ?: 0
        if (cols == 0) return@buildString
        val colW = twips(contentWidth) / cols
        append("""<w:tbl><w:tblPr><w:tblStyle w:val="TableGrid"/><w:tblW w:w="0" w:type="auto"/></w:tblPr><w:tblGrid>""")
        repeat(cols) { append("""<w:gridCol w:w="$colW"/>""") }
        append("</w:tblGrid>")
        for (row in t.rows) {
            append("<w:tr>")
            for (c in 0 until cols) {
                append("""<w:tc><w:tcPr><w:tcW w:w="$colW" w:type="dxa"/></w:tcPr>""")
                append(paragraph(WordDoc.Paragraph(listOf(WordDoc.Run(row.getOrElse(c) { "" })))))
                append("</w:tc>")
            }
            append("</w:tr>")
        }
        append("</w:tbl>")
        // Word needs a paragraph between two tables or after a table at the end of a cell.
        append("<w:p/>")
    }

    private fun image(img: WordDoc.Image, n: Int, maxW: Float, maxH: Float) = buildString {
        var w = img.widthPt.coerceAtLeast(1f)
        var h = img.heightPt.coerceAtLeast(1f)
        val s = minOf(1f, maxW / w, maxH / h)
        w *= s; h *= s
        val cx = emu(w); val cy = emu(h)
        append("""<w:p><w:r><w:drawing><wp:inline distT="0" distB="0" distL="0" distR="0"><wp:extent cx="$cx" cy="$cy"/><wp:docPr id="$n" name="Picture $n"/>""")
        append("""<wp:cNvGraphicFramePr><a:graphicFrameLocks noChangeAspect="1"/></wp:cNvGraphicFramePr>""")
        append("""<a:graphic><a:graphicData uri="http://schemas.openxmlformats.org/drawingml/2006/picture"><pic:pic>""")
        append("""<pic:nvPicPr><pic:cNvPr id="$n" name="image$n"/><pic:cNvPicPr/></pic:nvPicPr>""")
        append("""<pic:blipFill><a:blip r:embed="rIdImg$n"/><a:stretch><a:fillRect/></a:stretch></pic:blipFill>""")
        append("""<pic:spPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="$cx" cy="$cy"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom></pic:spPr>""")
        append("""</pic:pic></a:graphicData></a:graphic></wp:inline></w:drawing></w:r></w:p>""")
    }

    private fun stylesXml() = buildString {
        append(XML_HEADER).append("""<w:styles xmlns:w="$NS_W">""")
        append("""<w:docDefaults><w:rPrDefault><w:rPr><w:rFonts w:ascii="Calibri" w:hAnsi="Calibri" w:eastAsia="Calibri" w:cs="Arial"/><w:sz w:val="22"/><w:szCs w:val="22"/><w:lang w:val="en-US"/></w:rPr></w:rPrDefault>""")
        append("""<w:pPrDefault><w:pPr><w:spacing w:after="120" w:line="264" w:lineRule="auto"/></w:pPr></w:pPrDefault></w:docDefaults>""")
        append("""<w:style w:type="paragraph" w:default="1" w:styleId="Normal"><w:name w:val="Normal"/><w:qFormat/></w:style>""")
        fun heading(id: String, name: String, size: Int, level: Int?) {
            append("""<w:style w:type="paragraph" w:styleId="$id"><w:name w:val="$name"/><w:basedOn w:val="Normal"/><w:next w:val="Normal"/><w:qFormat/>""")
            append("""<w:pPr><w:keepNext/><w:spacing w:before="240" w:after="120"/>${level?.let { """<w:outlineLvl w:val="$it"/>""" } ?: ""}</w:pPr>""")
            append("""<w:rPr><w:b/><w:bCs/><w:sz w:val="$size"/><w:szCs w:val="$size"/></w:rPr></w:style>""")
        }
        heading("Title", "Title", 44, null)
        heading("Heading1", "heading 1", 32, 0)
        heading("Heading2", "heading 2", 26, 1)
        append("""<w:style w:type="table" w:default="1" w:styleId="TableNormal"><w:name w:val="Normal Table"/><w:tblPr><w:tblInd w:w="0" w:type="dxa"/><w:tblCellMar><w:top w:w="0" w:type="dxa"/><w:left w:w="108" w:type="dxa"/><w:bottom w:w="0" w:type="dxa"/><w:right w:w="108" w:type="dxa"/></w:tblCellMar></w:tblPr></w:style>""")
        append("""<w:style w:type="table" w:styleId="TableGrid"><w:name w:val="Table Grid"/><w:basedOn w:val="TableNormal"/><w:pPr><w:spacing w:after="0" w:line="240" w:lineRule="auto"/></w:pPr><w:tblPr><w:tblBorders>""")
        for (side in listOf("top", "left", "bottom", "right", "insideH", "insideV")) append("""<w:$side w:val="single" w:sz="4" w:space="0" w:color="auto"/>""")
        append("</w:tblBorders></w:tblPr></w:style>")
        append("</w:styles>")
    }
}
