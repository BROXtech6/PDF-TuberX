package com.excelto.pdf.converter.core.engine

import com.excelto.pdf.converter.R
import com.tom_roush.pdfbox.io.MemoryUsageSetting
import com.tom_roush.pdfbox.pdmodel.PDDocument
import java.io.File

enum class ChangeKind(@androidx.annotation.StringRes private val labelRes: Int) { ADDED(R.string.compare_added), REMOVED(R.string.compare_removed), CHANGED(R.string.compare_changed); val label: String get() = com.excelto.pdf.converter.language.tr(labelRes) }

data class Change(val kind: ChangeKind, val before: String, val after: String, val pageBefore: Int?, val pageAfter: Int?)

/** Finds text that was added, removed or changed between two versions of a PDF. */
object CompareEngine {

    data class Line(val text: String, val page: Int)

    fun compare(original: PdfTools.Input, revised: PdfTools.Input, progress: Progress): List<Change> {
        val a = lines(original)
        progress.report(30)
        val b = lines(revised)
        progress.report(55)
        if (a.isEmpty() && b.isEmpty()) {
            throw UserFacingException(R.string.err_these_pdfs_no_selectable, "These PDFs have no selectable text to compare. If they're scans, run them through Scan with text recognition first.")
        }
        val changes = diff(a, b)
        progress.report(100)
        return changes
    }

    private fun lines(input: PdfTools.Input): List<Line> = linesOf(TextEngine.pages(input))

    fun linesOf(pages: List<String>): List<Line> = pages.flatMapIndexed { i, text ->
        text.lines().map { it.trim().replace(Regex("\\s+"), " ") }.filter { it.isNotEmpty() }.map { Line(it, i + 1) }
    }

    /** Line-level diff (longest common subsequence), then pairs removals with additions as changes. */
    fun diff(a: List<Line>, b: List<Line>): List<Change> {
        val n = a.size
        val m = b.size
        if (n.toLong() * m > 25_000_000L) throw UserFacingException(R.string.err_these_documents_are_too, "These documents are too long to compare on a phone. Try comparing fewer pages.")
        val lcs = Array(n + 1) { IntArray(m + 1) }
        for (i in n - 1 downTo 0) for (j in m - 1 downTo 0) {
            lcs[i][j] = if (a[i].text == b[j].text) lcs[i + 1][j + 1] + 1 else maxOf(lcs[i + 1][j], lcs[i][j + 1])
        }
        val out = mutableListOf<Change>()
        val removed = mutableListOf<Line>()
        val added = mutableListOf<Line>()
        fun flush() {
            val pairs = minOf(removed.size, added.size)
            for (k in 0 until pairs) out += Change(ChangeKind.CHANGED, removed[k].text, added[k].text, removed[k].page, added[k].page)
            for (k in pairs until removed.size) out += Change(ChangeKind.REMOVED, removed[k].text, "", removed[k].page, null)
            for (k in pairs until added.size) out += Change(ChangeKind.ADDED, "", added[k].text, null, added[k].page)
            removed.clear(); added.clear()
        }
        var i = 0
        var j = 0
        while (i < n || j < m) {
            when {
                i < n && j < m && a[i].text == b[j].text -> { flush(); i++; j++ }
                j < m && (i == n || lcs[i][j + 1] >= lcs[i + 1][j]) -> { added += b[j]; j++ }
                else -> { removed += a[i]; i++ }
            }
        }
        flush()
        return out
    }

    /** A simple PDF listing every change, for sharing with others. */
    fun report(originalName: String, revisedName: String, changes: List<Change>, out: File) = PdfTools.writing(out) {
        PDDocument(MemoryUsageSetting.setupMixed(8L * 1024 * 1024)).use { doc ->
            val flow = PdfFlow(doc, margin = 40f)
            flow.paragraph("Comparison report", 18f, isBold = true, spaceAfter = 4f)
            val gray = 0xFF404040.toInt()
            flow.paragraph("Original: $originalName", 10f, gray)
            flow.paragraph("New: $revisedName", 10f, gray)
            flow.paragraph("${changes.size} changes found", 10f, gray, spaceAfter = 12f)
            for (c in changes) {
                val color = when (c.kind) {
                    ChangeKind.ADDED -> 0xFF185734.toInt()
                    ChangeKind.REMOVED -> 0xFF8F1E17.toInt()
                    ChangeKind.CHANGED -> 0xFF6B5300.toInt()
                }
                val where = listOfNotNull(c.pageBefore?.let { "original page $it" }, c.pageAfter?.let { "new page $it" }).joinToString(", ")
                flow.paragraph("${c.kind.label} · $where", 10f, color, isBold = true)
                if (c.before.isNotEmpty()) flow.paragraph("Before: ${c.before}", 10f)
                if (c.after.isNotEmpty()) flow.paragraph("After: ${c.after}", 10f)
                flow.paragraph(" ", 10f)
            }
            flow.close()
            doc.save(out)
        }
    }
}
