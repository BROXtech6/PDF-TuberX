package com.excelto.pdf.converter.ui

import com.excelto.pdf.converter.R
import com.excelto.pdf.converter.language.tr
import com.excelto.pdf.converter.language.trPlural
import android.app.Application
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.excelto.pdf.converter.app.App
import com.excelto.pdf.converter.core.engine.Change
import com.excelto.pdf.converter.core.engine.OcrScript
import com.excelto.pdf.converter.core.engine.ScanEngine
import com.excelto.pdf.converter.core.engine.UserFacingException
import com.excelto.pdf.converter.core.engine.CompareEngine
import com.excelto.pdf.converter.core.engine.CompressEngine
import com.excelto.pdf.converter.core.engine.EditEngine
import com.excelto.pdf.converter.core.engine.FormEngine
import com.excelto.pdf.converter.core.engine.FormField
import com.excelto.pdf.converter.core.engine.Mark
import com.excelto.pdf.converter.core.engine.TextEngine
import com.excelto.pdf.converter.core.engine.TextLine
import com.excelto.pdf.converter.core.engine.CompressLevel
import com.excelto.pdf.converter.core.engine.ExcelEngine
import com.excelto.pdf.converter.core.engine.ExcelOptions
import com.excelto.pdf.converter.core.engine.ImageToPdfEngine
import com.excelto.pdf.converter.core.engine.PageChoice
import com.excelto.pdf.converter.core.engine.PageSpec
import com.excelto.pdf.converter.core.engine.PasswordRequiredException
import com.excelto.pdf.converter.core.engine.PdfToExcelEngine
import com.excelto.pdf.converter.core.engine.PdfTools
import com.excelto.pdf.converter.core.engine.CropEngine
import com.excelto.pdf.converter.core.engine.ImageFormat
import com.excelto.pdf.converter.core.engine.NRect
import com.excelto.pdf.converter.core.engine.OcrEngine
import com.excelto.pdf.converter.core.engine.PageNumberEngine
import com.excelto.pdf.converter.core.engine.PageNumberOptions
import com.excelto.pdf.converter.core.engine.PdfToImageEngine
import com.excelto.pdf.converter.core.engine.RepairEngine
import com.excelto.pdf.converter.core.engine.TableLayout
import com.excelto.pdf.converter.core.engine.WatermarkEngine
import com.excelto.pdf.converter.core.engine.WatermarkOptions
import com.excelto.pdf.converter.core.jobs.JobCenter
import com.excelto.pdf.converter.core.jobs.JobResult
import com.excelto.pdf.converter.core.model.DocFile
import com.excelto.pdf.converter.core.storage.AppPrefs
import com.excelto.pdf.converter.core.storage.FileRepository
import com.excelto.pdf.converter.core.storage.OutputFiles
import com.excelto.pdf.converter.core.storage.ThemeMode
import com.excelto.pdf.converter.ui.components.formatSize
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

sealed interface Route {
    data object Home : Route
    data object Tools : Route
    data object Files : Route
    data object Settings : Route
    data class ToolScreen(
        val tool: Tool,
        val files: List<DocFile> = emptyList(),
        val images: List<Uri> = emptyList(),
        /** A link shared into the app, for HTML to PDF. */
        val text: String? = null,
        /** The sheet the Excel viewer was showing, for Excel to PDF. */
        val sheet: Int? = null,
    ) : Route
    data object Progress : Route
    data object Result : Route

    val isTab: Boolean get() = this == Home || this == Tools || this == Files || this == Settings
}

/** A file waiting for its password before a tool can use it. */
data class PasswordPrompt(val file: DocFile, val wrongPassword: Boolean, val onUnlocked: () -> Unit)

class AppViewModel(app: Application) : AndroidViewModel(app) {

    val prefs = AppPrefs(app)
    val repository = FileRepository(app, prefs)

    val stack = mutableStateListOf<Route>(Route.Home)
    val current: Route get() = stack.last()

    private val _files = MutableStateFlow<List<DocFile>>(emptyList())
    val files: StateFlow<List<DocFile>> = _files
    var loadingFiles by mutableStateOf(true)
        private set

    var isPremium by mutableStateOf(false)
        private set
    var themeMode by mutableStateOf(prefs.themeMode)
        private set
    var hasAllFilesAccess by mutableStateOf(false)
        private set

    var passwordPrompt by mutableStateOf<PasswordPrompt?>(null)
        private set
    private val passwords = HashMap<String, String>()

    private val messages = Channel<String>(Channel.BUFFERED)
    val messageFlow = messages.receiveAsFlow()

    init {
        refreshStatus()
        refreshFiles()
    }

    fun refreshStatus() {
        isPremium = runCatching { App.getInstance().isSubscribed }.getOrDefault(false)
        hasAllFilesAccess = repository.hasAllFilesAccess()
    }

    fun refreshFiles() {
        viewModelScope.launch {
            loadingFiles = _files.value.isEmpty()
            _files.value = runCatching { repository.scan() }.getOrDefault(_files.value)
            loadingFiles = false
        }
    }

    fun say(text: String) { messages.trySend(text) }

    // ---- Navigation -------------------------------------------------------------

    fun openTab(route: Route) {
        stack.clear()
        stack.add(route)
    }

    fun push(route: Route) { stack.add(route) }

    fun replaceTop(route: Route) {
        stack[stack.lastIndex] = route
    }

    /** Returns false when already on a tab's root, so the activity can handle exit. */
    fun back(): Boolean {
        if (stack.size <= 1) {
            if (current != Route.Home) { openTab(Route.Home); return true }
            return false
        }
        stack.removeAt(stack.lastIndex)
        // Never land back on a finished progress screen.
        while (stack.size > 1 && (current == Route.Progress || current == Route.Result)) stack.removeAt(stack.lastIndex)
        return true
    }

    /** Bumped when a Pro tool is opened on the free plan; the activity shows the paywall. */
    /** A Google Play update finished downloading and is waiting for a restart. */
    var updateReady by mutableStateOf(false)

    var paywallRequests by mutableStateOf(0)
        private set

    fun requestPaywall() { paywallRequests++ }

    /** A Pro tool a free user tried to open: they can go Pro or watch an ad to use it once. */
    class ProOffer(val tool: Tool, val reopen: () -> Unit)

    var proOffer by mutableStateOf<ProOffer?>(null)
        private set

    /** Tools unlocked for one use by a rewarded ad; used up when their job starts. */
    private val oneTimePasses = mutableSetOf<Tool>()

    fun canUse(tool: Tool): Boolean = isPremium || tool in oneTimePasses

    fun offerPro(tool: Tool, reopen: () -> Unit) { proOffer = ProOffer(tool, reopen) }

    fun dismissProOffer() { proOffer = null }

    /** The rewarded ad was watched: unlock the tool once and continue where the user was. */
    fun grantOnce(offer: ProOffer) {
        oneTimePasses += offer.tool
        proOffer = null
        offer.reopen()
        say(tr(R.string.vm_unlocked_once, offer.tool.label))
    }

    fun openTool(tool: Tool, preset: DocFile? = null, text: String? = null, sheet: Int? = null) {
        if (tool.proOnly && !canUse(tool)) {
            offerPro(tool) { openTool(tool, preset, text, sheet) }
            return
        }
        val files = listOfNotNull(preset?.takeIf { tool.acceptedType == it.type })
        push(Route.ToolScreen(tool, files, text = text, sheet = sheet))
    }

    fun setToolFiles(files: List<DocFile>) {
        val top = current as? Route.ToolScreen ?: return
        replaceTop(top.copy(files = files))
    }

    fun setToolImages(images: List<Uri>) {
        val top = current as? Route.ToolScreen ?: return
        replaceTop(top.copy(images = images))
    }

    // ---- Files ------------------------------------------------------------------

    fun importAndUse(uris: List<Uri>, onDone: (List<DocFile>) -> Unit) {
        viewModelScope.launch {
            val imported = uris.mapNotNull { uri -> runCatching { repository.import(uri) }.getOrNull() }
            if (imported.size < uris.size) say(tr(R.string.vm_some_failed))
            refreshFiles()
            if (imported.isNotEmpty()) onDone(imported)
        }
    }

    fun toggleFavorite(file: DocFile) {
        prefs.toggleFavorite(file.path)
        refreshFiles()
    }

    fun rename(file: DocFile, name: String) {
        viewModelScope.launch {
            val ok = withContext(Dispatchers.IO) { repository.rename(file, name) }
            say(if (ok != null) tr(R.string.vm_renamed) else tr(R.string.vm_rename_failed))
            refreshFiles()
        }
    }

    fun delete(file: DocFile) {
        viewModelScope.launch {
            val ok = withContext(Dispatchers.IO) { repository.delete(file) }
            say(if (ok) tr(R.string.vm_deleted) else tr(R.string.vm_delete_failed))
            refreshFiles()
        }
    }

    fun setTheme(mode: ThemeMode) {
        prefs.themeMode = mode
        themeMode = mode
    }

    // ---- Passwords --------------------------------------------------------------

    fun passwordFor(file: DocFile): String? = passwords[file.path]

    /** Asks for passwords of any locked PDFs in [files], then runs [then]. */
    fun withPasswords(files: List<DocFile>, then: () -> Unit) {
        viewModelScope.launch {
            val locked = withContext(Dispatchers.IO) {
                files.firstOrNull { it.path !in passwords && it.type == com.excelto.pdf.converter.core.model.DocType.PDF && PdfTools.isPasswordProtected(it.path) }
            }
            if (locked == null) then() else passwordPrompt = PasswordPrompt(locked, false) { withPasswords(files, then) }
        }
    }

    fun submitPassword(password: String) {
        val prompt = passwordPrompt ?: return
        viewModelScope.launch {
            val ok = withContext(Dispatchers.IO) {
                runCatching { PdfTools.open(prompt.file.path, password).close(); true }.getOrDefault(false)
            }
            if (ok) {
                passwords[prompt.file.path] = password
                passwordPrompt = null
                prompt.onUnlocked()
            } else {
                passwordPrompt = prompt.copy(wrongPassword = true)
            }
        }
    }

    fun dismissPassword() { passwordPrompt = null }

    private fun input(file: DocFile) = PdfTools.Input(file.path, passwords[file.path])

    // ---- Jobs -------------------------------------------------------------------

    private fun launch(tool: Tool, title: String, steps: List<String>, work: suspend (com.excelto.pdf.converter.core.engine.Progress) -> JobResult) {
        if (JobCenter.isBusy) { say(tr(R.string.vm_busy)); return }
        val started = JobCenter.start(title, steps, onFinished = { result ->
            OutputFiles.publish(getApplication(), result.files)
            prefs.recordJob(result.bytesSaved)
            refreshFiles()
        }, work = work)
        if (started) {
            // A rewarded one-time pass is used up by the job it unlocked.
            oneTimePasses.remove(tool)
            push(Route.Progress)
        }
    }

    private fun detail(file: File) = "${formatSize(file.length())} · Documents/ExcelToPdf/${file.parentFile?.name}"

    fun runExcelToPdf(file: DocFile, options: ExcelOptions) {
        val out = OutputFiles.newFile(Tool.EXCEL_TO_PDF.folder, file.stem, "pdf")
        launch(Tool.EXCEL_TO_PDF, tr(R.string.job_t_to_pdf), listOf(tr(R.string.step_read_sheet), tr(R.string.step_layout), tr(R.string.step_save_pdf))) { p ->
            val result = ExcelEngine.toPdf(file.path, options, out, p)
            val notes = result.notes.joinToString(" ")
            JobResult(listOf(out), if (notes.isEmpty()) detail(out) else "${detail(out)} · $notes")
        }
    }

    fun runPdfToExcel(file: DocFile, layout: TableLayout) = withPasswords(listOf(file)) {
        val out = OutputFiles.newFile(Tool.PDF_TO_EXCEL.folder, file.stem, "xlsx")
        launch(Tool.PDF_TO_EXCEL, tr(R.string.job_t_tables), listOf(tr(R.string.step_read_pages), tr(R.string.step_find_tables), tr(R.string.step_save_workbook))) { p ->
            val rows = PdfToExcelEngine.convert(input(file), layout, out, p)
            JobResult(listOf(out), "${trPlural(R.plurals.rows_count, rows, rows)} · ${formatSize(out.length())}")
        }
    }

    fun runImagesToPdf(images: List<Uri>, page: PageChoice, name: String) {
        val out = OutputFiles.newFile(Tool.IMAGE_TO_PDF.folder, name, "pdf")
        val resolver = getApplication<Application>().contentResolver
        launch(Tool.IMAGE_TO_PDF, tr(R.string.job_t_create), listOf(tr(R.string.step_read_photos), tr(R.string.step_place_pages), tr(R.string.step_save_pdf))) { p ->
            ImageToPdfEngine.convert(resolver, images, page, 20f, out, p)
            JobResult(listOf(out), "${trPlural(R.plurals.pages_count, images.size, images.size)} · ${formatSize(out.length())}")
        }
    }

    fun runCompress(file: DocFile, level: CompressLevel) = withPasswords(listOf(file)) {
        val out = OutputFiles.newFile(Tool.COMPRESS.folder, file.stem + "_compressed", "pdf")
        launch(Tool.COMPRESS, tr(R.string.job_t_compress), listOf(tr(R.string.step_read_file), tr(R.string.step_shrink), tr(R.string.step_save_pdf))) { p ->
            val r = CompressEngine.compress(input(file), level, out, p)
            val text = if (r.after < r.before) tr(R.string.compress_reduced, formatSize(r.before), formatSize(r.after))
            else tr(R.string.compress_already, formatSize(r.before))
            JobResult(listOf(out), text, bytesSaved = r.before - r.after)
        }
    }

    fun runMerge(files: List<DocFile>, name: String) = withPasswords(files) {
        val out = OutputFiles.newFile(Tool.MERGE.folder, name, "pdf")
        launch(Tool.MERGE, tr(R.string.job_t_merge), listOf(tr(R.string.step_read_files), tr(R.string.step_join), tr(R.string.step_save_pdf))) { p ->
            PdfTools.merge(files.map { input(it) }, out, p)
            JobResult(listOf(out), "${trPlural(R.plurals.merged_n, files.size, files.size)} · ${formatSize(out.length())}")
        }
    }

    fun runSplit(file: DocFile, ranges: List<IntRange>) = withPasswords(listOf(file)) {
        launch(Tool.SPLIT, tr(R.string.job_t_split), listOf(tr(R.string.step_read_file), tr(R.string.step_separate), tr(R.string.step_save_files))) { p ->
            val made = PdfTools.split(input(file), ranges, { i ->
                val r = ranges[i]
                val suffix = if (r.first == r.last) "page_${r.first}" else "pages_${r.first}-${r.last}"
                OutputFiles.newFile(Tool.SPLIT.folder, "${file.stem}_$suffix", "pdf")
            }, p)
            JobResult(made, trPlural(R.plurals.split_created_n, made.size, made.size, Tool.SPLIT.folder))
        }
    }

    fun runOrganize(file: DocFile, pages: List<PageSpec>) = withPasswords(listOf(file)) {
        val out = OutputFiles.newFile(Tool.ORGANIZE.folder, file.stem + "_organized", "pdf")
        launch(Tool.ORGANIZE, tr(R.string.job_t_pages), listOf(tr(R.string.step_read_file), tr(R.string.step_arrange), tr(R.string.step_save_pdf))) { p ->
            PdfTools.organize(input(file), pages, out, p)
            JobResult(listOf(out), "${trPlural(R.plurals.pages_count, pages.size, pages.size)} · ${formatSize(out.length())}")
        }
    }

    private val workDir: File get() = OutputFiles.cache(getApplication(), "work")

    /** [remove] holds 0-based page indexes. */
    fun runRemovePages(file: DocFile, count: Int, remove: Set<Int>) = withPasswords(listOf(file)) {
        val keep = (0 until count).filter { it !in remove }
        if (keep.isEmpty()) { say(tr(R.string.org_keep_one)); return@withPasswords }
        val out = OutputFiles.newFile(Tool.REMOVE_PAGES.folder, file.stem + "_pages_removed", "pdf")
        launch(Tool.REMOVE_PAGES, tr(R.string.job_t_remove), listOf(tr(R.string.step_read_file), tr(R.string.job_t_remove), tr(R.string.step_save_pdf))) { p ->
            PdfTools.organize(input(file), keep.map { PageSpec(it + 1) }, out, p)
            JobResult(listOf(out), "${trPlural(R.plurals.pages_left, keep.size, remove.size, keep.size)} · ${formatSize(out.length())}")
        }
    }

    /** [pages] holds 0-based page indexes, in page order. */
    fun runExtractPages(file: DocFile, pages: List<Int>, separate: Boolean) = withPasswords(listOf(file)) {
        val sorted = pages.sorted()
        launch(Tool.EXTRACT_PAGES, tr(R.string.job_t_extract), listOf(tr(R.string.step_read_file), tr(R.string.step_copy_pages), tr(R.string.step_save_pdf))) { p ->
            if (separate) {
                val made = PdfTools.split(input(file), sorted.map { (it + 1)..(it + 1) }, { i ->
                    OutputFiles.newFile(Tool.EXTRACT_PAGES.folder, "${file.stem}_page_${sorted[i] + 1}", "pdf")
                }, p)
                JobResult(made, "${trPlural(R.plurals.files_count, made.size, made.size)} · Documents/ExcelToPdf/${Tool.EXTRACT_PAGES.folder}")
            } else {
                val out = OutputFiles.newFile(Tool.EXTRACT_PAGES.folder, file.stem + "_extracted", "pdf")
                PdfTools.organize(input(file), sorted.map { PageSpec(it + 1) }, out, p)
                JobResult(listOf(out), "${trPlural(R.plurals.pages_count, sorted.size, sorted.size)} · ${formatSize(out.length())}")
            }
        }
    }

    /** [rotations] maps 0-based page index to extra degrees (90, 180, 270). */
    fun runRotate(file: DocFile, count: Int, rotations: Map<Int, Int>) = withPasswords(listOf(file)) {
        val out = OutputFiles.newFile(Tool.ROTATE.folder, file.stem + "_rotated", "pdf")
        launch(Tool.ROTATE, tr(R.string.job_t_rotate), listOf(tr(R.string.step_read_file), tr(R.string.step_turn), tr(R.string.step_save_pdf))) { p ->
            PdfTools.organize(input(file), (0 until count).map { PageSpec(it + 1, rotations[it] ?: 0) }, out, p)
            JobResult(listOf(out), "${rotations.count { it.value % 360 != 0 }.let { trPlural(R.plurals.pages_rotated, it, it) }} · ${formatSize(out.length())}")
        }
    }

    fun runPageNumbers(file: DocFile, options: PageNumberOptions) = withPasswords(listOf(file)) {
        val out = OutputFiles.newFile(Tool.PAGE_NUMBERS.folder, file.stem + "_numbered", "pdf")
        launch(Tool.PAGE_NUMBERS, tr(R.string.job_t_numbers), listOf(tr(R.string.step_read_file), tr(R.string.step_number), tr(R.string.step_save_pdf))) { p ->
            PageNumberEngine.apply(input(file), options, out, p)
            JobResult(listOf(out), detail(out))
        }
    }

    fun runCrop(file: DocFile, area: NRect, pageIndex: Int?, removeTrimmed: Boolean) = withPasswords(listOf(file)) {
        val out = OutputFiles.newFile(Tool.CROP.folder, file.stem + "_cropped", "pdf")
        launch(Tool.CROP, tr(R.string.job_t_crop), listOf(tr(R.string.step_read_file), tr(R.string.step_crop), tr(R.string.step_save_pdf))) { p ->
            CropEngine.apply(input(file), area, pageIndex, removeTrimmed, out, p)
            JobResult(listOf(out), (if (pageIndex == null) tr(R.string.crop_done_all) else tr(R.string.crop_done_page, pageIndex + 1)) + " · ${formatSize(out.length())}")
        }
    }

    fun runRepair(file: DocFile) = withPasswords(listOf(file)) {
        val out = OutputFiles.newFile(Tool.REPAIR.folder, file.stem + "_repaired", "pdf")
        launch(Tool.REPAIR, tr(R.string.job_t_repair), listOf(tr(R.string.step_read_file), tr(R.string.step_rebuild), tr(R.string.step_save_pdf))) { p ->
            val r = RepairEngine.repair(input(file), out, p)
            JobResult(listOf(out), "${r.message} · ${trPlural(R.plurals.pages_count, r.pages, r.pages)} · ${formatSize(out.length())}")
        }
    }

    fun runOcr(file: DocFile, script: OcrScript) = withPasswords(listOf(file)) {
        val out = OutputFiles.newFile(Tool.OCR.folder, file.stem + "_searchable", "pdf")
        launch(Tool.OCR, tr(R.string.job_t_ocr), listOf(tr(R.string.step_read_pages), tr(R.string.job_t_ocr), tr(R.string.step_save_pdf))) { p ->
            val r = OcrEngine.apply(input(file), script, out, workDir, p)
            val already = if (r.alreadyText > 0) " · " + trPlural(R.plurals.ocr_already_text, r.alreadyText, r.alreadyText) else ""
            JobResult(listOf(out), trPlural(R.plurals.ocr_made_searchable, r.recognized, r.recognized) + already)
        }
    }

    /** [pages] holds 0-based page indexes; empty means every page. */
    fun runPdfToImages(file: DocFile, pages: List<Int>, dpi: Float, format: ImageFormat) = withPasswords(listOf(file)) {
        val dir = OutputFiles.newFolder(Tool.PDF_TO_JPG.folder, file.stem)
        launch(Tool.PDF_TO_JPG, tr(R.string.job_t_jpg), listOf(tr(R.string.step_read_file), tr(R.string.step_draw_pages), tr(R.string.step_save_images))) { p ->
            val made = PdfToImageEngine.convert(input(file), pages, dpi, format, dir, file.stem, workDir, p)
            JobResult(made, "${trPlural(R.plurals.images_format_n, made.size, made.size, format.label)} · Documents/ExcelToPdf/${Tool.PDF_TO_JPG.folder}/${dir.name}")
        }
    }

    /** [source] is a web link or an HTML file path; [file] is set for files. */
    fun runHtmlToPdf(source: String, file: DocFile?, options: com.excelto.pdf.converter.core.engine.HtmlOptions) {
        val name = file?.stem ?: (android.net.Uri.parse(source).host?.removePrefix("www.")?.substringBefore('.') ?: "webpage")
        val out = OutputFiles.newFile(Tool.HTML_TO_PDF.folder, name, "pdf")
        val ctx = getApplication<Application>()
        launch(Tool.HTML_TO_PDF, tr(R.string.job_t_html), listOf(tr(R.string.step_load_page), tr(R.string.step_layout), tr(R.string.step_save_pdf))) { p ->
            val pages = com.excelto.pdf.converter.core.engine.HtmlToPdfEngine.convert(ctx, source, options, out, p)
            JobResult(listOf(out), "${trPlural(R.plurals.pages_count, pages, pages)} · ${formatSize(out.length())}")
        }
    }

    fun runWordToPdf(file: DocFile) {
        val out = OutputFiles.newFile(Tool.WORD_TO_PDF.folder, file.stem, "pdf")
        launch(Tool.WORD_TO_PDF, tr(R.string.job_t_to_pdf), listOf(tr(R.string.step_read_doc), tr(R.string.step_layout), tr(R.string.step_save_pdf))) { p ->
            val r = com.excelto.pdf.converter.core.engine.WordToPdfEngine.convert(file.path, out, p)
            val notes = if (r.notes.isEmpty()) "" else " · " + r.notes.joinToString(" ")
            JobResult(listOf(out), "${trPlural(R.plurals.pages_count, r.pages, r.pages)} · ${formatSize(out.length())}$notes")
        }
    }

    fun runPowerPointToPdf(file: DocFile, includeHidden: Boolean) {
        val out = OutputFiles.newFile(Tool.POWERPOINT_TO_PDF.folder, file.stem, "pdf")
        launch(Tool.POWERPOINT_TO_PDF, tr(R.string.job_t_to_pdf), listOf(tr(R.string.step_read_slides), tr(R.string.step_draw_slides), tr(R.string.step_save_pdf))) { p ->
            val r = com.excelto.pdf.converter.core.engine.PowerPointToPdfEngine.convert(file.path, includeHidden, out, p)
            val notes = if (r.notes.isEmpty()) "" else " · " + r.notes.joinToString(" ")
            JobResult(listOf(out), "${trPlural(R.plurals.slides_count, r.slides, r.slides)} · ${formatSize(out.length())}$notes")
        }
    }

    fun runPdfToWord(file: DocFile) = withPasswords(listOf(file)) {
        val out = OutputFiles.newFile(Tool.PDF_TO_WORD.folder, file.stem, "docx")
        launch(Tool.PDF_TO_WORD, tr(R.string.job_t_word), listOf(tr(R.string.step_read_text), tr(R.string.step_rebuild_layout), tr(R.string.step_save_doc))) { p ->
            val r = com.excelto.pdf.converter.core.engine.PdfToWordEngine.convert(input(file), out, p)
            val tables = if (r.tables > 0) " · " + trPlural(R.plurals.tables_count, r.tables, r.tables) else ""
            val images = if (r.images > 0) " · " + trPlural(R.plurals.images_count, r.images, r.images) else ""
            JobResult(listOf(out), "${trPlural(R.plurals.pages_count, r.pages, r.pages)} · ${trPlural(R.plurals.paragraphs_count, r.paragraphs, r.paragraphs)}$tables$images")
        }
    }

    fun runPdfToPowerPoint(file: DocFile) = withPasswords(listOf(file)) {
        val out = OutputFiles.newFile(Tool.PDF_TO_POWERPOINT.folder, file.stem, "pptx")
        launch(Tool.PDF_TO_POWERPOINT, tr(R.string.job_t_ppt), listOf(tr(R.string.step_read_pages), tr(R.string.step_make_slides), tr(R.string.step_save_ppt))) { p ->
            val slides = com.excelto.pdf.converter.core.engine.PdfToPptEngine.convert(input(file), out, workDir, p)
            JobResult(listOf(out), "${trPlural(R.plurals.slides_count, slides, slides)} · ${formatSize(out.length())}")
        }
    }

    fun runPdfToPdfA(file: DocFile) = withPasswords(listOf(file)) {
        val out = OutputFiles.newFile(Tool.PDF_TO_PDFA.folder, file.stem + "_PDFA", "pdf")
        launch(Tool.PDF_TO_PDFA, tr(R.string.job_t_pdfa), listOf(tr(R.string.step_read_pages), tr(R.string.step_embed), tr(R.string.step_save_pdfa))) { p ->
            val r = com.excelto.pdf.converter.core.engine.PdfToPdfAEngine.convert(getApplication(), input(file), out, workDir, p)
            val ocr = if (r.ocrPages > 0) " · " + tr(R.string.pdfa_ocr_pages, r.ocrPages) else ""
            JobResult(listOf(out), "PDF/A-2b · ${trPlural(R.plurals.pages_count, r.pages, r.pages)}$ocr · ${formatSize(out.length())}")
        }
    }

    fun runWatermark(file: DocFile, options: WatermarkOptions) = withPasswords(listOf(file)) {
        val out = OutputFiles.newFile(Tool.WATERMARK.folder, file.stem + "_watermarked", "pdf")
        launch(Tool.WATERMARK, tr(R.string.job_t_watermark), listOf(tr(R.string.step_read_file), tr(R.string.step_stamp), tr(R.string.step_save_pdf))) { p ->
            WatermarkEngine.apply(input(file), options, out, p)
            JobResult(listOf(out), detail(out))
        }
    }

    fun runProtect(file: DocFile, password: String, allowPrint: Boolean, allowCopy: Boolean) = withPasswords(listOf(file)) {
        val out = OutputFiles.newFile(Tool.PROTECT.folder, file.stem + "_protected", "pdf")
        launch(Tool.PROTECT, tr(R.string.job_t_protect), listOf(tr(R.string.step_read_file), tr(R.string.step_encrypt), tr(R.string.step_save_pdf))) { p ->
            PdfTools.protect(input(file), password, allowPrint, allowCopy, out, p)
            JobResult(listOf(out), "${tr(R.string.protect_done)} · ${formatSize(out.length())}")
        }
    }

    fun runUnlock(file: DocFile, password: String) {
        passwords[file.path] = password
        val out = OutputFiles.newFile(Tool.UNLOCK.folder, file.stem + "_unlocked", "pdf")
        launch(Tool.UNLOCK, tr(R.string.job_t_unlock), listOf(tr(R.string.step_check_pw), tr(R.string.step_copy_pages), tr(R.string.step_save_pdf))) { p ->
            PdfTools.unlock(input(file), out, p)
            JobResult(listOf(out), "${tr(R.string.unlock_done)} · ${formatSize(out.length())}")
        }
    }

    // ---- Scan and app lock ---------------------------------------------------------

    fun runScan(pages: List<Uri>, ocr: OcrScript?, name: String) {
        val out = OutputFiles.newFile(Tool.SCAN.folder, name, "pdf")
        val resolver = getApplication<Application>().contentResolver
        launch(Tool.SCAN, tr(R.string.job_t_scan), listOf(tr(R.string.step_read_pages), if (ocr != null) tr(R.string.job_t_ocr) else tr(R.string.step_place_pages), tr(R.string.step_save_pdf))) { p ->
            ScanEngine.build(resolver, pages, ocr, out, p)
            JobResult(listOf(out), "${trPlural(R.plurals.pages_count, pages.size, pages.size)}${if (ocr != null) " · " + tr(R.string.scan_searchable) else ""} · ${formatSize(out.length())}")
        }
    }

    var appLock by mutableStateOf(prefs.appLock)
        private set
    /** True while the lock screen is showing. */
    var locked by mutableStateOf(false)

    fun setAppLockEnabled(on: Boolean) {
        prefs.appLock = on
        appLock = on
    }

    // ---- Editing ------------------------------------------------------------------

    val signatureFile: File get() = File(getApplication<Application>().filesDir, "signature.png")

    suspend fun lines(file: DocFile, page: Int): List<TextLine> = withContext(Dispatchers.IO) {
        runCatching { TextEngine.lines(input(file), page) }.getOrDefault(emptyList())
    }

    suspend fun formFields(file: DocFile): List<FormField>? = withContext(Dispatchers.IO) {
        runCatching { FormEngine.read(input(file)) }.getOrNull()
    }

    fun runEdit(tool: Tool, file: DocFile, marks: List<Mark>) = withPasswords(listOf(file)) {
        val suffix = when (tool) { Tool.SIGN -> "_signed"; Tool.REDACT -> "_redacted"; Tool.ANNOTATE -> "_annotated"; else -> "_edited" }
        val out = OutputFiles.newFile(tool.folder, file.stem + suffix, "pdf")
        val work = OutputFiles.cache(getApplication(), "edit")
        val redacts = marks.count { it is Mark.Redaction }
        val steps = if (redacts > 0) listOf(tr(R.string.step_read_file), tr(R.string.step_apply), tr(R.string.step_remove_hidden)) else listOf(tr(R.string.step_read_file), tr(R.string.step_apply), tr(R.string.step_save_pdf))
        if (redacts > 0) oneTimePasses.remove(Tool.REDACT)
        launch(tool, if (redacts > 0) tr(R.string.job_t_redact) else tr(R.string.job_t_edit), steps) { p ->
            EditEngine.apply(input(file), marks, out, work, p)
            val pages = marks.map { it.page }.distinct().size
            JobResult(listOf(out), "${trPlural(R.plurals.changes_count, marks.size, marks.size)} · ${trPlural(R.plurals.pages_count, pages, pages)} · ${formatSize(out.length())}")
        }
    }

    fun runFill(file: DocFile, values: Map<String, String>, flatten: Boolean) = withPasswords(listOf(file)) {
        val out = OutputFiles.newFile(Tool.FILL_FORM.folder, file.stem + "_filled", "pdf")
        launch(Tool.FILL_FORM, tr(R.string.job_t_form), listOf(tr(R.string.step_read_form), tr(R.string.step_write_answers), tr(R.string.step_save_pdf))) { p ->
            FormEngine.fill(input(file), values, flatten, out, p)
            JobResult(listOf(out), "${trPlural(R.plurals.fields_filled, values.size, values.size)} · ${formatSize(out.length())}")
        }
    }

    var comparing by mutableStateOf(false)
        private set
    var comparison by mutableStateOf<List<Change>?>(null)
        private set

    fun compare(original: DocFile, revised: DocFile) = withPasswords(listOf(original, revised)) {
        viewModelScope.launch {
            comparing = true
            comparison = null
            try {
                comparison = withContext(Dispatchers.IO) { CompareEngine.compare(input(original), input(revised), com.excelto.pdf.converter.core.engine.Progress.NONE) }
            } catch (e: Exception) {
                say((e as? com.excelto.pdf.converter.core.engine.UserFacingException)?.localizedMessage ?: tr(R.string.vm_compare_failed))
            } finally {
                comparing = false
            }
        }
    }

    fun clearComparison() { comparison = null }

    fun saveComparison(original: DocFile, revised: DocFile, changes: List<Change>) {
        val out = OutputFiles.newFile(Tool.COMPARE.folder, "Comparison_${revised.stem}", "pdf")
        launch(Tool.COMPARE, tr(R.string.job_t_compare), listOf(tr(R.string.step_list_changes), tr(R.string.step_format_report), tr(R.string.step_save_pdf))) { p ->
            p.report(40)
            CompareEngine.report(original.name, revised.name, changes, out)
            JobResult(listOf(out), "${trPlural(R.plurals.changes_count, changes.size, changes.size)} · ${formatSize(out.length())}")
        }
    }

    /** Called when a job failed because the password was wrong or missing. */
    fun forgetPassword(path: String) { passwords.remove(path) }
}
