package com.excelto.pdf.converter.core.office

import com.excelto.pdf.converter.R
import com.excelto.pdf.converter.core.engine.UserFacingException
import com.excelto.pdf.converter.core.office.DocxReader.Companion.child
import com.excelto.pdf.converter.core.office.DocxReader.Companion.children
import com.excelto.pdf.converter.core.office.DocxReader.Companion.descendants
import com.excelto.pdf.converter.core.office.DocxReader.Companion.elements
import org.w3c.dom.Element
import java.io.File
import java.util.zip.ZipFile
import javax.xml.parsers.DocumentBuilderFactory
import kotlin.math.roundToInt

/** Slides as positioned shapes, ready to draw. Positions and sizes are in points. */
object Deck {
    data class Run(
        val text: String,
        val sizePt: Float = 18f,
        val bold: Boolean = false,
        val italic: Boolean = false,
        val underline: Boolean = false,
        val strike: Boolean = false,
        val color: Int = 0xFF000000.toInt(),
        val font: String? = null,
        val baseline: Int = 0,
    )

    enum class Align { LEFT, CENTER, RIGHT, JUSTIFY }
    enum class Anchor { TOP, MIDDLE, BOTTOM }

    data class Para(
        val runs: List<Run>,
        val align: Align = Align.LEFT,
        val marginLeft: Float = 0f,
        val indent: Float = 0f,
        val bullet: String? = null,
        val bulletColor: Int? = null,
        val spaceBefore: Float = 0f,
        val spaceAfter: Float = 0f,
        /** Multiple of single spacing, or points when [lineExact] is set. */
        val lineSpacing: Float = 1f,
        val lineExact: Float? = null,
        val rtl: Boolean = false,
        /** Size used for an empty paragraph's height. */
        val endSize: Float = 18f,
    )

    data class Text(
        val paras: List<Para>,
        val left: Float = 7.2f,
        val top: Float = 3.6f,
        val right: Float = 7.2f,
        val bottom: Float = 3.6f,
        val anchor: Anchor = Anchor.TOP,
        val fontScale: Float = 1f,
        val lineReduction: Float = 0f,
        val wrap: Boolean = true,
        val vertical: Boolean = false,
        /** Shrink text that doesn't fit, like PowerPoint's "Shrink text on overflow". */
        val shrinkOnOverflow: Boolean = false,
    )

    class Picture(val bytes: ByteArray?, val crop: FloatArray? = null, val note: String? = null)

    class Box(val x: Float, val y: Float, val w: Float, val h: Float, val rotation: Float = 0f, val flipH: Boolean = false, val flipV: Boolean = false)

    sealed interface Element { val box: Box }

    class Shape(
        override val box: Box,
        val geometry: String = "rect",
        val fill: Int? = null,
        val fillPicture: Picture? = null,
        val line: Int? = null,
        val lineWidth: Float = 0.75f,
        val dashed: Boolean = false,
        val text: Text? = null,
        val adjust: Float? = null,
    ) : Element

    class Pic(override val box: Box, val picture: Picture, val line: Int? = null, val lineWidth: Float = 0f, val geometry: String = "rect") : Element

    class Cell(val text: Text, val fill: Int?, val span: Int = 1, val rowSpan: Int = 1, val merged: Boolean = false)
    class Row(val height: Float, val cells: List<Cell>)
    class Table(override val box: Box, val columns: List<Float>, val rows: List<Row>, val borders: Int?) : Element

    class Slide(val background: Int?, val backgroundPicture: Picture?, val elements: List<Element>, val hidden: Boolean, val number: Int)

    class Presentation(val widthPt: Float, val heightPt: Float, val slides: List<Slide>, val notes: List<String>)
}

/**
 * Reads .pptx files with java.util.zip and the platform's DOM parser. Shapes inherit
 * position and text style from their layout and slide master; colors resolve through
 * the theme and the master's color map. Pure JVM, unit tested.
 */
class PptxReader {

    private lateinit var zip: ZipFile
    private val docs = HashMap<String, Element?>()
    private val skipped = linkedSetOf<String>()

    /** A slide, layout or master part with its relationships. */
    private inner class Part(val path: String) {
        val root: Element? = load(path)
        val rels: Map<String, String> by lazy { readRels(path) }
        val tree: Element? get() = child(child(root, "cSld"), "spTree")
        fun target(type: String) = relTypes(path)[type]
    }

    private class Theme(val colors: Map<String, Int>, val majorFont: String?, val minorFont: String?, val fills: List<Element>, val bgFills: List<Element>, val lines: List<Element>)

    private class Context(val slide: Part, val layout: Part?, val master: Part?, val theme: Theme, val clrMap: Map<String, String>)

    fun read(file: File, includeHidden: Boolean = false, check: () -> Unit = {}): Deck.Presentation {
        if (DocxReader.isOle(file)) throw UserFacingException(R.string.err_presentation_password_protected_old, "This presentation is password protected or in the old .ppt format. Save it as .pptx in PowerPoint and try again.")
        zip = try { ZipFile(file) } catch (e: Exception) {
            throw UserFacingException(R.string.err_presentation_couldnt_opened_may, "This presentation couldn't be opened. It may be damaged or not a real .pptx file.", e)
        }
        zip.use {
            val presPath = relTypes("").entries.firstOrNull { it.key.endsWith("/officeDocument") }?.value ?: "ppt/presentation.xml"
            val pres = load(presPath) ?: throw UserFacingException(R.string.err_presentation_no_slides, "This presentation has no slides.")
            val size = child(pres, "sldSz")
            val w = (size?.getAttribute("cx")?.toFloatOrNull() ?: 9144000f) / 12700f
            val h = (size?.getAttribute("cy")?.toFloatOrNull() ?: 6858000f) / 12700f
            val presRels = readRels(presPath)
            val defaultText = child(pres, "defaultTextStyle")
            val ids = children(child(pres, "sldIdLst"), "sldId").mapNotNull { presRels[it.getAttributeNS(R_NS, "id")] }
            if (ids.isEmpty()) throw UserFacingException(R.string.err_presentation_no_slides, "This presentation has no slides.")
            val slides = mutableListOf<Deck.Slide>()
            ids.forEachIndexed { index, path ->
                check()
                val slide = Part(path)
                val root = slide.root ?: return@forEachIndexed
                val hidden = root.getAttribute("show") == "0"
                if (hidden && !includeHidden) return@forEachIndexed
                val layout = slide.target(REL_LAYOUT)?.let { Part(it) }
                val master = layout?.target(REL_MASTER)?.let { Part(it) }
                val theme = master?.target(REL_THEME)?.let { readTheme(it) } ?: Theme(DEFAULT_COLORS, null, null, emptyList(), emptyList(), emptyList())
                val clrMap = (child(slide.root, "clrMapOvr")?.let { child(it, "overrideClrMapping") }
                    ?: child(layout?.root, "clrMapOvr")?.let { child(it, "overrideClrMapping") }
                    ?: child(master?.root, "clrMap"))?.let { m ->
                    (0 until m.attributes.length).associate { m.attributes.item(it).localName to m.attributes.item(it).nodeValue }
                } ?: DEFAULT_MAP
                val ctx = Context(slide, layout, master, theme, clrMap)
                this.defaultText = defaultText
                slides += readSlide(ctx, hidden, index + 1)
            }
            return Deck.Presentation(w, h, slides, skipped.map { "Not drawn: $it." })
        }
    }

    private var defaultText: Element? = null

    // ---- Package -----------------------------------------------------------------------

    private fun load(path: String): Element? = docs.getOrPut(path) {
        val entry = zip.getEntry(path) ?: return@getOrPut null
        runCatching {
            val f = DocumentBuilderFactory.newInstance().apply {
                isNamespaceAware = true
                runCatching { setFeature("http://apache.org/xml/features/disallow-doctype-decl", true) }
                isExpandEntityReferences = false
            }
            zip.getInputStream(entry).use { f.newDocumentBuilder().parse(it).documentElement }
        }.getOrNull()
    }

    private fun relsPath(path: String): String {
        if (path.isEmpty()) return "_rels/.rels"
        val dir = path.substringBeforeLast('/', "")
        return if (dir.isEmpty()) "_rels/${path}.rels" else "$dir/_rels/${path.substringAfterLast('/')}.rels"
    }

    private fun relEntries(path: String): List<Triple<String, String, String>> {
        val root = load(relsPath(path)) ?: return emptyList()
        val folder = path.substringBeforeLast('/', "")
        return children(root, "Relationship").filter { it.getAttribute("TargetMode") != "External" }.map {
            Triple(it.getAttribute("Id"), it.getAttribute("Type"), resolve(folder, it.getAttribute("Target")))
        }
    }

    private fun readRels(path: String) = relEntries(path).associate { it.first to it.third }
    private fun relTypes(path: String) = relEntries(path).associate { it.second to it.third }

    private fun resolve(folder: String, target: String): String {
        if (target.startsWith("/")) return target.removePrefix("/")
        val parts = (if (folder.isEmpty()) emptyList() else folder.split('/')).toMutableList()
        for (seg in target.split('/')) when (seg) {
            ".." -> if (parts.isNotEmpty()) parts.removeAt(parts.lastIndex)
            ".", "" -> Unit
            else -> parts += seg
        }
        return parts.joinToString("/")
    }

    private fun bytes(path: String): ByteArray? {
        val e = zip.getEntry(path) ?: return null
        if (e.size > 40L * 1024 * 1024) return null
        return zip.getInputStream(e).use { it.readBytes() }
    }

    // ---- Theme and colors -----------------------------------------------------------------

    private fun readTheme(path: String): Theme {
        val root = load(path) ?: return Theme(DEFAULT_COLORS, null, null, emptyList(), emptyList(), emptyList())
        val elementsRoot = child(root, "themeElements")
        val scheme = child(elementsRoot, "clrScheme")
        val colors = HashMap(DEFAULT_COLORS)
        for (c in elements(scheme)) {
            val v = elements(c).firstOrNull() ?: continue
            when (v.localName) {
                "srgbClr" -> DocxReader.hex(v.getAttribute("val"))?.let { colors[c.localName] = it }
                "sysClr" -> DocxReader.hex(v.getAttribute("lastClr"))?.let { colors[c.localName] = it }
            }
        }
        val fonts = child(elementsRoot, "fontScheme")
        val fmt = child(elementsRoot, "fmtScheme")
        return Theme(
            colors,
            child(child(fonts, "majorFont"), "latin")?.getAttribute("typeface"),
            child(child(fonts, "minorFont"), "latin")?.getAttribute("typeface"),
            elements(child(fmt, "fillStyleLst")),
            elements(child(fmt, "bgFillStyleLst")),
            elements(child(fmt, "lnStyleLst")),
        )
    }

    /** A color element (srgbClr, schemeClr…) with its modifiers. [phClr] fills in theme style colors. */
    private fun color(e: Element?, ctx: Context, phClr: Int? = null): Int? {
        if (e == null) return null
        val base: Int = when (e.localName) {
            "srgbClr" -> DocxReader.hex(e.getAttribute("val"))
            "sysClr" -> DocxReader.hex(e.getAttribute("lastClr")) ?: if (e.getAttribute("val") == "window") 0xFFFFFFFF.toInt() else 0xFF000000.toInt()
            "schemeClr" -> {
                val name = e.getAttribute("val")
                if (name == "phClr") phClr else ctx.theme.colors[ctx.clrMap[name] ?: name] ?: ctx.theme.colors[name]
            }
            "prstClr" -> PRESET[e.getAttribute("val")]
            "scrgbClr" -> {
                fun pc(a: String) = ((e.getAttribute(a).toFloatOrNull() ?: 0f) / 100000f * 255f).roundToInt().coerceIn(0, 255)
                (0xFF shl 24) or (pc("r") shl 16) or (pc("g") shl 8) or pc("b")
            }
            "hslClr" -> null
            else -> return elements(e).firstNotNullOfOrNull { color(it, ctx, phClr) }
        } ?: return null
        return Colors.modify(base, elements(e).map { it.localName to ((it.getAttribute("val").toFloatOrNull() ?: 0f) / 100000f) })
    }

    private fun solid(parent: Element?, ctx: Context): Int? = child(parent, "solidFill")?.let { color(elements(it).firstOrNull(), ctx) }

    /** The fill of shape properties, or null to fall through. Returns [NO_FILL] for noFill. */
    private fun fill(spPr: Element?, ctx: Context, part: Part): Pair<Int?, Deck.Picture?>? {
        for (f in elements(spPr)) when (f.localName) {
            "noFill" -> return NO_FILL to null
            "solidFill" -> return color(elements(f).firstOrNull(), ctx) to null
            "gradFill" -> return gradient(f, ctx) to null
            "blipFill" -> return null to picture(f, part)
            "pattFill" -> return color(elements(child(f, "fgClr")).firstOrNull(), ctx) to null
            "grpFill" -> return null
        }
        return null
    }

    /** Gradients are drawn with their middle color, which reads well for most slide designs. */
    private fun gradient(g: Element, ctx: Context, phClr: Int? = null): Int? {
        val stops = children(child(g, "gsLst"), "gs").mapNotNull { color(elements(it).firstOrNull(), ctx, phClr) }
        if (stops.isEmpty()) return null
        return Colors.average(stops)
    }

    private fun picture(blipFill: Element, part: Part): Deck.Picture? {
        val blip = child(blipFill, "blip") ?: return null
        val id = blip.getAttributeNS(R_NS, "embed").ifEmpty { return null }
        val path = part.rels[id] ?: return null
        val ext = path.substringAfterLast('.').lowercase()
        val crop = child(blipFill, "srcRect")?.let { r ->
            floatArrayOf(pct(r, "l"), pct(r, "t"), pct(r, "r"), pct(r, "b"))
        }?.takeIf { c -> c.any { it != 0f } }
        if (ext in setOf("emf", "wmf", "tif", "tiff", "svg", "wdp")) {
            // An SVG usually comes with a PNG fallback in the main blip.
            return Deck.Picture(null, crop, "Picture (${ext.uppercase()})")
        }
        return Deck.Picture(bytes(path), crop)
    }

    private fun pct(e: Element, name: String) = (e.getAttribute(name).toFloatOrNull() ?: 0f) / 100000f

    // ---- Slides -------------------------------------------------------------------------

    private fun readSlide(ctx: Context, hidden: Boolean, number: Int): Deck.Slide {
        // Background: the first of slide, layout, master that defines one.
        var bg: Int? = 0xFFFFFFFF.toInt()
        var bgPic: Deck.Picture? = null
        for (part in listOfNotNull(ctx.slide, ctx.layout, ctx.master)) {
            val b = child(child(part.root, "cSld"), "bg") ?: continue
            val pr = child(b, "bgPr")
            if (pr != null) {
                val f = fill(pr, ctx, part)
                if (f != null) { bg = f.first?.takeIf { it != NO_FILL } ?: 0xFFFFFFFF.toInt(); bgPic = f.second; break }
            }
            val ref = child(b, "bgRef")
            if (ref != null) {
                val c = color(elements(ref).firstOrNull(), ctx)
                val idx = ref.getAttribute("idx").toIntOrNull() ?: 0
                val style = if (idx >= 1001) ctx.theme.bgFills.getOrNull(idx - 1001) else ctx.theme.fills.getOrNull(idx - 1)
                bg = (styleFill(style, ctx, c) ?: c)?.takeIf { it != NO_FILL }
                if (style?.localName == "blipFill") bgPic = picture(style, ctx.master ?: part)
                break
            }
        }
        val elements = mutableListOf<Deck.Element>()
        // Master and layout shapes that aren't placeholders (logos, lines, footers art) show behind.
        val showMaster = ctx.slide.root?.getAttribute("showMasterSp") != "0" && ctx.layout?.root?.getAttribute("showMasterSp") != "0"
        if (showMaster) ctx.master?.let { readTree(it.tree, it, ctx, Transform.NONE, elements, decorOnly = true) }
        if (ctx.slide.root?.getAttribute("showMasterSp") != "0") ctx.layout?.let { readTree(it.tree, it, ctx, Transform.NONE, elements, decorOnly = true) }
        readTree(ctx.slide.tree, ctx.slide, ctx, Transform.NONE, elements, decorOnly = false)
        return Deck.Slide(bg, bgPic, elements, hidden, number)
    }

    private fun styleFill(style: Element?, ctx: Context, phClr: Int?): Int? = when (style?.localName) {
        "solidFill" -> color(elements(style).firstOrNull(), ctx, phClr)
        "gradFill" -> gradient(style, ctx, phClr)
        "noFill" -> NO_FILL
        else -> null
    }

    /** Maps a group's child coordinates onto the slide. */
    private class Transform(val ox: Float, val oy: Float, val sx: Float, val sy: Float) {
        fun box(x: Float, y: Float, w: Float, h: Float, rot: Float, fh: Boolean, fv: Boolean) =
            Deck.Box(ox + x * sx, oy + y * sy, w * sx, h * sy, rot, fh, fv)
        companion object { val NONE = Transform(0f, 0f, 1f, 1f) }
    }

    private fun readTree(tree: Element?, part: Part, ctx: Context, t: Transform, out: MutableList<Deck.Element>, decorOnly: Boolean) {
        for (e in elements(tree)) {
            when (e.localName) {
                "sp", "cxnSp" -> {
                    val ph = placeholder(e)
                    if (decorOnly && ph != null) continue
                    readShape(e, part, ctx, t, ph)?.let { out += it }
                }
                "pic" -> {
                    if (decorOnly && placeholder(e) != null) continue
                    readPic(e, part, ctx, t)?.let { out += it }
                }
                "grpSp" -> {
                    val x = child(child(e, "grpSpPr"), "xfrm")
                    val off = xy(child(x, "off"), "x", "y")
                    val ext = xy(child(x, "ext"), "cx", "cy")
                    val chOff = xy(child(x, "chOff"), "x", "y")
                    val chExt = xy(child(x, "chExt"), "cx", "cy")
                    val sx = if (chExt.first > 0f) ext.first / chExt.first else 1f
                    val sy = if (chExt.second > 0f) ext.second / chExt.second else 1f
                    val nt = Transform(t.ox + (off.first - chOff.first * sx) * t.sx, t.oy + (off.second - chOff.second * sy) * t.sy, t.sx * sx, t.sy * sy)
                    readTree(e, part, ctx, nt, out, decorOnly)
                }
                "graphicFrame" -> {
                    if (decorOnly) continue
                    readFrame(e, part, ctx, t)?.let { out += it }
                }
                "AlternateContent" -> {
                    val chosen = child(e, "Choice")?.takeIf { c -> descendants(c, "sp").isNotEmpty() || descendants(c, "pic").isNotEmpty() } ?: child(e, "Fallback")
                    readTree(chosen, part, ctx, t, out, decorOnly)
                }
                "contentPart" -> skipped += "ink drawings"
            }
        }
    }

    private class Ph(val type: String, val idx: String?)

    private fun placeholder(e: Element): Ph? {
        val nv = elements(e).firstOrNull { it.localName.startsWith("nv") }
        val ph = child(child(nv, "nvPr"), "ph") ?: return null
        return Ph(ph.getAttribute("type").ifEmpty { "body" }.let { if (it == "obj") "body" else it }, ph.getAttribute("idx").ifEmpty { null })
    }

    /** The layout and master shapes a placeholder inherits from, most specific first. */
    private fun inherited(ph: Ph?, ctx: Context): List<Pair<Element, Part>> {
        if (ph == null) return emptyList()
        val out = mutableListOf<Pair<Element, Part>>()
        fun find(part: Part?, byIdx: Boolean): Element? {
            val shapes = part?.tree?.let { tree -> elements(tree).filter { it.localName == "sp" || it.localName == "pic" } } ?: return null
            if (byIdx && ph.idx != null) shapes.firstOrNull { placeholder(it)?.idx == ph.idx }?.let { return it }
            val type = when (ph.type) { "ctrTitle" -> listOf("ctrTitle", "title"); "subTitle" -> listOf("subTitle", "body"); else -> listOf(ph.type) }
            for (ty in type) shapes.firstOrNull { placeholder(it)?.type == ty }?.let { return it }
            return null
        }
        find(ctx.layout, true)?.let { out += it to ctx.layout!! }
        find(ctx.master, false)?.let { out += it to ctx.master!! }
        return out
    }

    private fun xy(e: Element?, a: String, b: String): Pair<Float, Float> =
        ((e?.getAttribute(a)?.toFloatOrNull() ?: 0f) / 12700f) to ((e?.getAttribute(b)?.toFloatOrNull() ?: 0f) / 12700f)

    private fun box(spPr: Element?, chain: List<Pair<Element, Part>>, t: Transform): Deck.Box? {
        val xfrm = child(spPr, "xfrm") ?: chain.firstNotNullOfOrNull { (el, _) -> child(child(el, "spPr"), "xfrm") } ?: return null
        val (x, y) = xy(child(xfrm, "off"), "x", "y")
        val (w, h) = xy(child(xfrm, "ext"), "cx", "cy")
        val rot = (xfrm.getAttribute("rot").toFloatOrNull() ?: 0f) / 60000f
        return t.box(x, y, w, h, rot, xfrm.getAttribute("flipH") == "1", xfrm.getAttribute("flipV") == "1")
    }

    private fun readShape(e: Element, part: Part, ctx: Context, t: Transform, ph: Ph?): Deck.Shape? {
        val chain = inherited(ph, ctx)
        val spPr = child(e, "spPr")
        val box = box(spPr, chain, t) ?: return null
        val geom = child(spPr, "prstGeom")?.getAttribute("prst") ?: if (child(spPr, "custGeom") != null) "rect" else
            chain.firstNotNullOfOrNull { (el, _) -> child(child(el, "spPr"), "prstGeom")?.getAttribute("prst") } ?: "rect"
        val adjust = child(child(child(spPr, "prstGeom"), "avLst"), "gd")?.getAttribute("fmla")?.removePrefix("val ")?.toFloatOrNull()?.div(100000f)
        val style = child(e, "style")

        // Fill: direct, then the shape style's fillRef, then the placeholder's chain.
        var fill: Int? = null
        var fillPic: Deck.Picture? = null
        val direct = fill(spPr, ctx, part) ?: chain.firstNotNullOfOrNull { (el, p) -> fill(child(el, "spPr"), ctx, p) }
        if (direct != null) {
            fill = direct.first; fillPic = direct.second
        } else if (style != null) {
            val ref = child(style, "fillRef")
            val idx = ref?.getAttribute("idx")?.toIntOrNull() ?: 0
            if (idx > 0) {
                val c = color(elements(ref!!).firstOrNull(), ctx)
                fill = styleFill(ctx.theme.fills.getOrNull(idx - 1), ctx, c) ?: c
            }
        }
        if (fill == NO_FILL) fill = null

        // Outline.
        var line: Int? = null
        var lineWidth = 0.75f
        var dashed = false
        val ln = child(spPr, "ln") ?: chain.firstNotNullOfOrNull { (el, _) -> child(child(el, "spPr"), "ln") }
        if (ln != null) {
            lineWidth = (ln.getAttribute("w").toFloatOrNull()?.div(12700f)) ?: 0.75f
            line = if (child(ln, "noFill") != null) null else solid(ln, ctx) ?: child(ln, "gradFill")?.let { gradient(it, ctx) }
            dashed = child(ln, "prstDash")?.getAttribute("val").let { it != null && it != "solid" }
            if (line == null && child(ln, "noFill") == null && style != null) line = lineFromStyle(style, ctx)
        } else if (style != null) {
            line = lineFromStyle(style, ctx)
            val idx = child(style, "lnRef")?.getAttribute("idx")?.toIntOrNull() ?: 0
            ctx.theme.lines.getOrNull(idx - 1)?.getAttribute("w")?.toFloatOrNull()?.let { lineWidth = it / 12700f }
        }
        if (e.localName == "cxnSp" && line == null) line = 0xFF000000.toInt()

        val styleFontColor = child(style, "fontRef")?.let { color(elements(it).firstOrNull(), ctx) }
        val text = child(e, "txBody")?.let { readText(it, ph, chain, ctx, styleFontColor) }
        if (fill == null && fillPic == null && line == null && (text == null || text.paras.all { p -> p.runs.all { it.text.isBlank() } })) return null
        return Deck.Shape(box, if (e.localName == "cxnSp") "line" else geom, fill, fillPic, line, lineWidth, dashed, text, adjust)
    }

    private fun lineFromStyle(style: Element, ctx: Context): Int? {
        val ref = child(style, "lnRef") ?: return null
        val idx = ref.getAttribute("idx").toIntOrNull() ?: 0
        if (idx == 0) return null
        return color(elements(ref).firstOrNull(), ctx)
    }

    private fun readPic(e: Element, part: Part, ctx: Context, t: Transform): Deck.Pic? {
        val chain = inherited(placeholder(e), ctx)
        val spPr = child(e, "spPr")
        val box = box(spPr, chain, t) ?: return null
        val blipFill = child(e, "blipFill") ?: return null
        val pic = picture(blipFill, part) ?: return null
        if (descendants(e, "videoFile").isNotEmpty() || descendants(e, "audioFile").isNotEmpty()) skipped += "video and audio"
        val ln = child(spPr, "ln")
        val line = ln?.let { if (child(it, "noFill") != null) null else solid(it, ctx) }
        val geom = child(spPr, "prstGeom")?.getAttribute("prst") ?: "rect"
        return Deck.Pic(box, pic, line, (ln?.getAttribute("w")?.toFloatOrNull() ?: 9525f) / 12700f, geom)
    }

    private fun readFrame(e: Element, part: Part, ctx: Context, t: Transform): Deck.Element? {
        val x = child(e, "xfrm")
        val (ox, oy) = xy(child(x, "off"), "x", "y")
        val (w, h) = xy(child(x, "ext"), "cx", "cy")
        val box = t.box(ox, oy, w, h, 0f, false, false)
        val data = child(child(e, "graphic"), "graphicData") ?: return null
        val uri = data.getAttribute("uri")
        child(data, "tbl")?.let { return readTable(it, box, ctx) }
        val what = when {
            uri.endsWith("/chart") || uri.contains("chart") -> "Chart"
            uri.endsWith("/diagram") -> "SmartArt"
            else -> "Object"
        }
        skipped += when (what) { "Chart" -> "charts"; "SmartArt" -> "SmartArt"; else -> "embedded objects" }
        // An embedded object usually carries a preview picture.
        descendants(e, "blipFill").firstOrNull()?.let { bf -> picture(bf, part)?.let { return Deck.Pic(box, it) } }
        return Deck.Pic(box, Deck.Picture(null, null, what))
    }

    private fun readTable(tbl: Element, box: Deck.Box, ctx: Context): Deck.Table {
        val tblPr = child(tbl, "tblPr")
        val styled = child(tblPr, "tableStyleId") != null || tblPr?.getAttribute("firstRow") == "1"
        val firstRow = tblPr?.getAttribute("firstRow") == "1"
        val banded = tblPr?.getAttribute("bandRow") == "1"
        val accent = ctx.theme.colors["accent1"] ?: 0xFF4472C4.toInt()
        val cols = children(child(tbl, "tblGrid"), "gridCol").map { (it.getAttribute("w").toFloatOrNull() ?: 0f) / 12700f }
        val rows = children(tbl, "tr").mapIndexed { ri, tr ->
            val header = styled && firstRow && ri == 0
            val bodyIndex = if (firstRow) ri - 1 else ri
            val defaultFill = when {
                !styled -> null
                header -> accent
                banded && bodyIndex % 2 == 0 -> Colors.modify(accent, listOf("tint" to 0.4f))
                else -> Colors.modify(accent, listOf("tint" to 0.2f))
            }
            Deck.Row(
                (tr.getAttribute("h").toFloatOrNull() ?: 0f) / 12700f,
                children(tr, "tc").map { tc ->
                    val tcPr = child(tc, "tcPr")
                    val f = tcPr?.let { fill(it, ctx, Part("")) }
                    val cellFill = if (f != null) f.first?.takeIf { it != NO_FILL } else defaultFill
                    val textColor = if (header && f == null) 0xFFFFFFFF.toInt() else null
                    val body = child(tc, "txBody")
                    val text = body?.let { readText(it, null, emptyList(), ctx, textColor, tableHeader = header) } ?: Deck.Text(emptyList())
                    fun inset(name: String, def: Float) = tcPr?.getAttribute(name)?.toFloatOrNull()?.div(12700f) ?: def
                    Deck.Cell(
                        text.copy(left = inset("marL", 7.2f), right = inset("marR", 7.2f), top = inset("marT", 3.6f), bottom = inset("marB", 3.6f),
                            anchor = when (tcPr?.getAttribute("anchor")) { "ctr" -> Deck.Anchor.MIDDLE; "b" -> Deck.Anchor.BOTTOM; else -> Deck.Anchor.TOP }),
                        cellFill,
                        span = tc.getAttribute("gridSpan").toIntOrNull() ?: 1,
                        rowSpan = tc.getAttribute("rowSpan").toIntOrNull() ?: 1,
                        merged = tc.getAttribute("hMerge") == "1" || tc.getAttribute("vMerge") == "1",
                    )
                },
            )
        }
        return Deck.Table(box, cols, rows, if (styled) 0xFFFFFFFF.toInt() else 0xFF000000.toInt())
    }

    // ---- Text ---------------------------------------------------------------------------

    private fun readText(body: Element, ph: Ph?, chain: List<Pair<Element, Part>>, ctx: Context, styleColor: Int?, tableHeader: Boolean = false): Deck.Text {
        val bodyPrs = listOfNotNull(child(body, "bodyPr")) + chain.mapNotNull { (el, _) -> child(child(el, "txBody"), "bodyPr") }
        fun bp(name: String) = bodyPrs.firstNotNullOfOrNull { it.getAttribute(name).ifEmpty { null } }
        val autofit = bodyPrs.firstNotNullOfOrNull { b -> child(b, "normAutofit") ?: child(b, "noAutofit") ?: child(b, "spAutoFit") }
        val fontScale = autofit?.takeIf { it.localName == "normAutofit" }?.getAttribute("fontScale")?.toFloatOrNull()?.div(100000f) ?: 1f
        val lnRed = autofit?.takeIf { it.localName == "normAutofit" }?.getAttribute("lnSpcReduction")?.toFloatOrNull()?.div(100000f) ?: 0f

        // List style chain, most general first: presentation defaults, master text styles,
        // master placeholder, layout placeholder, the shape's own list style.
        val masterStyles = child(ctx.master?.root, "txStyles")
        val kind = when (ph?.type) {
            "title", "ctrTitle" -> "titleStyle"
            null -> "otherStyle"
            "dt", "ftr", "sldNum" -> "otherStyle"
            else -> "bodyStyle"
        }
        val lstStyles = buildList {
            defaultText?.let { add(it) }
            child(masterStyles, kind)?.let { add(it) }
            chain.asReversed().forEach { (el, _) -> child(child(el, "txBody"), "lstStyle")?.let { add(it) } }
            child(body, "lstStyle")?.let { add(it) }
        }
        val font = if (kind == "titleStyle") ctx.theme.majorFont else ctx.theme.minorFont

        val paras = children(body, "p").map { p ->
            val pPr = child(p, "pPr")
            val level = (pPr?.getAttribute("lvl")?.toIntOrNull() ?: 0).coerceIn(0, 8)
            val levelProps = lstStyles.mapNotNull { child(it, "lvl${level + 1}pPr") } + listOfNotNull(pPr)
            fun attr(name: String) = levelProps.lastOrNull { it.hasAttribute(name) }?.getAttribute(name)
            val defRPr = levelProps.mapNotNull { child(it, "defRPr") }
            val align = when (attr("algn")) { "ctr" -> Deck.Align.CENTER; "r" -> Deck.Align.RIGHT; "just", "dist" -> Deck.Align.JUSTIFY; else -> Deck.Align.LEFT }
            val rtl = attr("rtl") == "1"
            val marL = (attr("marL")?.toFloatOrNull() ?: 0f) / 12700f
            val indent = (attr("indent")?.toFloatOrNull() ?: 0f) / 12700f

            fun spacing(name: String): Pair<Float?, Float?> {
                val e = levelProps.lastOrNull { child(it, name) != null }?.let { child(it, name) } ?: return null to null
                val pts = child(e, "spcPts")?.getAttribute("val")?.toFloatOrNull()?.div(100f)
                val pct = child(e, "spcPct")?.getAttribute("val")?.toFloatOrNull()?.div(100000f)
                return pts to pct
            }

            val runs = mutableListOf<Deck.Run>()
            fun run(rPr: Element?, text: String) {
                val props = defRPr + listOfNotNull(rPr)
                fun ra(name: String) = props.lastOrNull { it.hasAttribute(name) }?.getAttribute(name)
                val size = ((ra("sz")?.toFloatOrNull() ?: 1800f) / 100f) * fontScale
                val colorEl = props.lastOrNull { child(it, "solidFill") != null }?.let { child(it, "solidFill") }
                val c = colorEl?.let { color(elements(it).firstOrNull(), ctx) } ?: styleColor ?: ctx.theme.colors[ctx.clrMap["tx1"] ?: "dk1"] ?: 0xFF000000.toInt()
                val typeface = props.lastOrNull { child(it, "latin") != null }?.let { child(it, "latin")?.getAttribute("typeface") }
                    ?.let { if (it.startsWith("+mj")) ctx.theme.majorFont else if (it.startsWith("+mn")) ctx.theme.minorFont else it } ?: font
                val cap = ra("cap")
                runs += Deck.Run(
                    text = if (cap == "all") text.uppercase() else text,
                    sizePt = size.coerceIn(1f, 400f),
                    bold = ra("b") == "1" || ra("b") == "true" || tableHeader && ra("b") == null,
                    italic = ra("i") == "1" || ra("i") == "true",
                    underline = ra("u").let { it != null && it != "none" },
                    strike = ra("strike").let { it != null && it != "noStrike" },
                    color = c,
                    font = typeface,
                    baseline = ra("baseline")?.toIntOrNull()?.let { if (it > 0) 1 else if (it < 0) -1 else 0 } ?: 0,
                )
            }
            for (r in elements(p)) when (r.localName) {
                "r" -> run(child(r, "rPr"), child(r, "t")?.textContent ?: "")
                "br" -> run(child(r, "rPr"), "\n")
                "fld" -> run(child(r, "rPr"), child(r, "t")?.textContent ?: "")
            }
            val endSize = ((child(p, "endParaRPr")?.getAttribute("sz")?.toFloatOrNull()
                ?: defRPr.lastOrNull { it.hasAttribute("sz") }?.getAttribute("sz")?.toFloatOrNull() ?: 1800f) / 100f) * fontScale

            // Bullets.
            val buProps = levelProps.lastOrNull { el -> elements(el).any { it.localName in BULLET_KINDS } }
            val bu = buProps?.let { el -> elements(el).last { it.localName in BULLET_KINDS } }
            val bullet = when (bu?.localName) {
                "buChar" -> bu.getAttribute("char").let { ch -> if (ch.any { it.code in 0xF000..0xF0FF } || ch == "§" || ch == "Ø" || ch == "ü") "•" else ch }
                "buAutoNum" -> autoNumber(bu, p)
                else -> null
            }?.takeIf { runs.any { r -> r.text.isNotBlank() } }
            val bulletColor = levelProps.lastOrNull { child(it, "buClr") != null }?.let { color(elements(child(it, "buClr")!!).firstOrNull(), ctx) }

            val (lnPts, lnPct) = spacing("lnSpc")
            val (bPts, bPct) = spacing("spcBef")
            val (aPts, aPct) = spacing("spcAft")
            val refSize = runs.maxOfOrNull { it.sizePt } ?: endSize
            Deck.Para(
                runs = runs,
                align = align,
                marginLeft = marL,
                indent = indent,
                bullet = bullet,
                bulletColor = bulletColor,
                spaceBefore = bPts ?: (bPct?.let { it * refSize * 1.2f } ?: 0f),
                spaceAfter = aPts ?: (aPct?.let { it * refSize * 1.2f } ?: 0f),
                lineSpacing = ((lnPct ?: 1f) - lnRed).coerceAtLeast(0.5f),
                lineExact = lnPts,
                rtl = rtl,
                endSize = endSize,
            )
        }
        fun inset(name: String, def: Float) = bp(name)?.toFloatOrNull()?.div(12700f) ?: def
        return Deck.Text(
            paras,
            left = inset("lIns", 7.2f), top = inset("tIns", 3.6f), right = inset("rIns", 7.2f), bottom = inset("bIns", 3.6f),
            anchor = when (bp("anchor")) { "ctr" -> Deck.Anchor.MIDDLE; "b" -> Deck.Anchor.BOTTOM; else -> Deck.Anchor.TOP },
            fontScale = fontScale, lineReduction = lnRed,
            wrap = bp("wrap") != "none",
            vertical = bp("vert").let { it != null && it != "horz" },
            shrinkOnOverflow = autofit?.localName == "normAutofit",
        )
    }


    private fun autoNumber(bu: Element, p: Element): String {
        // Count earlier paragraphs in the same text body with an auto-numbered bullet.
        val body = p.parentNode as? Element
        val siblings = children(body, "p")
        // Count the numbered paragraphs right before this one at the same level; any
        // other paragraph at that level restarts the count, like PowerPoint.
        fun level(e: Element) = child(e, "pPr")?.getAttribute("lvl")?.toIntOrNull() ?: 0
        val myLevel = level(p)
        var n = bu.getAttribute("startAt").toIntOrNull() ?: 1
        val index = siblings.indexOfFirst { it === p }
        for (k in index - 1 downTo 0) {
            val s = siblings[k]
            val lv = level(s)
            if (lv > myLevel) continue
            if (lv < myLevel) break
            if (child(child(s, "pPr"), "buAutoNum") == null) break
            n++
        }
        return when (bu.getAttribute("type")) {
            "alphaLcParenR" -> "${('a' + (n - 1) % 26)})"
            "alphaLcPeriod" -> "${('a' + (n - 1) % 26)}."
            "alphaUcPeriod" -> "${('A' + (n - 1) % 26)}."
            "alphaUcParenR" -> "${('A' + (n - 1) % 26)})"
            "romanLcPeriod" -> DocxReader.roman(n).lowercase() + "."
            "romanUcPeriod" -> DocxReader.roman(n) + "."
            "arabicParenR" -> "$n)"
            "arabicParenBoth" -> "($n)"
            "arabicPlain" -> "$n"
            else -> "$n."
        }
    }

    companion object {
        private const val R_NS = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
        private const val REL_LAYOUT = "http://schemas.openxmlformats.org/officeDocument/2006/relationships/slideLayout"
        private const val REL_MASTER = "http://schemas.openxmlformats.org/officeDocument/2006/relationships/slideMaster"
        private const val REL_THEME = "http://schemas.openxmlformats.org/officeDocument/2006/relationships/theme"
        const val NO_FILL = 0x00FFFFFF
        private val BULLET_KINDS = setOf("buNone", "buChar", "buAutoNum", "buBlip")

        val DEFAULT_MAP = mapOf("bg1" to "lt1", "tx1" to "dk1", "bg2" to "lt2", "tx2" to "dk2")
        val DEFAULT_COLORS: Map<String, Int> = mapOf(
            "dk1" to 0xFF000000, "lt1" to 0xFFFFFFFF, "dk2" to 0xFF44546A, "lt2" to 0xFFE7E6E6,
            "accent1" to 0xFF4472C4, "accent2" to 0xFFED7D31, "accent3" to 0xFFA5A5A5, "accent4" to 0xFFFFC000,
            "accent5" to 0xFF5B9BD5, "accent6" to 0xFF70AD47, "hlink" to 0xFF0563C1, "folHlink" to 0xFF954F72,
        ).mapValues { it.value.toInt() }
        private val PRESET: Map<String, Int> = mapOf(
            "black" to 0xFF000000, "white" to 0xFFFFFFFF, "red" to 0xFFFF0000, "green" to 0xFF008000, "blue" to 0xFF0000FF,
            "yellow" to 0xFFFFFF00, "gray" to 0xFF808080, "grey" to 0xFF808080, "orange" to 0xFFFFA500, "darkGray" to 0xFFA9A9A9,
            "lightGray" to 0xFFD3D3D3, "navy" to 0xFF000080, "purple" to 0xFF800080, "silver" to 0xFFC0C0C0,
        ).mapValues { it.value.toInt() }
    }
}

/** Color math for theme modifiers. Pure logic, unit tested. */
object Colors {
    fun modify(argb: Int, mods: List<Pair<String, Float>>): Int {
        var r = (argb shr 16 and 0xFF) / 255f
        var g = (argb shr 8 and 0xFF) / 255f
        var b = (argb and 0xFF) / 255f
        var a = (argb ushr 24) / 255f
        for ((name, v) in mods) when (name) {
            "lumMod", "lumOff" -> {
                val hsl = toHsl(r, g, b)
                if (name == "lumMod") hsl[2] *= v else hsl[2] += v
                hsl[2] = hsl[2].coerceIn(0f, 1f)
                val rgb = fromHsl(hsl[0], hsl[1], hsl[2]); r = rgb[0]; g = rgb[1]; b = rgb[2]
            }
            "tint" -> { r += (1 - r) * (1 - v); g += (1 - g) * (1 - v); b += (1 - b) * (1 - v) }
            "shade" -> { r *= v; g *= v; b *= v }
            "alpha" -> a = v
        }
        fun c(x: Float) = (x.coerceIn(0f, 1f) * 255f).roundToInt()
        return (c(a) shl 24) or (c(r) shl 16) or (c(g) shl 8) or c(b)
    }

    fun average(colors: List<Int>): Int {
        val n = colors.size
        val r = colors.sumOf { it shr 16 and 0xFF } / n
        val g = colors.sumOf { it shr 8 and 0xFF } / n
        val b = colors.sumOf { it and 0xFF } / n
        return (0xFF shl 24) or (r shl 16) or (g shl 8) or b
    }

    private fun toHsl(r: Float, g: Float, b: Float): FloatArray {
        val max = maxOf(r, g, b); val min = minOf(r, g, b)
        val l = (max + min) / 2
        if (max == min) return floatArrayOf(0f, 0f, l)
        val d = max - min
        val s = if (l > 0.5f) d / (2 - max - min) else d / (max + min)
        val h = when (max) {
            r -> (g - b) / d + (if (g < b) 6 else 0)
            g -> (b - r) / d + 2
            else -> (r - g) / d + 4
        } / 6
        return floatArrayOf(h, s, l)
    }

    private fun fromHsl(h: Float, s: Float, l: Float): FloatArray {
        if (s == 0f) return floatArrayOf(l, l, l)
        val q = if (l < 0.5f) l * (1 + s) else l + s - l * s
        val p = 2 * l - q
        fun hue(t0: Float): Float {
            var t = t0
            if (t < 0) t += 1; if (t > 1) t -= 1
            return when {
                t < 1f / 6 -> p + (q - p) * 6 * t
                t < 1f / 2 -> q
                t < 2f / 3 -> p + (q - p) * (2f / 3 - t) * 6
                else -> p
            }
        }
        return floatArrayOf(hue(h + 1f / 3), hue(h), hue(h - 1f / 3))
    }
}
