package com.excelto.pdf.converter.core.excel

/** How the user wants the sheets printed. */
data class PrintOptions(
    /** A4, Letter, or null for the sheet's own paper size. */
    val paper: Paper? = null,
    /** Null for the sheet's own orientation. */
    val landscape: Boolean? = null,
    val fitColumnsOnOnePage: Boolean = true,
    val printGridlines: Boolean = false,
)

enum class Paper(val width: Float, val height: Float) {
    LETTER(612f, 792f), LEGAL(612f, 1008f), TABLOID(792f, 1224f), EXECUTIVE(522f, 756f),
    A3(842f, 1191f), A4(595f, 842f), A5(420f, 595f), B4(729f, 1032f), B5(516f, 729f);

    companion object {
        /** Excel's paperSize codes. Unknown codes fall back to A4. */
        fun fromExcel(code: Int?): Paper = when (code) {
            1, 2 -> LETTER
            3, 4 -> TABLOID
            5 -> LEGAL
            7 -> EXECUTIVE
            8 -> A3
            9, 10 -> A4
            11 -> A5
            12 -> B4
            13 -> B5
            else -> A4
        }
    }
}

/**
 * Where every visible row and column of one sheet lands, the print scale, and how
 * the sheet splits into pages ("down, then over", like Excel). Pure Kotlin.
 */
class SheetLayout(val sheet: ExcelSheet, val range: CellRange, options: PrintOptions) {

    /** Visible columns and rows in the print range, in order. */
    val cols: IntArray = (range.firstCol..range.lastCol).filter { it !in sheet.hiddenCols }.toIntArray()
    val rows: IntArray = (range.firstRow..range.lastRow).filter { it !in sheet.hiddenRows }.toIntArray()

    /** Left edge of each visible column, and one extra entry for the right edge (points, unscaled). */
    val colX = FloatArray(cols.size + 1)
    val rowY = FloatArray(rows.size + 1)

    val pageWidth: Float
    val pageHeight: Float
    val marginLeft: Float
    val marginTop: Float
    val printableWidth: Float
    val printableHeight: Float
    val scale: Float

    /** Column bands and row bands: [start, end) indexes into [cols] / [rows]. */
    val colBands: List<IntRange>
    val rowBands: List<IntRange>

    init {
        for (i in cols.indices) colX[i + 1] = colX[i] + colWidth(cols[i])
        for (i in rows.indices) rowY[i + 1] = rowY[i] + rowHeight(rows[i])
        val setup = sheet.pageSetup
        val paper = options.paper ?: Paper.fromExcel(setup.paperSize)
        val landscape = options.landscape ?: setup.landscape ?: false
        pageWidth = if (landscape) paper.height else paper.width
        pageHeight = if (landscape) paper.width else paper.height
        marginLeft = setup.marginLeft * 72f
        marginTop = setup.marginTop * 72f
        printableWidth = (pageWidth - marginLeft - setup.marginRight * 72f).coerceAtLeast(72f)
        printableHeight = (pageHeight - marginTop - setup.marginBottom * 72f).coerceAtLeast(72f)
        val totalW = colX.last().coerceAtLeast(1f)
        val totalH = rowY.last().coerceAtLeast(1f)
        scale = when {
            options.fitColumnsOnOnePage -> minOf(1f, printableWidth / totalW)
            setup.fitToPage -> {
                val sw = if (setup.fitWidth > 0) setup.fitWidth * printableWidth / totalW else Float.MAX_VALUE
                val sh = if (setup.fitHeight > 0) setup.fitHeight * printableHeight / totalH else Float.MAX_VALUE
                minOf(1f, sw, sh)
            }
            else -> setup.scale / 100f
        }.coerceIn(0.1f, 4f)
        colBands = bands(colX, printableWidth / scale)
        rowBands = bands(rowY, printableHeight / scale)
    }

    fun colWidth(c: Int): Float = SheetUnits.columnPoints(sheet.colWidths[c] ?: sheet.defaultColWidth)
    fun rowHeight(r: Int): Float = sheet.rowHeights[r] ?: sheet.defaultRowHeight

    /** Pages in print order: every row band of the first column band, then the next column band. */
    val pages: List<Pair<IntRange, IntRange>> get() = colBands.flatMap { c -> rowBands.map { r -> c to r } }

    /** Position of column [c] among visible columns, or -1. */
    fun colPos(c: Int): Int = cols.binarySearch(c).let { if (it < 0) -1 else it }
    fun rowPos(r: Int): Int = rows.binarySearch(r).let { if (it < 0) -1 else it }

    /** X of the left edge of column [c] even when it's hidden or outside the range. */
    fun xOf(c: Int): Float {
        val i = cols.binarySearch(c)
        return if (i >= 0) colX[i] else colX[(-i - 1).coerceIn(0, cols.size)]
    }

    fun yOf(r: Int): Float {
        val i = rows.binarySearch(r)
        return if (i >= 0) rowY[i] else rowY[(-i - 1).coerceIn(0, rows.size)]
    }

    companion object {
        /** Splits positions into runs that fit [limit]. Each band has at least one item. */
        fun bands(edges: FloatArray, limit: Float): List<IntRange> {
            val n = edges.size - 1
            if (n <= 0) return listOf(0 until 0)
            val out = mutableListOf<IntRange>()
            var start = 0
            while (start < n) {
                var end = start + 1
                while (end < n && edges[end + 1] - edges[start] <= limit + 0.01f) end++
                out += start until end
                start = end
            }
            return out
        }
    }
}
