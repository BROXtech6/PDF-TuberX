package com.excelto.pdf.converter.ui.theme

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.addPathNodes
import androidx.compose.ui.unit.dp

/** Line icons drawn from the same 24×24 paths as the prototype. */
object AppIcons {
    private fun line(d: String, width: Float = 2f) = ImageVector.Builder(
        defaultWidth = 24.dp, defaultHeight = 24.dp, viewportWidth = 24f, viewportHeight = 24f,
    ).addPath(
        pathData = addPathNodes(d),
        stroke = SolidColor(Color.Black),
        strokeLineWidth = width,
        strokeLineCap = StrokeCap.Round,
        strokeLineJoin = StrokeJoin.Round,
    ).build()

    private fun solid(d: String) = ImageVector.Builder(
        defaultWidth = 24.dp, defaultHeight = 24.dp, viewportWidth = 24f, viewportHeight = 24f,
    ).addPath(pathData = addPathNodes(d), fill = SolidColor(Color.Black)).build()

    val spark = solid("M12 2l1.8 5.2L19 9l-5.2 1.8L12 16l-1.8-5.2L5 9l5.2-1.8z M19 14l.9 2.1L22 17l-2.1.9L19 20l-.9-2.1L16 17l2.1-.9z")
    val star = solid("M12 2l2.4 6.6L21 9l-5 4.6L17.5 21 12 17.3 6.5 21 8 13.6 3 9l6.6-.4z")
    val chat = line("M4 5h16v11H9l-5 4z M8 10h8")
    val globe = line("M4 5h8 M8 3v2 M5 9c1 3 4 5 7 6 M11 5c-1 4-3 7-6 9 M13 21l4-9 4 9 M14.5 18h5")
    val pen = line("M4 20h4L19 9l-4-4L4 16z M13 7l4 4")
    val marker = line("M9 11l6-6 4 4-6 6 M9 11l-4 4v4h4l4-4 M3 21h8")
    val sign = line("M3 18c3-5 5-9 7-9 3 0-2 8 1 8 2 0 3-3 5-3 1 0 1 2 5 2 M3 21h18")
    val form = line("M5 3h14v18H5z M8 8h8 M8 12h8 M8 16h4")
    val stamp = line("M4 4h16v16H4z M8 15l8-6 M8 9h.01 M16 15h.01")
    val lock = line("M6 11h12v10H6z M8 11V7a4 4 0 0 1 8 0v4")
    val unlock = line("M6 11h12v10H6z M8 11V7a4 4 0 0 1 7.5-2")
    val redact = line("M4 6h16v4H4z M4 14h10v4H4z")
    val compare = line("M4 4h7v16H4z M13 4h7v16h-7z M7 9h1 M16 12h1")
    val excel = line("M4 4h16v16H4z M4 10h16 M4 16h16 M10 4v16")
    val table = line("M7 3h10v7H7z M12 10v5 M9 13l3 3 3-3 M4 17h16v4H4z")
    val image = line("M4 5h16v14H4z M4 16l5-5 4 4 3-3 4 4 M15.5 9.5h.01")
    val compress = line("M8 3v5H3 M16 3v5h5 M8 21v-5H3 M16 21v-5h5")
    val merge = line("M7 4v5c0 3 5 3 5 6v5 M17 4v5c0 3-5 3-5 6 M9 18l3 3 3-3")
    val split = line("M12 3v6c0 3-5 3-5 6v5 M12 9c0 3 5 3 5 6v5")
    val organize = line("M4 4h7v7H4z M13 4h7v7h-7z M4 13h7v7H4z M13 13h7v7h-7z")
    val scan = line("M4 8V4h4 M16 4h4v4 M20 16v4h-4 M8 20H4v-4 M4 12h16")
    val share = line("M18 8a3 3 0 1 0 0-6 3 3 0 0 0 0 6z M6 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6z M18 22a3 3 0 1 0 0-6 3 3 0 0 0 0 6z M8.6 13.5l6.8 4 M15.4 6.5l-6.8 4")
    val trash = line("M4 7h16 M9 7V4h6v3 M6 7l1 14h10l1-14")
    val cloud = line("M7 18h10a4 4 0 0 0 .5-8A6 6 0 0 0 6 9.5 4.3 4.3 0 0 0 7 18z")
    val check = line("M5 13l4 4 10-10", 2.5f)
    val dot = line("M12 12h.01", 3f)
    val back = line("M15 5l-7 7 7 7")
    val chevron = line("M9 5l7 7-7 7")
    val search = line("M11 18a7 7 0 1 0 0-14 7 7 0 0 0 0 14z M21 21l-5-5")
    val moon = line("M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8z")
    val speaker = line("M11 5L6 9H3v6h3l5 4V5z M15.5 8.5a5 5 0 0 1 0 7 M18.5 5.5a9 9 0 0 1 0 13")
    val stop = solid("M7 7h10v10H7z")
    val home = line("M3 11l9-8 9 8 M5 9v11h14V9")
    val tools = organize
    val folder = line("M3 6h7l2 2h9v11H3z")
    val settings = line("M4 7h10 M18 7h2 M4 17h2 M10 17h10 M16 5v4 M8 15v4")
    val more = line("M12 5h.01 M12 12h.01 M12 19h.01", 3f)
    val plus = line("M12 5v14 M5 12h14")
    val rotate = line("M20 11a8 8 0 1 0-2.3 5.7 M20 4v7h-7")
    val undo = line("M9 14L4 9l5-5 M4 9h10a6 6 0 0 1 0 12h-3")
    val up = line("M6 15l6-6 6 6")
    val down = line("M6 9l6 6 6-6")
    val close = line("M6 6l12 12 M18 6L6 18")
    val ad = line("M4 4l16 16 M9 5h10v10 M5 9v10h10")
    val stack = line("M12 3l9 5-9 5-9-5z M3 13l9 5 9-5")
    val note = line("M4 4h16v12h-6l-4 4v-4H4z")
    val text = line("M5 6V4h14v2 M12 4v16 M9 20h6")
    val shield = line("M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6z")
    val word = line("M5 3h10l4 4v14H5z M8 10l1.5 6L11 12l1.5 4L14 10")
    val slides = line("M3 4h18v12H3z M12 16v4 M8 20h8 M9 8v4 M9 8h2.5a1.5 1.5 0 0 1 0 3H9")
    val html = line("M8 8l-4 4 4 4 M16 8l4 4-4 4 M14 5l-4 14")
    val jpg = line("M4 5h16v14H4z M4 16l5-5 4 4 3-3 4 4 M15.5 9.5h.01")
    val archive = line("M4 4h16v4H4z M5 8v12h14V8 M10 12h4")
    val repair = line("M14 6a4 4 0 0 0 5 5l-9 9a2.1 2.1 0 0 1-3-3z")
    val ocr = line("M4 8V4h4 M16 4h4v4 M20 16v4h-4 M8 20H4v-4 M8 9h8 M12 9v7")
    val numbers = line("M5 3h14v18H5z M10 17h4 M12 14v3 M11 15l1-1")
    val crop = line("M6 2v16h16 M2 6h16v16")
    val removePages = line("M6 3h9l4 4v14H6z M9 13h6")
    val extractPages = line("M6 3h9l4 4v14H6z M12 10v7 M9 14l3 3 3-3")
    val eye = line("M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12z M12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6z")
}
