package com.excelto.pdf.converter.core.office

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.text.Layout
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.StaticLayout
import android.text.TextDirectionHeuristics
import android.text.TextPaint
import android.text.style.AbsoluteSizeSpan
import android.text.style.BackgroundColorSpan
import android.text.style.ForegroundColorSpan
import android.text.style.LeadingMarginSpan
import android.text.style.StrikethroughSpan
import android.text.style.StyleSpan
import android.text.style.SubscriptSpan
import android.text.style.SuperscriptSpan
import android.text.style.TabStopSpan
import android.text.style.TypefaceSpan
import android.text.style.UnderlineSpan
import com.excelto.pdf.converter.core.engine.Progress
import java.io.File
import java.io.FileOutputStream

/**
 * Paginates a [Flow.Document] into a PDF with Android's PdfDocument and StaticLayout,
 * so text stays real, selectable text and every script the phone can show is drawn
 * (Arabic, Urdu, Hindi, Chinese…). Paragraphs split across pages line by line; table
 * rows move to the next page whole, and header rows repeat.
 */
class FlowRenderer(private val doc: Flow.Document, private val progress: Progress) {

    private val page = doc.page
    private val pdf = PdfDocument()
    private var current: PdfDocument.Page? = null
    private var canvas: Canvas? = null
    private var pageCount = 0
    private var y = 0f
    private val top get() = page.top
    private val bottom get() = page.heightPt - page.bottom
    private val left get() = page.left
    private val width get() = page.widthPt - page.left - page.right

    /** Header rows to draw again when a table continues on a new page. */
    private var repeatHeader: (() -> Unit)? = null

    fun render(out: File): Int {
        try {
            newPage()
            val total = doc.blocks.size
            doc.blocks.forEachIndexed { i, b ->
                progress.check()
                when (b) {
                    is Flow.Paragraph -> paragraph(b, left, width)
                    is Flow.Table -> table(b)
                    is Flow.Image -> image(b, left, width)
                    Flow.PageBreak -> newPage()
                }
                if (i % 8 == 0) progress.step(i + 1, total, 20, 92)
            }
            finishPage()
            FileOutputStream(out).use { pdf.writeTo(it) }
            return pageCount
        } finally {
            pdf.close()
        }
    }

    private fun newPage() {
        finishPage()
        pageCount++
        val info = PdfDocument.PageInfo.Builder(page.widthPt.toInt(), page.heightPt.toInt(), pageCount).create()
        current = pdf.startPage(info)
        canvas = current!!.canvas
        y = top
        repeatHeader?.invoke()
    }

    private fun finishPage() {
        current?.let { pdf.finishPage(it) }
        current = null
    }

    private val atTop get() = y <= top + 0.5f

    // ---- Paragraphs ---------------------------------------------------------------------

    private class Built(val layout: StaticLayout, val x: Float, val marker: String?, val markerPaint: TextPaint?, val markerX: Float, val para: Flow.Paragraph)

    private fun build(p: Flow.Paragraph, x0: Float, w0: Float): Built {
        val text = SpannableStringBuilder()
        val baseSize = p.runs.firstOrNull()?.style?.sizePt ?: 11f
        for (r in p.runs) {
            val start = text.length
            text.append(r.text)
            val end = text.length
            if (start == end) continue
            val s = r.style
            fun span(o: Any) = text.setSpan(o, start, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            span(AbsoluteSizeSpan(s.sizePt.coerceIn(1f, 400f).let { if (s.vertAlign != 0) it * 0.65f else it }.toInt().coerceAtLeast(1)))
            when {
                s.bold && s.italic -> span(StyleSpan(Typeface.BOLD_ITALIC))
                s.bold -> span(StyleSpan(Typeface.BOLD))
                s.italic -> span(StyleSpan(Typeface.ITALIC))
            }
            if (s.underline) span(UnderlineSpan())
            if (s.strike) span(StrikethroughSpan())
            s.color?.let { span(ForegroundColorSpan(it)) }
            s.highlight?.let { span(BackgroundColorSpan(it)) }
            span(TypefaceSpan(family(s.font)))
            if (s.vertAlign > 0) span(SuperscriptSpan()) else if (s.vertAlign < 0) span(SubscriptSpan())
        }
        if (text.isEmpty()) text.append(" ").also { text.setSpan(AbsoluteSizeSpan(baseSize.toInt().coerceAtLeast(1)), 0, 1, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE) }

        val indentL = p.indentLeft.coerceIn(-x0 + 0f, w0 * 0.8f)
        val indentR = p.indentRight.coerceIn(0f, w0 * 0.8f)
        // Hanging indent: the first line starts further left (or the marker sits there).
        val firstShift = p.firstLine
        val boxX: Float
        val boxW: Float
        val firstOffset: Int
        val restOffset: Int
        if (firstShift >= 0f || p.marker != null) {
            boxX = if (p.rtl) x0 + indentR else x0 + indentL
            boxW = (w0 - indentL - indentR).coerceAtLeast(24f)
            firstOffset = if (p.marker != null) 0 else firstShift.toInt()
            restOffset = 0
        } else {
            boxX = if (p.rtl) x0 + indentR else x0 + indentL + firstShift
            boxW = (w0 - indentL - indentR - firstShift).coerceAtLeast(24f)
            firstOffset = 0
            restOffset = (-firstShift).toInt()
        }
        if (firstOffset != 0 || restOffset != 0) text.setSpan(LeadingMarginSpan.Standard(firstOffset, restOffset), 0, text.length, Spanned.SPAN_INCLUSIVE_INCLUSIVE)
        var stop = 36
        while (stop < boxW) { text.setSpan(TabStopSpan.Standard(stop), 0, text.length, Spanned.SPAN_INCLUSIVE_INCLUSIVE); stop += 36 }

        val paint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { textSize = baseSize; color = Color.BLACK; typeface = Typeface.SANS_SERIF }
        fun make(mult: Float) = StaticLayout.Builder.obtain(text, 0, text.length, paint, boxW.toInt().coerceAtLeast(1))
            .setAlignment(
                when (p.align) {
                    Flow.Align.CENTER -> Layout.Alignment.ALIGN_CENTER
                    Flow.Align.RIGHT -> Layout.Alignment.ALIGN_OPPOSITE
                    else -> Layout.Alignment.ALIGN_NORMAL
                },
            )
            .setTextDirection(if (p.rtl) TextDirectionHeuristics.RTL else TextDirectionHeuristics.FIRSTSTRONG_LTR)
            .setJustificationMode(if (p.align == Flow.Align.JUSTIFY) Layout.JUSTIFICATION_MODE_INTER_WORD else Layout.JUSTIFICATION_MODE_NONE)
            .setLineSpacing(0f, mult)
            .setIncludePad(false)
            .setBreakStrategy(Layout.BREAK_STRATEGY_HIGH_QUALITY)
            .setHyphenationFrequency(Layout.HYPHENATION_FREQUENCY_NONE)
            .build()
        var layout = make(p.lineSpacing.coerceIn(0.6f, 4f) * 1.08f)
        p.exactLine?.let { exact ->
            val natural = layout.height.toFloat() / layout.lineCount.coerceAtLeast(1)
            if (natural > 0f) layout = make((exact / natural).coerceIn(0.5f, 6f))
        }

        var markerPaint: TextPaint? = null
        var markerX = 0f
        if (p.marker != null) {
            val st = p.runs.firstOrNull()?.style ?: Flow.Style()
            markerPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
                textSize = st.sizePt
                color = st.color ?: Color.BLACK
                typeface = Typeface.create(family(st.font), if (st.bold) Typeface.BOLD else Typeface.NORMAL)
            }
            val hang = (-firstShift).coerceAtLeast(markerPaint.measureText(p.marker) + 4f)
            markerX = if (p.rtl) boxX + boxW + hang - markerPaint.measureText(p.marker) else boxX - hang
        }
        return Built(layout, boxX, p.marker, markerPaint, markerX, p)
    }

    private fun paragraph(p: Flow.Paragraph, x0: Float, w0: Float) {
        if (p.pageBreakBefore && !atTop) newPage()
        if (!atTop) y += p.spaceBefore
        val b = build(p, x0, w0)
        draw(b, x0, w0)
        y += p.spaceAfter
    }

    private fun draw(b: Built, x0: Float, w0: Float) {
        val l = b.layout
        var line = 0
        while (line < l.lineCount) {
            val avail = bottom - y
            var end = line
            while (end < l.lineCount && l.getLineBottom(end) - l.getLineTop(line) <= avail) end++
            if (end == line) {
                if (!atTop) { newPage(); continue }
                end = line + 1
            }
            val c = canvas!!
            val yTop = l.getLineTop(line).toFloat()
            val h = l.getLineBottom(end - 1) - yTop
            b.para.shading?.let { fill -> c.drawRect(x0, y, x0 + w0, y + h, Paint().apply { color = fill }) }
            c.save()
            c.translate(b.x, y - yTop)
            c.clipRect(-b.x, yTop, page.widthPt, yTop + h)
            l.draw(c)
            c.restore()
            if (line == 0 && b.marker != null && b.markerPaint != null) {
                c.drawText(b.marker, b.markerX, y + l.getLineBaseline(0), b.markerPaint)
            }
            y += h
            line = end
        }
    }

    // ---- Pictures -----------------------------------------------------------------------

    private fun image(img: Flow.Image, x0: Float, w0: Float, draw: Boolean = true): Float {
        var w = img.widthPt
        var h = img.heightPt
        val s = minOf(1f, w0 / w, (bottom - top) / h)
        w *= s; h *= s
        if (!draw) return h
        if (y + h > bottom && !atTop) newPage()
        val x = when (img.align) {
            Flow.Align.CENTER -> x0 + (w0 - w) / 2
            Flow.Align.RIGHT -> x0 + w0 - w
            else -> x0
        }
        drawPicture(canvas!!, img, RectF(x, y, x + w, y + h))
        y += h + 4f
        return h
    }

    private fun drawPicture(c: Canvas, img: Flow.Image, r: RectF) {
        val bmp = img.bytes?.let { decode(it, r.width(), r.height()) }
        if (bmp != null) {
            c.drawBitmap(bmp, null, r, Paint(Paint.FILTER_BITMAP_FLAG))
            bmp.recycle()
        } else {
            c.drawRect(r, Paint().apply { color = 0xFFF1F3F4.toInt() })
            c.drawRect(r, Paint().apply { color = 0xFFBDC1C6.toInt(); style = Paint.Style.STROKE; strokeWidth = 0.75f })
            val tp = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 9f; color = 0xFF5F6368.toInt(); textAlign = Paint.Align.CENTER }
            c.drawText(img.note ?: "Picture", r.centerX(), r.centerY() + 3f, tp)
        }
    }

    /** Decodes at about 200 dpi for the box it fills, so big photos don't run out of memory. */
    private fun decode(bytes: ByteArray, wPt: Float, hPt: Float): Bitmap? = runCatching {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
        if (bounds.outWidth <= 0) return null
        val targetW = (wPt * 200f / 72f).coerceAtLeast(1f)
        val targetH = (hPt * 200f / 72f).coerceAtLeast(1f)
        var sample = 1
        while (bounds.outWidth / (sample * 2) >= targetW && bounds.outHeight / (sample * 2) >= targetH) sample *= 2
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, BitmapFactory.Options().apply { inSampleSize = sample })
    }.getOrNull()

    // ---- Tables -------------------------------------------------------------------------

    private class CellBox(val cell: Flow.Cell, val col: Int, val x: Float, val w: Float, val content: List<Any>, val height: Float)

    private val pad = 5.4f
    private val line = Paint().apply { color = Color.BLACK; strokeWidth = 0.5f; style = Paint.Style.STROKE }

    private fun table(t: Flow.Table) {
        if (!atTop) y += 2f
        val colX = FloatArray(t.columns.size + 1)
        val x0 = left + t.indent.coerceIn(0f, width / 2)
        colX[0] = x0
        for (i in t.columns.indices) colX[i + 1] = colX[i] + t.columns[i]
        val scale = if (colX.last() - x0 > width - t.indent) (width - t.indent) / (colX.last() - x0) else 1f
        for (i in colX.indices) colX[i] = x0 + (colX[i] - x0) * scale

        val rows = t.rows.map { row -> layoutRow(row, colX) }
        // Which grid columns continue a vertical merge in the next row.
        val continues = t.rows.map { row ->
            val set = HashSet<Int>()
            var col = 0
            for (c in row.cells) { if (c.vMergeContinue) set += col; col += c.span }
            set
        }
        val headerCount = t.rows.takeWhile { it.header }.size.takeIf { it < t.rows.size } ?: 0

        fun drawRow(i: Int) {
            val boxes = rows[i]
            val h = maxOf(t.rows[i].minHeight, boxes.maxOfOrNull { it.height } ?: 0f)
            val c = canvas!!
            for (b in boxes) {
                b.cell.fill?.let { f -> c.drawRect(b.x, y, b.x + b.w, y + h, Paint().apply { color = f }) }
                if (!b.cell.vMergeContinue) drawCell(b)
                if (t.borders) {
                    c.drawLine(b.x, y, b.x, y + h, line)
                    c.drawLine(b.x + b.w, y, b.x + b.w, y + h, line)
                    if (!b.cell.vMergeContinue) c.drawLine(b.x, y, b.x + b.w, y, line)
                    val nextContinues = i + 1 < rows.size && b.col in continues[i + 1]
                    if (!nextContinues) c.drawLine(b.x, y + h, b.x + b.w, y + h, line)
                }
            }
            y += h
        }

        for (i in rows.indices) {
            progress.check()
            val h = maxOf(t.rows[i].minHeight, rows[i].maxOfOrNull { it.height } ?: 0f)
            if (y + h > bottom && !atTop) {
                newPage()
                if (i >= headerCount) for (k in 0 until headerCount) drawRow(k)
            }
            drawRow(i)
        }
        y += 6f
    }

    private fun layoutRow(row: Flow.Row, colX: FloatArray): List<CellBox> {
        val out = ArrayList<CellBox>()
        var col = 0
        for (cell in row.cells) {
            if (col >= colX.size - 1) break
            val end = (col + cell.span).coerceAtMost(colX.size - 1)
            val x = colX[col]
            val w = colX[end] - x
            val inner = (w - pad * 2).coerceAtLeast(8f)
            val content = ArrayList<Any>()
            var h = 0f
            if (!cell.vMergeContinue) {
                for (b in flatten(cell.blocks)) when (b) {
                    is Flow.Paragraph -> {
                        val built = build(b.copy(spaceBefore = 0f), x + pad, inner)
                        content += built
                        h += built.layout.height + b.spaceAfter.coerceAtMost(6f)
                    }
                    is Flow.Image -> {
                        val ih = image(b, 0f, inner, draw = false)
                        content += b
                        h += ih + 2f
                    }
                    else -> Unit
                }
            }
            out += CellBox(cell, col, x, w, content, h + 4f)
            col = end
        }
        return out
    }

    /** Nested tables inside a cell become one line per row, cells separated by tabs. */
    private fun flatten(blocks: List<Flow.Block>): List<Flow.Block> = blocks.flatMap { b ->
        if (b is Flow.Table) b.rows.map { r ->
            val style = r.cells.firstNotNullOfOrNull { c -> c.blocks.filterIsInstance<Flow.Paragraph>().firstOrNull()?.runs?.firstOrNull()?.style } ?: Flow.Style()
            Flow.Paragraph(listOf(Flow.Run(r.cells.joinToString("\t") { c -> c.blocks.filterIsInstance<Flow.Paragraph>().joinToString(" ") { it.text } }, style)))
        } else listOf(b)
    }

    private fun drawCell(b: CellBox) {
        val c = canvas!!
        var yy = y + 2f
        for (item in b.content) {
            when (item) {
                is Built -> {
                    c.save()
                    c.translate(item.x, yy)
                    item.layout.draw(c)
                    c.restore()
                    if (item.marker != null && item.markerPaint != null) c.drawText(item.marker, item.markerX, yy + item.layout.getLineBaseline(0), item.markerPaint)
                    yy += item.layout.height + item.para.spaceAfter.coerceAtMost(6f)
                }
                is Flow.Image -> {
                    val inner = b.w - pad * 2
                    val s = minOf(1f, inner / item.widthPt, (bottom - top) / item.heightPt)
                    val w = item.widthPt * s
                    val h = item.heightPt * s
                    drawPicture(c, item, RectF(b.x + pad, yy, b.x + pad + w, yy + h))
                    yy += h + 2f
                }
            }
        }
    }

    companion object {
        fun family(font: String?): String {
            val f = font?.lowercase() ?: return "sans-serif"
            return when {
                listOf("courier", "consolas", "mono", "menlo", "lucida console").any { it in f } -> "monospace"
                listOf("times", "georgia", "cambria", "garamond", "book", "serif", "palatino", "baskerville", "minion").any { it in f } && "sans" !in f -> "serif"
                else -> "sans-serif"
            }
        }
    }
}
