package com.excelto.pdf.converter.core.engine

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.rendering.PDFRenderer
import java.io.Closeable
import java.io.File
import kotlin.math.sqrt

/**
 * Renders PDF pages to bitmaps. Uses Android's PdfRenderer (fast and accurate). Files
 * it can't read directly (password protected) are unlocked into [workDir] first; if
 * the password doesn't allow that, PdfBox's own renderer is used instead.
 */
class PdfRaster private constructor(
    private val android: PdfRenderer?,
    private val fd: ParcelFileDescriptor?,
    private val pdfbox: PDDocument?,
    private val temp: File?,
) : Closeable {

    val pageCount: Int get() = android?.pageCount ?: pdfbox!!.numberOfPages

    /** Visible page size in points (rotation applied). */
    fun pageSize(index: Int): Pair<Float, Float> {
        android?.let { r -> r.openPage(index).use { return it.width.toFloat() to it.height.toFloat() } }
        val frame = PageFrame(pdfbox!!.getPage(index))
        return frame.width to frame.height
    }

    /**
     * Renders page [index] at [dpi] on white, scaled down if it would exceed [maxPixels]
     * so very large pages don't run out of memory.
     */
    fun render(index: Int, dpi: Float, maxPixels: Long = 24_000_000L): Bitmap {
        val (wPt, hPt) = pageSize(index)
        var scale = dpi / 72f
        val pixels = wPt * scale * hPt * scale
        if (pixels > maxPixels) scale *= sqrt(maxPixels / pixels.toDouble()).toFloat()
        val w = (wPt * scale).toInt().coerceAtLeast(1)
        val h = (hPt * scale).toInt().coerceAtLeast(1)
        android?.let { r ->
            r.openPage(index).use { page ->
                val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                bmp.eraseColor(Color.WHITE)
                page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_PRINT)
                return bmp
            }
        }
        return PDFRenderer(pdfbox!!).renderImage(index, scale)
    }

    override fun close() {
        runCatching { android?.close() }
        runCatching { fd?.close() }
        runCatching { pdfbox?.close() }
        temp?.delete()
    }

    companion object {
        fun open(input: PdfTools.Input, workDir: File): PdfRaster {
            val file = File(input.path)
            // Plain files open straight away in Android's renderer.
            runCatching {
                val fd = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
                try {
                    return PdfRaster(PdfRenderer(fd), fd, null, null)
                } catch (e: Exception) {
                    fd.close()
                    throw e
                }
            }
            // Locked or unusual files: unlock a copy if the password allows it.
            val doc = PdfTools.open(input.path, input.password)
            if (doc.isEncrypted && PdfTools.hasOwnerRights(doc)) {
                doc.close()
                val temp = File(workDir, "raster_${System.nanoTime()}.pdf")
                PdfTools.unlock(input, temp, Progress.NONE)
                val fd = ParcelFileDescriptor.open(temp, ParcelFileDescriptor.MODE_READ_ONLY)
                return runCatching { PdfRaster(PdfRenderer(fd), fd, null, temp) }.getOrElse {
                    fd.close()
                    PdfRaster(null, null, PdfTools.open(temp.path), temp)
                }
            }
            return PdfRaster(null, null, doc, null)
        }
    }
}
