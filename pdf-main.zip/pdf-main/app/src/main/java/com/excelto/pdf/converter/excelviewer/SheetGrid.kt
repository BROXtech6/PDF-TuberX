package com.excelto.pdf.converter.excelviewer

import com.excelto.pdf.converter.R
import com.excelto.pdf.converter.language.tr
import com.excelto.pdf.converter.language.trPlural
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import androidx.compose.animation.core.AnimationState
import androidx.compose.animation.core.animateDecay
import androidx.compose.animation.core.exponentialDecay
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculateCentroid
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChanged
import androidx.compose.ui.input.pointer.util.VelocityTracker
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import com.excelto.pdf.converter.core.excel.CellKind
import com.excelto.pdf.converter.core.excel.CellRange
import com.excelto.pdf.converter.core.excel.CellStyle
import com.excelto.pdf.converter.core.excel.ExcelSheet
import com.excelto.pdf.converter.core.excel.ExcelWorkbook
import com.excelto.pdf.converter.core.excel.Formulas
import com.excelto.pdf.converter.core.excel.GridGeometry
import com.excelto.pdf.converter.core.excel.HAlign
import com.excelto.pdf.converter.core.excel.LineStyle
import com.excelto.pdf.converter.core.excel.VAlign
import com.excelto.pdf.converter.ui.theme.LocalPalette
import com.excelto.pdf.converter.ui.theme.Type
import kotlinx.coroutines.launch
import kotlin.math.abs

/** Scroll position (points), zoom, selection and find results of one sheet. */
class GridState {
    var zoom by mutableFloatStateOf(1f)
    var offX by mutableFloatStateOf(0f)
    var offY by mutableFloatStateOf(0f)
    var selected by mutableStateOf<Pair<Int, Int>?>(null)
    var query by mutableStateOf("")
    var results by mutableStateOf<List<Pair<Int, Int>>>(emptyList())
    var resultIndex by mutableIntStateOf(0)
    /** Body viewport in points, set while drawing; used to scroll a cell into view. */
    var viewW = 300f
    var viewH = 500f
    var frozenW = 0f
    var frozenH = 0f
    val bitmaps = HashMap<Int, Bitmap?>()

    fun clamp(g: GridGeometry) {
        offX = offX.coerceIn(0f, maxOf(0f, g.width - frozenW - viewW))
        offY = offY.coerceIn(0f, maxOf(0f, g.height - frozenH - viewH))
    }

    /** Selects a cell and scrolls so it's visible. */
    fun reveal(r: Int, c: Int, g: GridGeometry) {
        selected = r to c
        val x = g.colX[c.coerceAtMost(g.lastCol)] - frozenW
        val y = g.rowY[r.coerceAtMost(g.lastRow)] - frozenH
        if (x >= 0f && (x < offX || x > offX + viewW * 0.8f)) offX = x - viewW * 0.2f
        if (y >= 0f && (y < offY || y > offY + viewH * 0.8f)) offY = y - viewH * 0.3f
        clamp(g)
    }
}

/** Finds cells whose shown text contains the query. Pure logic over the sheet model. */
object SheetSearch {
    fun find(workbook: ExcelWorkbook, sheet: ExcelSheet, query: String, limit: Int = 5000): List<Pair<Int, Int>> {
        val q = query.trim()
        if (q.isEmpty()) return emptyList()
        val out = ArrayList<Pair<Int, Int>>()
        for ((r, row) in sheet.rows) {
            if (r in sheet.hiddenRows) continue
            for (i in 0 until row.size) {
                if (!row.hasValue(i)) continue
                if (workbook.display(row, i).text.contains(q, ignoreCase = true)) {
                    out += r to row.cols[i]
                    if (out.size >= limit) return out
                }
            }
        }
        return out
    }
}

@Composable
fun SheetGrid(l: ExcelViewActivity.Loaded, onLongPress: (Int, Int) -> Unit) {
    val p = LocalPalette.current
    val density = LocalDensity.current.density
    val g = l.geometry
    val s = l.state
    val sheet = l.sheet
    val wb = l.workbook
    val scope = rememberCoroutineScope()
    val rtl = sheet.rightToLeft
    val fr = sheet.freezeRows.coerceIn(0, g.lastRow)
    val fc = sheet.freezeCols.coerceIn(0, g.lastCol)
    s.frozenW = g.colX[fc]
    s.frozenH = g.rowY[fr]

    val headerH = 26f * density
    val digits = (g.lastRow + 1).toString().length
    val headerW = maxOf(34f, digits * 8f + 14f) * density
    val pxPerPt = density * 1.25f

    val colors = Colors(
        header = p.surface.toArgb(), headerText = p.muted.toArgb(), headerLine = p.line.toArgb(),
        headerSelected = p.primarySoft.toArgb(), selection = p.primaryText.toArgb(),
    )

    LaunchedEffect(l) { s.clamp(g) }

    Box(Modifier.fillMaxSize().background(androidx.compose.ui.graphics.Color.White)) {
        Canvas(
            Modifier.fillMaxSize()
                .semantics { contentDescription = tr(R.string.xl_grid_a11y, sheet.name) }
                .pointerInput(l) {
                    // One finger scrolls (with fling); two fingers zoom around their center.
                    awaitEachGesture {
                        awaitFirstDown(requireUnconsumed = false)
                        val tracker = VelocityTracker()
                        var multi = false
                        do {
                            val event = awaitPointerEvent()
                            val pressed = event.changes.count { it.pressed }
                            val scale = pxPerPt * s.zoom
                            if (pressed >= 2) {
                                multi = true
                                val zoom = event.calculateZoom()
                                val c = event.calculateCentroid()
                                if (zoom != 1f && c != Offset.Unspecified) {
                                    val newZoom = (s.zoom * zoom).coerceIn(0.5f, 3f)
                                    val cx = (if (rtl) size.width - c.x else c.x) - headerW
                                    val cy = c.y - headerH
                                    val ptX = cx / scale + s.offX
                                    val ptY = cy / scale + s.offY
                                    s.zoom = newZoom
                                    val ns = pxPerPt * newZoom
                                    s.offX = ptX - cx / ns
                                    s.offY = ptY - cy / ns
                                }
                                val pan = event.calculatePan()
                                s.offX -= (if (rtl) -pan.x else pan.x) / (pxPerPt * s.zoom)
                                s.offY -= pan.y / (pxPerPt * s.zoom)
                                s.clamp(g)
                                event.changes.forEach { if (it.positionChanged()) it.consume() }
                            } else if (pressed == 1 && !multi) {
                                val ch = event.changes.first { it.pressed }
                                tracker.addPosition(ch.uptimeMillis, ch.position)
                                val d = ch.position - ch.previousPosition
                                if (d != Offset.Zero) {
                                    s.offX -= (if (rtl) -d.x else d.x) / scale
                                    s.offY -= d.y / scale
                                    s.clamp(g)
                                    if (abs(d.x) + abs(d.y) > 0.5f) ch.consume()
                                }
                            }
                        } while (event.changes.any { it.pressed })
                        if (!multi) {
                            val v = tracker.calculateVelocity()
                            val scale = pxPerPt * s.zoom
                            val vx = (if (rtl) -v.x else v.x) / scale
                            val vy = v.y / scale
                            if (abs(vx) + abs(vy) > 150f) scope.launch {
                                var lastX = 0f
                                var lastY = 0f
                                launch {
                                    AnimationState(0f, -vx).animateDecay(exponentialDecay()) { s.offX += value - lastX; lastX = value; s.clamp(g) }
                                }
                                AnimationState(0f, -vy).animateDecay(exponentialDecay()) { s.offY += value - lastY; lastY = value; s.clamp(g) }
                            }
                        }
                    }
                }
                .pointerInput(l) {
                    fun cellAt(o: Offset): Pair<Int, Int>? {
                        val x = if (rtl) size.width - o.x else o.x
                        if (x < headerW || o.y < headerH) return null
                        val scale = pxPerPt * s.zoom
                        val fwPx = s.frozenW * scale
                        val fhPx = s.frozenH * scale
                        val ptX = if (x - headerW < fwPx) (x - headerW) / scale else (x - headerW - fwPx) / scale + s.frozenW + s.offX
                        val ptY = if (o.y - headerH < fhPx) (o.y - headerH) / scale else (o.y - headerH - fhPx) / scale + s.frozenH + s.offY
                        return g.anchorOf(g.rowAt(ptY), g.colAt(ptX))
                    }
                    detectTapGestures(
                        onTap = { o -> cellAt(o)?.let { s.selected = it } },
                        onLongPress = { o -> cellAt(o)?.let { s.selected = it; onLongPress(it.first, it.second) } },
                    )
                },
        ) {
            drawIntoCanvas { canvas ->
                val c = canvas.nativeCanvas
                val scale = pxPerPt * s.zoom
                val w = size.width
                val h = size.height
                val fwPx = s.frozenW * scale
                val fhPx = s.frozenH * scale
                s.viewW = maxOf(1f, (w - headerW - fwPx) / scale)
                s.viewH = maxOf(1f, (h - headerH - fhPx) / scale)
                val r = Renderer(c, g, sheet, wb, s, scale, w, rtl, colors)
                // Body, then frozen rows, frozen columns and the frozen corner on top.
                r.region(fr..g.lastRow, fc..g.lastCol, headerW + fwPx, headerH + fhPx, w, h, s.frozenW + s.offX, s.frozenH + s.offY)
                if (fr > 0) r.region(0 until fr, fc..g.lastCol, headerW + fwPx, headerH, w, headerH + fhPx, s.frozenW + s.offX, 0f)
                if (fc > 0) r.region(fr..g.lastRow, 0 until fc, headerW, headerH + fhPx, headerW + fwPx, h, 0f, s.frozenH + s.offY)
                if (fr > 0 && fc > 0) r.region(0 until fr, 0 until fc, headerW, headerH, headerW + fwPx, headerH + fhPx, 0f, 0f)
                if (fr > 0) r.line(headerW, headerH + fhPx, w, headerH + fhPx, 0xFF9AA0A6.toInt(), 1.5f * density)
                if (fc > 0) r.line(headerW + fwPx, headerH, headerW + fwPx, h, 0xFF9AA0A6.toInt(), 1.5f * density)
                r.headers(headerW, headerH, fr, fc, h, density)
            }
        }
        if (sheet.chartCount > 0) {
            Text(
                trPlural(R.plurals.xl_charts_hidden, sheet.chartCount, sheet.chartCount),
                style = Type.small, color = p.text,
                modifier = Modifier.align(Alignment.TopEnd).padding(top = 34.dp, end = 10.dp).clip(RoundedCornerShape(8.dp)).background(p.surface).padding(horizontal = 10.dp, vertical = 6.dp),
            )
        }
        if (s.zoom != 1f) {
            Text(
                "${(s.zoom * 100).toInt()}%", style = Type.small, color = p.text,
                modifier = Modifier.align(Alignment.TopStart).padding(top = 34.dp, start = 48.dp).clip(RoundedCornerShape(8.dp)).background(p.surface).padding(horizontal = 8.dp, vertical = 4.dp),
            )
        }
    }
}

private class Colors(val header: Int, val headerText: Int, val headerLine: Int, val headerSelected: Int, val selection: Int)

/** Draws one frame of the grid with android.graphics, visible cells only. */
private class Renderer(
    val c: Canvas,
    val g: GridGeometry,
    val sheet: ExcelSheet,
    val wb: ExcelWorkbook,
    val s: GridState,
    val scale: Float,
    val viewW: Float,
    val rtl: Boolean,
    val colors: Colors,
) {
    private val fill = Paint()
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val text = TextPaint(Paint.ANTI_ALIAS_FLAG)
    private val grid = Paint().apply { color = 0xFFE2E3E3.toInt(); strokeWidth = 1f }
    private val r = RectF()

    /** Mirrors a horizontal span for right-to-left sheets. */
    private fun mx(left: Float, right: Float): Pair<Float, Float> = if (rtl) (viewW - right) to (viewW - left) else left to right

    fun line(x1: Float, y1: Float, x2: Float, y2: Float, color: Int, width: Float) {
        val (a, b) = mx(x1, x2)
        stroke.color = color; stroke.strokeWidth = width; stroke.pathEffect = null
        c.drawLine(a, y1, b, y2, stroke)
    }

    fun region(rows: IntRange, cols: IntRange, px0: Float, py0: Float, px1: Float, py1: Float, cx0: Float, cy0: Float) {
        if (rows.isEmpty() || cols.isEmpty() || px1 <= px0 || py1 <= py0) return
        val r0 = maxOf(rows.first, g.rowAt(cy0))
        val r1 = minOf(rows.last, g.rowAt(cy0 + (py1 - py0) / scale))
        val c0 = maxOf(cols.first, g.colAt(cx0))
        val c1 = minOf(cols.last, g.colAt(cx0 + (px1 - px0) / scale))
        if (r0 > r1 || c0 > c1) return
        fun x(col: Int) = px0 + (g.colX[col] - cx0) * scale
        fun y(row: Int) = py0 + (g.rowY[row] - cy0) * scale
        fun cellRect(rr: Int, cc: Int, m: CellRange?) {
            val left = x(cc)
            val right = if (m != null) x(minOf(m.lastCol, g.lastCol) + 1) else x(cc + 1)
            val (a, b) = mx(left, right)
            r.set(a, y(rr), b, if (m != null) y(minOf(m.lastRow, g.lastRow) + 1) else y(rr + 1))
        }

        c.save()
        val (ca, cb) = mx(px0, px1)
        c.clipRect(ca, py0, cb, py1)

        // 1. Gridlines.
        for (col in c0..c1 + 1) { val (a, _) = mx(x(col), x(col)); c.drawLine(a, py0, a, py1, grid) }
        for (row in r0..r1 + 1) { val yy = y(row); c.drawLine(ca, yy, cb, yy, grid) }

        // Merged areas that start above or left of the visible cells still need drawing.
        val merges = LinkedHashSet<CellRange>()
        for (row in r0..r1) for (col in c0..c1) {
            (g.mergeStarting(row, col) ?: g.mergeCovering(row, col))?.let { merges += it }
        }

        // 2. Fills (and white under merges, hiding their inner gridlines).
        for (m in merges) {
            val style = styleAt(m.firstRow, m.firstCol)
            cellRect(m.firstRow, m.firstCol, m)
            fill.color = style.fill ?: 0xFFFFFFFF.toInt()
            c.drawRect(r, fill)
        }
        for (row in r0..r1) {
            val data = sheet.rows[row]
            for (col in c0..c1) {
                if (g.mergeStarting(row, col) != null || g.mergeCovering(row, col) != null) continue
                val i = data?.indexOf(col) ?: -1
                val styleIndex = if (i >= 0) data!!.styles[i] else sheet.colStyles[col] ?: continue
                val f = wb.style(styleIndex).fill ?: continue
                cellRect(row, col, null)
                fill.color = f
                c.drawRect(r, fill)
            }
        }

        // 3. Borders.
        for (row in r0..r1) {
            val data = sheet.rows[row] ?: continue
            for (i in 0 until data.size) {
                val col = data.cols[i]
                if (col < c0 || col > c1 || g.mergeCovering(row, col) != null) continue
                val st = wb.style(data.styles[i])
                if (st.left == null && st.right == null && st.top == null && st.bottom == null) continue
                cellRect(row, col, g.mergeStarting(row, col))
                val leftSide = if (rtl) st.right else st.left
                val rightSide = if (rtl) st.left else st.right
                leftSide?.let { border(it.style, it.color, r.left, r.top, r.left, r.bottom) }
                rightSide?.let { border(it.style, it.color, r.right, r.top, r.right, r.bottom) }
                st.top?.let { border(it.style, it.color, r.left, r.top, r.right, r.top) }
                st.bottom?.let { border(it.style, it.color, r.left, r.bottom, r.right, r.bottom) }
            }
        }

        // 4. Pictures.
        sheet.images.forEachIndexed { k, img ->
            val top = g.rowY[img.fromRow.coerceAtMost(g.lastRow)] + img.fromRowOffset
            val leftPt = g.colX[img.fromCol.coerceAtMost(g.lastCol)] + img.fromColOffset
            val rightPt = img.toCol?.let { g.colX[it.coerceAtMost(g.lastCol)] + img.toColOffset } ?: (leftPt + img.widthPt)
            val bottomPt = img.toRow?.let { g.rowY[it.coerceAtMost(g.lastRow)] + img.toRowOffset } ?: (top + img.heightPt)
            if (img.fromRow > rows.last || (img.toRow ?: img.fromRow) < rows.first) return@forEachIndexed
            if (img.fromCol > cols.last || (img.toCol ?: img.fromCol) < cols.first) return@forEachIndexed
            val (a, b) = mx(px0 + (leftPt - cx0) * scale, px0 + (rightPt - cx0) * scale)
            r.set(a, py0 + (top - cy0) * scale, b, py0 + (bottomPt - cy0) * scale)
            if (r.right < 0 || r.left > viewW || r.bottom < py0 || r.top > py1) return@forEachIndexed
            val bmp = s.bitmaps.getOrPut(k) { decode(img.bytes) }
            if (bmp != null) c.drawBitmap(bmp, null, r, Paint(Paint.FILTER_BITMAP_FLAG))
            else { fill.color = 0xFFF1F3F4.toInt(); c.drawRect(r, fill) }
        }

        // 5. Text, with left-aligned text spilling into empty cells on its right, like Excel.
        for (row in r0..r1) {
            val data = sheet.rows[row] ?: continue
            for (i in 0 until data.size) {
                val col = data.cols[i]
                if (col < c0 - 8 || col > c1 || !data.hasValue(i) || g.mergeCovering(row, col) != null) continue
                val shown = wb.display(data, i)
                if (shown.text.isEmpty()) continue
                val st = wb.style(data.styles[i])
                val m = g.mergeStarting(row, col)
                val isNumber = data.kinds[i] == CellKind.NUMBER
                val align = when (st.hAlign) {
                    HAlign.GENERAL -> if (isNumber) HAlign.RIGHT else if (data.kinds[i] == CellKind.BOOL || data.kinds[i] == CellKind.ERROR) HAlign.CENTER else HAlign.LEFT
                    HAlign.FILL, HAlign.JUSTIFY, HAlign.DISTRIBUTED -> HAlign.LEFT
                    HAlign.CENTER_CONTINUOUS -> HAlign.CENTER
                    else -> st.hAlign
                }
                setFont(st, shown.color)
                var lastCol = m?.lastCol ?: col
                if (m == null && !st.wrap && align == HAlign.LEFT && !isNumber) {
                    val need = text.measureText(shown.text) / scale
                    var widthPt = g.colX[col + 1] - g.colX[col]
                    var next = col + 1
                    while (widthPt < need && next <= g.lastCol && next - col < 12) {
                        val j = data.indexOf(next)
                        if (j >= 0 && data.hasValue(j)) break
                        widthPt += g.colX[next + 1] - g.colX[next]
                        lastCol = next
                        next++
                    }
                }
                val box = if (lastCol != col && m == null) CellRange(row, col, row, lastCol) else m
                cellRect(row, col, box)
                drawText(shown.text, st, align, isNumber)
            }
        }

        // 6. Selection and find highlight.
        s.results.getOrNull(s.resultIndex)?.let { (rr, cc) ->
            if (rr in r0..r1 && cc in c0..c1) {
                cellRect(rr, cc, g.mergeStarting(rr, cc))
                fill.color = 0x55FFD54F
                c.drawRect(r, fill)
            }
        }
        s.selected?.let { (rr, cc) ->
            val m = g.mergeStarting(rr, cc)
            if (rr <= r1 && (m?.lastRow ?: rr) >= r0 && cc <= c1 && (m?.lastCol ?: cc) >= c0) {
                cellRect(rr, cc, m)
                stroke.color = colors.selection; stroke.strokeWidth = 2.5f * (scale / 1.25f).coerceIn(1f, 3f); stroke.pathEffect = null
                c.drawRect(r, stroke)
            }
        }
        c.restore()
    }

    private fun styleAt(row: Int, col: Int): CellStyle {
        val data = sheet.rows[row] ?: return CellStyle.DEFAULT
        val i = data.indexOf(col)
        return if (i >= 0) wb.style(data.styles[i]) else sheet.colStyles[col]?.let { wb.style(it) } ?: CellStyle.DEFAULT
    }

    private fun border(style: LineStyle, color: Int, x1: Float, y1: Float, x2: Float, y2: Float) {
        stroke.color = color
        stroke.strokeWidth = (style.width * scale * 0.75f).coerceAtLeast(1f)
        stroke.pathEffect = style.dash?.let { d -> DashPathEffect(FloatArray(d.size) { d[it] * scale }, 0f) }
        c.drawLine(x1, y1, x2, y2, stroke)
        if (style.double) {
            val off = 2f * scale
            if (y1 == y2) c.drawLine(x1, y1 + off, x2, y2 + off, stroke) else c.drawLine(x1 + off, y1, x2 + off, y2, stroke)
        }
    }

    private fun setFont(st: CellStyle, color: Int?) {
        val f = st.font
        val name = f.name.lowercase()
        val family = when {
            listOf("courier", "consolas", "mono").any { it in name } -> Typeface.MONOSPACE
            listOf("times", "cambria", "georgia", "garamond").any { it in name } -> Typeface.SERIF
            else -> Typeface.SANS_SERIF
        }
        text.typeface = Typeface.create(family, when { f.bold && f.italic -> Typeface.BOLD_ITALIC; f.bold -> Typeface.BOLD; f.italic -> Typeface.ITALIC; else -> Typeface.NORMAL })
        text.textSize = f.size * scale
        text.color = color ?: f.color
        text.isUnderlineText = f.underline
        text.isStrikeThruText = f.strike
    }

    private fun drawText(value: String, st: CellStyle, align: HAlign, isNumber: Boolean) {
        val pad = 2f * scale + st.indent * 9f * scale
        c.save()
        c.clipRect(r)
        if (st.wrap) {
            val width = (r.width() - 4f * scale).toInt().coerceAtLeast(1)
            val layout = StaticLayout.Builder.obtain(value, 0, value.length, text, width)
                .setAlignment(when (align) { HAlign.CENTER -> Layout.Alignment.ALIGN_CENTER; HAlign.RIGHT -> Layout.Alignment.ALIGN_OPPOSITE; else -> Layout.Alignment.ALIGN_NORMAL })
                .setIncludePad(false).build()
            val top = when (st.vAlign) {
                VAlign.TOP -> r.top + scale
                VAlign.CENTER -> r.top + (r.height() - layout.height) / 2
                else -> r.bottom - layout.height - scale
            }
            c.translate(r.left + 2f * scale, top)
            layout.draw(c)
        } else {
            val shown = if (isNumber && text.measureText(value) > r.width() - 2 * pad) "#".repeat(((r.width() - 2 * pad) / text.measureText("#")).toInt().coerceAtLeast(1)) else value
            val tw = text.measureText(shown)
            val effective = if (rtl && align == HAlign.LEFT) HAlign.RIGHT else if (rtl && align == HAlign.RIGHT) HAlign.LEFT else align
            val x = when (effective) {
                HAlign.CENTER -> r.left + (r.width() - tw) / 2
                HAlign.RIGHT -> r.right - pad - tw
                else -> r.left + pad
            }
            val fm = text.fontMetrics
            val y = when (st.vAlign) {
                VAlign.TOP -> r.top - fm.ascent + scale
                VAlign.CENTER -> r.centerY() - (fm.ascent + fm.descent) / 2
                else -> r.bottom - fm.descent - scale
            }
            c.drawText(shown, x, y, text)
        }
        c.restore()
    }

    fun headers(headerW: Float, headerH: Float, fr: Int, fc: Int, viewH: Float, density: Float) {
        val fwPx = s.frozenW * scale
        val fhPx = s.frozenH * scale
        text.typeface = Typeface.DEFAULT
        text.textSize = 11f * density
        text.isUnderlineText = false
        text.isStrikeThruText = false
        val sel = s.selected

        // Column letters.
        fill.color = colors.header
        val (ha, hb) = mx(headerW, viewW)
        c.drawRect(ha, 0f, hb, headerH, fill)
        fun columns(cols: IntRange, px0: Float, px1: Float, cx0: Float) {
            if (cols.isEmpty() || px1 <= px0) return
            val c0 = maxOf(cols.first, g.colAt(cx0))
            val c1 = minOf(cols.last, g.colAt(cx0 + (px1 - px0) / scale))
            val (ca, cb) = mx(px0, px1)
            c.save(); c.clipRect(ca, 0f, cb, headerH)
            for (col in c0..c1) {
                val (a, b) = mx(px0 + (g.colX[col] - cx0) * scale, px0 + (g.colX[col + 1] - cx0) * scale)
                if (b - a < 1f) continue
                if (sel?.second == col) { fill.color = colors.headerSelected; c.drawRect(a, 0f, b, headerH, fill) }
                text.color = colors.headerText
                val label = Formulas.columnName(col)
                c.drawText(label, (a + b) / 2 - text.measureText(label) / 2, headerH / 2 + text.textSize / 3, text)
                stroke.color = colors.headerLine; stroke.strokeWidth = 1f; stroke.pathEffect = null
                c.drawLine(b, 0f, b, headerH, stroke)
            }
            c.restore()
        }
        if (fc > 0) columns(0 until fc, headerW, headerW + fwPx, 0f)
        columns(fc..g.lastCol, headerW + fwPx, viewW, s.frozenW + s.offX)

        // Row numbers.
        val (ra, rb) = mx(0f, headerW)
        fill.color = colors.header
        c.drawRect(ra, headerH, rb, viewH, fill)
        fun rowsBand(rows: IntRange, py0: Float, py1: Float, cy0: Float) {
            if (rows.isEmpty() || py1 <= py0) return
            val r0 = maxOf(rows.first, g.rowAt(cy0))
            val r1 = minOf(rows.last, g.rowAt(cy0 + (py1 - py0) / scale))
            c.save(); c.clipRect(ra, py0, rb, py1)
            for (row in r0..r1) {
                val top = py0 + (g.rowY[row] - cy0) * scale
                val bottom = py0 + (g.rowY[row + 1] - cy0) * scale
                if (bottom - top < 1f) continue
                if (sel?.first == row) { fill.color = colors.headerSelected; c.drawRect(ra, top, rb, bottom, fill) }
                text.color = colors.headerText
                val label = (row + 1).toString()
                if (bottom - top > text.textSize * 0.8f) c.drawText(label, (ra + rb) / 2 - text.measureText(label) / 2, (top + bottom) / 2 + text.textSize / 3, text)
                stroke.color = colors.headerLine; stroke.strokeWidth = 1f; stroke.pathEffect = null
                c.drawLine(ra, bottom, rb, bottom, stroke)
            }
            c.restore()
        }
        if (fr > 0) rowsBand(0 until fr, headerH, headerH + fhPx, 0f)
        rowsBand(fr..g.lastRow, headerH + fhPx, viewH, s.frozenH + s.offY)

        // Corner and header edges.
        fill.color = colors.header
        c.drawRect(ra, 0f, rb, headerH, fill)
        stroke.color = colors.headerLine; stroke.strokeWidth = 1f
        c.drawLine(ha, headerH, hb, headerH, stroke)
        val edge = if (rtl) viewW - headerW else headerW
        c.drawLine(edge, 0f, edge, viewH, stroke)
    }

    private fun decode(bytes: ByteArray): Bitmap? = runCatching {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o)
        var sample = 1
        while (o.outWidth / (sample * 2) >= 1200 || o.outHeight / (sample * 2) >= 1200) sample *= 2
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, BitmapFactory.Options().apply { inSampleSize = sample })
    }.getOrNull()
}
