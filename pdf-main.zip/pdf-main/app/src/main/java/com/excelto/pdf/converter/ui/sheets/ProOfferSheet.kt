package com.excelto.pdf.converter.ui.sheets

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.res.stringResource
import com.excelto.pdf.converter.R
import com.excelto.pdf.converter.ads.Ads
import com.excelto.pdf.converter.ui.AppViewModel
import com.excelto.pdf.converter.ui.LocalHost
import com.excelto.pdf.converter.ui.components.IconBadge
import com.excelto.pdf.converter.ui.components.PrimaryButton
import com.excelto.pdf.converter.ui.components.SecondaryButton
import com.excelto.pdf.converter.ui.theme.LocalPalette
import com.excelto.pdf.converter.ui.theme.Type

/**
 * Shown when a free user opens a Pro tool: go Pro, or watch a short video to use the
 * tool once. The video is always the user's choice (rewarded ads must be opt-in).
 */
@Composable
fun ProOfferSheet(vm: AppViewModel, offer: AppViewModel.ProOffer) {
    val p = LocalPalette.current
    val host = LocalHost.current
    var waiting by remember { mutableStateOf(false) }
    val noVideo = stringResource(R.string.pro_sheet_no_video)
    AppSheet(onDismiss = { vm.dismissProOffer() }) {
        Column(Modifier.fillMaxWidth().padding(top = 4.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
            IconBadge(offer.tool.icon, offer.tool.tint, size = 56.dp, iconSize = 28.dp, radius = 18.dp)
            Text(stringResource(R.string.pro_sheet_title, offer.tool.label), style = Type.section.copy(fontSize = 18.sp), color = p.text)
            Text(stringResource(R.string.pro_sheet_body), style = Type.body, color = p.muted)
        }
        Spacer(Modifier.height(10.dp))
        PrimaryButton(stringResource(R.string.pro_sheet_get_pro), { vm.dismissProOffer(); host.openPaywall() })
        if (Ads.enabled) {
            SecondaryButton(
                if (waiting) stringResource(R.string.pro_sheet_loading) else stringResource(R.string.pro_sheet_watch),
                {
                    if (waiting) return@SecondaryButton
                    waiting = true
                    host.watchRewarded(
                        onReward = { waiting = false; vm.grantOnce(offer) },
                        onUnavailable = { waiting = false; vm.say(noVideo) },
                    )
                },
            )
        }
        Row(Modifier.fillMaxWidth().padding(top = 4.dp), horizontalArrangement = Arrangement.Center) {
            Text(stringResource(R.string.pro_sheet_local), style = Type.small, color = p.muted)
        }
    }
}
