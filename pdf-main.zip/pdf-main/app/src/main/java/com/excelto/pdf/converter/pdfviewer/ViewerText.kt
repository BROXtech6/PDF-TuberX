package com.excelto.pdf.converter.pdfviewer

import com.excelto.pdf.converter.core.engine.ChunkStripper
import com.excelto.pdf.converter.core.engine.NRect
import com.excelto.pdf.converter.core.engine.PdfTools
import com.excelto.pdf.converter.core.engine.TextEngine
import com.tom_roush.pdfbox.text.PDFTextStripper

/** Text for the viewer: find matches with their boxes, and a page's text for read-aloud. */
object ViewerText {

    /** One match: page (0-based) and the line's box (0..1 from the top-left), when known. */
    data class Hit(val page: Int, val rect: NRect?)

    /**
     * Finds [query] on every page, case-insensitively, calling [onPage] as each page is
     * searched so results can show while a long document is still being read.
     * Rotated pages report the page without a box.
     */
    fun search(path: String, query: String, isActive: () -> Boolean, onPage: (page: Int, total: Int, hits: List<Hit>) -> Unit) {
        val q = query.trim()
        if (q.isEmpty()) return
        PdfTools.open(path).use { doc ->
            val total = doc.numberOfPages
            val stripper = ChunkStripper()
            for (i in 0 until total) {
                if (!isActive()) return
                val page = doc.getPage(i)
                val hits = runCatching {
                    val chunks = stripper.page(doc, i + 1)
                    if (page.rotation % 360 != 0) {
                        if (chunks.joinToString(" ") { it.text }.contains(q, ignoreCase = true)) listOf(Hit(i, null)) else emptyList()
                    } else {
                        val box = page.cropBox
                        TextEngine.group(chunks, i, box.width, box.height)
                            .filter { it.text.contains(q, ignoreCase = true) }
                            .map { Hit(i, it.rect) }
                    }
                }.getOrDefault(emptyList())
                onPage(i, total, hits)
            }
        }
    }

    /** The plain text of one page (0-based), in reading order. Empty for scans. */
    fun pageText(path: String, index: Int): String = runCatching {
        PdfTools.open(path).use { doc ->
            if (index !in 0 until doc.numberOfPages) return ""
            PDFTextStripper().apply { sortByPosition = true; startPage = index + 1; endPage = index + 1 }.getText(doc)
                .replace(Regex("-\\n(?=\\p{Ll})"), "")
                .replace(Regex("\\s*\\n\\s*"), " ")
                .trim()
        }
    }.getOrDefault("")

    /** Splits text into pieces the speech engine accepts (it has a length limit). */
    fun chunks(text: String, max: Int = 3500): List<String> {
        if (text.length <= max) return listOf(text).filter { it.isNotBlank() }
        val out = ArrayList<String>()
        var rest = text
        while (rest.length > max) {
            val cut = rest.lastIndexOfAny(charArrayOf('.', '!', '?', '؟', '।', '。'), max).takeIf { it > max / 2 } ?: rest.lastIndexOf(' ', max).takeIf { it > 0 } ?: max
            out += rest.substring(0, cut + 1).trim()
            rest = rest.substring(cut + 1)
        }
        if (rest.isNotBlank()) out += rest.trim()
        return out
    }
}
