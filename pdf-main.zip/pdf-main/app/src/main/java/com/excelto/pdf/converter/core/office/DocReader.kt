package com.excelto.pdf.converter.core.office

import com.excelto.pdf.converter.R
import com.excelto.pdf.converter.core.engine.UserFacingException
import org.apache.poi.hwpf.HWPFDocument
import org.apache.poi.hwpf.usermodel.CharacterRun
import org.apache.poi.hwpf.usermodel.Paragraph
import java.io.File

/**
 * Reads old Word 97–2003 (.doc) files with Apache POI's HWPF into the same flow as
 * .docx: paragraphs with their formatting, simple lists, tables and pictures.
 */
object DocReader {

    fun read(file: File): Flow.Document {
        val doc = try {
            file.inputStream().buffered().use { HWPFDocument(it) }
        } catch (e: org.apache.poi.EncryptedDocumentException) {
            throw UserFacingException(R.string.err_word_file_password_protected, "This Word file is password protected. Remove the password in Word and try again.", e)
        } catch (e: Exception) {
            throw UserFacingException(R.string.err_doc_file_couldnt_read, "This .doc file couldn't be read. Save it as .docx in Word and try again.", e)
        }
        val range = doc.range
        val page = runCatching {
            val s = range.getSection(0)
            Flow.Page(
                s.pageWidth / 20f, s.pageHeight / 20f,
                s.marginTop / 20f, s.marginRight / 20f, s.marginBottom / 20f, s.marginLeft / 20f,
            ).takeIf { it.widthPt > 72f && it.heightPt > 72f }
        }.getOrNull() ?: Flow.Page()
        val contentWidth = page.widthPt - page.left - page.right
        val pictures = doc.picturesTable
        val blocks = mutableListOf<Flow.Block>()
        val notes = linkedSetOf<String>()
        val fields = FieldState()

        fun paragraphBlocks(p: Paragraph): List<Flow.Block> {
            val out = mutableListOf<Flow.Block>()
            val runs = mutableListOf<Flow.Run>()
            var pageBreak = false
            for (i in 0 until p.numCharacterRuns()) {
                val cr = p.getCharacterRun(i)
                if (cr.isMarkedDeleted || cr.isVanished) continue
                if (pictures.hasPicture(cr)) {
                    runCatching { pictures.extractPicture(cr, false) }.getOrNull()?.let { pic ->
                        val w = pic.dxaGoal * (pic.horizontalScalingFactor.takeIf { it > 0 } ?: 1000) / 1000f / 20f
                        val h = pic.dyaGoal * (pic.verticalScalingFactor.takeIf { it > 0 } ?: 1000) / 1000f / 20f
                        val ext = pic.suggestFileExtension().lowercase()
                        out += if (ext in setOf("emf", "wmf", "pict", "tiff")) Flow.Image(null, w.coerceAtLeast(40f), h.coerceAtLeast(30f), note = "Picture (${ext.uppercase()})")
                        else Flow.Image(pic.content, w.coerceAtLeast(10f), h.coerceAtLeast(10f))
                    }
                    continue
                }
                val text = fields.clean(cr.text())
                if (text.contains('\u000C')) pageBreak = true
                val shown = text.replace("\u000C", "").replace('\u000B', '\n').replace("\r", "").replace("\u0007", "")
                    .filter { it == '\n' || it == '\t' || it >= ' ' }
                if (shown.isNotEmpty()) runs += Flow.Run(shown, style(cr))
            }
            val align = when (p.justification.toInt()) { 1 -> Flow.Align.CENTER; 2 -> Flow.Align.RIGHT; 3, 4, 5 -> Flow.Align.JUSTIFY; else -> Flow.Align.LEFT }
            val para = Flow.Paragraph(
                runs = runs,
                align = align,
                indentLeft = p.indentFromLeft / 20f,
                indentRight = p.indentFromRight / 20f,
                firstLine = p.firstLineIndent / 20f,
                spaceBefore = p.spacingBefore / 20f,
                spaceAfter = p.spacingAfter / 20f,
                marker = if (p.isInList) "•" else null,
                rtl = runs.any { r -> r.text.any { Character.getDirectionality(it).let { d -> d == Character.DIRECTIONALITY_RIGHT_TO_LEFT || d == Character.DIRECTIONALITY_RIGHT_TO_LEFT_ARABIC } } },
                pageBreakBefore = p.pageBreakBefore(),
            )
            if (runs.isNotEmpty() || out.isEmpty()) out.add(0, para)
            if (pageBreak) out += Flow.PageBreak
            return out
        }

        var i = 0
        val total = range.numParagraphs()
        while (i < total) {
            val p = range.getParagraph(i)
            if (p.isInTable) {
                val table = runCatching { range.getTable(p) }.getOrNull()
                if (table != null) {
                    val rows = (0 until table.numRows()).map { r ->
                        val row = table.getRow(r)
                        Flow.Row((0 until row.numCells()).map { c ->
                            val cell = row.getCell(c)
                            Flow.Cell((0 until cell.numParagraphs()).flatMap { k -> paragraphBlocks(cell.getParagraph(k)) })
                        }, header = runCatching { row.isTableHeader }.getOrDefault(false))
                    }
                    val cols = rows.maxOfOrNull { it.cells.size } ?: 1
                    blocks += Flow.Table(rows, List(cols) { contentWidth / cols })
                    i += table.numParagraphs().coerceAtLeast(1)
                    continue
                }
            }
            blocks += paragraphBlocks(p)
            i++
        }
        if (blocks.isEmpty()) blocks += Flow.Paragraph(emptyList())
        if (runCatching { doc.headerStoryRange?.text()?.isNotBlank() == true }.getOrDefault(false)) notes += runCatching { com.excelto.pdf.converter.language.tr(com.excelto.pdf.converter.R.string.note_no_headers) }.getOrDefault("Not shown: headers and footers.")
        return Flow.Document(blocks, page, notes.toList())
    }

    private fun style(cr: CharacterRun): Flow.Style {
        val color = runCatching { cr.ico24 }.getOrDefault(-1).let { c ->
            // ico24 is 0x00BBGGRR; -1 means automatic.
            if (c == -1 || c == 0xFF000000.toInt()) null
            else (0xFF shl 24) or ((c and 0xFF) shl 16) or (c and 0xFF00) or ((c shr 16) and 0xFF)
        }
        return Flow.Style(
            bold = cr.isBold,
            italic = cr.isItalic,
            underline = cr.underlineCode != 0,
            strike = cr.isStrikeThrough || cr.isDoubleStrikeThrough,
            sizePt = (cr.fontSize / 2f).takeIf { it >= 1f } ?: 11f,
            color = color,
            font = cr.fontName,
            vertAlign = when (cr.subSuperScriptIndex.toInt()) { 1 -> 1; 2 -> -1; else -> 0 },
            caps = cr.isCapitalized,
        )
    }

    /** Drops field codes (\u0013 code \u0014 result \u0015) and keeps the shown result. */
    private class FieldState {
        private var depth = 0
        private val inCode = ArrayList<Boolean>()

        fun clean(text: String): String = buildString {
            for (ch in text) when (ch) {
                '\u0013' -> { depth++; inCode += true }
                '\u0014' -> if (inCode.isNotEmpty()) inCode[inCode.lastIndex] = false
                '\u0015' -> { if (depth > 0) depth--; if (inCode.isNotEmpty()) inCode.removeAt(inCode.lastIndex) }
                '\u0001', '\u0008' -> Unit
                else -> if (inCode.none { it }) append(ch)
            }
        }
    }
}
