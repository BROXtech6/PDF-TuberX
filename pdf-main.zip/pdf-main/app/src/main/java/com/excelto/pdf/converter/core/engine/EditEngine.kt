package com.excelto.pdf.converter.core.engine

import com.excelto.pdf.converter.R
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import com.tom_roush.pdfbox.cos.COSArray
import com.tom_roush.pdfbox.cos.COSBase
import com.tom_roush.pdfbox.cos.COSDictionary
import com.tom_roush.pdfbox.cos.COSName
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.pdmodel.PDPage
import com.tom_roush.pdfbox.pdmodel.PDPageContentStream
import com.tom_roush.pdfbox.pdmodel.common.PDRectangle
import com.tom_roush.pdfbox.pdmodel.graphics.blend.BlendMode
import com.tom_roush.pdfbox.pdmodel.graphics.color.PDColor
import com.tom_roush.pdfbox.pdmodel.graphics.color.PDDeviceRGB
import com.tom_roush.pdfbox.pdmodel.graphics.image.JPEGFactory
import com.tom_roush.pdfbox.pdmodel.graphics.image.LosslessFactory
import com.tom_roush.pdfbox.pdmodel.graphics.state.PDExtendedGraphicsState
import com.tom_roush.pdfbox.pdmodel.interactive.annotation.PDAnnotationText
import com.tom_roush.pdfbox.pdmodel.interactive.form.PDTerminalField
import java.io.File
import java.util.Collections
import java.util.IdentityHashMap

/** A point on a page, 0..1 from the top-left corner of the page as it is shown. */
data class NPoint(val x: Float, val y: Float)

/** A rectangle on a page, 0..1 from the top-left corner of the page as it is shown. */
data class NRect(val left: Float, val top: Float, val right: Float, val bottom: Float) {
    val width get() = right - left
    val height get() = bottom - top
    fun normalized() = NRect(minOf(left, right), minOf(top, bottom), maxOf(left, right), maxOf(top, bottom))
    fun contains(p: NPoint) = p.x in left..right && p.y in top..bottom
}

/** One change the user made in the editor. [page] is 0-based. */
sealed interface Mark {
    val page: Int

    data class Highlight(override val page: Int, val rect: NRect) : Mark
    data class Ink(override val page: Int, val strokes: List<List<NPoint>>, val color: Int, val width: Float) : Mark
    data class Note(override val page: Int, val at: NPoint, val text: String) : Mark

    /** New text. With [coverOriginal] a white box first hides the words underneath. */
    data class TextBox(override val page: Int, val rect: NRect, val text: String, val fontSize: Float, val color: Int, val coverOriginal: Boolean) : Mark
    data class Signature(override val page: Int, val rect: NRect, val imagePath: String) : Mark

    /** Removed for good: the page is flattened to an image with these areas blacked out. */
    data class Redaction(override val page: Int, val rect: NRect) : Mark
}

object EditEngine {

    private const val REDACT_DPI = 200f
    private const val HIGHLIGHT = 0xFFFFE234.toInt()
    private const val NOTE_INK = 0xFF4A3700.toInt()
    private const val NOTE_PAPER = 0xFFFFF1A8.toInt()

    fun apply(input: PdfTools.Input, marks: List<Mark>, out: File, workDir: File, progress: Progress) {
        val stamped = File(workDir, "stamped_${System.currentTimeMillis()}.pdf")
        try {
            val redactions = marks.filterIsInstance<Mark.Redaction>()
            PdfTools.open(input.path, input.password).use { doc ->
                PdfTools.requireOwnerRights(doc)
                // Edited copies are saved without the old password; Android's renderer can't read encrypted files.
                doc.isAllSecurityToBeRemoved = true
                stamp(doc, marks.filter { it !is Mark.Redaction }, progress)
                doc.save(if (redactions.isEmpty()) out else stamped)
            }
            if (redactions.isNotEmpty()) flattenRedactedPages(stamped, redactions, out, progress)
            progress.report(100)
        } catch (e: Throwable) {
            out.delete()
            throw e
        } finally {
            stamped.delete()
        }
    }

    private fun stamp(doc: PDDocument, marks: List<Mark>, progress: Progress) {
        val text = PdfText(doc)
        val byPage = marks.groupBy { it.page }
        val pages = byPage.keys.sorted()
        pages.forEachIndexed { index, page0 ->
            if (page0 >= doc.numberOfPages) return@forEachIndexed
            val page = doc.getPage(page0)
            val frame = PageFrame(page)
            PDPageContentStream(doc, page, PDPageContentStream.AppendMode.APPEND, true, true).use { cs ->
                cs.transform(frame.matrix)
                for (mark in byPage.getValue(page0)) draw(doc, page, mark, cs, frame, text)
            }
            progress.step(index + 1, pages.size, 5, 70)
        }
    }

    private fun setFill(cs: PDPageContentStream, color: Int) =
        cs.setNonStrokingColor(PdfText.red(color), PdfText.green(color), PdfText.blue(color))

    private fun draw(doc: PDDocument, page: PDPage, mark: Mark, cs: PDPageContentStream, f: PageFrame, text: PdfText) {
        when (mark) {
            is Mark.Highlight -> {
                val r = mark.rect.normalized()
                cs.saveGraphicsState()
                cs.setGraphicsStateParameters(PDExtendedGraphicsState().apply {
                    nonStrokingAlphaConstant = 0.45f
                    blendMode = BlendMode.MULTIPLY
                })
                setFill(cs, HIGHLIGHT)
                cs.addRect(f.x(r.left), f.y(r.bottom), r.width * f.width, r.height * f.height)
                cs.fill()
                cs.restoreGraphicsState()
            }
            is Mark.Ink -> {
                cs.saveGraphicsState()
                cs.setStrokingColor(PdfText.red(mark.color), PdfText.green(mark.color), PdfText.blue(mark.color))
                cs.setLineWidth((mark.width * f.width).coerceAtLeast(0.5f))
                cs.setLineCapStyle(1)
                cs.setLineJoinStyle(1)
                for (stroke in mark.strokes) {
                    if (stroke.isEmpty()) continue
                    cs.moveTo(f.x(stroke[0].x), f.y(stroke[0].y))
                    if (stroke.size == 1) cs.lineTo(f.x(stroke[0].x) + 0.1f, f.y(stroke[0].y))
                    for (pt in stroke.drop(1)) cs.lineTo(f.x(pt.x), f.y(pt.y))
                    cs.stroke()
                }
                cs.restoreGraphicsState()
            }
            is Mark.Note -> {
                val px = f.x(mark.at.x)
                val py = f.y(mark.at.y)
                val note = PDAnnotationText().apply {
                    rectangle = f.pageRect(px, py - 20f, px + 20f, py)
                    contents = mark.text
                    titlePopup = "Note"
                    name = PDAnnotationText.NAME_COMMENT
                    color = PDColor(floatArrayOf(1f, 214 / 255f, 107 / 255f), PDDeviceRGB.INSTANCE)
                    isNoRotate = true
                    isPrinted = true
                }
                page.annotations = page.annotations.toMutableList().apply { add(note) }
            }
            is Mark.TextBox -> {
                val r = mark.rect.normalized()
                val left = f.x(r.left)
                val right = f.x(r.right)
                val bottom = f.y(r.bottom)
                val top = f.y(r.top)
                val size = (mark.fontSize * f.height).coerceIn(4f, 72f)
                if (mark.coverOriginal) {
                    cs.saveGraphicsState()
                    setFill(cs, Color.WHITE)
                    cs.addRect(left - 1f, bottom - size * 0.3f, (right - left) + 2f, (top - bottom) + size * 0.35f)
                    cs.fill()
                    cs.restoreGraphicsState()
                }
                drawColumn(cs, text, mark.text, left + 1f, maxOf(right, left + 40f), top + size * 0.2f, bottom - size, size, mark.color)
            }
            is Mark.Signature -> {
                val bitmap = BitmapFactory.decodeFile(mark.imagePath) ?: throw UserFacingException(R.string.err_signature_image_couldnt_read, "The signature image couldn't be read.")
                try {
                    val image = LosslessFactory.createFromImage(doc, bitmap)
                    val r = mark.rect.normalized()
                    val boxW = r.width * f.width
                    val boxH = r.height * f.height
                    val scale = minOf(boxW / bitmap.width, boxH / bitmap.height)
                    val w = bitmap.width * scale
                    val h = bitmap.height * scale
                    cs.drawImage(image, f.x(r.left) + (boxW - w) / 2, f.y(r.bottom) + (boxH - h) / 2, w, h)
                } finally {
                    bitmap.recycle()
                }
            }
            is Mark.Redaction -> Unit
        }
    }

    /** Wrapped text from [top] down to [bottom], right-aligned for right-to-left text. */
    private fun drawColumn(cs: PDPageContentStream, text: PdfText, value: String, left: Float, right: Float, top: Float, bottom: Float, size: Float, color: Int) {
        val leading = size * 1.15f
        val rtl = PdfText.isRtlParagraph(value)
        var baseline = top - leading + size * 0.2f
        for (line in text.wrap(value, size, right - left)) {
            if (baseline < bottom) break
            if (rtl) text.drawLine(cs, line, right, baseline, size, color, TextAlign.RIGHT)
            else text.drawLine(cs, line, left, baseline, size, color)
            baseline -= leading
        }
    }

    /**
     * True redaction: each page with a redaction is rendered to an image, the areas are
     * painted black on the image, and the page is replaced by that image. The hidden
     * text no longer exists anywhere in the file.
     */
    private fun flattenRedactedPages(source: File, redactions: List<Mark.Redaction>, out: File, progress: Progress) {
        val byPage = redactions.groupBy { it.page }
        PDDocument.load(source).use { doc ->
            ParcelFileDescriptor.open(source, ParcelFileDescriptor.MODE_READ_ONLY).use { fd ->
                PdfRenderer(fd).use { renderer ->
                    val total = doc.numberOfPages
                    val oldAnnotations = Collections.newSetFromMap(IdentityHashMap<COSBase, Boolean>())
                    for (index in 0 until total) {
                        progress.check()
                        val boxes = byPage[index] ?: continue
                        val old = doc.getPage(index)
                        val frame = PageFrame(old)
                        old.cosObject.getCOSArray(COSName.ANNOTS)?.forEach { oldAnnotations += it.let { a -> (a as? com.tom_roush.pdfbox.cos.COSObject)?.`object` ?: a } }
                        val replacement = PDPage(PDRectangle(frame.width, frame.height))
                        doc.pages.insertBefore(replacement, old)
                        val image = rasterize(doc, renderer, index, boxes)
                        PDPageContentStream(doc, replacement).use { cs -> cs.drawImage(image, 0f, 0f, frame.width, frame.height) }
                        doc.pages.remove(old)
                        // Links or bookmarks may still point at the old page: leave nothing readable in it.
                        listOf(COSName.CONTENTS, COSName.RESOURCES, COSName.ANNOTS, COSName.METADATA, COSName.getPDFName("Thumb"), COSName.getPDFName("PieceInfo"))
                            .forEach { old.cosObject.removeItem(it) }
                        progress.step(index + 1, total, 70, 95)
                    }
                    removeHiddenCopies(doc, oldAnnotations)
                    doc.save(out)
                }
            }
        }
    }

    /** Tagged-PDF structure and form values can repeat page text; drop them for redacted pages. */
    private fun removeHiddenCopies(doc: PDDocument, oldAnnotations: Set<COSBase>) {
        val catalog = doc.documentCatalog.cosObject
        catalog.removeItem(COSName.STRUCT_TREE_ROOT)
        catalog.removeItem(COSName.MARK_INFO)
        val form = doc.documentCatalog.acroForm ?: return
        for (field in form.fieldTree.filterIsInstance<PDTerminalField>().toList()) {
            val widgets = field.widgets
            if (widgets.isEmpty() || !widgets.all { it.cosObject in oldAnnotations }) continue
            val parent = field.parent
            if (parent == null) {
                form.cosObject.getCOSArray(COSName.FIELDS)?.let { removeFrom(it, field.cosObject) }
            } else {
                parent.cosObject.getCOSArray(COSName.KIDS)?.let { removeFrom(it, field.cosObject) }
            }
        }
    }

    private fun removeFrom(array: COSArray, item: COSDictionary) {
        for (i in array.size() - 1 downTo 0) {
            val entry = array.getObject(i)
            if (entry === item) array.remove(i)
        }
    }

    private fun rasterize(doc: PDDocument, renderer: PdfRenderer, index: Int, boxes: List<Mark.Redaction>) =
        renderer.openPage(index).use { page ->
            val scale = REDACT_DPI / 72f
            val bitmap = Bitmap.createBitmap((page.width * scale).toInt().coerceAtLeast(1), (page.height * scale).toInt().coerceAtLeast(1), Bitmap.Config.ARGB_8888)
            try {
                bitmap.eraseColor(Color.WHITE)
                page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_PRINT)
                val canvas = Canvas(bitmap)
                val paint = Paint().apply { color = Color.BLACK; style = Paint.Style.FILL }
                for (b in boxes) {
                    val r = b.rect.normalized()
                    canvas.drawRect(RectF(r.left * bitmap.width, r.top * bitmap.height, r.right * bitmap.width, r.bottom * bitmap.height), paint)
                }
                JPEGFactory.createFromImage(doc, bitmap, 0.88f)
            } finally {
                bitmap.recycle()
            }
        }
}
