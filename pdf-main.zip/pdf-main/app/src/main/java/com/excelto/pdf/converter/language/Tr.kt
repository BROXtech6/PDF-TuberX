package com.excelto.pdf.converter.language

import android.content.Context
import android.content.res.Configuration
import android.os.LocaleList
import androidx.annotation.PluralsRes
import androidx.annotation.StringRes
import androidx.appcompat.app.AppCompatDelegate
import com.excelto.pdf.converter.app.App

/**
 * Text in the app's language from anywhere, including code that has no screen (view
 * model messages, job titles, tool names). Screens get the same strings, since every
 * language change reopens them.
 */
private object Localized {
    @Volatile private var cached: Pair<String, Context>? = null

    fun context(): Context {
        val app: Context = App.getInstance()
        val tags = AppCompatDelegate.getApplicationLocales().toLanguageTags()
        if (tags.isEmpty()) return app
        cached?.let { (tag, context) -> if (tag == tags) return context }
        // Android 12 and older keep the app context in the phone's language, so build one.
        val config = Configuration(app.resources.configuration).apply { setLocales(LocaleList.forLanguageTags(tags)) }
        return app.createConfigurationContext(config).also { cached = tags to it }
    }
}

fun tr(@StringRes id: Int): String = Localized.context().getString(id)

fun tr(@StringRes id: Int, vararg args: Any?): String = Localized.context().getString(id, *args)

fun trPlural(@PluralsRes id: Int, count: Int, vararg args: Any?): String =
    Localized.context().resources.getQuantityString(id, count, *args)
