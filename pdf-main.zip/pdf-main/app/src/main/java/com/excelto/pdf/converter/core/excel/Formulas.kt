package com.excelto.pdf.converter.core.excel

/** Formula text helpers. Pure logic, unit tested. */
object Formulas {

    // A cell reference not inside a string or a sheet/function name: optional $, 1–3 letters, optional $, digits.
    private val REF = Regex("""(?<![A-Za-z0-9_."'])(\$?)([A-Z]{1,3})(\$?)(\d{1,7})(?![A-Za-z0-9_(])""")

    /**
     * Moves the relative references in a shared formula from its master cell by
     * [dRow] rows and [dCol] columns, as Excel does when filling: A1+$B$1 moved one row
     * down becomes A2+$B$1. Text inside quotes is left alone.
     */
    fun shift(formula: String, dRow: Int, dCol: Int): String {
        if (dRow == 0 && dCol == 0) return formula
        val out = StringBuilder()
        var inString = false
        var start = 0
        fun flush(end: Int) {
            val part = formula.substring(start, end)
            out.append(if (inString) part else REF.replace(part) { m ->
                val (colAbs, letters, rowAbs, digits) = m.destructured
                val col = if (colAbs.isEmpty()) CellRange.column(letters) + dCol else CellRange.column(letters)
                val row = if (rowAbs.isEmpty()) digits.toInt() + dRow else digits.toInt()
                if (col < 0 || row < 1) m.value else "$colAbs${columnName(col)}$rowAbs$row"
            })
            start = end
        }
        for (i in formula.indices) {
            if (formula[i] == '"') {
                flush(if (inString) i + 1 else i)
                inString = !inString
            }
        }
        flush(formula.length)
        return out.toString()
    }

    /** 0 → A, 25 → Z, 26 → AA. */
    fun columnName(col: Int): String {
        var n = col + 1
        val sb = StringBuilder()
        while (n > 0) {
            val r = (n - 1) % 26
            sb.append('A' + r)
            n = (n - 1) / 26
        }
        return sb.reverse().toString()
    }
}
