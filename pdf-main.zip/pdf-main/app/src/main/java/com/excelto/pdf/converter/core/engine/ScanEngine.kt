package com.excelto.pdf.converter.core.engine

import com.excelto.pdf.converter.R
import android.content.ContentResolver
import android.net.Uri
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.TextRecognizer
import com.google.mlkit.vision.text.chinese.ChineseTextRecognizerOptions
import com.google.mlkit.vision.text.devanagari.DevanagariTextRecognizerOptions
import com.google.mlkit.vision.text.japanese.JapaneseTextRecognizerOptions
import com.google.mlkit.vision.text.korean.KoreanTextRecognizerOptions
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import com.tom_roush.pdfbox.io.MemoryUsageSetting
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.pdmodel.PDPage
import com.tom_roush.pdfbox.pdmodel.PDPageContentStream
import com.tom_roush.pdfbox.pdmodel.common.PDRectangle
import com.tom_roush.pdfbox.pdmodel.font.PDFont
import com.tom_roush.pdfbox.pdmodel.graphics.image.JPEGFactory
import com.tom_roush.pdfbox.pdmodel.graphics.state.RenderingMode
import java.io.File

/** Scripts ML Kit can read on the phone. Arabic and Urdu aren't supported by ML Kit. */
enum class OcrScript(@androidx.annotation.StringRes private val labelRes: Int) { LATIN(R.string.ocr_latin), DEVANAGARI(R.string.ocr_hindi), CHINESE(R.string.ocr_chinese), JAPANESE(R.string.ocr_japanese), KOREAN(R.string.ocr_korean); val label: String get() = com.excelto.pdf.converter.language.tr(labelRes) }

/**
 * Builds a PDF from scanned pages. With text recognition on, each page gets an
 * invisible text layer placed over the words, so the PDF can be searched and copied.
 */
object ScanEngine {

    private const val PAGE_WIDTH = 595f // A4 width in points

    fun build(resolver: ContentResolver, pages: List<Uri>, ocr: OcrScript?, out: File, progress: Progress) {
        require(pages.isNotEmpty()) { "Scan at least one page" }
        val recognizer: TextRecognizer? = ocr?.let { recognizerFor(it) }
        try {
            PdfTools.writing(out) {
                PDDocument(MemoryUsageSetting.setupTempFileOnly()).use { doc ->
                    val fonts = PdfFonts.FontSet(doc)
                    pages.forEachIndexed { index, uri ->
                        progress.check()
                        val bitmap = ImageToPdfEngine.load(resolver, uri) ?: throw UserFacingException(R.string.err_scanned_page_couldnt_read, "A scanned page couldn't be read.")
                        try {
                            val scale = PAGE_WIDTH / bitmap.width
                            val pageHeight = bitmap.height * scale
                            val page = PDPage(PDRectangle(PAGE_WIDTH, pageHeight))
                            doc.addPage(page)
                            val image = JPEGFactory.createFromImage(doc, bitmap, 0.85f)
                            PDPageContentStream(doc, page).use { cs ->
                                cs.drawImage(image, 0f, 0f, PAGE_WIDTH, pageHeight)
                                if (recognizer != null) {
                                    val text = runCatching { Tasks.await(recognizer.process(InputImage.fromBitmap(bitmap, 0))) }.getOrNull()
                                    text?.textBlocks?.flatMap { it.lines }?.forEach { line ->
                                        val box = line.boundingBox ?: return@forEach
                                        invisibleLine(cs, fonts, line.text.trim(), box.left * scale, pageHeight - box.bottom * scale, box.width() * scale, box.height() * scale)
                                    }
                                }
                            }
                        } finally {
                            bitmap.recycle()
                        }
                        progress.step(index + 1, pages.size)
                    }
                    doc.save(out)
                }
            }
        } finally {
            recognizer?.close()
        }
        progress.report(100)
    }

    /**
     * Writes [words] as invisible text over the line's box, stretched horizontally to fit
     * it. The text stays in reading (logical) order so search and copy work. Characters
     * no embeddable font has are left out.
     */
    internal fun invisibleLine(cs: PDPageContentStream, fonts: PdfFonts.FontSet, words: String, left: Float, bottom: Float, width: Float, height: Float) {
        if (words.isEmpty() || width <= 0f || height <= 0f) return
        val runs = mutableListOf<Pair<PDFont, StringBuilder>>()
        words.codePoints().forEach { cp ->
            val font = if (Character.isWhitespace(cp)) runs.lastOrNull()?.first ?: fonts.helvetica else fonts.fontFor(cp) ?: return@forEach
            val last = runs.lastOrNull()
            if (last != null && last.first === font) last.second.appendCodePoint(if (Character.isWhitespace(cp)) ' '.code else cp)
            else runs += font to StringBuilder().appendCodePoint(if (Character.isWhitespace(cp)) ' '.code else cp)
        }
        if (runs.isEmpty()) return
        val fontSize = (height * 0.85f).coerceAtLeast(2f)
        val natural = runs.sumOf { (font, text) -> runCatching { font.getStringWidth(text.toString()).toDouble() }.getOrDefault(0.0) }.toFloat() / 1000f * fontSize
        cs.beginText()
        cs.setRenderingMode(RenderingMode.NEITHER)
        if (natural > 0f) cs.setHorizontalScaling((width / natural * 100f).coerceIn(10f, 500f))
        cs.newLineAtOffset(left, bottom + height * 0.15f)
        for ((font, text) in runs) {
            cs.setFont(font, fontSize)
            runCatching { cs.showText(text.toString()) }
        }
        cs.endText()
    }

    internal fun recognizerFor(script: OcrScript): TextRecognizer = when (script) {
        OcrScript.LATIN -> TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
        OcrScript.DEVANAGARI -> TextRecognition.getClient(DevanagariTextRecognizerOptions.Builder().build())
        OcrScript.CHINESE -> TextRecognition.getClient(ChineseTextRecognizerOptions.Builder().build())
        OcrScript.JAPANESE -> TextRecognition.getClient(JapaneseTextRecognizerOptions.Builder().build())
        OcrScript.KOREAN -> TextRecognition.getClient(KoreanTextRecognizerOptions.Builder().build())
    }
}
