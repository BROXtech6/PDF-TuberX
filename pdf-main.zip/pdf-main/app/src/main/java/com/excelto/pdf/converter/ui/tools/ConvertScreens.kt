package com.excelto.pdf.converter.ui.tools

import com.excelto.pdf.converter.R
import com.excelto.pdf.converter.language.tr
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import com.excelto.pdf.converter.core.engine.HtmlOptions
import com.excelto.pdf.converter.core.engine.HtmlToPdfEngine
import com.excelto.pdf.converter.ui.AppViewModel
import com.excelto.pdf.converter.ui.Route
import com.excelto.pdf.converter.ui.components.ChoiceRow
import com.excelto.pdf.converter.ui.sheets.FilePickerSheet
import com.excelto.pdf.converter.ui.sheets.appTextFieldColors

@Composable
fun HtmlToPdfScreen(vm: AppViewModel, route: Route.ToolScreen) {
    var mode by rememberSaveable { mutableIntStateOf(if (route.files.isNotEmpty()) 1 else 0) } // 0 = link, 1 = file
    var link by rememberSaveable { mutableStateOf(route.text.orEmpty()) }
    var size by rememberSaveable { mutableIntStateOf(0) }
    var orientation by rememberSaveable { mutableIntStateOf(0) }
    var margin by rememberSaveable { mutableIntStateOf(1) }
    var picking by rememberSaveable { mutableStateOf(false) }
    val url = HtmlToPdfEngine.findUrl(link) ?: link.trim().takeIf { it.contains('.') && !it.contains(' ') }?.let { "https://$it" }
    val file = route.files.firstOrNull()
    val ready = if (mode == 0) url != null else file != null
    ToolScaffold(
        vm, route, tr(R.string.cat_to_pdf), enabled = ready, showFileCard = false, requireFile = false,
        onStart = {
            val (w, h) = if (size == 0) 595f to 842f else 612f to 792f
            val options = HtmlOptions(w, h, landscape = orientation == 1, marginPt = listOf(0f, 36f, 72f)[margin])
            vm.runHtmlToPdf(if (mode == 0) url!! else file!!.path, if (mode == 0) null else file, options)
        },
    ) {
        ChoiceRow(listOf(tr(R.string.html_web_link), tr(R.string.html_file)), mode) { mode = it }
        if (mode == 0) {
            OutlinedTextField(
                link, { link = it }, singleLine = true, colors = appTextFieldColors(),
                label = { Text(tr(R.string.html_address)) }, placeholder = { Text("https://example.com") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri),
                isError = link.isNotBlank() && url == null,
                supportingText = { Text(tr(R.string.html_address_hint)) },
                modifier = Modifier.fillMaxWidth(),
            )
        } else {
            FileCard(file) { picking = true }
            Note(tr(R.string.html_assets_note))
        }
        Label(tr(R.string.opt_page_size))
        ChoiceRow(listOf("A4", "Letter"), size) { size = it }
        MoreOptions {
            Label(tr(R.string.opt_orientation))
            ChoiceRow(listOf(tr(R.string.opt_portrait), tr(R.string.opt_landscape)), orientation) { orientation = it }
            Label(tr(R.string.opt_margins))
            ChoiceRow(listOf(tr(R.string.opt_none), tr(R.string.opt_normal), tr(R.string.opt_wide)), margin) { margin = it }
        }
    }
    if (picking) FilePickerSheet(vm, route.tool, route.files, onChosen = { vm.setToolFiles(it) }, onDismiss = { picking = false })
}

@Composable
fun PdfToWordScreen(vm: AppViewModel, route: Route.ToolScreen) {
    ToolScaffold(vm, route, tr(R.string.word_go), enabled = true, onStart = { vm.runPdfToWord(route.files.first()) }) {
        InfoCard(
            tr(R.string.word_info_title),
            tr(R.string.word_info),
        )
        Note(tr(R.string.word_note))
    }
}

@Composable
fun PdfToPowerPointScreen(vm: AppViewModel, route: Route.ToolScreen) {
    ToolScaffold(vm, route, tr(R.string.ppt_go), enabled = true, onStart = { vm.runPdfToPowerPoint(route.files.first()) }) {
        InfoCard(
            tr(R.string.tool_pdf_to_powerpoint_desc),
            tr(R.string.ppt_info),
        )
        Note(tr(R.string.ppt_note))
    }
}

@Composable
fun PdfToPdfAScreen(vm: AppViewModel, route: Route.ToolScreen) {
    ToolScaffold(vm, route, tr(R.string.pdfa_go), enabled = true, onStart = { vm.runPdfToPdfA(route.files.first()) }) {
        InfoCard(
            tr(R.string.pdfa_info_title),
            tr(R.string.pdfa_info),
        )
        Note(tr(R.string.pdfa_note))
    }
}

@Composable
fun WordToPdfScreen(vm: AppViewModel, route: Route.ToolScreen) {
    ToolScaffold(vm, route, tr(R.string.cat_to_pdf), enabled = true, onStart = { vm.runWordToPdf(route.files.first()) }) {
        InfoCard(
            tr(R.string.docx_info_title),
            tr(R.string.docx_info),
        )
        Note(tr(R.string.docx_note))
    }
}

@Composable
fun PowerPointToPdfScreen(vm: AppViewModel, route: Route.ToolScreen) {
    var hidden by rememberSaveable { mutableStateOf(false) }
    ToolScaffold(vm, route, tr(R.string.cat_to_pdf), enabled = true, onStart = { vm.runPowerPointToPdf(route.files.first(), hidden) }) {
        InfoCard(
            tr(R.string.pptx_info_title),
            tr(R.string.pptx_info),
        )
        MoreOptions {
            com.excelto.pdf.converter.ui.components.ChoiceBox(tr(R.string.pptx_hidden), hidden, { hidden = !hidden }, androidx.compose.ui.Modifier.fillMaxWidth())
        }
        Note(tr(R.string.pptx_note))
    }
}
