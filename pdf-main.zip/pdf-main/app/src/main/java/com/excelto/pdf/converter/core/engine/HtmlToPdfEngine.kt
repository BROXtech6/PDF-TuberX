package com.excelto.pdf.converter.core.engine

import com.excelto.pdf.converter.R
import android.annotation.SuppressLint
import android.content.Context
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import android.print.PdfPrinter
import android.print.PrintAttributes
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.io.File

/** Page setup for HTML to PDF, in points. */
data class HtmlOptions(
    val pageWidthPt: Float = 595f,
    val pageHeightPt: Float = 842f,
    val landscape: Boolean = false,
    val marginPt: Float = 36f,
) {
    val width get() = if (landscape) maxOf(pageWidthPt, pageHeightPt) else minOf(pageWidthPt, pageHeightPt)
    val height get() = if (landscape) minOf(pageWidthPt, pageHeightPt) else maxOf(pageWidthPt, pageHeightPt)
}

/**
 * Saves a web page or an HTML file as a PDF. The page is loaded in an off-screen
 * WebView on the phone and printed with Chromium's own PDF output, so text
 * stays as vector text. Nothing is sent to a server; only the link itself is fetched.
 */
object HtmlToPdfEngine {

    private const val TIMEOUT_MS = 45_000L

    /** [source] is an http(s) link or a path to a local .html file. Returns the page count. */
    @SuppressLint("SetJavaScriptEnabled")
    suspend fun convert(context: Context, source: String, options: HtmlOptions, out: File, progress: Progress): Int {
        val isLink = source.startsWith("http://", true) || source.startsWith("https://", true)
        if (isLink && !isOnline(context)) throw UserFacingException(R.string.err_youre_offline_connect_internet, "You're offline. Connect to the internet to save a web page, or choose an HTML file on your phone.")
        if (!isLink && !File(source).exists()) throw UserFacingException(R.string.err_html_file_couldnt_found, "This HTML file couldn't be found.")
        progress.report(5)


        return try {
            withContext(Dispatchers.Main) {
                val web = WebView(context)
                try {
                    web.settings.apply {
                        javaScriptEnabled = true
                        domStorageEnabled = true
                        loadWithOverviewMode = false
                        useWideViewPort = false
                        allowFileAccess = !isLink
                        textZoom = 100
                    }

                    val loaded = CompletableDeferred<String?>()
                    web.webViewClient = object : WebViewClient() {
                        override fun onPageFinished(view: WebView, url: String) { loaded.complete(null) }
                        override fun onReceivedError(view: WebView, request: WebResourceRequest, error: WebResourceError) {
                            if (request.isForMainFrame) loaded.complete("This page couldn't be loaded (${error.description}). Check the link and your connection.")
                        }
                        override fun onReceivedHttpError(view: WebView, request: WebResourceRequest, response: WebResourceResponse) {
                            if (request.isForMainFrame && response.statusCode >= 400) loaded.complete("The website answered with error ${response.statusCode}. Check the link.")
                        }
                    }
                    if (isLink) web.loadUrl(source) else web.loadUrl(File(source).toURI().toString())
                    progress.report(15)
                    val error = withTimeoutOrNull(TIMEOUT_MS) { loaded.await() }
                    if (!loaded.isCompleted) throw UserFacingException(R.string.err_page_took_too_long, "The page took too long to load. Try again, or save it as an HTML file first.")
                    if (error != null) throw UserFacingException(error)
                    // Give scripts, fonts and pictures a moment to settle.
                    // Page margins come from CSS so Chromium doesn't add its own on top.
                    web.evaluateJavascript("(function(){var s=document.createElement('style');s.textContent='@page{margin:${options.marginPt}pt}';(document.head||document.documentElement).appendChild(s)})()", null)
                    delay(700)
                    progress.check()
                    progress.report(45)

                    // Chromium's own print output: real, searchable text and page breaks
                    // that avoid cutting lines in half.

                    val media = PrintAttributes.MediaSize(
                        "custom", "Page",
                        (options.pageWidthPt.coerceAtMost(options.pageHeightPt) * 1000f / 72f).toInt(),
                        (options.pageWidthPt.coerceAtLeast(options.pageHeightPt) * 1000f / 72f).toInt(),
                    ).let { if (options.landscape) it.asLandscape() else it.asPortrait() }
                    val attributes = PrintAttributes.Builder()
                        .setMediaSize(media)
                        .setResolution(PrintAttributes.Resolution("pdf", "pdf", 300, 300))
                        .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
                        .setColorMode(PrintAttributes.COLOR_MODE_COLOR)
                        .build()
                    val failure = PdfPrinter.print(web.createPrintDocumentAdapter("page"), attributes, out)
                    if (failure != null) throw UserFacingException(R.string.err_page_pdf_failed, "This page couldn't be saved as a PDF ($failure).", null, failure)
                    progress.report(95)
                    val pages = withContext(Dispatchers.IO) {
                        ParcelFileDescriptor.open(out, ParcelFileDescriptor.MODE_READ_ONLY).use { fd -> PdfRenderer(fd).use { it.pageCount } }
                    }
                    progress.report(100)
                    pages
                } finally {
                    web.stopLoading()
                    web.destroy()
                }
            }
        } catch (e: Throwable) {
            out.delete()
            throw e
        }
    }

    /** The first web link in shared text, like "Look at this https://example.com/a". */
    fun findUrl(text: String?): String? = text?.let { Regex("""https?://[^\s"'<>]+""").find(it)?.value?.trimEnd('.', ',', ')', ']') }

    private fun isOnline(context: Context): Boolean {
        val cm = context.getSystemService(ConnectivityManager::class.java) ?: return true
        val caps = cm.getNetworkCapabilities(cm.activeNetwork) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }
}
