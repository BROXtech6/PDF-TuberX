package com.excelto.pdf.converter.core.storage

import android.content.Context
import android.media.MediaScannerConnection
import android.os.Environment
import java.io.File

/**
 * All saved files go to Documents/ExcelToPdf/<Tool>/, the same folders the earlier
 * versions of the app used, so users keep finding their old files.
 */
object OutputFiles {

    val root: File
        get() = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS), "ExcelToPdf")

    fun folder(tool: String): File = File(root, tool).apply { mkdirs() }

    /** Returns a file that does not exist yet: "Name.pdf", "Name (1).pdf", "Name (2).pdf"… */
    fun newFile(tool: String, baseName: String, extension: String): File {
        val dir = folder(tool)
        val clean = sanitize(baseName).ifBlank { "Document" }
        var candidate = File(dir, "$clean.$extension")
        var n = 1
        while (candidate.exists()) {
            candidate = File(dir, "$clean ($n).$extension")
            n++
        }
        return candidate
    }

    /** A new, empty folder under the tool folder: "Name", "Name (1)"… */
    fun newFolder(tool: String, baseName: String): File {
        val parent = folder(tool)
        val clean = sanitize(baseName).ifBlank { "Images" }
        var candidate = File(parent, clean)
        var n = 1
        while (candidate.exists()) { candidate = File(parent, "$clean ($n)"); n++ }
        candidate.mkdirs()
        return candidate
    }

    fun sanitize(name: String): String =
        name.replace(Regex("[\\\\/:*?\"<>|\\n\\r\\t]"), "_").trim().take(120)

    /** Makes new files show up in other apps (Files, Drive upload, share sheets). */
    fun publish(context: Context, files: List<File>) {
        if (files.isEmpty()) return
        MediaScannerConnection.scanFile(context.applicationContext, files.map { it.absolutePath }.toTypedArray(), null, null)
    }

    /** Scratch space for imports and intermediate files. Cleared by "Clear cache". */
    fun cache(context: Context, sub: String): File = File(context.cacheDir, sub).apply { mkdirs() }
}
