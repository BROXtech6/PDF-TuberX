package com.excelto.pdf.converter.ui.tools

import com.excelto.pdf.converter.R
import com.excelto.pdf.converter.language.tr
import com.excelto.pdf.converter.language.trPlural
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.excelto.pdf.converter.core.engine.CompressLevel
import com.excelto.pdf.converter.core.engine.ExcelEngine
import com.excelto.pdf.converter.core.engine.ExcelOptions
import com.excelto.pdf.converter.core.engine.PageChoice
import com.excelto.pdf.converter.core.engine.PasswordRequiredException
import com.excelto.pdf.converter.core.engine.PdfTools
import com.excelto.pdf.converter.core.engine.TableLayout
import com.excelto.pdf.converter.core.model.DocFile
import com.excelto.pdf.converter.ui.AppViewModel
import com.excelto.pdf.converter.ui.InnerHeader
import com.excelto.pdf.converter.ui.LocalHost
import com.excelto.pdf.converter.ui.Needs
import com.excelto.pdf.converter.ui.Route
import com.excelto.pdf.converter.ui.Tool
import com.excelto.pdf.converter.ui.components.ChoiceBox
import com.excelto.pdf.converter.ui.components.ChoiceRow
import com.excelto.pdf.converter.ui.components.FileBadge
import com.excelto.pdf.converter.ui.components.PrimaryButton
import com.excelto.pdf.converter.ui.components.ToggleRow
import com.excelto.pdf.converter.ui.components.formatSize
import com.excelto.pdf.converter.ui.sheets.FilePickerSheet
import com.excelto.pdf.converter.ui.sheets.appTextFieldColors
import com.excelto.pdf.converter.ui.theme.AppIcons
import com.excelto.pdf.converter.ui.theme.LocalPalette
import com.excelto.pdf.converter.ui.theme.Type
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@Composable
fun ToolScreenContent(vm: AppViewModel, route: Route.ToolScreen) {
    when (route.tool) {
        Tool.EXCEL_TO_PDF -> ExcelToPdfScreen(vm, route)
        Tool.PDF_TO_EXCEL -> PdfToExcelScreen(vm, route)
        Tool.IMAGE_TO_PDF -> ImagesToPdfScreen(vm, route)
        Tool.COMPRESS -> CompressScreen(vm, route)
        Tool.MERGE -> MergeScreen(vm, route)
        Tool.SPLIT -> SplitScreen(vm, route)
        Tool.ORGANIZE -> OrganizeScreen(vm, route)
        Tool.WATERMARK -> WatermarkScreen(vm, route)
        Tool.PROTECT -> ProtectScreen(vm, route)
        Tool.UNLOCK -> UnlockScreen(vm, route)
        Tool.EDIT, Tool.ANNOTATE, Tool.SIGN, Tool.REDACT -> EditorScreen(vm, route)
        Tool.FILL_FORM -> FillFormScreen(vm, route)
        Tool.COMPARE -> CompareScreen(vm, route)
        Tool.SCAN -> ScanScreen(vm, route)
        Tool.REMOVE_PAGES -> RemovePagesScreen(vm, route)
        Tool.EXTRACT_PAGES -> ExtractPagesScreen(vm, route)
        Tool.ROTATE -> RotateScreen(vm, route)
        Tool.PAGE_NUMBERS -> PageNumbersScreen(vm, route)
        Tool.CROP -> CropScreen(vm, route)
        Tool.REPAIR -> RepairScreen(vm, route)
        Tool.OCR -> OcrScreen(vm, route)
        Tool.PDF_TO_JPG -> PdfToJpgScreen(vm, route)
        Tool.PDF_TO_WORD -> PdfToWordScreen(vm, route)
        Tool.PDF_TO_POWERPOINT -> PdfToPowerPointScreen(vm, route)
        Tool.PDF_TO_PDFA -> PdfToPdfAScreen(vm, route)
        Tool.HTML_TO_PDF -> HtmlToPdfScreen(vm, route)
        Tool.WORD_TO_PDF -> WordToPdfScreen(vm, route)
        Tool.POWERPOINT_TO_PDF -> PowerPointToPdfScreen(vm, route)
    }
}

/**
 * Shared layout for tool screens: header, chosen-file card, scrolling options and a
 * main button pinned to the bottom. Opens the file picker straight away when no file
 * has been chosen yet.
 */
@Composable
fun ToolScaffold(
    vm: AppViewModel,
    route: Route.ToolScreen,
    button: String,
    enabled: Boolean,
    onStart: () -> Unit,
    showFileCard: Boolean = route.tool.needsOneFile,
    requireFile: Boolean = route.tool.needsOneFile || route.tool.needs == Needs.MANY_PDFS,
    content: @Composable ColumnScope.() -> Unit,
) {
    val p = LocalPalette.current
    val needsFile = requireFile
    var picking by rememberSaveable(route.tool) { mutableStateOf(needsFile && route.files.isEmpty()) }
    Column(Modifier.fillMaxSize()) {
        InnerHeader(route.tool.label, onBack = { vm.back() })
        Column(
            Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            if (showFileCard) FileCard(route.files.firstOrNull()) { picking = true }
            if (!needsFile || route.files.isNotEmpty()) content()
        }
        Box(Modifier.background(p.bg).padding(start = 14.dp, end = 14.dp, top = 8.dp, bottom = 12.dp)) {
            PrimaryButton(button, onStart, enabled = enabled && (!needsFile || route.files.isNotEmpty()))
        }
    }
    if (picking) {
        FilePickerSheet(vm, route.tool, route.files, onChosen = { vm.setToolFiles(it) }, onDismiss = { picking = false })
    }
}

@Composable
fun FileCard(file: DocFile?, onChange: () -> Unit) {
    val p = LocalPalette.current
    Row(
        Modifier.fillMaxWidth().heightIn(min = 56.dp).clip(RoundedCornerShape(14.dp)).background(p.surface)
            .border(1.dp, p.line, RoundedCornerShape(14.dp)).clickable(role = Role.Button, onClick = onChange)
            .padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        if (file == null) {
            Icon(AppIcons.plus, null, tint = p.primaryText, modifier = Modifier.size(22.dp))
            Text(tr(R.string.picker_choose_file), style = Type.bodyStrong, color = p.text, modifier = Modifier.weight(1f))
        } else {
            FileBadge(file.type, 32.dp, 38.dp)
            Column(Modifier.weight(1f)) {
                Text(file.name, style = Type.bodyStrong, color = p.text, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(formatSize(file.size), style = Type.small, color = p.muted)
            }
            Text(tr(R.string.common_change), style = Type.bodyStrong, color = p.primaryText)
        }
    }
}

@Composable
fun Label(text: String) = Text(text, style = Type.bodyStrong, color = LocalPalette.current.text)

@Composable
fun Note(text: String) = Text(text, style = Type.small, color = LocalPalette.current.muted)

@Composable
fun InfoCard(title: String, body: String) {
    val p = LocalPalette.current
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(p.primarySoft).padding(12.dp)) {
        Text(title, style = Type.bodyStrong, color = p.text)
        Text(body, style = Type.small, color = p.muted)
    }
}

@Composable
fun NameField(value: String, onChange: (String) -> Unit, folder: String) {
    OutlinedTextField(
        value, onChange, singleLine = true, colors = appTextFieldColors(), label = { Text(tr(R.string.sheet_file_name)) },
        modifier = Modifier.fillMaxWidth(),
        supportingText = { Text(tr(R.string.saved_to, folder)) },
    )
}

// ---- Excel to PDF -----------------------------------------------------------------

@Composable
private fun ExcelToPdfScreen(vm: AppViewModel, route: Route.ToolScreen) {
    val file = route.files.firstOrNull()
    val names by produceState<List<String>?>(null, file?.path) {
        value = null
        if (file != null) value = withContext(Dispatchers.IO) { runCatching { ExcelEngine.sheetNames(file.path) }.getOrNull() }
    }
    val chosen = remember(file?.path) { mutableStateListOf<Int>() }
    // Coming from the spreadsheet viewer: start with the sheet that was on screen.
    LaunchedEffect(names) {
        names?.let { list ->
            chosen.clear()
            val from = route.sheet
            if (from != null && from in list.indices) chosen.add(from) else chosen.addAll(list.indices)
        }
    }
    var fit by rememberSaveable { mutableStateOf(true) }
    var page by rememberSaveable { mutableIntStateOf(0) }
    var orientation by rememberSaveable { mutableIntStateOf(0) }
    var gridlines by rememberSaveable { mutableStateOf(false) }

    ToolScaffold(vm, route, tr(R.string.cat_to_pdf), enabled = names == null || chosen.isNotEmpty(), onStart = {
        val all = names?.indices?.toSet()
        vm.runExcelToPdf(file!!, ExcelOptions(
            sheets = chosen.toSet().takeIf { all != null && it != all },
            fitColumnsOnOnePage = fit,
            page = PageChoice.entries[page],
            landscape = when (orientation) { 1 -> false; 2 -> true; else -> null },
            printGridlines = gridlines,
        ))
    }) {
        val list = names
        if (list == null) {
            Note(tr(R.string.excel_reading))
        } else if (list.size > 1) {
            Label(tr(R.string.excel_sheets))
            list.chunked(3).forEach { row ->
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    row.forEach { name ->
                        val i = list.indexOf(name)
                        ChoiceBox(name, i in chosen, { if (i in chosen) chosen.remove(i) else chosen.add(i) }, Modifier.weight(1f))
                    }
                    repeat(3 - row.size) { Box(Modifier.weight(1f)) }
                }
            }
        }
        Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(LocalPalette.current.surface)) {
            ToggleRow(tr(R.string.excel_fit), if (fit) tr(R.string.excel_fit_on) else tr(R.string.excel_fit_off), fit, { fit = it }, showDivider = true)
            ToggleRow(tr(R.string.excel_gridlines), if (gridlines) tr(R.string.excel_gridlines_on) else tr(R.string.excel_gridlines_off), gridlines, { gridlines = it }, showDivider = false)
        }
        Label(tr(R.string.opt_page_size))
        ChoiceRow(PageChoice.entries.map { if (it == PageChoice.ORIGINAL) tr(R.string.excel_as_in_excel) else it.label }, page) { page = it }
        Label(tr(R.string.opt_orientation))
        ChoiceRow(listOf(tr(R.string.excel_as_in_excel), tr(R.string.opt_portrait), tr(R.string.opt_landscape)), orientation) { orientation = it }
    }
}

// ---- PDF to Excel -----------------------------------------------------------------

@Composable
private fun PdfToExcelScreen(vm: AppViewModel, route: Route.ToolScreen) {
    var layout by rememberSaveable { mutableIntStateOf(0) }
    ToolScaffold(vm, route, tr(R.string.pdf_excel_go), enabled = true, onStart = {
        vm.runPdfToExcel(route.files.first(), TableLayout.entries[layout])
    }) {
        InfoCard(tr(R.string.pdf_excel_info_title), tr(R.string.pdf_excel_info))
        Label(tr(R.string.opt_layout))
        ChoiceRow(TableLayout.entries.map { it.label }, layout) { layout = it }
    }
}

// ---- Compress ---------------------------------------------------------------------

@Composable
private fun CompressScreen(vm: AppViewModel, route: Route.ToolScreen) {
    var level by rememberSaveable { mutableIntStateOf(CompressLevel.BALANCED.ordinal) }
    val subs = mapOf(
        CompressLevel.STRONG to tr(R.string.compress_strong),
        CompressLevel.BALANCED to tr(R.string.compress_balanced),
        CompressLevel.LIGHT to tr(R.string.compress_light),
    )
    ToolScaffold(vm, route, tr(R.string.tool_short_compress), enabled = true, onStart = {
        vm.runCompress(route.files.first(), CompressLevel.entries[level])
    }) {
        Label(tr(R.string.compress_level))
        CompressLevel.entries.forEach { l ->
            ChoiceBox(l.label, level == l.ordinal, { level = l.ordinal }, Modifier.fillMaxWidth(), sub = subs[l])
        }
        Note(tr(R.string.compress_note))
    }
}

// ---- Merge ------------------------------------------------------------------------

@Composable
private fun MergeScreen(vm: AppViewModel, route: Route.ToolScreen) {
    val p = LocalPalette.current
    var picking by remember { mutableStateOf(false) }
    var name by rememberSaveable { mutableStateOf("") }
    val files = route.files
    LaunchedEffect(files.firstOrNull()?.path) { if (name.isBlank() && files.isNotEmpty()) name = "Merged_${files.first().stem}" }
    ToolScaffold(vm, route, if (files.size >= 2) tr(R.string.merge_go, files.size) else tr(R.string.merge_need_two), enabled = files.size >= 2 && name.isNotBlank(), onStart = {
        vm.runMerge(files, name.trim())
    }) {
        Label(tr(R.string.merge_order))
        files.forEachIndexed { i, f ->
            Row(
                Modifier.fillMaxWidth().heightIn(min = 56.dp).clip(RoundedCornerShape(12.dp)).background(p.surface).padding(start = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text("${i + 1}", style = Type.bodyStrong, color = p.primaryText, modifier = Modifier.width(22.dp))
                Text(f.name, style = Type.bodyStrong, color = p.text, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                IconButtonSmall(AppIcons.up, tr(R.string.a11y_move_up, f.name), enabled = i > 0) {
                    vm.setToolFiles(files.toMutableList().apply { add(i - 1, removeAt(i)) })
                }
                IconButtonSmall(AppIcons.close, tr(R.string.a11y_remove, f.name)) { vm.setToolFiles(files - f) }
            }
        }
        Row(
            Modifier.fillMaxWidth().heightIn(min = 48.dp).clip(RoundedCornerShape(12.dp)).border(1.dp, p.muted, RoundedCornerShape(12.dp))
                .clickable(role = Role.Button) { picking = true },
            horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically,
        ) { Text(tr(R.string.merge_add), style = Type.bodyStrong, color = p.text) }
        NameField(name, { name = it }, Tool.MERGE.folder)
    }
    if (picking) FilePickerSheet(vm, Tool.MERGE, files, onChosen = { vm.setToolFiles(it) }, onDismiss = { picking = false })
}

@Composable
fun IconButtonSmall(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, enabled: Boolean = true, onClick: () -> Unit) {
    val p = LocalPalette.current
    Box(
        Modifier.size(44.dp).clip(RoundedCornerShape(22.dp)).clickable(enabled = enabled, role = Role.Button, onClickLabel = label, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) { Icon(icon, label, tint = if (enabled) p.text else p.line, modifier = Modifier.size(18.dp)) }
}

// ---- Split ------------------------------------------------------------------------

/** Page count, asking for the password first if the file is locked. */
@Composable
fun rememberPageCount(vm: AppViewModel, file: DocFile?): Int? {
    var attempt by remember { mutableIntStateOf(0) }
    val count by produceState<Int?>(null, file?.path, attempt) {
        value = null
        if (file == null) return@produceState
        value = withContext(Dispatchers.IO) {
            try { PdfTools.pageCount(file.path, vm.passwordFor(file)) } catch (e: PasswordRequiredException) { -1 } catch (e: Exception) { 0 }
        }
    }
    LaunchedEffect(count) { if (count == -1 && file != null) vm.withPasswords(listOf(file)) { attempt++ } }
    return count?.takeIf { it >= 0 }
}

@Composable
private fun SplitScreen(vm: AppViewModel, route: Route.ToolScreen) {
    val file = route.files.firstOrNull()
    val count = rememberPageCount(vm, file)
    var mode by rememberSaveable { mutableIntStateOf(0) }
    var custom by rememberSaveable { mutableStateOf("") }
    val ranges = when {
        count == null || count == 0 -> null
        mode == 0 -> PdfTools.everyPage(count)
        mode == 1 -> PdfTools.halves(count)
        else -> PdfTools.parseRanges(custom, count)
    }
    ToolScaffold(vm, route, if (ranges != null) trPlural(R.plurals.split_go_n, ranges.size, ranges.size) else tr(R.string.split_go), enabled = ranges != null, onStart = {
        vm.runSplit(file!!, ranges!!)
    }) {
        Note(when (count) { null -> tr(R.string.split_counting); 0 -> tr(R.string.pdf_unreadable); else -> trPlural(R.plurals.pages_count, count, count) })
        Label(tr(R.string.split_into))
        ChoiceRow(listOf(tr(R.string.split_every), tr(R.string.split_halves), tr(R.string.split_custom)), mode) { mode = it }
        if (mode == 2) {
            OutlinedTextField(
                custom, { custom = it }, singleLine = true, colors = appTextFieldColors(), modifier = Modifier.fillMaxWidth(),
                label = { Text(tr(R.string.split_ranges)) }, placeholder = { Text(tr(R.string.split_ranges_example)) },
                isError = custom.isNotBlank() && ranges == null,
                supportingText = { Text(if (custom.isNotBlank() && ranges == null) tr(R.string.split_range_hint, count ?: 1) else tr(R.string.split_each)) },
            )
        }
    }
}

// ---- Protect and unlock -----------------------------------------------------------

@Composable
private fun PasswordField(value: String, onChange: (String) -> Unit, label: String, isError: Boolean = false, support: String? = null) {
    var visible by remember { mutableStateOf(false) }
    OutlinedTextField(
        value, onChange, singleLine = true, colors = appTextFieldColors(), modifier = Modifier.fillMaxWidth(),
        label = { Text(label) }, isError = isError,
        supportingText = if (support != null) { { Text(support) } } else null,
        visualTransformation = if (visible) VisualTransformation.None else PasswordVisualTransformation(),
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
        trailingIcon = {
            Text(if (visible) tr(R.string.common_hide) else tr(R.string.common_show), style = Type.bodyStrong, color = LocalPalette.current.primaryText,
                modifier = Modifier.clickable(role = Role.Button) { visible = !visible }.padding(12.dp))
        },
    )
}

@Composable
private fun ProtectScreen(vm: AppViewModel, route: Route.ToolScreen) {
    val p = LocalPalette.current
    var pw by remember { mutableStateOf("") }
    var pw2 by remember { mutableStateOf("") }
    var allowPrint by rememberSaveable { mutableStateOf(true) }
    var allowCopy by rememberSaveable { mutableStateOf(false) }
    val score = listOf(pw.length >= 8, pw.length >= 12, pw.any { it.isUpperCase() } && pw.any { it.isLowerCase() }, pw.any { it.isDigit() }, pw.any { !it.isLetterOrDigit() }).count { it }
    val (label, fraction, color) = when {
        pw.isEmpty() -> Triple(tr(R.string.pw_hint), 0f, p.line)
        score <= 1 -> Triple(tr(R.string.pw_weak), 0.25f, androidx.compose.ui.graphics.Color(0xFFB3261E))
        score <= 3 -> Triple(tr(R.string.pw_fair), 0.6f, androidx.compose.ui.graphics.Color(0xFFA86A00))
        else -> Triple(tr(R.string.pw_strong), 1f, androidx.compose.ui.graphics.Color(0xFF217346))
    }
    val ok = pw.length >= 6 && pw == pw2
    ToolScaffold(vm, route, tr(R.string.tool_protect), enabled = ok, onStart = {
        vm.runProtect(route.files.first(), pw, allowPrint, allowCopy)
    }) {
        PasswordField(pw, { pw = it }, tr(R.string.password_label))
        Column {
            Box(Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)).background(p.line)) {
                Box(Modifier.fillMaxWidth(fraction).height(8.dp).clip(RoundedCornerShape(4.dp)).background(color))
            }
            Text(label, style = Type.tiny.copy(fontSize = 12.sp), color = if (pw.isEmpty()) p.muted else if (p.isDark) p.text else color, modifier = Modifier.padding(top = 4.dp))
        }
        PasswordField(pw2, { pw2 = it }, tr(R.string.pw_confirm), isError = pw2.isNotEmpty() && pw != pw2,
            support = if (pw2.isNotEmpty() && pw != pw2) tr(R.string.pw_mismatch) else null)
        Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(p.surface)) {
            ToggleRow(tr(R.string.pw_allow_print), null, allowPrint, { allowPrint = it })
            ToggleRow(tr(R.string.pw_allow_copy), null, allowCopy, { allowCopy = it }, showDivider = false)
        }
        Note(tr(R.string.pw_note))
    }
}

@Composable
private fun UnlockScreen(vm: AppViewModel, route: Route.ToolScreen) {
    val file = route.files.firstOrNull()
    val locked by produceState<Boolean?>(null, file?.path) {
        value = file?.let { withContext(Dispatchers.IO) { PdfTools.isPasswordProtected(it.path) } }
    }
    var pw by remember { mutableStateOf("") }
    ToolScaffold(vm, route, tr(R.string.unlock_go), enabled = locked == true && pw.isNotEmpty(), onStart = {
        vm.runUnlock(file!!, pw)
    }) {
        when (locked) {
            null -> Note(tr(R.string.unlock_checking))
            false -> InfoCard(tr(R.string.unlock_none_title), tr(R.string.unlock_none))
            true -> {
                PasswordField(pw, { pw = it }, tr(R.string.unlock_current))
                Note(tr(R.string.unlock_note))
            }
        }
    }
}

