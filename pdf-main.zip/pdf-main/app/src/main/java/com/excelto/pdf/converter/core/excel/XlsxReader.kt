package com.excelto.pdf.converter.core.excel

import com.excelto.pdf.converter.R
import com.excelto.pdf.converter.core.engine.UserFacingException
import org.xmlpull.v1.XmlPullParser
import java.io.File
import java.io.InputStream
import java.util.zip.ZipFile
import kotlin.math.roundToInt

/**
 * Reads .xlsx and .xlsm files with java.util.zip and an XmlPullParser (no POI):
 * sheets and visibility, the 1904 date system, print areas, shared strings (rich text
 * runs joined), styles (number formats, fonts, fills, borders, alignment), column widths,
 * row heights, merged cells, page setup, right-to-left sheets, cell values (cached
 * formula results) and pictures. Charts are counted, not drawn.
 *
 * [parserFactory] makes a new pull parser; the app uses Android's, tests use kXML.
 */
class XlsxReader(private val parserFactory: () -> XmlPullParser) {

    private lateinit var zip: ZipFile

    fun read(file: File, onlySheets: Set<Int>? = null, check: () -> Unit = {}): ExcelWorkbook {
        if (isOleFile(file)) {
            throw UserFacingException(R.string.err_spreadsheet_password_protected_remove, "This spreadsheet is password protected. Remove the password in Excel and try again.")
        }
        zip = try {
            ZipFile(file)
        } catch (e: Exception) {
            throw UserFacingException(R.string.err_spreadsheet_couldnt_opened_may, "This spreadsheet couldn't be opened. It may be damaged or in an unsupported format.", e)
        }
        zip.use {
            val workbookPath = rels("_rels/.rels", "").values.firstOrNull { it.type.endsWith("/officeDocument") }?.target ?: "xl/workbook.xml"
            val workbookRels = rels(relsPath(workbookPath), folder(workbookPath))
            val info = readWorkbook(workbookPath)
            val shared = workbookRels.values.firstOrNull { it.type.endsWith("/sharedStrings") }?.let { readSharedStrings(it.target) } ?: emptyList()
            val theme = workbookRels.values.firstOrNull { it.type.endsWith("/theme") }?.let { readTheme(it.target) } ?: defaultTheme
            val styles = workbookRels.values.firstOrNull { it.type.endsWith("/styles") }?.let { readStyles(it.target, theme) } ?: listOf(CellStyle.DEFAULT)
            val sheets = info.sheets.mapIndexed { index, s ->
                check()
                val rel = workbookRels[s.relId]
                if (rel == null || !rel.type.endsWith("/worksheet") || (onlySheets != null && index !in onlySheets)) {
                    // Chart sheets and skipped sheets: name only.
                    ExcelSheet(s.name, hidden = s.hidden || rel?.type?.endsWith("/worksheet") != true, chartCount = if (rel?.type?.endsWith("/chartsheet") == true) 1 else 0)
                } else {
                    readSheet(s.name, s.hidden, rel.target, shared, styles, info.printAreas[index], check)
                }
            }
            return ExcelWorkbook(sheets, styles, info.date1904)
        }
    }

    /** Sheet names and visibility only, without reading cells. */
    fun sheetNames(file: File): List<Pair<String, Boolean>> {
        if (isOleFile(file)) throw UserFacingException(R.string.err_spreadsheet_password_protected_remove, "This spreadsheet is password protected. Remove the password in Excel and try again.")
        zip = try { ZipFile(file) } catch (e: Exception) {
            throw UserFacingException(R.string.err_spreadsheet_couldnt_opened_may, "This spreadsheet couldn't be opened. It may be damaged or in an unsupported format.", e)
        }
        zip.use {
            val workbookPath = rels("_rels/.rels", "").values.firstOrNull { it.type.endsWith("/officeDocument") }?.target ?: "xl/workbook.xml"
            return readWorkbook(workbookPath).sheets.map { it.name to it.hidden }
        }
    }

    // ---- Parts and relationships -------------------------------------------------

    private class Rel(val type: String, val target: String)

    private fun folder(path: String) = path.substringBeforeLast('/', "")
    private fun relsPath(part: String) = (if (folder(part).isEmpty()) "" else folder(part) + "/") + "_rels/" + part.substringAfterLast('/') + ".rels"

    private fun resolve(base: String, target: String): String {
        if (target.startsWith("/")) return target.drop(1)
        val parts = (if (base.isEmpty()) emptyList() else base.split('/')).toMutableList()
        for (seg in target.split('/')) when (seg) {
            ".." -> if (parts.isNotEmpty()) parts.removeAt(parts.lastIndex)
            ".", "" -> Unit
            else -> parts += seg
        }
        return parts.joinToString("/")
    }

    private fun open(path: String): InputStream? = zip.getEntry(path)?.let { zip.getInputStream(it) }

    private inline fun parse(path: String, block: (XmlPullParser) -> Unit) {
        val stream = open(path) ?: return
        stream.use {
            val p = parserFactory()
            p.setInput(it, null)
            block(p)
        }
    }

    private fun rels(path: String, base: String): Map<String, Rel> {
        val out = HashMap<String, Rel>()
        parse(path) { p ->
            p.each { name ->
                if (name == "Relationship" && p.attr("TargetMode") != "External") {
                    out[p.attr("Id").orEmpty()] = Rel(p.attr("Type").orEmpty(), resolve(base, p.attr("Target").orEmpty()))
                }
            }
        }
        return out
    }

    // ---- Workbook ------------------------------------------------------------------

    private class SheetInfo(val name: String, val hidden: Boolean, val relId: String)
    private class WorkbookInfo(val sheets: List<SheetInfo>, val date1904: Boolean, val printAreas: Map<Int, CellRange>)

    private fun readWorkbook(path: String): WorkbookInfo {
        val sheets = mutableListOf<SheetInfo>()
        var date1904 = false
        val printAreas = HashMap<Int, CellRange>()
        parse(path) { p ->
            p.each { name ->
                when (name) {
                    "workbookPr" -> date1904 = p.attr("date1904").isTrue()
                    "sheet" -> sheets += SheetInfo(p.attr("name").orEmpty(), p.attr("state").let { it == "hidden" || it == "veryHidden" }, p.attr("id").orEmpty())
                    "definedName" -> if (p.attr("name") == "_xlnm.Print_Area") {
                        val sheet = p.attr("localSheetId")?.toIntOrNull()
                        val text = p.nextText()
                        // "Sheet1!$A$1:$F$40" (only the first area is used)
                        val ref = text.substringBefore(',').substringAfterLast('!')
                        if (sheet != null) CellRange.parse(ref)?.let { printAreas[sheet] = it }
                    }
                }
            }
        }
        return WorkbookInfo(sheets, date1904, printAreas)
    }

    private fun readSharedStrings(path: String): List<String> {
        val out = ArrayList<String>()
        parse(path) { p ->
            val sb = StringBuilder()
            var inSi = false
            var skipDepth = -1
            var event = p.eventType
            while (event != XmlPullParser.END_DOCUMENT) {
                when (event) {
                    XmlPullParser.START_TAG -> when (p.name.local()) {
                        "si" -> { inSi = true; sb.setLength(0) }
                        "rPh", "phoneticPr" -> if (skipDepth < 0) skipDepth = p.depth // phonetic guides aren't shown
                        "t" -> if (inSi && skipDepth < 0) sb.append(p.nextText())
                    }
                    XmlPullParser.END_TAG -> when (p.name.local()) {
                        "si" -> { out += sb.toString(); inSi = false }
                        else -> if (skipDepth == p.depth) skipDepth = -1
                    }
                }
                event = p.next()
            }
        }
        return out
    }

    // ---- Theme and colors ------------------------------------------------------------

    private val defaultTheme = listOf(
        0xFFFFFFFF, 0xFF000000, 0xFFE7E6E6, 0xFF44546A, 0xFF4472C4, 0xFFED7D31,
        0xFFA5A5A5, 0xFFFFC000, 0xFF5B9BD5, 0xFF70AD47, 0xFF0563C1, 0xFF954F72,
    ).map { it.toInt() }

    private fun readTheme(path: String): List<Int> {
        val scheme = HashMap<String, Int>()
        var current: String? = null
        parse(path) { p ->
            p.each { name ->
                when (name) {
                    "dk1", "lt1", "dk2", "lt2", "accent1", "accent2", "accent3", "accent4", "accent5", "accent6", "hlink", "folHlink" -> current = name
                    "srgbClr" -> current?.let { c -> p.attr("val")?.let { scheme[c] = parseRgb(it) }; current = null }
                    "sysClr" -> current?.let { c -> p.attr("lastClr")?.let { scheme[c] = parseRgb(it) }; current = null }
                }
            }
        }
        // Theme index order used by cell colors: lt1, dk1, lt2, dk2, accents, links.
        val order = listOf("lt1", "dk1", "lt2", "dk2", "accent1", "accent2", "accent3", "accent4", "accent5", "accent6", "hlink", "folHlink")
        return order.mapIndexed { i, k -> scheme[k] ?: defaultTheme[i] }
    }

    private fun parseRgb(hex: String): Int {
        val h = hex.trim()
        val v = h.toLongOrNull(16) ?: return 0xFF000000.toInt()
        return if (h.length <= 6) (0xFF000000 or v).toInt() else (v or 0xFF000000).toInt() // alpha in files is often 00; ignore it
    }

    /** A color element (rgb, theme+tint or indexed). Null for automatic. */
    private fun color(p: XmlPullParser, theme: List<Int>, indexed: Map<Int, Int>): Int? {
        val base = p.attr("rgb")?.let { parseRgb(it) }
            ?: p.attr("theme")?.toIntOrNull()?.let { theme.getOrNull(it) }
            ?: p.attr("indexed")?.toIntOrNull()?.let { ExcelColors.indexed(it, indexed) }
            ?: return null
        val tint = p.attr("tint")?.toDoubleOrNull() ?: 0.0
        return if (tint == 0.0) base else applyTint(base, tint)
    }

    // ---- Styles --------------------------------------------------------------------

    private fun readStyles(path: String, theme: List<Int>): List<CellStyle> {
        val numFmts = HashMap<Int, String>()
        val fonts = mutableListOf<CellFont>()
        val fills = mutableListOf<Int?>()
        val borders = mutableListOf<Array<BorderLine?>>()
        val xfs = mutableListOf<CellStyle>()
        val indexed = HashMap<Int, Int>()

        // Custom palettes come after the rest in the file, so read them first.
        parse(path) { p ->
            var i = 0
            var inIndexed = false
            p.each { name ->
                if (name == "indexedColors") inIndexed = true
                if (name == "rgbColor" && inIndexed) p.attr("rgb")?.let { indexed[i++] = parseRgb(it) }
            }
        }

        parse(path) { p ->
            var section = ""
            var font = CellFont()
            var fillType: String? = null
            var fillColor: Int? = null
            var fillBg: Int? = null
            var border = arrayOfNulls<BorderLine>(4)
            var side = -1
            var sideStyle = LineStyle.NONE
            var xf: CellStyle? = null
            var event = p.eventType
            while (event != XmlPullParser.END_DOCUMENT) {
                if (event == XmlPullParser.START_TAG) {
                    when (val name = p.name.local()) {
                        "numFmts", "fonts", "fills", "borders", "cellXfs", "cellStyleXfs", "dxfs", "colors" -> section = name
                        "numFmt" -> if (section == "numFmts") p.attr("numFmtId")?.toIntOrNull()?.let { numFmts[it] = p.attr("formatCode").orEmpty() }
                        "font" -> if (section == "fonts") font = CellFont()
                        "b" -> if (section == "fonts") font = font.copy(bold = p.attr("val").isTrueOrMissing())
                        "i" -> if (section == "fonts") font = font.copy(italic = p.attr("val").isTrueOrMissing())
                        "strike" -> if (section == "fonts") font = font.copy(strike = p.attr("val").isTrueOrMissing())
                        "u" -> if (section == "fonts") font = font.copy(underline = p.attr("val") != "none")
                        "sz" -> if (section == "fonts") p.attr("val")?.toFloatOrNull()?.let { font = font.copy(size = it) }
                        "name" -> if (section == "fonts") p.attr("val")?.let { font = font.copy(name = it) }
                        "color" -> when (section) {
                            "fonts" -> color(p, theme, indexed)?.let { font = font.copy(color = it) }
                            "borders" -> if (side >= 0) border[side] = BorderLine(sideStyle, color(p, theme, indexed) ?: 0xFF000000.toInt())
                        }
                        "fill" -> if (section == "fills") { fillType = null; fillColor = null; fillBg = null }
                        "patternFill" -> if (section == "fills") fillType = p.attr("patternType") ?: "none"
                        "fgColor" -> if (section == "fills") fillColor = color(p, theme, indexed)
                        "bgColor" -> if (section == "fills") fillBg = color(p, theme, indexed)
                        "gradientFill" -> if (section == "fills") fillType = "gradient"
                        "stop" -> Unit
                        "border" -> if (section == "borders") border = arrayOfNulls(4)
                        "left", "start", "right", "end", "top", "bottom" -> if (section == "borders") {
                            side = when (name) { "left", "start" -> 0; "right", "end" -> 1; "top" -> 2; else -> 3 }
                            sideStyle = LineStyle.of(p.attr("style"))
                            border[side] = if (sideStyle == LineStyle.NONE) null else BorderLine(sideStyle)
                        }
                        "xf" -> if (section == "cellXfs") {
                            val numFmtId = p.attr("numFmtId")?.toIntOrNull() ?: 0
                            val b = borders.getOrNull(p.attr("borderId")?.toIntOrNull() ?: 0)
                            xf = CellStyle(
                                font = fonts.getOrNull(p.attr("fontId")?.toIntOrNull() ?: 0) ?: CellFont(),
                                fill = fills.getOrNull(p.attr("fillId")?.toIntOrNull() ?: 0),
                                left = b?.get(0), right = b?.get(1), top = b?.get(2), bottom = b?.get(3),
                                numFmt = numFmts[numFmtId] ?: NumberFormatter.builtIn(numFmtId) ?: "General",
                            )
                        }
                        "alignment" -> if (section == "cellXfs") xf = xf?.copy(
                            hAlign = when (p.attr("horizontal")) {
                                "left" -> HAlign.LEFT; "center" -> HAlign.CENTER; "right" -> HAlign.RIGHT
                                "fill" -> HAlign.FILL; "justify" -> HAlign.JUSTIFY; "centerContinuous" -> HAlign.CENTER_CONTINUOUS
                                "distributed" -> HAlign.DISTRIBUTED; else -> HAlign.GENERAL
                            },
                            vAlign = when (p.attr("vertical")) {
                                "top" -> VAlign.TOP; "center" -> VAlign.CENTER; "justify" -> VAlign.JUSTIFY
                                "distributed" -> VAlign.DISTRIBUTED; else -> VAlign.BOTTOM
                            },
                            wrap = p.attr("wrapText").isTrue(),
                            indent = p.attr("indent")?.toIntOrNull() ?: 0,
                        )
                    }
                } else if (event == XmlPullParser.END_TAG) {
                    when (p.name.local()) {
                        "font" -> if (section == "fonts") fonts += font
                        "fill" -> if (section == "fills") fills += when (fillType) {
                            null, "none", "gray125" -> null
                            "gradient" -> null
                            else -> fillColor ?: fillBg
                        }
                        "left", "start", "right", "end", "top", "bottom" -> side = -1
                        "border" -> if (section == "borders") borders += border
                        "xf" -> if (section == "cellXfs") { xf?.let { xfs += it }; xf = null }
                        "numFmts", "fonts", "fills", "borders", "cellXfs", "cellStyleXfs", "dxfs", "colors" -> section = ""
                    }
                }
                event = p.next()
            }
        }
        return xfs.ifEmpty { listOf(CellStyle.DEFAULT) }
    }

    // ---- Worksheets ------------------------------------------------------------------

    private fun readSheet(
        name: String,
        hidden: Boolean,
        path: String,
        shared: List<String>,
        styles: List<CellStyle>,
        printArea: CellRange?,
        check: () -> Unit,
    ): ExcelSheet {
        val rows = java.util.TreeMap<Int, RowData>()
        val colWidths = HashMap<Int, Float>()
        val colStyles = HashMap<Int, Int>()
        val hiddenCols = HashSet<Int>()
        val rowHeights = HashMap<Int, Float>()
        val hiddenRows = HashSet<Int>()
        val merges = mutableListOf<CellRange>()
        var rtl = false
        var defaultColWidth: Float? = null
        var baseColWidth = 8f
        var defaultRowHeight = 15f
        var setup = PageSetup()
        var fitToPage = false
        var drawingId: String? = null
        val formulas = HashMap<Long, String>()
        // Shared formulas: the master's text and cell, by shared index.
        val sharedFormulas = HashMap<String, Triple<String, Int, Int>>()
        var freezeRows = 0
        var freezeCols = 0

        parse(path) { p ->
            var row: RowData? = null
            var rowIndex = -1
            var cellCol = -1
            var cellType: String? = null
            var cellStyle = 0
            var value: String? = null
            var inline: StringBuilder? = null
            var nextCol = 0
            var count = 0
            var event = p.eventType
            while (event != XmlPullParser.END_DOCUMENT) {
                if (event == XmlPullParser.START_TAG) {
                    when (p.name.local()) {
                        "pageSetUpPr" -> fitToPage = p.attr("fitToPage").isTrue()
                        "sheetView" -> rtl = p.attr("rightToLeft").isTrue()
                        "sheetFormatPr" -> {
                            p.attr("defaultColWidth")?.toFloatOrNull()?.let { defaultColWidth = it }
                            p.attr("baseColWidth")?.toFloatOrNull()?.let { baseColWidth = it }
                            p.attr("defaultRowHeight")?.toFloatOrNull()?.let { defaultRowHeight = it }
                        }
                        "col" -> {
                            val min = (p.attr("min")?.toIntOrNull() ?: 1) - 1
                            val max = ((p.attr("max")?.toIntOrNull() ?: (min + 1)) - 1).coerceAtMost(min + 16384)
                            val w = p.attr("width")?.toFloatOrNull()
                            val isHidden = p.attr("hidden").isTrue()
                            val style = p.attr("style")?.toIntOrNull()
                            for (c in min..max) {
                                if (w != null) colWidths[c] = w
                                if (isHidden) hiddenCols += c
                                if (style != null && style != 0 && max - min < 1000) colStyles[c] = style
                            }
                        }
                        "row" -> {
                            rowIndex = (p.attr("r")?.toIntOrNull() ?: (rowIndex + 2)) - 1
                            row = RowData()
                            nextCol = 0
                            if (p.attr("customHeight").isTrue() || p.attr("ht") != null) p.attr("ht")?.toFloatOrNull()?.let { rowHeights[rowIndex] = it }
                            if (p.attr("hidden").isTrue()) hiddenRows += rowIndex
                            if (++count % 500 == 0) check()
                        }
                        "c" -> {
                            cellCol = p.attr("r")?.let { ref -> CellRange.parseCell(ref)?.second } ?: nextCol
                            nextCol = cellCol + 1
                            cellType = p.attr("t")
                            cellStyle = p.attr("s")?.toIntOrNull() ?: 0
                            value = null
                            inline = null
                        }
                        "pane" -> if (p.attr("state") == "frozen" || p.attr("state") == "frozenSplit") {
                            freezeCols = p.attr("xSplit")?.toFloatOrNull()?.toInt() ?: 0
                            freezeRows = p.attr("ySplit")?.toFloatOrNull()?.toInt() ?: 0
                        }
                        "f" -> {
                            val si = p.attr("si")
                            val isShared = p.attr("t") == "shared"
                            val text = p.nextText().trim()
                            val key = formulaKey(rowIndex, cellCol)
                            when {
                                text.isNotEmpty() -> {
                                    formulas[key] = text
                                    if (isShared && si != null) sharedFormulas[si] = Triple(text, rowIndex, cellCol)
                                }
                                isShared && si != null -> sharedFormulas[si]?.let { (master, r0, c0) ->
                                    formulas[key] = Formulas.shift(master, rowIndex - r0, cellCol - c0)
                                }
                            }
                        }
                        "v" -> value = p.nextText()
                        "is" -> inline = StringBuilder()
                        "t" -> inline?.append(p.nextText())
                        "mergeCell" -> p.attr("ref")?.let { CellRange.parse(it) }?.let { merges += it }
                        "printOptions" -> setup = setup.copy(printGridlines = p.attr("gridLines").isTrue())
                        "pageMargins" -> setup = setup.copy(
                            marginLeft = p.attr("left")?.toFloatOrNull() ?: setup.marginLeft,
                            marginRight = p.attr("right")?.toFloatOrNull() ?: setup.marginRight,
                            marginTop = p.attr("top")?.toFloatOrNull() ?: setup.marginTop,
                            marginBottom = p.attr("bottom")?.toFloatOrNull() ?: setup.marginBottom,
                        )
                        "pageSetup" -> setup = setup.copy(
                            landscape = when (p.attr("orientation")) { "landscape" -> true; "portrait" -> false; else -> null },
                            paperSize = p.attr("paperSize")?.toIntOrNull(),
                            fitWidth = p.attr("fitToWidth")?.toIntOrNull() ?: 1,
                            fitHeight = p.attr("fitToHeight")?.toIntOrNull() ?: 1,
                            scale = p.attr("scale")?.toIntOrNull() ?: 100,
                        )
                        "drawing" -> drawingId = p.attr("id")
                    }
                } else if (event == XmlPullParser.END_TAG) {
                    when (p.name.local()) {
                        "c" -> {
                            val r = row
                            if (r != null && cellCol >= 0) addCell(r, cellCol, cellType, value, inline?.toString(), cellStyle, shared)
                        }
                        "row" -> {
                            val r = row
                            if (r != null && r.size > 0) rows[rowIndex] = r
                            row = null
                        }
                    }
                }
                event = p.next()
            }
        }

        val sheetRels = rels(relsPath(path), folder(path))
        var images = emptyList<SheetImage>()
        var charts = 0
        drawingId?.let { id -> sheetRels[id]?.let { rel -> readDrawing(rel.target).let { (imgs, ch) -> images = imgs; charts = ch } } }
        // Excel's stored widths include 5 px of padding: 8.43 visible characters = 9.140625.
        val defaultWidth = defaultColWidth ?: (baseColWidth + 5f / 7f).let { (it * 256).roundToInt() / 256f }

        return ExcelSheet(
            name = name, hidden = hidden, rightToLeft = rtl, rows = rows,
            colWidths = colWidths, defaultColWidth = defaultWidth,
            rowHeights = rowHeights, defaultRowHeight = defaultRowHeight,
            hiddenRows = hiddenRows, hiddenCols = hiddenCols, merges = merges,
            printArea = printArea, pageSetup = setup.copy(fitToPage = fitToPage),
            images = images, chartCount = charts, colStyles = colStyles,
            formulas = formulas, freezeRows = freezeRows, freezeCols = freezeCols,
        )
    }

    private fun addCell(row: RowData, col: Int, type: String?, v: String?, inline: String?, style: Int, shared: List<String>) {
        when (type) {
            "s" -> v?.trim()?.toIntOrNull()?.let { row.put(col, CellKind.STRING, str = shared.getOrNull(it).orEmpty(), style = style) }
                ?: row.put(col, CellKind.BLANK, style = style)
            "str" -> row.put(col, CellKind.STRING, str = v.orEmpty(), style = style)
            "inlineStr" -> row.put(col, CellKind.STRING, str = inline ?: v.orEmpty(), style = style)
            "b" -> row.put(col, CellKind.BOOL, num = if (v?.trim() == "1") 1.0 else 0.0, style = style)
            "e" -> row.put(col, CellKind.ERROR, str = v.orEmpty(), style = style)
            "d" -> row.put(col, CellKind.STRING, str = v.orEmpty(), style = style)
            else -> {
                val n = v?.trim()?.toDoubleOrNull()
                if (n != null) row.put(col, CellKind.NUMBER, num = n, style = style)
                else row.put(col, CellKind.BLANK, style = style)
            }
        }
    }

    /** Pictures (with their anchors) and the number of charts in a drawing part. */
    private fun readDrawing(path: String): Pair<List<SheetImage>, Int> {
        val rels = rels(relsPath(path), folder(path))
        val images = mutableListOf<SheetImage>()
        var charts = 0
        parse(path) { p ->
            var anchor: String? = null
            var target = 0 // 1 = from, 2 = to
            val fromCell = IntArray(2); val fromOff = LongArray(2)
            val toCell = IntArray(2); val toOff = LongArray(2)
            var ext = longArrayOf(0, 0)
            var blip: String? = null
            var field: String? = null
            var event = p.eventType
            while (event != XmlPullParser.END_DOCUMENT) {
                if (event == XmlPullParser.START_TAG) {
                    when (val n = p.name.local()) {
                        "twoCellAnchor", "oneCellAnchor", "absoluteAnchor" -> {
                            anchor = n; blip = null; ext = longArrayOf(0, 0)
                            fromCell.fill(0); fromOff.fill(0); toCell.fill(0); toOff.fill(0)
                        }
                        "from" -> target = 1
                        "to" -> target = 2
                        "col", "colOff", "row", "rowOff" -> field = n
                        "ext" -> if (anchor != null && p.attr("cx") != null) ext = longArrayOf(p.attr("cx")!!.toLong(), p.attr("cy")!!.toLong())
                        "blip" -> blip = p.attr("embed")
                        "chart" -> charts++
                    }
                } else if (event == XmlPullParser.TEXT && field != null && target > 0) {
                    val v = p.text.trim().toLongOrNull() ?: 0L
                    val cells = if (target == 1) fromCell else toCell
                    val offs = if (target == 1) fromOff else toOff
                    when (field) {
                        "col" -> cells[0] = v.toInt()
                        "row" -> cells[1] = v.toInt()
                        "colOff" -> offs[0] = v
                        "rowOff" -> offs[1] = v
                    }
                } else if (event == XmlPullParser.END_TAG) {
                    when (p.name.local()) {
                        "from", "to" -> target = 0
                        "col", "colOff", "row", "rowOff" -> field = null
                        "twoCellAnchor", "oneCellAnchor", "absoluteAnchor" -> {
                            val media = blip?.let { rels[it]?.target }
                            val bytes = media?.let { m -> open(m)?.use { it.readBytes() } }
                            if (bytes != null && anchor != "absoluteAnchor") {
                                val two = anchor == "twoCellAnchor"
                                images += SheetImage(
                                    fromCol = fromCell[0], fromColOffset = fromOff[0] / EMU_PER_PT, fromRow = fromCell[1], fromRowOffset = fromOff[1] / EMU_PER_PT,
                                    toCol = if (two) toCell[0] else null, toColOffset = toOff[0] / EMU_PER_PT,
                                    toRow = if (two) toCell[1] else null, toRowOffset = toOff[1] / EMU_PER_PT,
                                    widthPt = ext[0] / EMU_PER_PT, heightPt = ext[1] / EMU_PER_PT,
                                    bytes = bytes,
                                )
                            }
                            anchor = null
                        }
                    }
                }
                event = p.next()
            }
        }
        return images to charts
    }

    companion object {
        private const val EMU_PER_PT = 12700f

        /** Encrypted .xlsx files are OLE compound files, not zips. */
        fun isOleFile(file: File): Boolean = runCatching {
            file.inputStream().use { s ->
                val b = ByteArray(4)
                s.read(b) == 4 && b[0] == 0xD0.toByte() && b[1] == 0xCF.toByte() && b[2] == 0x11.toByte() && b[3] == 0xE0.toByte()
            }
        }.getOrDefault(false)

        /** Excel's tint: lighten (positive) or darken (negative) in HSL space. */
        fun applyTint(argb: Int, tint: Double): Int {
            val r = (argb shr 16 and 0xFF) / 255.0
            val g = (argb shr 8 and 0xFF) / 255.0
            val b = (argb and 0xFF) / 255.0
            val max = maxOf(r, g, b); val min = minOf(r, g, b)
            var h = 0.0; var s = 0.0
            var l = (max + min) / 2
            if (max != min) {
                val d = max - min
                s = if (l > 0.5) d / (2 - max - min) else d / (max + min)
                h = when (max) {
                    r -> (g - b) / d + (if (g < b) 6 else 0)
                    g -> (b - r) / d + 2
                    else -> (r - g) / d + 4
                } / 6
            }
            l = if (tint < 0) l * (1 + tint) else l * (1 - tint) + tint
            fun hue(p: Double, q: Double, t0: Double): Double {
                var t = t0
                if (t < 0) t += 1.0
                if (t > 1) t -= 1.0
                return when {
                    t < 1.0 / 6 -> p + (q - p) * 6 * t
                    t < 0.5 -> q
                    t < 2.0 / 3 -> p + (q - p) * (2.0 / 3 - t) * 6
                    else -> p
                }
            }
            val (nr, ng, nb) = if (s == 0.0) Triple(l, l, l) else {
                val q = if (l < 0.5) l * (1 + s) else l + s - l * s
                val p = 2 * l - q
                Triple(hue(p, q, h + 1.0 / 3), hue(p, q, h), hue(p, q, h - 1.0 / 3))
            }
            fun c(x: Double) = (x * 255).roundToInt().coerceIn(0, 255)
            return (0xFF shl 24) or (c(nr) shl 16) or (c(ng) shl 8) or c(nb)
        }
    }
}

// ---- Small pull-parser helpers ----------------------------------------------------

/** Element name without a namespace prefix ("x:row" → "row"). */
internal fun String.local(): String = substringAfter(':')

/** Attribute by local name, ignoring prefixes ("r:id" matches "id"). */
internal fun XmlPullParser.attr(name: String): String? {
    for (i in 0 until attributeCount) if (getAttributeName(i).local() == name) return getAttributeValue(i)
    return null
}

internal fun String?.isTrue() = this == "1" || this.equals("true", ignoreCase = true)
internal fun String?.isTrueOrMissing() = this == null || isTrue()

/** Calls [block] with the local name of every start tag. */
internal inline fun XmlPullParser.each(block: (String) -> Unit) {
    var event = eventType
    while (event != XmlPullParser.END_DOCUMENT) {
        if (event == XmlPullParser.START_TAG) block(name.local())
        event = next()
    }
}
