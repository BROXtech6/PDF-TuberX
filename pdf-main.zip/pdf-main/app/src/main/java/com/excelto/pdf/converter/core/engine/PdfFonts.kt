package com.excelto.pdf.converter.core.engine

import com.tom_roush.fontbox.ttf.OpenTypeFont
import com.tom_roush.fontbox.ttf.TTFParser
import com.tom_roush.fontbox.ttf.TrueTypeCollection
import com.tom_roush.fontbox.ttf.TrueTypeFont
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.pdmodel.font.PDFont
import com.tom_roush.pdfbox.pdmodel.font.PDType0Font
import com.tom_roush.pdfbox.pdmodel.font.PDType1Font
import java.io.File

/**
 * Fonts for text we write into PDFs. Plain Western text uses Helvetica (not embedded).
 * Everything else uses fonts that ship with Android, embedded as a subset.
 *
 * PdfBox can only embed fonts with TrueType outlines. Some phones only have CJK fonts
 * with CFF outlines (NotoSansCJK .ttc); [PdfText] then draws those lines as images.
 */
object PdfFonts {

    /** System font files in the order we try them. A ",n" suffix picks a font inside a .ttc. */
    private val candidates = listOf(
        "/system/fonts/Roboto-Regular.ttf",
        "/system/fonts/NotoSans-Regular.ttf",
        "/system/fonts/NotoNaskhArabic-Regular.ttf",
        "/system/fonts/NotoNaskhArabicUI-Regular.ttf",
        "/system/fonts/NotoSansArabic-Regular.ttf",
        "/system/fonts/NotoSansHebrew-Regular.ttf",
        "/system/fonts/NotoSansDevanagari-Regular.ttf",
        "/system/fonts/NotoSansDevanagari-VF.ttf",
        "/system/fonts/NotoSansDevanagariUI-Regular.ttf",
        "/system/fonts/NotoSansDevanagariUI-VF.ttf",
        "/system/fonts/NotoSansThai-Regular.ttf",
        "/system/fonts/NotoSansArmenian-Regular.ttf",
        "/system/fonts/NotoSansGeorgian-Regular.ttf",
        "/system/fonts/DroidSansFallbackFull.ttf",
        "/system/fonts/DroidSansFallback.ttf",
        "/system/fonts/NotoSansCJK-Regular.ttc,0",
        "/system/fonts/DroidSans.ttf",
    )

    /** Parsed system fonts, shared across documents. Null when a file is missing or can't be embedded. */
    private val parsed = HashMap<String, TrueTypeFont?>()

    /** Fonts PdfBox can embed, parsed lazily and in order. */
    fun systemFonts(): Sequence<Pair<String, TrueTypeFont>> = candidates.asSequence().mapNotNull { spec ->
        val ttf = synchronized(parsed) { parsed.getOrPut(spec) { parse(spec) } } ?: return@mapNotNull null
        spec to ttf
    }

    private fun parse(spec: String): TrueTypeFont? {
        val path = spec.substringBefore(',')
        val file = File(path)
        if (!file.exists()) return null
        return runCatching {
            val ttf: TrueTypeFont? = if (path.endsWith(".ttc")) {
                val index = spec.substringAfter(',', "0").toInt()
                var found: TrueTypeFont? = null
                var i = 0
                TrueTypeCollection(file.inputStream()).processAllFonts { font -> if (i++ == index) found = font }
                found
            } else {
                file.inputStream().use { TTFParser(false, true).parse(it) }
            }
            // PdfBox can only embed (and subset) fonts with TrueType outlines: CFF-based
            // OpenType fonts have no 'glyf' table.
            if (ttf == null || (ttf is OpenTypeFont && ttf.isPostScript) || !ttf.tableMap.containsKey("glyf")) null else ttf
        }.getOrNull()
    }

    fun hasGlyph(ttf: TrueTypeFont, codePoint: Int): Boolean =
        runCatching { (ttf.getUnicodeCmapLookup(false)?.getGlyphId(codePoint) ?: 0) > 0 }.getOrDefault(false)

    /** True for characters Helvetica (WinAnsi) can show without embedding a font. */
    fun isWinAnsi(codePoint: Int): Boolean =
        codePoint in 0x20..0x7E || codePoint in 0xA0..0xFF || codePoint in winAnsiExtras

    private val winAnsiExtras = setOf(
        0x20AC, 0x201A, 0x0192, 0x201E, 0x2026, 0x2020, 0x2021, 0x02C6, 0x2030, 0x0160, 0x2039, 0x0152,
        0x017D, 0x2018, 0x2019, 0x201C, 0x201D, 0x2022, 0x2013, 0x2014, 0x02DC, 0x2122, 0x0161, 0x203A,
        0x0153, 0x017E, 0x0178,
    )

    fun isRtl(text: String) = text.any {
        val d = Character.getDirectionality(it)
        d == Character.DIRECTIONALITY_RIGHT_TO_LEFT || d == Character.DIRECTIONALITY_RIGHT_TO_LEFT_ARABIC
    }

    /**
     * The fonts loaded into one document. PDType0Font objects belong to a document, so
     * each output document gets its own set.
     */
    class FontSet(
        private val doc: PDDocument,
        private val bold: Boolean = false,
        /** PDF/A: embed every font, even for plain Western text. */
        private val embedAll: Boolean = false,
    ) {
        private val loaded = LinkedHashMap<String, PDType0Font>()
        private val ttfs = LinkedHashMap<String, TrueTypeFont>()

        val helvetica: PDFont get() = when {
            embedAll -> embeddedFor('A'.code) ?: PDType1Font.HELVETICA
            bold -> PDType1Font.HELVETICA_BOLD
            else -> PDType1Font.HELVETICA
        }

        /** The first font that has [codePoint], or null when no embeddable font has it. */
        fun fontFor(codePoint: Int): PDFont? {
            if (!embedAll && isWinAnsi(codePoint)) return helvetica
            return embeddedFor(codePoint)
        }

        private fun embeddedFor(codePoint: Int): PDFont? {
            for ((spec, ttf) in ttfs) if (hasGlyph(ttf, codePoint)) return loaded[spec]
            for ((spec, ttf) in systemFonts()) {
                if (spec in ttfs || !hasGlyph(ttf, codePoint)) continue
                val font = runCatching { PDType0Font.load(doc, ttf, true) }.getOrNull() ?: continue
                ttfs[spec] = ttf
                loaded[spec] = font
                return font
            }
            return null
        }

        /**
         * One font that covers every character in [text]. Fillable forms need it embedded
         * in full ([subset] false) so viewers can draw new values; flattened forms can subset.
         */
        fun fullFontFor(text: String, subset: Boolean = false): PDType0Font? {
            val needed = text.codePoints().toArray().filter { !Character.isWhitespace(it) }
            for ((_, ttf) in systemFonts()) {
                if (needed.all { hasGlyph(ttf, it) }) return runCatching { PDType0Font.load(doc, ttf, subset) }.getOrNull()
            }
            return null
        }
    }
}
