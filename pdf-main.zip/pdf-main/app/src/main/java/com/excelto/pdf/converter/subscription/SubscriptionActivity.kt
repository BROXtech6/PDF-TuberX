package com.excelto.pdf.converter.subscription

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.annotation.StringRes
import androidx.compose.ui.res.pluralStringResource
import androidx.compose.ui.res.stringResource
import androidx.activity.OnBackPressedCallback
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.android.billingclient.api.AcknowledgePurchaseParams
import com.android.billingclient.api.BillingClient
import com.android.billingclient.api.BillingClientStateListener
import com.android.billingclient.api.BillingFlowParams
import com.android.billingclient.api.BillingResult
import com.android.billingclient.api.PendingPurchasesParams
import com.android.billingclient.api.ProductDetails
import com.android.billingclient.api.Purchase
import com.android.billingclient.api.PurchasesUpdatedListener
import com.android.billingclient.api.QueryProductDetailsParams
import com.android.billingclient.api.QueryPurchasesParams
import com.excelto.pdf.converter.MainActivity
import com.excelto.pdf.converter.R
import com.excelto.pdf.converter.core.storage.AppPrefs
import com.excelto.pdf.converter.ui.components.PrimaryButton
import com.excelto.pdf.converter.ui.theme.AppIcons
import com.excelto.pdf.converter.ui.theme.AppTheme
import com.excelto.pdf.converter.ui.theme.LocalPalette
import com.excelto.pdf.converter.ui.theme.Type
import com.google.firebase.analytics.FirebaseAnalytics

/**
 * The Pro paywall. Same Google Play products and purchase checks as before
 * (weekly_sub and monthly_sub subscriptions, life_time one-time purchase), with a
 * clearer design: what Pro gives, three plans with real prices from Google Play,
 * free-trial wording when an offer has one, Restore purchases, and an always-visible
 * close button.
 */
class SubscriptionActivity : AppCompatActivity(), PurchasesUpdatedListener {

    enum class Plan(val productId: String, @StringRes val title: Int) {
        WEEKLY("weekly_sub", R.string.paywall_plan_weekly),
        MONTHLY("monthly_sub", R.string.paywall_plan_monthly),
        LIFETIME("life_time", R.string.paywall_plan_lifetime),
    }

    /** What Google Play says about one plan. */
    data class Price(val formatted: String, val micros: Long, val period: String?, val trialDays: Int?)

    private lateinit var billing: BillingClient
    private lateinit var analytics: FirebaseAnalytics
    private val details = HashMap<Plan, ProductDetails>()
    private val offers = HashMap<Plan, ProductDetails.SubscriptionOfferDetails>()

    private var prices by mutableStateOf<Map<Plan, Price>>(emptyMap())
    private var selected by mutableStateOf(Plan.MONTHLY)
    private var busy by mutableStateOf(false)

    private val fromStart get() = intent.getStringExtra("sub") == "start_activity"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        analytics = FirebaseAnalytics.getInstance(this)
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() = close()
        })
        billing = BillingClient.newBuilder(this)
            .setListener(this)
            .enablePendingPurchases(PendingPurchasesParams.newBuilder().enableOneTimeProducts().build())
            .build()
        connect()
        setContent { AppTheme(AppPrefs(this).themeMode) { Screen() } }
    }

    private fun close() {
        if (fromStart) startActivity(Intent(this, MainActivity::class.java))
        finish()
    }

    // ---- Billing -----------------------------------------------------------------------------

    private fun connect(then: (() -> Unit)? = null) {
        billing.startConnection(object : BillingClientStateListener {
            override fun onBillingServiceDisconnected() { Log.w(TAG, "Billing disconnected") }
            override fun onBillingSetupFinished(result: BillingResult) {
                if (result.responseCode != BillingClient.BillingResponseCode.OK) {
                    Log.e(TAG, "Billing setup failed: ${result.debugMessage}")
                    return
                }
                loadProducts()
                logCurrentStatus()
                then?.invoke()
            }
        })
    }

    private fun loadProducts() {
        val subs = listOf(Plan.WEEKLY, Plan.MONTHLY).map {
            QueryProductDetailsParams.Product.newBuilder().setProductId(it.productId).setProductType(BillingClient.ProductType.SUBS).build()
        }
        billing.queryProductDetailsAsync(QueryProductDetailsParams.newBuilder().setProductList(subs).build()) { result, list ->
            if (result.responseCode != BillingClient.BillingResponseCode.OK) return@queryProductDetailsAsync
            val found = HashMap<Plan, Price>()
            for (pd in list.productDetailsList) {
                val plan = Plan.entries.firstOrNull { it.productId == pd.productId } ?: continue
                val offer = bestOffer(pd) ?: continue
                val phases = offer.pricingPhases.pricingPhaseList
                val trial = phases.firstOrNull { it.priceAmountMicros == 0L }
                val base = phases.lastOrNull { it.priceAmountMicros > 0L } ?: phases.last()
                details[plan] = pd
                offers[plan] = offer
                found[plan] = Price(base.formattedPrice, base.priceAmountMicros, base.billingPeriod, trial?.let { days(it.billingPeriod) })
            }
            runOnUiThread { prices = prices + found }
        }
        val life = QueryProductDetailsParams.Product.newBuilder().setProductId(Plan.LIFETIME.productId).setProductType(BillingClient.ProductType.INAPP).build()
        billing.queryProductDetailsAsync(QueryProductDetailsParams.newBuilder().setProductList(listOf(life)).build()) { result, list ->
            if (result.responseCode != BillingClient.BillingResponseCode.OK) return@queryProductDetailsAsync
            val pd = list.productDetailsList.firstOrNull() ?: return@queryProductDetailsAsync
            val one = pd.oneTimePurchaseOfferDetails ?: return@queryProductDetailsAsync
            details[Plan.LIFETIME] = pd
            runOnUiThread { prices = prices + (Plan.LIFETIME to Price(one.formattedPrice, one.priceAmountMicros, null, null)) }
        }
    }

    /** Prefers an offer with a free trial, like the previous paywall. */
    private fun bestOffer(pd: ProductDetails): ProductDetails.SubscriptionOfferDetails? {
        val all = pd.subscriptionOfferDetails ?: return null
        return all.firstOrNull { o -> o.pricingPhases.pricingPhaseList.any { it.priceAmountMicros == 0L } } ?: all.firstOrNull()
    }

    private fun buy() {
        val plan = selected
        log("subscribe_click", plan)
        if (!billing.isReady) {
            Toast.makeText(this, R.string.paywall_connecting, Toast.LENGTH_SHORT).show()
            connect { runOnUiThread { buy() } }
            return
        }
        val pd = details[plan]
        if (pd == null) {
            Toast.makeText(this, R.string.paywall_unavailable, Toast.LENGTH_SHORT).show()
            return
        }
        val params = BillingFlowParams.ProductDetailsParams.newBuilder().setProductDetails(pd)
        offers[plan]?.let { params.setOfferToken(it.offerToken) }
        log("subscribe_flow_start", plan)
        busy = true
        billing.launchBillingFlow(this, BillingFlowParams.newBuilder().setProductDetailsParamsList(listOf(params.build())).build())
    }

    override fun onPurchasesUpdated(result: BillingResult, purchases: MutableList<Purchase>?) {
        runOnUiThread { busy = false }
        when (result.responseCode) {
            BillingClient.BillingResponseCode.OK -> purchases?.forEach { handle(it) }
            BillingClient.BillingResponseCode.USER_CANCELED -> log("subscription_cancel", selected, "reason" to "user_canceled")
            BillingClient.BillingResponseCode.ITEM_ALREADY_OWNED -> restore()
            else -> {
                logError("purchases_updated", result.responseCode, result.debugMessage)
                runOnUiThread { Toast.makeText(this, R.string.paywall_failed, Toast.LENGTH_SHORT).show() }
            }
        }
    }

    private fun handle(purchase: Purchase) {
        when (purchase.purchaseState) {
            Purchase.PurchaseState.PURCHASED -> {
                if (!validSignature(purchase)) {
                    logError("verify", -1, "invalid_signature")
                    runOnUiThread { Toast.makeText(this, R.string.paywall_unverified, Toast.LENGTH_SHORT).show() }
                    return
                }
                if (!purchase.isAcknowledged) {
                    billing.acknowledgePurchase(AcknowledgePurchaseParams.newBuilder().setPurchaseToken(purchase.purchaseToken).build()) { }
                }
                unlock(purchase.products.firstOrNull() ?: selected.productId, purchase.purchaseToken)
            }
            Purchase.PurchaseState.PENDING -> runOnUiThread {
                Toast.makeText(this, R.string.paywall_pending, Toast.LENGTH_LONG).show()
            }
            else -> Unit
        }
    }

    private fun validSignature(p: Purchase): Boolean = runCatching {
        VerifyPurchase.verifyPurchase(getString(R.string.base64key), p.originalJson, p.signature)
    }.getOrDefault(false)

    private fun unlock(productId: String, token: String) {
        getSharedPreferences("settings", MODE_PRIVATE).edit().putBoolean("is_premium", true).commit()
        analytics.logEvent("subscription_success", Bundle().apply {
            putString("plan", productId); putString("product_id", productId); putString("purchase_token", token)
        })
        analytics.setUserProperty("subscriber", "yes")
        runOnUiThread {
            Toast.makeText(this, R.string.paywall_welcome, Toast.LENGTH_SHORT).show()
            // Restart so every screen (and the ads) sees the new status.
            packageManager.getLaunchIntentForPackage(packageName)?.let {
                startActivity(it.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK))
            }
            finish()
        }
    }

    /** Finds an earlier purchase on this Google account and unlocks Pro. */
    private fun restore() {
        if (!billing.isReady) { connect { restore() }; return }
        runOnUiThread { busy = true }
        billing.queryPurchasesAsync(QueryPurchasesParams.newBuilder().setProductType(BillingClient.ProductType.SUBS).build()) { _, subs ->
            billing.queryPurchasesAsync(QueryPurchasesParams.newBuilder().setProductType(BillingClient.ProductType.INAPP).build()) { _, inApp ->
                val owned = (subs + inApp).firstOrNull { it.purchaseState == Purchase.PurchaseState.PURCHASED && validSignature(it) }
                runOnUiThread { busy = false }
                if (owned != null) {
                    if (!owned.isAcknowledged) billing.acknowledgePurchase(AcknowledgePurchaseParams.newBuilder().setPurchaseToken(owned.purchaseToken).build()) { }
                    unlock(owned.products.firstOrNull() ?: "restored", owned.purchaseToken)
                } else {
                    runOnUiThread { Toast.makeText(this, R.string.paywall_none_found, Toast.LENGTH_LONG).show() }
                }
            }
        }
    }

    private fun logCurrentStatus() {
        billing.queryPurchasesAsync(QueryPurchasesParams.newBuilder().setProductType(BillingClient.ProductType.SUBS).build()) { _, subs ->
            billing.queryPurchasesAsync(QueryPurchasesParams.newBuilder().setProductType(BillingClient.ProductType.INAPP).build()) { _, inApp ->
                val active = (subs + inApp).firstOrNull { it.purchaseState == Purchase.PurchaseState.PURCHASED }
                analytics.logEvent("subscription_status", Bundle().apply {
                    putInt("is_subscribed", if (active != null) 1 else 0)
                    putString("plan", active?.products?.firstOrNull() ?: selected.productId)
                })
                analytics.setUserProperty("subscriber", if (active != null) "yes" else "no")
            }
        }
    }

    private fun log(event: String, plan: Plan, vararg extra: Pair<String, String>) {
        analytics.logEvent(event, Bundle().apply { putString("plan", plan.productId); extra.forEach { putString(it.first, it.second) } })
    }

    private fun logError(stage: String, code: Int, message: String?) {
        analytics.logEvent("subscription_error", Bundle().apply { putString("stage", stage); putInt("code", code); putString("message", message) })
    }

    override fun onDestroy() {
        super.onDestroy()
        runCatching { billing.endConnection() }
    }

    // ---- UI ----------------------------------------------------------------------------------

    @Composable
    private fun Screen() {
        val p = LocalPalette.current
        Box(Modifier.fillMaxSize().background(p.bg).windowInsetsPadding(WindowInsets.safeDrawing)) {
            Column(
                Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp),
            ) {
                Column(Modifier.fillMaxWidth().padding(top = 36.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Box(Modifier.size(64.dp).clip(RoundedCornerShape(20.dp)).background(p.primarySoft), contentAlignment = Alignment.Center) {
                        Icon(AppIcons.star, null, tint = p.primaryText, modifier = Modifier.size(32.dp))
                    }
                    Text(stringResource(R.string.paywall_title), style = Type.title.copy(fontSize = 24.sp), color = p.text, textAlign = TextAlign.Center)
                    Text(stringResource(R.string.paywall_subtitle), style = Type.body, color = p.muted, textAlign = TextAlign.Center)
                }
                Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(p.surface).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Benefit(stringResource(R.string.paywall_benefit_no_ads))
                    Benefit(stringResource(R.string.paywall_benefit_office))
                    Benefit(stringResource(R.string.paywall_benefit_redact))
                    Benefit(stringResource(R.string.paywall_benefit_new_tools))
                    Benefit(stringResource(R.string.paywall_benefit_offline))
                }
                Plans()
                val price = prices[selected]
                val trial = price?.trialDays
                PrimaryButton(
                    when {
                        busy -> stringResource(R.string.paywall_wait)
                        trial != null -> pluralStringResource(R.plurals.paywall_start_trial, trial, trial)
                        selected == Plan.LIFETIME -> stringResource(R.string.paywall_buy_once)
                        else -> stringResource(R.string.paywall_continue)
                    },
                    { if (!busy) buy() },
                    enabled = !busy,
                )
                Text(
                    footnote(selected, price),
                    style = Type.small, color = p.muted, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth(),
                )
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                    Link(stringResource(R.string.paywall_restore)) { restore() }
                    Text("·", style = Type.small, color = p.muted)
                    Link(stringResource(R.string.paywall_terms)) { TermsAndConditionsDialog().show(supportFragmentManager, "terms") }
                    Text("·", style = Type.small, color = p.muted)
                    Link(stringResource(R.string.paywall_privacy)) {
                        startActivity(Intent(this@SubscriptionActivity, com.excelto.pdf.converter.legal.PrivacyActivity::class.java))
                    }
                }
            }
            // The close button is always visible, as Google Play requires.
            Box(
                Modifier.align(Alignment.TopEnd).padding(8.dp).size(44.dp).clip(CircleShape).background(p.surface)
                    .clickable(role = Role.Button, onClickLabel = stringResource(R.string.paywall_close)) { close() },
                contentAlignment = Alignment.Center,
            ) { Icon(AppIcons.close, stringResource(R.string.paywall_close), tint = p.text, modifier = Modifier.size(20.dp)) }
        }
    }

    @Composable
    private fun Benefit(text: String) {
        val p = LocalPalette.current
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Box(Modifier.size(24.dp).clip(CircleShape).background(p.primary), contentAlignment = Alignment.Center) {
                Icon(AppIcons.check, null, tint = p.onPrimary, modifier = Modifier.size(14.dp))
            }
            Text(text, style = Type.bodyStrong, color = p.text)
        }
    }

    @Composable
    private fun Plans() {
        val weekly = prices[Plan.WEEKLY]
        val monthly = prices[Plan.MONTHLY]
        val save = PaywallMath.savingPercent(weekly?.micros, monthly?.micros)
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            PlanCard(Plan.MONTHLY, monthly, badge = save?.let { stringResource(R.string.paywall_save, it) })
            PlanCard(Plan.LIFETIME, prices[Plan.LIFETIME], badge = stringResource(R.string.paywall_best_value))
            PlanCard(Plan.WEEKLY, weekly, badge = null)
        }
    }

    /** The line under a plan's name: its trial, or how often it's paid. */
    @Composable
    private fun planDetail(plan: Plan, price: Price?): String {
        val trial = price?.trialDays
        return when {
            plan == Plan.LIFETIME -> stringResource(R.string.paywall_pay_once)
            trial != null -> pluralStringResource(
                if (plan == Plan.WEEKLY) R.plurals.paywall_trial_week else R.plurals.paywall_trial_month, trial, trial, price.formatted,
            )
            else -> stringResource(if (plan == Plan.WEEKLY) R.string.paywall_per_week else R.string.paywall_per_month)
        }
    }

    @Composable
    private fun PlanCard(plan: Plan, price: Price?, badge: String?) {
        val p = LocalPalette.current
        val on = selected == plan
        Box {
            Row(
                Modifier.fillMaxWidth().heightIn(min = 68.dp).clip(RoundedCornerShape(16.dp))
                    .background(if (on) p.primarySoft else p.surface)
                    .border(if (on) 2.dp else 1.dp, if (on) p.primaryText else p.line, RoundedCornerShape(16.dp))
                    .selectable(selected = on, role = Role.RadioButton) { selected = plan; log("plan_select", plan) }
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                Box(
                    Modifier.size(22.dp).clip(CircleShape).border(2.dp, if (on) p.primaryText else p.line, CircleShape),
                    contentAlignment = Alignment.Center,
                ) { if (on) Box(Modifier.size(12.dp).clip(CircleShape).background(p.primaryText)) }
                Column(Modifier.weight(1f)) {
                    Text(stringResource(plan.title), style = Type.bodyStrong.copy(fontSize = 16.sp), color = p.text)
                    Text(planDetail(plan, price), style = Type.small, color = p.muted)
                }
                Text(price?.formatted ?: "…", style = Type.bodyStrong.copy(fontSize = 16.sp), color = p.text)
            }
            if (badge != null) {
                Text(
                    badge, style = Type.tiny.copy(fontSize = 11.sp), color = p.onPrimary,
                    modifier = Modifier.align(Alignment.TopEnd).offset(x = (-14).dp, y = (-9).dp).clip(RoundedCornerShape(10.dp))
                        .background(p.primary).padding(horizontal = 8.dp, vertical = 3.dp),
                )
            }
        }
    }

    @Composable
    private fun Link(text: String, onClick: () -> Unit) {
        val p = LocalPalette.current
        Text(text, style = Type.small, color = p.primaryText, modifier = Modifier.heightIn(min = 44.dp).clip(RoundedCornerShape(8.dp))
            .clickable(role = Role.Button, onClick = onClick).padding(horizontal = 8.dp, vertical = 13.dp))
    }

    @Composable
    private fun footnote(plan: Plan, price: Price?): String {
        val trial = price?.trialDays
        return when {
            plan == Plan.LIFETIME -> stringResource(R.string.paywall_note_lifetime)
            trial != null -> pluralStringResource(
                if (plan == Plan.WEEKLY) R.plurals.paywall_note_trial_week else R.plurals.paywall_note_trial_month, trial, trial, price.formatted,
            )
            else -> stringResource(R.string.paywall_note_renews)
        }
    }

    companion object {
        private const val TAG = "Paywall"

        private fun days(period: String): Int? = PaywallMath.days(period)
    }
}

/** Paywall arithmetic. Pure logic, unit tested. */
object PaywallMath {
    /** ISO-8601 billing periods like P3D, P1W, P1M to days. */
    fun days(period: String?): Int? {
        val m = Regex("P(\\d+)([DWMY])").matchEntire(period ?: return null) ?: return null
        val n = m.groupValues[1].toInt()
        return when (m.groupValues[2]) { "D" -> n; "W" -> n * 7; "M" -> n * 30; else -> n * 365 }
    }

    /** How much cheaper monthly is than paying weekly for a month, in whole percent. */
    fun savingPercent(weeklyMicros: Long?, monthlyMicros: Long?): Int? {
        if (weeklyMicros == null || monthlyMicros == null || weeklyMicros <= 0) return null
        val weeklyPerMonth = weeklyMicros * 52.0 / 12.0
        val pct = ((1 - monthlyMicros / weeklyPerMonth) * 100).toInt()
        return pct.takeIf { it in 5..95 }
    }
}
