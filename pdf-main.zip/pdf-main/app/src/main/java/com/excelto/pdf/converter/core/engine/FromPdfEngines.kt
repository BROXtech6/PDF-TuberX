package com.excelto.pdf.converter.core.engine

import com.excelto.pdf.converter.R
import android.content.Context
import android.graphics.Bitmap
import com.excelto.pdf.converter.core.office.DocxWriter
import com.excelto.pdf.converter.core.office.PdfLayout
import com.excelto.pdf.converter.core.office.PptxWriter
import com.excelto.pdf.converter.core.office.WordDoc
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.tom_roush.pdfbox.contentstream.PDFStreamEngine
import com.tom_roush.pdfbox.contentstream.operator.DrawObject
import com.tom_roush.pdfbox.contentstream.operator.Operator
import com.tom_roush.pdfbox.contentstream.operator.state.Concatenate
import com.tom_roush.pdfbox.contentstream.operator.state.Restore
import com.tom_roush.pdfbox.contentstream.operator.state.Save
import com.tom_roush.pdfbox.contentstream.operator.state.SetGraphicsStateParameters
import com.tom_roush.pdfbox.contentstream.operator.state.SetMatrix
import com.tom_roush.pdfbox.cos.COSArray
import com.tom_roush.pdfbox.cos.COSBase
import com.tom_roush.pdfbox.cos.COSName
import com.tom_roush.pdfbox.cos.COSString
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.pdmodel.PDDocumentInformation
import com.tom_roush.pdfbox.pdmodel.PDPage
import com.tom_roush.pdfbox.pdmodel.PDPageContentStream
import com.tom_roush.pdfbox.pdmodel.common.PDMetadata
import com.tom_roush.pdfbox.pdmodel.common.PDRectangle
import com.tom_roush.pdfbox.pdmodel.graphics.form.PDFormXObject
import com.tom_roush.pdfbox.pdmodel.graphics.image.JPEGFactory
import com.tom_roush.pdfbox.pdmodel.graphics.image.PDImageXObject
import com.tom_roush.pdfbox.pdmodel.graphics.color.PDOutputIntent
import com.tom_roush.pdfbox.text.PDFTextStripper
import java.io.ByteArrayOutputStream
import java.io.File
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import java.util.TimeZone
import java.util.UUID

/** Finds the pictures drawn on a page, with their size and place (top-left based, in points). */
internal class ImageLocator(private val page: PDPage) : PDFStreamEngine() {

    class Found(val image: PDImageXObject, val left: Float, val top: Float, val width: Float, val height: Float)

    val found = mutableListOf<Found>()
    private val seen = HashSet<COSBase>()

    init {
        addOperator(Concatenate())
        addOperator(DrawObject())
        addOperator(SetGraphicsStateParameters())
        addOperator(Save())
        addOperator(Restore())
        addOperator(SetMatrix())
    }

    fun run(): List<Found> {
        processPage(page)
        return found
    }

    override fun processOperator(operator: Operator, operands: List<COSBase>) {
        if (operator.name == "Do") {
            val name = operands.firstOrNull() as? COSName ?: return
            val xobject = runCatching { resources?.getXObject(name) }.getOrNull() ?: return
            when (xobject) {
                is PDImageXObject -> {
                    val m = graphicsState.currentTransformationMatrix
                    val w = m.scalingFactorX
                    val h = m.scalingFactorY
                    if (w < 16f || h < 16f || !seen.add(xobject.cosObject)) return
                    val box = page.cropBox
                    found += Found(xobject, m.translateX - box.lowerLeftX, box.upperRightY - (m.translateY + h), w, h)
                }
                is PDFormXObject -> runCatching { showForm(xobject) }
            }
            return
        }
        super.processOperator(operator, operands)
    }
}

// ---- PDF to Word ----------------------------------------------------------------------

object PdfToWordEngine {

    data class Result(val pages: Int, val paragraphs: Int, val tables: Int, val images: Int)

    /**
     * Rebuilds each page as editable Word content: headings, paragraphs (with bold and
     * italic), tables and pictures in reading order, with a page break between pages.
     * Scans have no text to rebuild, so they are sent to OCR first.
     */
    fun convert(input: PdfTools.Input, out: File, progress: Progress): Result = PdfTools.writing(out) {
        PdfTools.open(input.path, input.password).use { doc ->
            val total = doc.numberOfPages
            val blocks = mutableListOf<WordDoc.Block>()
            val stripper = ChunkStripper()
            var paragraphs = 0
            var tables = 0
            var images = 0
            var anyText = false
            for (i in 0 until total) {
                progress.check()
                val page = doc.getPage(i)
                val frame = PageFrame(page)
                val chunks = runCatching { stripper.page(doc, i + 1) }.getOrDefault(emptyList())
                if (chunks.any { it.text.isNotBlank() }) anyText = true
                val placed = PdfLayout.rebuild(chunks, frame.width).toMutableList()
                if (frame.rotation == 0) {
                    for (img in runCatching { ImageLocator(page).run() }.getOrDefault(emptyList())) {
                        val bytes = imageBytes(img.image) ?: continue
                        placed += PdfLayout.Placed(img.top, WordDoc.Image(bytes.first, bytes.second, img.width, img.height))
                    }
                }
                placed.sortBy { it.top }
                for (p in placed) {
                    when (p.block) {
                        is WordDoc.Paragraph -> paragraphs++
                        is WordDoc.Table -> tables++
                        is WordDoc.Image -> images++
                        else -> Unit
                    }
                    blocks += p.block
                }
                if (i < total - 1) blocks += WordDoc.PageBreak
                progress.step(i + 1, total, 5, 85)
            }
            if (!anyText) {
                throw NeedsOcrException(R.string.err_pdf_scan_no_text, "This PDF is a scan, so it has no text to turn into Word. Run OCR first to recognize the text, then convert again.",
                    input.path,
                )
            }
            val first = PageFrame(doc.getPage(0))
            val page = WordDoc.Page(first.width, first.height, if (minOf(first.width, first.height) < 300f) 18f else 54f)
            DocxWriter.write(out, blocks, page, File(input.path).nameWithoutExtension)
            progress.report(100)
            Result(total, paragraphs, tables, images)
        }
    }

    /** JPEGs are copied as they are; everything else becomes PNG. Very large pictures are skipped. */
    private fun imageBytes(image: PDImageXObject): Pair<ByteArray, Boolean>? = runCatching {
        if (image.width.toLong() * image.height > 25_000_000L) return null
        val filters = image.cosObject.filters
        val onlyDct = filters is COSName && filters == COSName.DCT_DECODE ||
            filters is COSArray && filters.size() == 1 && filters.getObject(0) == COSName.DCT_DECODE
        if (onlyDct && image.colorSpace?.numberOfComponents != 4) {
            image.cosObject.createRawInputStream().use { return it.readBytes() to false }
        }
        val bitmap: Bitmap = image.image ?: return null
        try {
            val out = ByteArrayOutputStream()
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
            out.toByteArray() to true
        } finally {
            bitmap.recycle()
        }
    }.getOrNull()
}

// ---- PDF to PowerPoint ------------------------------------------------------------------

object PdfToPptEngine {

    private const val DPI = 200f

    /** One slide per page: the page as a sharp picture, and its text in the speaker notes. */
    fun convert(input: PdfTools.Input, out: File, workDir: File, progress: Progress): Int = PdfTools.writing(out) {
        val notes = TextEngine.pages(input, progress = Progress.NONE)
        PdfRaster.open(input, workDir).use { raster ->
            val total = raster.pageCount
            if (total == 0) throw UserFacingException(R.string.err_pdf_no_pages, "This PDF has no pages.")
            val (w0, h0) = raster.pageSize(0)
            PptxWriter.write(out, w0, h0, total) { i ->
                progress.check()
                val (pw, ph) = raster.pageSize(i)
                val bitmap = raster.render(i, DPI, maxPixels = 12_000_000L)
                val bytes = try {
                    ByteArrayOutputStream().also { bitmap.compress(Bitmap.CompressFormat.JPEG, 90, it) }.toByteArray()
                } finally {
                    bitmap.recycle()
                }
                progress.step(i + 1, total, 5, 95)
                PptxWriter.Slide(bytes, isPng = false, notes = notes.getOrElse(i) { "" }, aspect = pw / ph)
            }
            progress.report(100)
            total
        }
    }
}

// ---- PDF to PDF/A -----------------------------------------------------------------------

object PdfToPdfAEngine {

    data class Result(val pages: Int, val ocrPages: Int)

    private const val DPI = 200f

    /**
     * Makes a PDF/A-2b copy for long-term archiving. Each page is redrawn as a picture so
     * nothing a PDF/A file forbids (transparency groups, unembedded fonts, JavaScript,
     * encryption) carries over, and the text is kept as an invisible, searchable layer
     * in embedded fonts. Adds the sRGB output intent, XMP identification and a file ID.
     */
    fun convert(context: Context, input: PdfTools.Input, out: File, workDir: File, progress: Progress): Result = PdfTools.writing(out) {
        PdfTools.open(input.path, input.password).use { source ->
            val total = source.numberOfPages
            if (total == 0) throw UserFacingException(R.string.err_pdf_no_pages, "This PDF has no pages.")
            val info = source.documentInformation
            val title = info?.title?.takeIf { it.isNotBlank() } ?: File(input.path).nameWithoutExtension
            val stripper = ChunkStripper()
            var ocrPages = 0
            val recognizer by lazy { ScanEngine.recognizerFor(OcrScript.LATIN) }
            PDDocument().use { doc ->
                val fonts = PdfFonts.FontSet(doc, embedAll = true)
                PdfRaster.open(input, workDir).use { raster ->
                    for (i in 0 until total) {
                        progress.check()
                        val (w, h) = raster.pageSize(i)
                        val bitmap = raster.render(i, DPI, maxPixels = 16_000_000L)
                        try {
                            val page = PDPage(PDRectangle(w, h))
                            doc.addPage(page)
                            val image = JPEGFactory.createFromImage(doc, bitmap, 0.85f)
                            PDPageContentStream(doc, page).use { cs ->
                                cs.drawImage(image, 0f, 0f, w, h)
                                val srcPage = source.getPage(i)
                                val chunks = if (PageFrame(srcPage).rotation == 0) runCatching { stripper.page(source, i + 1) }.getOrDefault(emptyList()) else emptyList()
                                if (chunks.isNotEmpty()) {
                                    for (line in TextEngine.group(chunks, i, w, h)) {
                                        val r = line.rect
                                        ScanEngine.invisibleLine(cs, fonts, line.text, r.left * w, h - r.bottom * h, (r.right - r.left) * w, (r.bottom - r.top) * h)
                                    }
                                } else {
                                    val scale = bitmap.width / w
                                    val text = runCatching { Tasks.await(recognizer.process(InputImage.fromBitmap(bitmap, 0))) }.getOrNull()
                                    val lines = text?.textBlocks?.flatMap { it.lines }.orEmpty()
                                    if (lines.isNotEmpty()) ocrPages++
                                    for (line in lines) {
                                        val box = line.boundingBox ?: continue
                                        ScanEngine.invisibleLine(cs, fonts, line.text.trim(), box.left / scale, h - box.bottom / scale, box.width() / scale, box.height() / scale)
                                    }
                                }
                            }
                        } finally {
                            bitmap.recycle()
                        }
                        progress.step(i + 1, total, 5, 90)
                    }
                }
                addPdfAParts(context, doc, title, info?.author)
                doc.save(out)
            }
            progress.report(100)
            Result(total, ocrPages)
        }
    }

    private fun addPdfAParts(context: Context, doc: PDDocument, title: String, author: String?) {
        val now = Calendar.getInstance(TimeZone.getTimeZone("UTC"))
        val iso = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US).apply { timeZone = TimeZone.getTimeZone("UTC") }.format(now.time)
        doc.documentInformation = PDDocumentInformation().apply {
            this.title = title
            if (!author.isNullOrBlank()) this.author = author
            producer = "PDF Converter"
            creator = "PDF Converter"
            creationDate = now
            modificationDate = now
        }
        fun x(s: String) = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
        val xmp = buildString {
            append("""<?xpacket begin="" id="W5M0MpCehiHzreSzNTczkc9d"?>""")
            append("""<x:xmpmeta xmlns:x="adobe:ns:meta/"><rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#">""")
            append("""<rdf:Description rdf:about="" xmlns:pdfaid="http://www.aiim.org/pdfa/ns/id/"><pdfaid:part>2</pdfaid:part><pdfaid:conformance>B</pdfaid:conformance></rdf:Description>""")
            append("""<rdf:Description rdf:about="" xmlns:dc="http://purl.org/dc/elements/1.1/"><dc:format>application/pdf</dc:format>""")
            append("""<dc:title><rdf:Alt><rdf:li xml:lang="x-default">${x(title)}</rdf:li></rdf:Alt></dc:title>""")
            if (!author.isNullOrBlank()) append("""<dc:creator><rdf:Seq><rdf:li>${x(author)}</rdf:li></rdf:Seq></dc:creator>""")
            append("</rdf:Description>")
            append("""<rdf:Description rdf:about="" xmlns:xmp="http://ns.adobe.com/xap/1.0/"><xmp:CreateDate>$iso</xmp:CreateDate><xmp:ModifyDate>$iso</xmp:ModifyDate><xmp:MetadataDate>$iso</xmp:MetadataDate><xmp:CreatorTool>PDF Converter</xmp:CreatorTool></rdf:Description>""")
            append("""<rdf:Description rdf:about="" xmlns:pdf="http://ns.adobe.com/pdf/1.3/"><pdf:Producer>PDF Converter</pdf:Producer></rdf:Description>""")
            append("""</rdf:RDF></x:xmpmeta><?xpacket end="w"?>""")
        }
        val metadata = PDMetadata(doc)
        metadata.importXMPMetadata(xmp.toByteArray(Charsets.UTF_8))
        doc.documentCatalog.metadata = metadata

        context.assets.open("sRGB.icc").use { icc ->
            val intent = PDOutputIntent(doc, icc)
            intent.info = "sRGB IEC61966-2.1"
            intent.outputCondition = "sRGB IEC61966-2.1"
            intent.outputConditionIdentifier = "sRGB IEC61966-2.1"
            intent.registryName = "http://www.color.org"
            doc.documentCatalog.addOutputIntent(intent)
        }

        val id = MessageDigest.getInstance("MD5").digest((UUID.randomUUID().toString() + title).toByteArray())
        doc.document.documentID = COSArray().apply { add(COSString(id)); add(COSString(id)) }
    }
}
