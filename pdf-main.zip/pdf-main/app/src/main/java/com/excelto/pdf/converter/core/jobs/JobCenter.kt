package com.excelto.pdf.converter.core.jobs

import com.excelto.pdf.converter.language.trPlural
import com.excelto.pdf.converter.language.tr
import com.excelto.pdf.converter.R
import com.excelto.pdf.converter.core.engine.NeedsOcrException
import com.excelto.pdf.converter.core.engine.PasswordRequiredException
import com.excelto.pdf.converter.core.engine.Progress
import com.excelto.pdf.converter.core.engine.UserFacingException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.io.File

data class JobResult(
    val files: List<File>,
    /** One line under the file name, such as "Reduced from 4.2 MB to 1.1 MB". */
    val detail: String,
    val bytesSaved: Long = 0,
)

sealed interface JobState {
    val title: String
    val steps: List<String>

    data class Running(override val title: String, override val steps: List<String>, val percent: Int) : JobState
    data class Done(
        override val title: String,
        override val steps: List<String>,
        val result: JobResult,
        val seen: Boolean,
        /** When the job finished (elapsedRealtime), so stale results never trigger an ad. */
        val finishedAt: Long = android.os.SystemClock.elapsedRealtime(),
    ) : JobState
    data class Failed(override val title: String, override val steps: List<String>, val message: String, val needsPassword: Boolean, val ocrPath: String? = null) : JobState
}

/**
 * Runs one job at a time outside any screen, so the user can keep working while it
 * runs. Screens observe [state].
 */
object JobCenter {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var current: Job? = null

    private val _state = MutableStateFlow<JobState?>(null)
    val state: StateFlow<JobState?> = _state.asStateFlow()

    val isBusy: Boolean get() = _state.value is JobState.Running

    fun start(
        title: String,
        steps: List<String> = listOf("Reading file", "Applying changes", "Saving file"),
        onFinished: (JobResult) -> Unit = {},
        work: suspend (Progress) -> JobResult,
    ): Boolean {
        if (isBusy) return false
        _state.value = JobState.Running(title, steps, 0)
        current = scope.launch {
            val job = coroutineContext[Job]
            val progress = Progress(job) { p ->
                val s = _state.value
                if (s is JobState.Running) _state.value = s.copy(percent = p)
            }
            try {
                val result = work(progress)
                _state.value = JobState.Done(title, steps, result, seen = false)
                onFinished(result)
            } catch (e: CancellationException) {
                _state.value = null
            } catch (e: PasswordRequiredException) {
                _state.value = JobState.Failed(title, steps, tr(R.string.job_err_password), needsPassword = true)
            } catch (e: NeedsOcrException) {
                _state.value = JobState.Failed(title, steps, e.localizedMessage ?: "", needsPassword = false, ocrPath = e.path)
            } catch (e: UserFacingException) {
                _state.value = JobState.Failed(title, steps, e.localizedMessage ?: tr(R.string.job_err_generic), needsPassword = false)
            } catch (e: OutOfMemoryError) {
                _state.value = JobState.Failed(title, steps, tr(R.string.job_err_memory), needsPassword = false)
            } catch (e: Throwable) {
                android.util.Log.e("JobCenter", "Job failed: $title", e)
                _state.value = JobState.Failed(title, steps, tr(R.string.job_err_unknown), needsPassword = false)
            }
        }
        return true
    }

    fun cancel() {
        current?.cancel()
        _state.value = null
    }

    fun markSeen() {
        val s = _state.value
        if (s is JobState.Done) _state.value = s.copy(seen = true)
    }

    fun clear() {
        if (!isBusy) _state.value = null
    }
}
