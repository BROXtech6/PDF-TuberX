package com.excelto.pdf.converter.legal

import com.excelto.pdf.converter.language.tr
import com.excelto.pdf.converter.language.AppLanguage
import com.excelto.pdf.converter.R
import androidx.compose.ui.platform.LocalContext
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.excelto.pdf.converter.core.storage.AppPrefs
import com.excelto.pdf.converter.ui.InnerHeader
import com.excelto.pdf.converter.ui.theme.AppTheme
import com.excelto.pdf.converter.ui.theme.LocalPalette
import com.excelto.pdf.converter.ui.theme.Type

/** The privacy policy, readable inside the app and offline. */
class PrivacyActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { AppTheme(AppPrefs(this).themeMode) { Screen() } }
    }

    @Composable
    private fun Screen() {
        val p = LocalPalette.current
        Column(Modifier.fillMaxSize().background(p.bg).windowInsetsPadding(WindowInsets.safeDrawing)) {
            InnerHeader(tr(R.string.settings_privacy), onBack = { finish() })
            Column(
                Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 18.dp, vertical = 14.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                Text(tr(R.string.privacy_updated, PrivacyPolicy.UPDATED), style = Type.small, color = p.muted)
                Column(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(p.primarySoft).padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp),
                ) {
                    Text(tr(R.string.privacy_in_short), style = Type.bodyStrong, color = p.text)
                    Text(tr(R.string.privacy_summary), style = Type.body, color = p.text)
                }
                // The full policy is the official English text; the summary above is translated.
                if (!AppLanguage.current(LocalContext.current).tag.startsWith("en")) {
                    Text(tr(R.string.privacy_english_note), style = Type.small, color = p.muted)
                }
                PrivacyPolicy.SECTIONS.forEach { (title, body) ->
                    Text(title, style = Type.section.copy(fontSize = 16.sp), color = p.text,
                        modifier = Modifier.padding(top = 8.dp).semantics { heading() })
                    Text(body, style = Type.body, color = p.text)
                }
                Text(
                    PrivacyPolicy.EMAIL, style = Type.bodyStrong, color = p.primaryText,
                    modifier = Modifier.clip(RoundedCornerShape(8.dp)).clickable {
                        runCatching {
                            startActivity(Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:${PrivacyPolicy.EMAIL}"))
                                .putExtra(Intent.EXTRA_SUBJECT, "Privacy question"))
                        }
                    }.padding(vertical = 12.dp),
                )
            }
        }
    }
}

/** The policy text. Keep it in step with the app's real behaviour and the Play Data safety form. */
object PrivacyPolicy {
    const val UPDATED = "November 19, 2026"
    const val EMAIL = "tubertechno77@gmail.com"

    const val SUMMARY =
        "Your documents stay on your phone. Converting, editing, signing, scanning and reading all happen on " +
            "the device, and we never upload your files. The free version shows ads from Google, and we use " +
            "Google tools to count app usage and fix crashes."

    val SECTIONS: List<Pair<String, String>> = listOf(
        "Who we are" to
            "PDF Converter is made by Tubers (\"we\", \"us\"). This policy explains what information the " +
            "app handles, why, and the choices you have.",

        "Your files" to
            "• PDF, Word, PowerPoint, Excel, image and web files you open or create are processed only on your " +
            "phone. We do not upload, collect, read or store them on any server.\n" +
            "• Text recognition (OCR) and document scanning run on your phone.\n" +
            "• Files are saved in your phone's Documents folder. They leave your phone only when you choose to " +
            "share them or open them in another app.\n" +
            "• HTML to PDF: when you enter a web link, the app loads that page directly from its website, like a " +
            "browser does. We don't see the link or the page.",

        "Permissions" to
            "• All files access: to find and open your documents anywhere on your phone and save results.\n" +
            "• Camera: only when you scan a document.\n" +
            "• Notifications: to tell you when a long job is finished and for occasional app news.\n" +
            "• Internet: for ads, purchases, the optional web-page conversion, and the analytics described below.\n" +
            "• Fingerprint or face unlock: only if you turn on App lock. Android checks it; the app never " +
            "receives your biometric data.",

        "Information collected automatically" to
            "We use Google Firebase services to understand how the app is used and to keep it working:\n" +
            "• Firebase Analytics: which screens and tools are used, app version, device model, Android version, " +
            "language, approximate country (from your IP address) and an app-instance ID.\n" +
            "• Firebase Crashlytics and Performance Monitoring: crash reports and speed measurements with device " +
            "details, so we can fix problems.\n" +
            "• Firebase Cloud Messaging: a device token so we can send notifications.\n" +
            "None of these include the contents or names of your documents.",

        "Advertising" to
            "The free version shows ads from Google AdMob. To show and measure ads, Google may use your device's " +
            "advertising ID, IP address, and information about your device and the ads you see or tap. Where the " +
            "law requires it (for example in the EU and UK), we ask for your consent first, and you can change " +
            "your choice at any time in Settings > Ad privacy choices. You can also reset or delete your " +
            "advertising ID in your phone's settings (Settings > Privacy > Ads). Pro users see no ads.\n" +
            "Google's use of this data is described at policies.google.com/technologies/ads.",

        "Purchases" to
            "Pro subscriptions and the lifetime purchase are handled by Google Play. We receive only the purchase " +
            "status and a purchase token to unlock Pro; we never see your card or payment details. Manage or " +
            "cancel subscriptions in the Google Play app.",

        "Sharing and selling" to
            "We do not sell your personal information. Information is shared only with the Google services named " +
            "above, which process it for us, or when the law requires it.",

        "How long we keep data" to
            "Your files stay on your phone until you delete them; uninstalling the app removes its settings. " +
            "Analytics and crash data are kept by Google for a limited time (for example, Firebase Analytics " +
            "keeps data for up to 14 months by default) and are then deleted.",

        "Your choices and rights" to
            "You can turn off personalized ads (see Advertising), deny or remove app permissions in Android " +
            "settings, and stop using the app at any time. Depending on where you live, you may have the right " +
            "to access or delete personal data about you. Email us and we'll help; because we don't hold your " +
            "files or an account for you, most data is on your phone or with Google.",

        "Children" to
            "The app is not directed at children under 13, and we do not knowingly collect personal information " +
            "from them.",

        "Security" to
            "Because documents are processed on your phone, they are protected by your phone's own security. You " +
            "can add App lock and password-protect PDFs. No method of storage or transmission is completely " +
            "secure, but we use Google's standard, encrypted services for the data described above.",

        "Changes to this policy" to
            "If we change this policy, we'll update it here and change the date at the top. Important changes " +
            "will be shown in the app.",

        "Contact us" to
            "Questions about privacy? Email us:",
    )
}
