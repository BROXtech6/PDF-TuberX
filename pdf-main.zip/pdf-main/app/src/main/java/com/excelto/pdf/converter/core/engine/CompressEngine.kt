package com.excelto.pdf.converter.core.engine

import com.excelto.pdf.converter.R

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import com.tom_roush.pdfbox.cos.COSBase
import com.tom_roush.pdfbox.cos.COSName
import com.tom_roush.pdfbox.cos.COSStream
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.pdmodel.PDResources
import com.tom_roush.pdfbox.pdmodel.graphics.form.PDFormXObject
import com.tom_roush.pdfbox.pdmodel.graphics.image.JPEGFactory
import com.tom_roush.pdfbox.pdmodel.graphics.image.PDImageXObject
import java.io.File
import java.util.IdentityHashMap

enum class CompressLevel(@androidx.annotation.StringRes private val labelRes: Int, val scale: Float, val quality: Int) {
    STRONG(R.string.compress_level_strong, 0.5f, 45),
    BALANCED(R.string.compress_level_balanced, 0.75f, 62),
    LIGHT(R.string.compress_level_light, 1f, 80); val label: String get() = com.excelto.pdf.converter.language.tr(labelRes)
}

/**
 * Real compression: photos inside the PDF are resized and saved again as JPEG, which is
 * where most of a PDF's size usually is. Every page's resources are walked, including
 * form XObjects nested inside them. Saving with PdfBox also drops unused objects.
 */
object CompressEngine {

    data class Result(val before: Long, val after: Long)

    private class Walk(val doc: PDDocument, val level: CompressLevel) {
        /** Original image stream → its replacement (or null when it was left alone). */
        val done = IdentityHashMap<COSBase, PDImageXObject?>()
        val visitedForms = IdentityHashMap<COSBase, Boolean>()
    }

    fun compress(input: PdfTools.Input, level: CompressLevel, out: File, progress: Progress): Result {
        val before = File(input.path).length()
        PdfTools.writing(out) {
            PdfTools.open(input.path, input.password).use { doc ->
                PdfTools.requireOwnerRights(doc)
                val walk = Walk(doc, level)
                val total = doc.numberOfPages
                for (i in 0 until total) {
                    progress.check()
                    doc.getPage(i).resources?.let { shrink(it, walk) }
                    progress.step(i + 1, total, 5, 80)
                }
                progress.report(90)
                doc.save(out)
            }
        }
        progress.report(100)
        val after = out.length()
        // If we could not make it smaller, keep the original bytes instead.
        if (after >= before) File(input.path).copyTo(out, overwrite = true)
        return Result(before, minOf(before, after))
    }

    private fun shrink(resources: PDResources, walk: Walk) {
        for (name in resources.xObjectNames.toList()) {
            val ref = resources.cosObject.getCOSDictionary(COSName.XOBJECT)?.getDictionaryObject(name) as? COSStream ?: continue
            when (ref.getCOSName(COSName.SUBTYPE)) {
                COSName.IMAGE -> {
                    val replacement = if (walk.done.containsKey(ref)) walk.done[ref] else {
                        val image = runCatching { resources.getXObject(name) as? PDImageXObject }.getOrNull()
                        val made = image?.let { reencode(it, walk) }
                        walk.done[ref] = made
                        made
                    }
                    if (replacement != null) resources.put(name, replacement)
                }
                COSName.FORM -> {
                    if (walk.visitedForms.put(ref, true) != null) continue
                    val form = runCatching { resources.getXObject(name) as? PDFormXObject }.getOrNull() ?: continue
                    form.resources?.let { shrink(it, walk) }
                }
            }
        }
    }

    private fun reencode(image: PDImageXObject, walk: Walk): PDImageXObject? {
        val stream = image.cosObject
        // Only plain JPEG photos are safe to re-encode. Masks and transparency are skipped.
        val filters = image.stream.filters.orEmpty()
        if (filters.size != 1 || filters[0] != COSName.DCT_DECODE) return null
        if (image.isStencil) return null
        if (stream.getDictionaryObject(COSName.SMASK) != null || stream.getDictionaryObject(COSName.MASK) != null) return null
        if (stream.getDictionaryObject(COSName.DECODE) != null) return null
        val original = runCatching { stream.createRawInputStream().use { it.readBytes() } }.getOrNull() ?: return null
        if (original.size < 20_000) return null

        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(original, 0, original.size, bounds)
        if (bounds.outWidth <= 0) return null // CMYK and other JPEGs Android can't read
        val targetW = (bounds.outWidth * walk.level.scale).toInt().coerceAtLeast(1)
        val targetH = (bounds.outHeight * walk.level.scale).toInt().coerceAtLeast(1)
        var sample = 1
        while (bounds.outWidth / (sample * 2) >= targetW) sample *= 2
        val decoded = BitmapFactory.decodeByteArray(original, 0, original.size, BitmapFactory.Options().apply { inSampleSize = sample })
            ?: return null
        val scaled = if (decoded.width != targetW) Bitmap.createScaledBitmap(decoded, targetW, targetH, true) else decoded
        return try {
            val made = JPEGFactory.createFromImage(walk.doc, scaled, walk.level.quality / 100f)
            val size = made.cosObject.length
            if (size in 1 until original.size) made else null
        } catch (e: Exception) {
            null
        } finally {
            if (scaled !== decoded) scaled.recycle()
            decoded.recycle()
        }
    }
}
