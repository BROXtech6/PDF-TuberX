package com.excelto.pdf.converter.core.office

import com.excelto.pdf.converter.R
import com.excelto.pdf.converter.core.engine.UserFacingException
import org.w3c.dom.Element
import org.w3c.dom.Node
import java.io.File
import java.util.zip.ZipFile
import javax.xml.parsers.DocumentBuilderFactory

/** A Word document laid out as a flow of blocks, ready to paginate. Sizes are in points. */
object Flow {
    data class Style(
        val bold: Boolean = false,
        val italic: Boolean = false,
        val underline: Boolean = false,
        val strike: Boolean = false,
        val sizePt: Float = 11f,
        val color: Int? = null,
        val highlight: Int? = null,
        val font: String? = null,
        val vertAlign: Int = 0, // 1 = superscript, -1 = subscript
        val caps: Boolean = false,
    )

    data class Run(val text: String, val style: Style)

    enum class Align { LEFT, CENTER, RIGHT, JUSTIFY }

    sealed interface Block

    data class Paragraph(
        val runs: List<Run>,
        val align: Align = Align.LEFT,
        val indentLeft: Float = 0f,
        val indentRight: Float = 0f,
        val firstLine: Float = 0f,
        val spaceBefore: Float = 0f,
        val spaceAfter: Float = 0f,
        /** Multiple of single spacing, or an exact height when [exactLine] is set. */
        val lineSpacing: Float = 1f,
        val exactLine: Float? = null,
        val marker: String? = null,
        val rtl: Boolean = false,
        val pageBreakBefore: Boolean = false,
        val shading: Int? = null,
        val keepNext: Boolean = false,
    ) : Block {
        val text get() = runs.joinToString("") { it.text }
    }

    class Image(val bytes: ByteArray?, val widthPt: Float, val heightPt: Float, val align: Align = Align.LEFT, val note: String? = null) : Block

    data class Cell(val blocks: List<Block>, val span: Int = 1, val fill: Int? = null, val vMergeContinue: Boolean = false)
    data class Row(val cells: List<Cell>, val header: Boolean = false, val minHeight: Float = 0f)
    data class Table(val rows: List<Row>, val columns: List<Float>, val borders: Boolean = true, val indent: Float = 0f) : Block

    data object PageBreak : Block

    data class Page(val widthPt: Float = 595f, val heightPt: Float = 842f, val top: Float = 72f, val right: Float = 72f, val bottom: Float = 72f, val left: Float = 72f)

    class Document(val blocks: List<Block>, val page: Page, val notes: List<String> = emptyList())
}

/**
 * Reads .docx files (Office Open XML) with java.util.zip and the platform's DOM parser:
 * styles with inheritance, direct paragraph and run formatting, lists and their
 * numbering, tables with merged cells and shading, inline pictures, page breaks and
 * the page size and margins. Headers, footers, footnotes, text boxes, charts and
 * equations are not drawn; [Flow.Document.notes] says when some were skipped.
 * Pure JVM, unit tested.
 */
class DocxReader {

    private lateinit var zip: ZipFile
    private val styles = HashMap<String, Element>()
    private var defaultPPr: Element? = null
    private var defaultRPr: Element? = null
    private var defaultParaStyle: String? = null
    private val numbering = HashMap<String, Map<Int, Level>>()
    private val counters = HashMap<String, IntArray>()
    private val rels = HashMap<String, String>()
    private val skipped = linkedSetOf<String>()
    private var contentWidth = 451f

    private class Level(val format: String, val text: String, val start: Int, val indent: Float?, val hanging: Float?, val font: String?)

    fun read(file: File): Flow.Document {
        if (isOle(file)) throw UserFacingException(R.string.err_word_file_password_protected_2, "This Word file is password protected or in an old format this tool can't read. Save it as .docx and try again.")
        zip = try { ZipFile(file) } catch (e: Exception) {
            throw UserFacingException(R.string.err_word_file_couldnt_opened, "This Word file couldn't be opened. It may be damaged or not a real .docx file.", e)
        }
        zip.use {
            val docPath = relTargets("_rels/.rels", "").entries.firstOrNull { it.key.endsWith("/officeDocument") }?.value ?: "word/document.xml"
            val folder = docPath.substringBeforeLast('/', "")
            relTargets(relsPath(docPath), folder, idMap = rels)
            parse(rels.values.firstOrNull { it.endsWith("styles.xml") } ?: "$folder/styles.xml")?.let { readStyles(it.documentElement) }
            parse("$folder/numbering.xml")?.let { readNumbering(it.documentElement) }
            val doc = parse(docPath)?.documentElement ?: throw UserFacingException(R.string.err_word_file_no_document, "This Word file has no document content.")
            val body = child(doc, "body") ?: throw UserFacingException(R.string.err_word_file_no_document, "This Word file has no document content.")
            val page = readPage(children(body, "sectPr").lastOrNull())
            contentWidth = page.widthPt - page.left - page.right
            val blocks = mutableListOf<Flow.Block>()
            readBlocks(body, blocks)
            if (blocks.isEmpty()) blocks += Flow.Paragraph(emptyList())
            if (zip.getEntry("$folder/header1.xml") != null || zip.getEntry("$folder/footer1.xml") != null) skipped += "headers and footers"
            return Flow.Document(blocks, page, skipped.map { "Not shown: $it." })
        }
    }

    // ---- Package ------------------------------------------------------------------------

    private fun parse(path: String): org.w3c.dom.Document? {
        val entry = zip.getEntry(path.removePrefix("/")) ?: return null
        return runCatching {
            val f = DocumentBuilderFactory.newInstance().apply {
                isNamespaceAware = true
                runCatching { setFeature("http://apache.org/xml/features/disallow-doctype-decl", true) }
                isExpandEntityReferences = false
            }
            zip.getInputStream(entry).use { f.newDocumentBuilder().parse(it) }
        }.getOrNull()
    }

    private fun relsPath(path: String): String {
        val dir = path.substringBeforeLast('/', "")
        val name = path.substringAfterLast('/')
        return if (dir.isEmpty()) "_rels/$name.rels" else "$dir/_rels/$name.rels"
    }

    /** Relationship type → target, and optionally id → target, resolved against [folder]. */
    private fun relTargets(path: String, folder: String, idMap: MutableMap<String, String>? = null): Map<String, String> {
        val out = LinkedHashMap<String, String>()
        val root = parse(path)?.documentElement ?: return out
        for (r in children(root, "Relationship")) {
            if (r.getAttribute("TargetMode") == "External") continue
            val target = resolve(folder, r.getAttribute("Target"))
            out[r.getAttribute("Type")] = target
            idMap?.put(r.getAttribute("Id"), target)
        }
        return out
    }

    private fun resolve(folder: String, target: String): String {
        if (target.startsWith("/")) return target.removePrefix("/")
        val parts = (if (folder.isEmpty()) emptyList() else folder.split('/')).toMutableList()
        for (seg in target.split('/')) when (seg) {
            ".." -> if (parts.isNotEmpty()) parts.removeAt(parts.lastIndex)
            ".", "" -> Unit
            else -> parts += seg
        }
        return parts.joinToString("/")
    }

    // ---- Styles and numbering ---------------------------------------------------------------

    private fun readStyles(root: Element) {
        child(root, "docDefaults")?.let { d ->
            defaultPPr = child(child(d, "pPrDefault"), "pPr")
            defaultRPr = child(child(d, "rPrDefault"), "rPr")
        }
        for (s in children(root, "style")) {
            val id = s.wAttr("styleId") ?: continue
            styles[id] = s
            if (s.wAttr("type") == "paragraph" && s.wAttr("default").let { it == "1" || it == "true" }) defaultParaStyle = id
        }
    }

    /** The style chain from the most basic style to [id]. */
    private fun chain(id: String?): List<Element> {
        val out = ArrayList<Element>()
        var cur = id
        var guard = 0
        while (cur != null && guard++ < 20) {
            val s = styles[cur] ?: break
            out.add(0, s)
            cur = child(s, "basedOn")?.wAttr("val")
        }
        return out
    }

    private fun readNumbering(root: Element) {
        val abstract = HashMap<String, Map<Int, Level>>()
        for (a in children(root, "abstractNum")) {
            val levels = HashMap<Int, Level>()
            for (l in children(a, "lvl")) {
                val ilvl = l.wAttr("ilvl")?.toIntOrNull() ?: continue
                val ind = child(child(l, "pPr"), "ind")
                levels[ilvl] = Level(
                    format = child(l, "numFmt")?.wAttr("val") ?: "decimal",
                    text = child(l, "lvlText")?.wAttr("val") ?: "",
                    start = child(l, "start")?.wAttr("val")?.toIntOrNull() ?: 1,
                    indent = (ind?.wAttr("left") ?: ind?.wAttr("start"))?.toFloatOrNull()?.div(20f),
                    hanging = ind?.wAttr("hanging")?.toFloatOrNull()?.div(20f),
                    font = child(child(l, "rPr"), "rFonts")?.wAttr("ascii"),
                )
            }
            a.wAttr("abstractNumId")?.let { abstract[it] = levels }
        }
        for (n in children(root, "num")) {
            val id = n.wAttr("numId") ?: continue
            val base = child(n, "abstractNumId")?.wAttr("val")?.let { abstract[it] } ?: continue
            numbering[id] = base
        }
    }

    private fun marker(numId: String, ilvl: Int): Pair<String, Level>? {
        val levels = numbering[numId] ?: return null
        val level = levels[ilvl] ?: return null
        val counts = counters.getOrPut(numId) { IntArray(9) { i -> (levels[i]?.start ?: 1) - 1 } }
        counts[ilvl]++
        for (deeper in ilvl + 1 until 9) counts[deeper] = (levels[deeper]?.start ?: 1) - 1
        if (level.format == "bullet") {
            val ch = level.text.ifEmpty { "•" }
            // Symbol / Wingdings bullets are private-use characters; show a real bullet.
            val shown = if (ch.any { it.code in 0xF000..0xF0FF } || level.font?.contains("Symbol", true) == true || level.font?.contains("Wingdings", true) == true) {
                if (ilvl % 3 == 1) "◦" else if (ilvl % 3 == 2) "▪" else "•"
            } else ch
            return shown to level
        }
        if (level.format == "none") return "" to level
        var text = level.text
        for (k in 0..ilvl) {
            val lv = levels[k] ?: continue
            text = text.replace("%${k + 1}", format(counts[k].coerceAtLeast(lv.start), lv.format))
        }
        return text to level
    }

    // ---- Page --------------------------------------------------------------------------

    private fun readPage(sect: Element?): Flow.Page {
        val sz = child(sect, "pgSz")
        val mar = child(sect, "pgMar")
        fun tw(e: Element?, name: String, def: Float) = e?.wAttr(name)?.toFloatOrNull()?.div(20f) ?: def
        var w = tw(sz, "w", 595f)
        var h = tw(sz, "h", 842f)
        if (sz?.wAttr("orient") == "landscape" && w < h) { val t = w; w = h; h = t }
        return Flow.Page(
            w.coerceIn(72f, 14400f), h.coerceIn(72f, 14400f),
            tw(mar, "top", 72f).let { kotlin.math.abs(it) }, tw(mar, "right", 72f),
            tw(mar, "bottom", 72f).let { kotlin.math.abs(it) }, tw(mar, "left", 72f),
        )
    }

    // ---- Body --------------------------------------------------------------------------

    private fun readBlocks(parent: Element, out: MutableList<Flow.Block>) {
        for (n in elements(parent)) {
            when (n.localName) {
                "p" -> readParagraph(n, out)
                "tbl" -> readTable(n)?.let { out += it }
                "sdt" -> child(n, "sdtContent")?.let { readBlocks(it, out) }
                "customXml" -> readBlocks(n, out)
                "altChunk" -> skipped += "embedded content"
            }
        }
    }

    private fun readParagraph(p: Element, out: MutableList<Flow.Block>) {
        val pPr = child(p, "pPr")
        val styleId = child(pPr, "pStyle")?.wAttr("val") ?: defaultParaStyle
        val styleChain = chain(styleId)
        // Paragraph properties: defaults, then the style chain, then direct formatting.
        val pProps = listOfNotNull(defaultPPr) + styleChain.mapNotNull { child(it, "pPr") } + listOfNotNull(pPr)
        val baseRPr = listOfNotNull(defaultRPr) + styleChain.mapNotNull { child(it, "rPr") }

        var align = Flow.Align.LEFT
        var left = 0f; var right = 0f; var first = 0f
        var before = 0f; var after = 0f
        var line = 1f; var exact: Float? = null
        var rtl = false; var pageBreak = false; var keepNext = false
        var shading: Int? = null
        var numId: String? = null; var ilvl = 0
        for (pp in pProps) {
            child(pp, "jc")?.wAttr("val")?.let {
                align = when (it) { "center" -> Flow.Align.CENTER; "right", "end" -> Flow.Align.RIGHT; "both", "distribute" -> Flow.Align.JUSTIFY; else -> Flow.Align.LEFT }
            }
            child(pp, "ind")?.let { ind ->
                (ind.wAttr("left") ?: ind.wAttr("start"))?.toFloatOrNull()?.let { left = it / 20f }
                (ind.wAttr("right") ?: ind.wAttr("end"))?.toFloatOrNull()?.let { right = it / 20f }
                ind.wAttr("firstLine")?.toFloatOrNull()?.let { first = it / 20f }
                ind.wAttr("hanging")?.toFloatOrNull()?.let { first = -it / 20f }
            }
            child(pp, "spacing")?.let { sp ->
                sp.wAttr("before")?.toFloatOrNull()?.let { before = it / 20f }
                sp.wAttr("after")?.toFloatOrNull()?.let { after = it / 20f }
                if (sp.wAttr("beforeAutospacing") == "1") before = 14f
                if (sp.wAttr("afterAutospacing") == "1") after = 14f
                sp.wAttr("line")?.toFloatOrNull()?.let { v ->
                    when (sp.wAttr("lineRule")) {
                        "exact", "atLeast" -> { exact = v / 20f; line = 1f }
                        else -> { line = (v / 240f).coerceIn(0.5f, 5f); exact = null }
                    }
                }
            }
            child(pp, "bidi")?.let { rtl = it.onOff() }
            child(pp, "pageBreakBefore")?.let { pageBreak = it.onOff() }
            child(pp, "keepNext")?.let { keepNext = it.onOff() }
            child(pp, "shd")?.let { shading = fillColor(it) ?: shading }
            child(pp, "numPr")?.let { np ->
                child(np, "numId")?.wAttr("val")?.let { numId = it }
                child(np, "ilvl")?.wAttr("val")?.toIntOrNull()?.let { ilvl = it }
            }
        }

        var markerText: String? = null
        val nid = numId
        if (nid != null && nid != "0") {
            marker(nid, ilvl.coerceIn(0, 8))?.let { (text, level) ->
                markerText = text.takeIf { it.isNotEmpty() }
                if (child(pPr, "ind") == null) {
                    level.indent?.let { left = it }
                    level.hanging?.let { first = -it }
                }
            }
        }

        val runs = mutableListOf<Flow.Run>()
        val images = mutableListOf<Flow.Image>()
        var breakAfter = false
        fun collect(container: Element) {
            for (n in elements(container)) when (n.localName) {
                "r" -> {
                    val style = runStyle(baseRPr + listOfNotNull(child(n, "rPr")).let { direct ->
                        val rStyle = direct.firstOrNull()?.let { child(it, "rStyle")?.wAttr("val") }
                        chain(rStyle).mapNotNull { child(it, "rPr") } + direct
                    })
                    val vanish = child(n, "rPr")?.let { child(it, "vanish") }?.onOff() == true
                    if (vanish) continue
                    val sb = StringBuilder()
                    for (c in elements(n)) when (c.localName) {
                        "t" -> sb.append(c.textContent)
                        "tab", "ptab" -> sb.append('\t')
                        "br", "cr" -> if (c.wAttr("type") == "page") {
                            if (sb.isNotEmpty()) { runs += Flow.Run(sb.toString(), style); sb.clear() }
                            breakAfter = true
                        } else sb.append('\n')
                        "noBreakHyphen" -> sb.append('‑')
                        "softHyphen" -> sb.append('­')
                        "sym" -> sb.append(symbol(c))
                        "drawing", "pict", "object" -> image(c)?.let { images += it }
                        "footnoteReference", "endnoteReference" -> skipped += "footnotes"
                    }
                    if (sb.isNotEmpty()) runs += Flow.Run(if (style.caps) sb.toString().uppercase() else sb.toString(), style)
                }
                "hyperlink", "smartTag", "ins", "fldSimple", "customXml", "bdo", "dir" -> collect(n)
                "sdt" -> child(n, "sdtContent")?.let { collect(it) }
                "oMath", "oMathPara" -> { skipped += "equations"; runs += Flow.Run(n.textContent, runStyle(baseRPr)) }
                "del", "moveFrom" -> Unit
            }
        }
        collect(p)

        val para = Flow.Paragraph(
            runs = mergeRuns(runs),
            align = align,
            indentLeft = left, indentRight = right, firstLine = first,
            spaceBefore = before, spaceAfter = after,
            lineSpacing = line, exactLine = exact,
            marker = markerText,
            rtl = rtl, pageBreakBefore = pageBreak, shading = shading, keepNext = keepNext,
        )
        val hasText = runs.any { it.text.isNotEmpty() } || markerText != null
        if (hasText || images.isEmpty()) out += para
        images.forEach { out += Flow.Image(it.bytes, it.widthPt, it.heightPt, align, it.note) }
        if (breakAfter) out += Flow.PageBreak
    }

    private fun mergeRuns(runs: List<Flow.Run>): List<Flow.Run> {
        val out = ArrayList<Flow.Run>(runs.size)
        for (r in runs) {
            val last = out.lastOrNull()
            if (last != null && last.style == r.style) out[out.lastIndex] = Flow.Run(last.text + r.text, r.style) else out += r
        }
        return out
    }

    private fun runStyle(props: List<Element>): Flow.Style {
        var s = Flow.Style()
        for (r in props) {
            child(r, "b")?.let { s = s.copy(bold = it.onOff()) }
            child(r, "i")?.let { s = s.copy(italic = it.onOff()) }
            child(r, "u")?.let { s = s.copy(underline = it.wAttr("val").let { v -> v != null && v != "none" }) }
            child(r, "strike")?.let { s = s.copy(strike = it.onOff()) }
            child(r, "dstrike")?.let { if (it.onOff()) s = s.copy(strike = true) }
            child(r, "caps")?.let { s = s.copy(caps = it.onOff()) }
            child(r, "sz")?.wAttr("val")?.toFloatOrNull()?.let { s = s.copy(sizePt = (it / 2f).coerceIn(1f, 400f)) }
            child(r, "color")?.wAttr("val")?.let { v -> hex(v)?.let { s = s.copy(color = it) } }
            child(r, "highlight")?.wAttr("val")?.let { s = s.copy(highlight = highlightColor(it)) }
            child(r, "shd")?.let { fillColor(it)?.let { c -> s = s.copy(highlight = c) } }
            child(r, "rFonts")?.let { f -> (f.wAttr("ascii") ?: f.wAttr("hAnsi") ?: f.wAttr("cs"))?.let { s = s.copy(font = it) } }
            child(r, "vertAlign")?.wAttr("val")?.let { s = s.copy(vertAlign = when (it) { "superscript" -> 1; "subscript" -> -1; else -> 0 }) }
        }
        return s
    }

    private fun symbol(e: Element): String {
        val code = e.wAttr("char")?.toIntOrNull(16) ?: return ""
        val c = if (code in 0xF000..0xF0FF) code - 0xF000 else code
        return when (c) { 0xB7, 0xA7 -> "•"; 0xFC -> "✓"; 0xFB -> "✗"; else -> String(Character.toChars(c)) }
    }

    // ---- Pictures -----------------------------------------------------------------------

    private fun image(e: Element): Flow.Image? {
        val extent = descendants(e, "extent").firstOrNull()
        var w = extent?.getAttribute("cx")?.toFloatOrNull()?.div(12700f)
        var h = extent?.getAttribute("cy")?.toFloatOrNull()?.div(12700f)
        if (w == null || h == null) {
            // VML: style="width:120pt;height:80pt"
            val style = descendants(e, "shape").firstOrNull()?.getAttribute("style").orEmpty()
            w = Regex("width:([\\d.]+)pt").find(style)?.groupValues?.get(1)?.toFloatOrNull()
            h = Regex("height:([\\d.]+)pt").find(style)?.groupValues?.get(1)?.toFloatOrNull()
        }
        if (descendants(e, "chart").isNotEmpty()) {
            skipped += "charts"
            return Flow.Image(null, w ?: 300f, h ?: 180f, note = "Chart")
        }
        val blip = descendants(e, "blip").firstOrNull()
        val id = blip?.getAttributeNS(R_NS, "embed")?.ifEmpty { null }
            ?: descendants(e, "imagedata").firstOrNull()?.getAttributeNS(R_NS, "id")?.ifEmpty { null }
        if (id == null) {
            if (descendants(e, "txbx").isNotEmpty() || descendants(e, "textbox").isNotEmpty()) skipped += "text boxes"
            return null
        }
        val path = rels[id] ?: return null
        val entry = zip.getEntry(path) ?: return null
        if (entry.size > 30L * 1024 * 1024) return null
        val ext = path.substringAfterLast('.').lowercase()
        if (ext in setOf("emf", "wmf", "tif", "tiff", "svg")) {
            return Flow.Image(null, w ?: 200f, h ?: 150f, note = "Picture (${ext.uppercase()})")
        }
        val bytes = zip.getInputStream(entry).use { it.readBytes() }
        return Flow.Image(bytes, (w ?: 200f).coerceAtLeast(1f), (h ?: 150f).coerceAtLeast(1f))
    }

    // ---- Tables -------------------------------------------------------------------------

    private fun readTable(t: Element): Flow.Table? {
        val tblPr = child(t, "tblPr")
        val styleId = child(tblPr, "tblStyle")?.wAttr("val")
        val styleBorders = chain(styleId).mapNotNull { child(child(it, "tblPr"), "tblBorders") }.lastOrNull()
        val borders = child(tblPr, "tblBorders") ?: styleBorders
        val hasBorders = borders == null && styleId != null && styleId.contains("Grid", true) ||
            borders != null && elements(borders).any { it.wAttr("val").let { v -> v != null && v != "none" && v != "nil" } }
        val grid = children(child(t, "tblGrid"), "gridCol").map { (it.wAttr("w")?.toFloatOrNull() ?: 0f) / 20f }
        val indent = child(tblPr, "tblInd")?.wAttr("w")?.toFloatOrNull()?.div(20f) ?: 0f
        val rows = mutableListOf<Flow.Row>()
        for (tr in children(t, "tr")) {
            val trPr = child(tr, "trPr")
            val header = child(trPr, "tblHeader")?.onOff() == true
            val minH = child(trPr, "trHeight")?.wAttr("val")?.toFloatOrNull()?.div(20f) ?: 0f
            val cells = mutableListOf<Flow.Cell>()
            for (tc in elements(tr).flatMap { if (it.localName == "sdt") elements(child(it, "sdtContent")) else listOf(it) }) {
                if (tc.localName != "tc") continue
                val tcPr = child(tc, "tcPr")
                val span = child(tcPr, "gridSpan")?.wAttr("val")?.toIntOrNull()?.coerceAtLeast(1) ?: 1
                val vMerge = child(tcPr, "vMerge")
                val cont = vMerge != null && vMerge.wAttr("val").let { it == null || it == "continue" }
                val fill = child(tcPr, "shd")?.let { fillColor(it) }
                val blocks = mutableListOf<Flow.Block>()
                readBlocks(tc, blocks)
                cells += Flow.Cell(blocks, span, fill, cont)
            }
            if (cells.isNotEmpty()) rows += Flow.Row(cells, header, minH)
        }
        if (rows.isEmpty()) return null
        val count = rows.maxOf { r -> r.cells.sumOf { it.span } }
        var columns = if (grid.size >= count && grid.sum() > 0f) grid.take(count) else List(count) { contentWidth / count }
        val total = columns.sum()
        if (total > contentWidth * 1.02f || total <= 0f) columns = columns.map { it * contentWidth / total.coerceAtLeast(1f) }
        return Flow.Table(rows, columns, hasBorders, indent)
    }

    // ---- XML helpers ----------------------------------------------------------------------

    companion object {
        private const val W_NS = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
        private const val R_NS = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"

        fun isOle(file: File): Boolean = runCatching {
            file.inputStream().use { s ->
                val b = ByteArray(8)
                s.read(b) == 8 && b[0] == 0xD0.toByte() && b[1] == 0xCF.toByte() && b[2] == 0x11.toByte() && b[3] == 0xE0.toByte()
            }
        }.getOrDefault(false)

        internal fun Element.wAttr(name: String): String? =
            getAttributeNS(W_NS, name).ifEmpty { null } ?: getAttribute("w:$name").ifEmpty { null }

        internal fun Element.onOff(): Boolean = wAttr("val").let { it == null || it == "1" || it == "true" || it == "on" }

        internal fun elements(parent: Element?): List<Element> {
            if (parent == null) return emptyList()
            val out = ArrayList<Element>()
            var n: Node? = parent.firstChild
            while (n != null) {
                if (n is Element) out += n
                n = n.nextSibling
            }
            return out
        }

        internal fun child(parent: Element?, name: String): Element? = elements(parent).firstOrNull { it.localName == name }
        internal fun children(parent: Element?, name: String): List<Element> = elements(parent).filter { it.localName == name }

        internal fun descendants(parent: Element, name: String): List<Element> {
            val list = parent.getElementsByTagNameNS("*", name)
            return (0 until list.length).map { list.item(it) as Element }
        }

        fun hex(v: String): Int? {
            if (v.equals("auto", true) || v.length != 6) return null
            return v.toIntOrNull(16)?.let { it or 0xFF000000.toInt() }
        }

        private fun fillColor(shd: Element): Int? {
            val fill = shd.wAttr("fill") ?: return null
            return hex(fill)?.takeIf { it != 0xFFFFFFFF.toInt() }
        }

        fun highlightColor(name: String): Int? = when (name) {
            "yellow" -> 0xFFFFFF00; "green" -> 0xFF00FF00; "cyan" -> 0xFF00FFFF; "magenta" -> 0xFFFF00FF
            "blue" -> 0xFF0000FF; "red" -> 0xFFFF0000; "darkBlue" -> 0xFF000080; "darkCyan" -> 0xFF008080
            "darkGreen" -> 0xFF008000; "darkMagenta" -> 0xFF800080; "darkRed" -> 0xFF800000; "darkYellow" -> 0xFF808000
            "darkGray" -> 0xFF808080; "lightGray" -> 0xFFC0C0C0; "black" -> 0xFF000000
            else -> null
        }?.toInt()

        /** List numbers in Word's formats. Pure logic, unit tested. */
        fun format(n: Int, fmt: String): String = when (fmt) {
            "lowerLetter" -> letters(n).lowercase()
            "upperLetter" -> letters(n)
            "lowerRoman" -> roman(n).lowercase()
            "upperRoman" -> roman(n)
            "decimalZero" -> if (n < 10) "0$n" else "$n"
            "ordinal" -> "$n" + when { n % 100 in 11..13 -> "th"; n % 10 == 1 -> "st"; n % 10 == 2 -> "nd"; n % 10 == 3 -> "rd"; else -> "th" }
            else -> n.toString()
        }

        private fun letters(n: Int): String {
            if (n <= 0) return "A"
            val ch = 'A' + (n - 1) % 26
            return ch.toString().repeat((n - 1) / 26 + 1)
        }

        fun roman(n: Int): String {
            if (n <= 0 || n >= 4000) return n.toString()
            val v = intArrayOf(1000, 900, 500, 400, 100, 90, 50, 40, 10, 9, 5, 4, 1)
            val s = arrayOf("M", "CM", "D", "CD", "C", "XC", "L", "XL", "X", "IX", "V", "IV", "I")
            var x = n
            return buildString { for (i in v.indices) while (x >= v[i]) { append(s[i]); x -= v[i] } }
        }
    }
}
