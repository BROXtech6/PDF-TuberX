package com.excelto.pdf.converter.language

import android.content.Context
import android.content.res.Configuration
import android.content.res.Resources
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.app.LocaleManagerCompat
import androidx.core.os.LocaleListCompat
import java.util.Locale

/**
 * The app's languages. The choice is stored by AndroidX (per-app language): Android 13+
 * keeps it in system settings, older versions in the app. Every AppCompatActivity then
 * opens in that language, right-to-left for Arabic and Urdu.
 */
object AppLanguage {

    /** [tag] is a BCP 47 language tag; [native] is the name in its own language. */
    data class Language(val tag: String, val native: String, val english: String)

    val ALL = listOf(
        Language("en", "English", "English"),
        Language("ar", "العربية", "Arabic"),
        Language("hi", "हिन्दी", "Hindi"),
        Language("es", "Español", "Spanish"),
        Language("pt-BR", "Português (Brasil)", "Portuguese (Brazil)"),
        Language("id", "Bahasa Indonesia", "Indonesian"),
        Language("ur", "اردو", "Urdu"),
        Language("bn", "বাংলা", "Bengali"),
        Language("ru", "Русский", "Russian"),
        Language("fr", "Français", "French"),
        Language("de", "Deutsch", "German"),
        Language("tr", "Türkçe", "Turkish"),
        Language("vi", "Tiếng Việt", "Vietnamese"),
        Language("ja", "日本語", "Japanese"),
        Language("ko", "한국어", "Korean"),
        Language("zh", "中文（简体）", "Chinese (Simplified)"),
        Language("it", "Italiano", "Italian"),
        Language("pt-PT", "Português (Portugal)", "Portuguese (Portugal)"),
        Language("nl", "Nederlands", "Dutch"),
        Language("af", "Afrikaans", "Afrikaans"),
    )

    /** The language the user picked, or null when the app follows the phone. */
    fun chosen(): Language? {
        val locale = AppCompatDelegate.getApplicationLocales()[0] ?: return null
        return match(locale)
    }

    /** The app's language right now: the user's pick, else the phone's, else English. */
    fun current(context: Context): Language = chosen() ?: phone(context) ?: ALL.first()

    /**
     * The phone's language, if the app has it. Asks the system directly: once the app has
     * its own language, Android 13+ reports that language for the process instead.
     */
    fun phone(context: Context): Language? {
        val list = LocaleManagerCompat.getSystemLocales(context)
        for (i in 0 until list.size()) list[i]?.let { locale -> match(locale)?.let { return it } }
        return null
    }

    fun apply(language: Language) {
        AppCompatDelegate.setApplicationLocales(LocaleListCompat.forLanguageTags(language.tag))
    }

    /** Resources in [language], so a screen can preview text before the choice is applied. */
    fun resources(context: Context, language: Language): Resources {
        val config = Configuration(context.resources.configuration).apply { setLocale(Locale.forLanguageTag(language.tag)) }
        return context.createConfigurationContext(config).resources
    }

    /**
     * Carries over a language picked in an earlier version of the app, which saved it in
     * its own preferences. Runs once, before any screen opens.
     */
    fun migrate(context: Context) {
        val prefs = context.getSharedPreferences("apero_ad_pref", Context.MODE_PRIVATE)
        val old = prefs.getString("KEY_SELECTED_LANGUAGE", null) ?: return
        prefs.edit().remove("KEY_SELECTED_LANGUAGE").apply()
        if (!AppCompatDelegate.getApplicationLocales().isEmpty) return
        val language = match(Locale.forLanguageTag(old)) ?: return
        apply(language)
    }

    /** Best supported language for [locale]: exact region first (pt-BR), then language. */
    fun match(locale: Locale): Language? {
        val lang = when (locale.language) { "in" -> "id"; "iw" -> "he"; else -> locale.language }
        if (lang == "pt") return ALL.first { it.tag == if (locale.country == "PT") "pt-PT" else "pt-BR" }
        return ALL.firstOrNull { it.tag == lang }
    }
}
