package com.excelto.pdf.converter.core.excel

/**
 * A spreadsheet in memory, read from .xlsx, .xls or .csv, ready to draw. Pure Kotlin.
 *
 * Cells are stored compactly per row (parallel arrays) and formatted only when drawn,
 * so sheets with 50,000+ rows fit in memory. Styles are shared by index.
 */
class ExcelWorkbook(
    val sheets: List<ExcelSheet>,
    val styles: List<CellStyle>,
    val date1904: Boolean = false,
) {
    fun style(index: Int): CellStyle = styles.getOrElse(index) { CellStyle.DEFAULT }

    /** The text Excel shows for a cell, and an optional color from the format. */
    fun display(row: RowData, i: Int): NumberFormatter.Result {
        val style = style(row.styles[i])
        return when (row.kinds[i]) {
            CellKind.NUMBER -> NumberFormatter.format(row.nums[i], style.numFmt, date1904)
            CellKind.STRING -> NumberFormatter.formatText(row.strs[i].orEmpty(), style.numFmt)
            CellKind.BOOL -> NumberFormatter.Result(if (row.nums[i] != 0.0) "TRUE" else "FALSE")
            else -> NumberFormatter.Result(row.strs[i].orEmpty())
        }
    }
}

object CellKind {
    const val NUMBER: Byte = 1
    const val STRING: Byte = 2
    const val BOOL: Byte = 3
    const val ERROR: Byte = 4
    const val BLANK: Byte = 5 // styled but empty
}

/** One row's cells in column order. */
class RowData {
    var size = 0
        private set
    var cols = IntArray(4); private set
    var kinds = ByteArray(4); private set
    var nums = DoubleArray(4); private set
    var strs = arrayOfNulls<String>(4); private set
    var styles = IntArray(4); private set

    fun put(col: Int, kind: Byte, num: Double = 0.0, str: String? = null, style: Int = 0) {
        // Readers add cells in column order; keep it sorted even if they don't.
        var at = size
        while (at > 0 && cols[at - 1] > col) at--
        if (at > 0 && cols[at - 1] == col) { set(at - 1, col, kind, num, str, style); return }
        if (size == cols.size) {
            val n = size * 2
            cols = cols.copyOf(n); kinds = kinds.copyOf(n); nums = nums.copyOf(n); strs = strs.copyOf(n); styles = styles.copyOf(n)
        }
        if (at < size) {
            System.arraycopy(cols, at, cols, at + 1, size - at); System.arraycopy(kinds, at, kinds, at + 1, size - at)
            System.arraycopy(nums, at, nums, at + 1, size - at); System.arraycopy(strs, at, strs, at + 1, size - at)
            System.arraycopy(styles, at, styles, at + 1, size - at)
        }
        set(at, col, kind, num, str, style)
        size++
    }

    private fun set(i: Int, col: Int, kind: Byte, num: Double, str: String?, style: Int) {
        cols[i] = col; kinds[i] = kind; nums[i] = num; strs[i] = str; styles[i] = style
    }

    /** Index of [col] in this row, or -1. */
    fun indexOf(col: Int): Int {
        var lo = 0
        var hi = size - 1
        while (lo <= hi) {
            val mid = (lo + hi) ushr 1
            val c = cols[mid]
            if (c < col) lo = mid + 1 else if (c > col) hi = mid - 1 else return mid
        }
        return -1
    }

    fun hasValue(i: Int): Boolean = kinds[i] != CellKind.BLANK && !(kinds[i] == CellKind.STRING && strs[i].isNullOrEmpty())
}

/** A block of cells, 0-based and inclusive. */
data class CellRange(val firstRow: Int, val firstCol: Int, val lastRow: Int, val lastCol: Int) {
    operator fun contains(cell: Pair<Int, Int>) = cell.first in firstRow..lastRow && cell.second in firstCol..lastCol

    companion object {
        /** Parses "A1:C10", "$A$1:$C$10" or "B2". */
        fun parse(ref: String): CellRange? {
            val parts = ref.replace("$", "").split(':')
            val a = parseCell(parts[0]) ?: return null
            val b = if (parts.size > 1) parseCell(parts[1]) ?: return null else a
            return CellRange(minOf(a.first, b.first), minOf(a.second, b.second), maxOf(a.first, b.first), maxOf(a.second, b.second))
        }

        /** "C10" → (row 9, column 2). */
        fun parseCell(ref: String): Pair<Int, Int>? {
            val m = Regex("^([A-Za-z]{1,3})(\\d+)$").find(ref.trim()) ?: return null
            return (m.groupValues[2].toInt() - 1) to column(m.groupValues[1])
        }

        fun column(letters: String): Int = letters.uppercase().fold(0) { acc, c -> acc * 26 + (c - 'A' + 1) } - 1
    }
}

enum class HAlign { GENERAL, LEFT, CENTER, RIGHT, FILL, JUSTIFY, CENTER_CONTINUOUS, DISTRIBUTED }
enum class VAlign { TOP, CENTER, BOTTOM, JUSTIFY, DISTRIBUTED }

enum class LineStyle(val width: Float, val dash: FloatArray? = null, val double: Boolean = false) {
    NONE(0f),
    HAIR(0.25f, floatArrayOf(0.75f, 0.75f)),
    THIN(0.5f),
    MEDIUM(1.25f),
    THICK(2f),
    DASHED(0.5f, floatArrayOf(3f, 1.5f)),
    DOTTED(0.5f, floatArrayOf(0.75f, 1.5f)),
    DOUBLE(0.5f, double = true),
    MEDIUM_DASHED(1.25f, floatArrayOf(4.5f, 1.5f)),
    DASH_DOT(0.5f, floatArrayOf(3f, 1.5f, 0.75f, 1.5f)),
    MEDIUM_DASH_DOT(1.25f, floatArrayOf(4.5f, 1.5f, 1.5f, 1.5f)),
    DASH_DOT_DOT(0.5f, floatArrayOf(3f, 1.5f, 0.75f, 1.5f, 0.75f, 1.5f)),
    MEDIUM_DASH_DOT_DOT(1.25f, floatArrayOf(4.5f, 1.5f, 1.5f, 1.5f, 1.5f, 1.5f)),
    SLANT_DASH_DOT(1.25f, floatArrayOf(4.5f, 1.5f, 1.5f, 1.5f));

    companion object {
        fun of(name: String?): LineStyle = when (name?.lowercase()) {
            null, "", "none" -> NONE
            "hair" -> HAIR
            "thin" -> THIN
            "medium" -> MEDIUM
            "thick" -> THICK
            "dashed" -> DASHED
            "dotted" -> DOTTED
            "double" -> DOUBLE
            "mediumdashed" -> MEDIUM_DASHED
            "dashdot" -> DASH_DOT
            "mediumdashdot" -> MEDIUM_DASH_DOT
            "dashdotdot" -> DASH_DOT_DOT
            "mediumdashdotdot" -> MEDIUM_DASH_DOT_DOT
            "slantdashdot" -> SLANT_DASH_DOT
            else -> THIN
        }
    }
}

data class BorderLine(val style: LineStyle, val color: Int = 0xFF000000.toInt())

data class CellFont(
    val name: String = "Calibri",
    val size: Float = 11f,
    val bold: Boolean = false,
    val italic: Boolean = false,
    val underline: Boolean = false,
    val strike: Boolean = false,
    val color: Int = 0xFF000000.toInt(),
)

data class CellStyle(
    val font: CellFont = CellFont(),
    /** Solid fill color (ARGB), or null for no fill. */
    val fill: Int? = null,
    val left: BorderLine? = null,
    val right: BorderLine? = null,
    val top: BorderLine? = null,
    val bottom: BorderLine? = null,
    val hAlign: HAlign = HAlign.GENERAL,
    val vAlign: VAlign = VAlign.BOTTOM,
    val wrap: Boolean = false,
    val indent: Int = 0,
    val numFmt: String = "General",
) {
    companion object {
        val DEFAULT = CellStyle()
    }
}

data class PageSetup(
    /** Null when the sheet doesn't say. */
    val landscape: Boolean? = null,
    /** Excel paper size code (1 = Letter, 9 = A4 ...), or null. */
    val paperSize: Int? = null,
    val fitToPage: Boolean = false,
    /** Pages wide/tall when [fitToPage]; 0 means "automatic". */
    val fitWidth: Int = 1,
    val fitHeight: Int = 1,
    /** Zoom in percent when not fitting to pages. */
    val scale: Int = 100,
    /** Margins in inches. */
    val marginLeft: Float = 0.7f,
    val marginRight: Float = 0.7f,
    val marginTop: Float = 0.75f,
    val marginBottom: Float = 0.75f,
    val printGridlines: Boolean = false,
)

/** An image placed on the sheet. Offsets are in points from the anchor cell's top-left. */
class SheetImage(
    val fromCol: Int, val fromColOffset: Float, val fromRow: Int, val fromRowOffset: Float,
    /** Bottom-right anchor; null for one-cell anchors, which use [widthPt]/[heightPt]. */
    val toCol: Int?, val toColOffset: Float, val toRow: Int?, val toRowOffset: Float,
    val widthPt: Float, val heightPt: Float,
    val bytes: ByteArray,
)

/** Key for [ExcelSheet.formulas]. */
fun formulaKey(row: Int, col: Int): Long = (row.toLong() shl 20) or col.toLong()

class ExcelSheet(
    val name: String,
    val hidden: Boolean = false,
    val rightToLeft: Boolean = false,
    /** Row index (0-based) → cells. */
    val rows: java.util.TreeMap<Int, RowData> = java.util.TreeMap(),
    /** Column widths in characters (Excel's unit). */
    val colWidths: Map<Int, Float> = emptyMap(),
    val defaultColWidth: Float = SheetUnits.DEFAULT_WIDTH,
    /** Row heights in points. */
    val rowHeights: Map<Int, Float> = emptyMap(),
    val defaultRowHeight: Float = 15f,
    val hiddenRows: Set<Int> = emptySet(),
    val hiddenCols: Set<Int> = emptySet(),
    val merges: List<CellRange> = emptyList(),
    val printArea: CellRange? = null,
    val pageSetup: PageSetup = PageSetup(),
    val images: List<SheetImage> = emptyList(),
    val chartCount: Int = 0,
    /** Style for every cell of a column that has no cell of its own (from <col style>). */
    val colStyles: Map<Int, Int> = emptyMap(),
    /** Formulas by cell ([formulaKey]), without the leading "=". Values are the cached results. */
    val formulas: Map<Long, String> = emptyMap(),
    /** Frozen rows at the top and columns at the left (Excel's "Freeze Panes"). */
    val freezeRows: Int = 0,
    val freezeCols: Int = 0,
) {
    /** The block that has values, styles or images, or null for an empty sheet. */
    fun usedRange(workbook: ExcelWorkbook): CellRange? {
        var firstRow = Int.MAX_VALUE; var lastRow = -1; var firstCol = Int.MAX_VALUE; var lastCol = -1
        for ((r, row) in rows) for (i in 0 until row.size) {
            val visible = row.hasValue(i) || workbook.style(row.styles[i]).let { it.fill != null || it.left != null || it.right != null || it.top != null || it.bottom != null }
            if (!visible) continue
            firstRow = minOf(firstRow, r); lastRow = maxOf(lastRow, r)
            firstCol = minOf(firstCol, row.cols[i]); lastCol = maxOf(lastCol, row.cols[i])
        }
        for (m in merges) {
            firstRow = minOf(firstRow, m.firstRow); lastRow = maxOf(lastRow, m.lastRow)
            firstCol = minOf(firstCol, m.firstCol); lastCol = maxOf(lastCol, m.lastCol)
        }
        for (img in images) {
            firstRow = minOf(firstRow, img.fromRow); lastRow = maxOf(lastRow, img.toRow ?: img.fromRow)
            firstCol = minOf(firstCol, img.fromCol); lastCol = maxOf(lastCol, img.toCol ?: img.fromCol)
        }
        if (lastRow < 0) return null
        return CellRange(firstRow, firstCol, lastRow, lastCol)
    }
}

/** Excel's size units. */
object SheetUnits {
    /**
     * Column width as stored in files (characters of the default font's digit width,
     * already including Excel's 5 px of padding) to points. A visible width of c
     * characters is stored as c + 5/7, so this is the same as px = trunc(c * 7 + 5):
     * the default 8.43 characters (stored 9.140625) is 64 px = 48 pt.
     */
    fun columnPoints(width: Float): Float = kotlin.math.floor(width * 7f + 0.5f) * 0.75f

    /** Stored width for [chars] visible characters. */
    fun storedWidth(chars: Float): Float = chars + 5f / 7f

    const val DEFAULT_WIDTH = 9.140625f
}

/** Excel's default 56-color palette, used by indexed colors (.xls and older .xlsx). */
object ExcelColors {
    private val palette = intArrayOf(
        0x000000, 0xFFFFFF, 0xFF0000, 0x00FF00, 0x0000FF, 0xFFFF00, 0xFF00FF, 0x00FFFF,
        0x800000, 0x008000, 0x000080, 0x808000, 0x800080, 0x008080, 0xC0C0C0, 0x808080,
        0x9999FF, 0x993366, 0xFFFFCC, 0xCCFFFF, 0x660066, 0xFF8080, 0x0066CC, 0xCCCCFF,
        0x000080, 0xFF00FF, 0xFFFF00, 0x00FFFF, 0x800080, 0x800000, 0x008080, 0x0000FF,
        0x00CCFF, 0xCCFFFF, 0xCCFFCC, 0xFFFF99, 0x99CCFF, 0xFF99CC, 0xCC99FF, 0xFFCC99,
        0x3366FF, 0x33CCCC, 0x99CC00, 0xFFCC00, 0xFF9900, 0xFF6600, 0x666699, 0x969696,
        0x003366, 0x339966, 0x003300, 0x333300, 0x993300, 0x993366, 0x333399, 0x333333,
    )

    /** Color for palette index [index] (8..63, with 0..7 as the first eight). Null for "automatic". */
    fun indexed(index: Int, custom: Map<Int, Int> = emptyMap()): Int? {
        custom[index]?.let { return it }
        val i = when (index) {
            in 0..7 -> index
            in 8..63 -> index - 8
            else -> return null // 64 = system foreground, 65 = system background
        }
        return (0xFF000000.toInt()) or palette[i]
    }
}
