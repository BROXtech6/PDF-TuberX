package com.excelto.pdf.converter.core.engine

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Typeface
import android.icu.text.Bidi
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.pdmodel.PDPageContentStream
import com.tom_roush.pdfbox.pdmodel.font.PDFont
import com.tom_roush.pdfbox.pdmodel.graphics.image.LosslessFactory
import com.tom_roush.pdfbox.util.Matrix
import kotlin.math.ceil

enum class TextAlign { LEFT, CENTER, RIGHT }

/**
 * Writes text into PDFs with PdfBox. PdfBox doesn't shape Arabic or reorder
 * right-to-left text, so this does it first:
 *
 * 1. Arabic and Urdu letters are joined into connected forms by [ArabicShaper]
 *    (Android's ICU ArabicShaping isn't in the public SDK).
 * 2. Each line is reordered into visual order with ICU's Bidi.
 * 3. Each character is drawn with the first font that has it (Helvetica, then the
 *    phone's Noto/Roboto fonts, embedded as subsets).
 *
 * Scripts that need shaping PdfBox can't do (Hindi and other Indic scripts, Thai,
 * Khmer, Myanmar), or text no embeddable font covers, are drawn as a sharp
 * transparent image made with Android's own text engine instead. Those lines look
 * right but aren't selectable.
 */
class PdfText(private val doc: PDDocument, bold: Boolean = false) {

    private val fonts = PdfFonts.FontSet(doc, bold)
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        typeface = if (bold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
    }

    private class Run(val text: String, val font: PDFont)

    /** A line ready to draw: either font runs in visual order, or an image fallback. */
    private class Prepared(val runs: List<Run>?, val logical: String)

    private fun prepare(line: String): Prepared {
        if (line.isEmpty()) return Prepared(emptyList(), line)
        if (needsImage(line)) return Prepared(null, line)
        val visual = visualOrder(shapeArabic(line))
        val runs = mutableListOf<Run>()
        val sb = StringBuilder()
        var current: PDFont? = null
        var i = 0
        while (i < visual.length) {
            val cp = visual.codePointAt(i)
            val n = Character.charCount(cp)
            if (Character.getType(cp) == Character.FORMAT.toInt() || cp == 0xFEFF) { i += n; continue } // bidi marks
            val font = if (Character.isWhitespace(cp)) (current ?: fonts.helvetica) else fonts.fontFor(cp)
            if (font == null) return Prepared(null, line)
            if (font !== current && sb.isNotEmpty()) {
                runs += Run(sb.toString(), current!!)
                sb.setLength(0)
            }
            current = font
            if (Character.isWhitespace(cp)) sb.append(' ') else sb.appendCodePoint(cp)
            i += n
        }
        if (sb.isNotEmpty()) runs += Run(sb.toString(), current!!)
        return Prepared(runs, line)
    }

    /** Width of one line of [text] at [size] points. */
    fun width(text: String, size: Float): Float {
        val p = prepare(text)
        return if (p.runs != null) {
            p.runs.sumOf { runCatching { it.font.getStringWidth(it.text).toDouble() }.getOrDefault(0.0) }.toFloat() / 1000f * size
        } else {
            paint.textSize = size
            paint.measureText(text)
        }
    }

    /** Splits [text] into lines no wider than [maxWidth], keeping its own line breaks. */
    fun wrap(text: String, size: Float, maxWidth: Float): List<String> {
        val out = mutableListOf<String>()
        for (paragraph in text.replace("\r\n", "\n").split('\n')) {
            if (paragraph.isBlank()) { out += ""; continue }
            var line = StringBuilder()
            for (word in paragraph.split(' ')) {
                val candidate = if (line.isEmpty()) word else "$line $word"
                if (width(candidate, size) <= maxWidth || line.isEmpty()) {
                    line = StringBuilder(candidate)
                    // A single word wider than the line is broken by characters.
                    while (width(line.toString(), size) > maxWidth && line.length > 1) {
                        var cut = line.length - 1
                        while (cut > 1 && width(line.substring(0, cut), size) > maxWidth) cut--
                        out += line.substring(0, cut)
                        line = StringBuilder(line.substring(cut))
                    }
                } else {
                    out += line.toString()
                    line = StringBuilder(word)
                }
            }
            out += line.toString()
        }
        return out
    }

    /**
     * Draws one line. [x] is the left edge, center or right edge depending on [align];
     * [y] is the baseline. [rotation] is in degrees, counter-clockwise around (x, y).
     * [color] is an Android ARGB color. Fill opacity set by the caller applies too.
     */
    fun drawLine(
        cs: PDPageContentStream,
        text: String,
        x: Float,
        y: Float,
        size: Float,
        color: Int,
        align: TextAlign = TextAlign.LEFT,
        rotation: Float = 0f,
    ) {
        if (text.isBlank()) return
        val p = prepare(text)
        val w = width(text, size)
        val left = when (align) {
            TextAlign.LEFT -> 0f
            TextAlign.CENTER -> -w / 2
            TextAlign.RIGHT -> -w
        }
        cs.saveGraphicsState()
        cs.transform(Matrix.getRotateInstance(Math.toRadians(rotation.toDouble()), x, y))
        if (p.runs != null) {
            cs.setNonStrokingColor(red(color), green(color), blue(color))
            cs.beginText()
            cs.newLineAtOffset(left, 0f)
            for (run in p.runs) {
                cs.setFont(run.font, size)
                cs.showText(run.text)
            }
            cs.endText()
        } else {
            drawAsImage(cs, text, left, size, color)
        }
        cs.restoreGraphicsState()
    }

    /** Fallback: Android draws the text (shaping every script) into a transparent image. */
    private fun drawAsImage(cs: PDPageContentStream, text: String, left: Float, size: Float, color: Int) {
        val scale = (300f / 72f).coerceAtMost(4096f / maxOf(1f, width(text, size)))
        paint.textSize = size * scale
        paint.color = color or (0xFF shl 24)
        val metrics = paint.fontMetrics
        val wPx = ceil(paint.measureText(text)).toInt().coerceAtLeast(1)
        val hPx = ceil(metrics.descent - metrics.ascent).toInt().coerceAtLeast(1)
        val bitmap = Bitmap.createBitmap(wPx, hPx, Bitmap.Config.ARGB_8888)
        try {
            Canvas(bitmap).drawText(text, 0f, -metrics.ascent, paint)
            val image = LosslessFactory.createFromImage(doc, bitmap)
            // Baseline sits at -ascent pixels from the top of the image.
            cs.drawImage(image, left, metrics.descent / scale * -1f, wPx / scale, hPx / scale)
        } finally {
            bitmap.recycle()
        }
    }

    companion object {
        fun red(c: Int) = ((c shr 16) and 0xFF) / 255f
        fun green(c: Int) = ((c shr 8) and 0xFF) / 255f
        fun blue(c: Int) = (c and 0xFF) / 255f

        /** True when the text's first strong character is right-to-left. */
        fun isRtlParagraph(text: String): Boolean = Bidi.getBaseDirection(text) == Bidi.RTL

        /** Joins Arabic letters into their connected forms. Logical order in, logical order out. */
        fun shapeArabic(text: String): String = ArabicShaper.shape(text)

        /** Reorders one line from logical to visual order, mirroring brackets in RTL runs. */
        fun visualOrder(line: String): String {
            if (!PdfFonts.isRtl(line)) return line
            return runCatching {
                Bidi(line, Bidi.DIRECTION_DEFAULT_LEFT_TO_RIGHT.toInt()).writeReordered(Bidi.DO_MIRRORING.toInt())
            }.getOrDefault(line)
        }

        /** Scripts whose letters PdfBox can't arrange (no OpenType shaping). */
        fun needsImage(text: String): Boolean = text.any { ch ->
            val c = ch.code
            c in 0x0900..0x0DFF || // Devanagari, Bengali, Gurmukhi, Gujarati, Oriya, Tamil, Telugu, Kannada, Malayalam, Sinhala
                c in 0x0E00..0x0EFF || // Thai, Lao
                c in 0x0F00..0x0FFF || // Tibetan
                c in 0x1000..0x109F || // Myanmar
                c in 0x1780..0x17FF    // Khmer
        }
    }
}
