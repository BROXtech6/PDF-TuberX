package com.excelto.pdf.converter.ui.screens

import com.excelto.pdf.converter.R
import com.excelto.pdf.converter.language.tr
import com.excelto.pdf.converter.language.trPlural
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.excelto.pdf.converter.core.jobs.JobCenter
import com.excelto.pdf.converter.core.jobs.JobState
import com.excelto.pdf.converter.core.model.DocFile
import com.excelto.pdf.converter.core.model.DocType
import com.excelto.pdf.converter.core.model.Source
import com.excelto.pdf.converter.ui.AppViewModel
import com.excelto.pdf.converter.ui.InnerHeader
import com.excelto.pdf.converter.ui.LocalHost
import com.excelto.pdf.converter.ui.Route
import com.excelto.pdf.converter.ui.Tool
import com.excelto.pdf.converter.ui.components.Card16
import com.excelto.pdf.converter.ui.components.FileRow
import com.excelto.pdf.converter.ui.components.IconBadge
import com.excelto.pdf.converter.ui.components.PrimaryButton
import com.excelto.pdf.converter.ui.components.ProgressRing
import com.excelto.pdf.converter.ui.components.SecondaryButton
import com.excelto.pdf.converter.ui.components.SectionTitle
import com.excelto.pdf.converter.ui.components.TextAction
import com.excelto.pdf.converter.ui.theme.AppIcons
import com.excelto.pdf.converter.ui.theme.LocalPalette
import com.excelto.pdf.converter.ui.theme.Type

@Composable
fun ProgressScreen(vm: AppViewModel) {
    val p = LocalPalette.current
    val state by JobCenter.state.collectAsState()
    val s = state
    val host = LocalHost.current

    LaunchedEffect(s is JobState.Done) {
        if (s is JobState.Done && vm.current == Route.Progress) {
            JobCenter.markSeen()
            // A natural break: the file is saved. An interstitial may show (capped, see Ads)
            // before the result, never while the user is waiting on the job. If the job
            // finished while the user was away, returning to the app shows the result with
            // no ad (AdMob forbids ads that appear unexpectedly when an app opens).
            val fresh = android.os.SystemClock.elapsedRealtime() - s.finishedAt < 5_000
            val showResult = { if (vm.current == Route.Progress) vm.replaceTop(Route.Result) }
            if (fresh) host.afterJob(showResult) else showResult()
        }
    }

    Column(Modifier.fillMaxSize()) {
        InnerHeader(s?.title ?: tr(R.string.job_working), onBack = { vm.back() })
        when (s) {
            is JobState.Failed -> Column(
                Modifier.fillMaxSize().padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(14.dp, Alignment.CenterVertically),
            ) {
                IconBadge(AppIcons.close, com.excelto.pdf.converter.ui.theme.Tints.red, size = 64.dp, iconSize = 30.dp, radius = 32.dp)
                Text(tr(R.string.job_failed_title, s.title), style = Type.section.copy(fontSize = 18.sp), color = p.text, textAlign = TextAlign.Center)
                Text(s.message, style = Type.body, color = p.muted, textAlign = TextAlign.Center)
                val ocr = s.ocrPath
                if (ocr != null) {
                    PrimaryButton(tr(R.string.job_run_ocr), {
                        JobCenter.clear()
                        vm.back()
                        vm.openTool(Tool.OCR, DocFile.from(java.io.File(ocr), Source.PHONE))
                    })
                    TextAction(tr(R.string.common_go_back), { JobCenter.clear(); vm.back() })
                } else {
                    PrimaryButton(tr(R.string.common_go_back), { JobCenter.clear(); vm.back() })
                }
            }
            else -> {
                val percent = (s as? JobState.Running)?.percent ?: 100
                val steps = s?.steps ?: emptyList()
                Column(
                    Modifier.fillMaxSize().padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(16.dp, Alignment.CenterVertically),
                ) {
                    ProgressRing(percent, 150.dp, 12.dp, p.line, p.primaryText) {
                        Text("$percent%", style = Type.stat.copy(fontSize = 30.sp), color = p.text)
                    }
                    Text(s?.title ?: "", style = Type.section.copy(fontSize = 16.sp), color = p.text)
                    Column(Modifier.widthIn(max = 260.dp).fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        steps.forEachIndexed { i, label ->
                            val threshold = (i + 1) * 100 / steps.size
                            val done = percent >= threshold
                            val now = !done && percent >= i * 100 / steps.size
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                Box(
                                    Modifier.size(22.dp).clip(CircleShape).background(if (done) p.primaryText else if (now) p.primarySoft else p.line),
                                    contentAlignment = Alignment.Center,
                                ) { Icon(if (done) AppIcons.check else AppIcons.dot, null, tint = if (done) p.bg else p.primaryText, modifier = Modifier.size(13.dp)) }
                                Text(label, style = Type.bodyStrong, color = if (done || now) p.text else p.muted)
                            }
                        }
                    }
                    Text(tr(R.string.job_stays), style = Type.small, color = p.muted)
                    PrimaryButton(tr(R.string.job_keep_working), { vm.openTab(Route.Home); vm.say(tr(R.string.job_show_here)) })
                    TextAction(tr(R.string.common_cancel), { JobCenter.cancel(); vm.back(); vm.say(tr(R.string.job_canceled)) }, color = p.danger)
                }
            }
        }
    }
}

@Composable
fun ResultScreen(vm: AppViewModel) {
    val p = LocalPalette.current
    val host = LocalHost.current
    val state by JobCenter.state.collectAsState()
    val done = state as? JobState.Done
    if (done == null) {
        LaunchedEffect(Unit) { vm.openTab(Route.Home) }
        return
    }
    val result = done.result
    val files = result.files.filter { it.exists() }
    val first = files.firstOrNull()
    val pop = remember { Animatable(0.5f) }
    LaunchedEffect(Unit) { pop.animateTo(1f, spring(dampingRatio = Spring.DampingRatioMediumBouncy)) }

    Column(Modifier.fillMaxSize()) {
        InnerHeader(tr(R.string.job_result), onBack = { vm.openTab(Route.Home) })
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 22.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Box(Modifier.size(56.dp).scale(pop.value).clip(CircleShape).background(p.primary), contentAlignment = Alignment.Center) {
                    Icon(AppIcons.check, null, tint = p.onPrimary, modifier = Modifier.size(30.dp))
                }
                Column(Modifier.weight(1f)) {
                    Text(tr(R.string.job_done), style = Type.section.copy(fontSize = 20.sp), color = p.text)
                    Text(first?.name ?: "", style = Type.body, color = p.text)
                    Text(result.detail, style = Type.small, color = p.muted)
                }
            }
            if (first != null) {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    PrimaryButton(tr(R.string.common_open), { host.openFile(first) }, Modifier.weight(1f))
                    SecondaryButton(tr(R.string.common_share), { host.share(files) }, Modifier.weight(1f), textColor = p.primaryText)
                }
            }
            val images = files.isNotEmpty() && files.all { it.extension.lowercase() in setOf("jpg", "jpeg", "png") }
            if (images) {
                SectionTitle(trPlural(R.plurals.images_count, files.size, files.size))
                files.chunked(3).forEach { row ->
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        row.forEach { f -> ImageThumb(f, Modifier.weight(1f)) { host.openFile(f) } }
                        repeat(3 - row.size) { Box(Modifier.weight(1f)) }
                    }
                }
            } else if (files.size > 1) {
                SectionTitle(trPlural(R.plurals.files_count, files.size, files.size))
                files.forEach { f -> FileRow(DocFile.from(f, Source.CREATED), onClick = { host.openFile(f) }) }
            }
            if (first != null && first.extension.equals("pdf", true)) {
                SectionTitle(tr(R.string.job_next), Modifier.padding(top = 6.dp))
                val doc = DocFile.from(first, Source.CREATED)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(Tool.COMPRESS, Tool.PROTECT, Tool.WATERMARK).filter { it.folder != first.parentFile?.name }.take(3).forEach { tool ->
                        Column(
                            Modifier.weight(1f).heightIn(min = 80.dp).clip(Card16).background(p.surface)
                                .clickable(role = Role.Button) { vm.openTab(Route.Home); vm.openTool(tool, doc) }.padding(8.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(6.dp, Alignment.CenterVertically),
                        ) {
                            IconBadge(tool.icon, tool.tint, size = 36.dp, iconSize = 19.dp, radius = 12.dp)
                            Text(tool.label, style = Type.tiny.copy(fontSize = 12.sp), color = p.text)
                        }
                    }
                }
            }
            TextAction(tr(R.string.job_back_home), { vm.openTab(Route.Home) }, color = p.text)
        }
    }
}

/** A small, downsampled preview of a saved image; tap to open it. */
@Composable
private fun ImageThumb(file: java.io.File, modifier: Modifier, onClick: () -> Unit) {
    val p = LocalPalette.current
    val bitmap by androidx.compose.runtime.produceState<android.graphics.Bitmap?>(null, file.path) {
        value = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
            val bounds = android.graphics.BitmapFactory.Options().apply { inJustDecodeBounds = true }
            android.graphics.BitmapFactory.decodeFile(file.path, bounds)
            var sample = 1
            while (bounds.outWidth / (sample * 2) >= 300) sample *= 2
            android.graphics.BitmapFactory.decodeFile(file.path, android.graphics.BitmapFactory.Options().apply { inSampleSize = sample })
        }
    }
    Box(
        modifier.aspectRatio(0.72f).clip(RoundedCornerShape(10.dp)).background(p.surface)
            .clickable(role = Role.Button, onClick = onClick)
            .semantics { contentDescription = file.name },
        contentAlignment = Alignment.Center,
    ) {
        bitmap?.let { androidx.compose.foundation.Image(it.asImageBitmap(), null, contentScale = androidx.compose.ui.layout.ContentScale.Fit, modifier = Modifier.fillMaxSize()) }
    }
}
