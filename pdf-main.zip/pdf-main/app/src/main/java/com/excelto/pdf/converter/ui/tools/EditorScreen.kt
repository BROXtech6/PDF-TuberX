package com.excelto.pdf.converter.ui.tools

import com.excelto.pdf.converter.R
import com.excelto.pdf.converter.language.tr
import com.excelto.pdf.converter.language.trPlural
import androidx.annotation.StringRes
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.stateDescription
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.excelto.pdf.converter.core.engine.Mark
import com.excelto.pdf.converter.core.engine.NPoint
import com.excelto.pdf.converter.core.engine.NRect
import com.excelto.pdf.converter.core.engine.TextLine
import com.excelto.pdf.converter.core.model.DocFile
import com.excelto.pdf.converter.core.render.PdfPages
import com.excelto.pdf.converter.ui.AppViewModel
import com.excelto.pdf.converter.ui.InnerHeader
import com.excelto.pdf.converter.ui.Route
import com.excelto.pdf.converter.ui.Tool
import com.excelto.pdf.converter.ui.sheets.ConfirmSheet
import com.excelto.pdf.converter.ui.sheets.FilePickerSheet
import com.excelto.pdf.converter.ui.sheets.appTextFieldColors
import com.excelto.pdf.converter.ui.theme.AppIcons
import com.excelto.pdf.converter.ui.theme.LocalPalette
import com.excelto.pdf.converter.ui.theme.Type
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

enum class EditMode(@StringRes private val labelRes: Int, val icon: ImageVector, @StringRes private val hintRes: Int) {
    VIEW(R.string.edit_scroll, AppIcons.eye, R.string.edit_scroll_hint),
    TEXT(R.string.edit_text, AppIcons.text, R.string.edit_text_hint),
    HIGHLIGHT(R.string.edit_highlight, AppIcons.marker, R.string.edit_highlight_hint),
    DRAW(R.string.edit_draw, AppIcons.pen, R.string.edit_draw_hint),
    NOTE(R.string.edit_note, AppIcons.note, R.string.edit_note_hint),
    SIGN(R.string.tool_short_sign, AppIcons.sign, R.string.edit_sign_hint),
    REDACT(R.string.edit_redact, AppIcons.redact, R.string.edit_redact_hint),
    ;

    val label: String get() = tr(labelRes)
    val hint: String get() = tr(hintRes)
}

private const val INK_COLOR = 0xFF1D3F8F.toInt()
private const val INK_WIDTH = 0.004f

/** Pending dialog in the editor: add or change text, or write a note. */
private sealed interface EditDialog {
    data class NewText(val page: Int, val at: NPoint) : EditDialog
    data class ReplaceLine(val line: TextLine) : EditDialog
    data class NewNote(val page: Int, val at: NPoint) : EditDialog
}

@Composable
fun EditorScreen(vm: AppViewModel, route: Route.ToolScreen) {
    val p = LocalPalette.current
    val file = route.files.firstOrNull()
    var picking by remember { mutableStateOf(file == null) }
    val startMode = when (route.tool) {
        Tool.SIGN -> EditMode.SIGN
        Tool.REDACT -> EditMode.REDACT
        Tool.ANNOTATE -> EditMode.HIGHLIGHT
        else -> EditMode.TEXT
    }
    var mode by remember { mutableStateOf(startMode) }
    val marks = remember(file?.path) { mutableStateListOf<Mark>() }
    var dialog by remember { mutableStateOf<EditDialog?>(null) }
    var signing by remember { mutableStateOf<Pair<Int, NPoint>?>(null) }
    var confirmRedact by remember { mutableStateOf(false) }
    var confirmLeave by remember { mutableStateOf(false) }
    var signatureVersion by remember { mutableStateOf(0) }
    val signature by produceState<Bitmap?>(null, signatureVersion) {
        value = withContext(Dispatchers.IO) { vm.signatureFile.takeIf { it.exists() }?.let { BitmapFactory.decodeFile(it.absolutePath) } }
    }
    val count = rememberPageCount(vm, file)

    fun placeSignature(page: Int, at: NPoint, bmp: Bitmap) {
        val w = 0.32f
        val h = w * bmp.height / bmp.width * 0.707f
        marks += Mark.Signature(page, NRect(at.x - w / 2, at.y - h / 2, at.x + w / 2, at.y + h / 2).clamp(), vm.signatureFile.absolutePath)
    }

    Column(Modifier.fillMaxSize()) {
        InnerHeader(route.tool.label, onBack = { if (marks.isEmpty()) vm.back() else confirmLeave = true }) {
            IconButtonSmall(AppIcons.undo, tr(R.string.edit_undo), enabled = marks.isNotEmpty()) { if (marks.isNotEmpty()) marks.removeAt(marks.lastIndex) }
            Box(
                Modifier.padding(end = 6.dp).heightIn(min = 40.dp).clip(RoundedCornerShape(20.dp))
                    .background(if (marks.isNotEmpty()) p.primary else p.line)
                    .clickable(enabled = marks.isNotEmpty(), role = Role.Button) {
                        if (marks.any { it is Mark.Redaction }) confirmRedact = true else vm.runEdit(route.tool, file!!, marks.toList())
                    }
                    .padding(horizontal = 16.dp),
                contentAlignment = Alignment.Center,
            ) { Text(tr(R.string.language_save), style = Type.bodyStrong, color = if (marks.isNotEmpty()) p.onPrimary else p.muted) }
        }
        if (file == null) {
            Column(Modifier.weight(1f).padding(14.dp)) { FileCard(null) { picking = true } }
        } else {
            Text(mode.hint, style = Type.small, color = p.text, modifier = Modifier.fillMaxWidth().background(p.viewer).padding(horizontal = 14.dp, vertical = 8.dp))
            val linesByPage = remember(file.path) { mutableStateMapOf<Int, List<TextLine>>() }
            LazyColumn(
                Modifier.weight(1f).fillMaxWidth().background(p.viewer),
                contentPadding = PaddingValues(14.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp),
            ) {
                val pages = count ?: 0
                items(pages) { index ->
                    if (mode == EditMode.TEXT && index !in linesByPage) {
                        LaunchedEffect(index) { linesByPage[index] = vm.lines(file, index) }
                    }
                    EditablePage(
                        file = file, index = index, mode = mode,
                        marks = marks.filter { it.page == index },
                        lines = if (mode == EditMode.TEXT) linesByPage[index].orEmpty() else emptyList(),
                        signature = signature,
                        onAdd = { marks += it },
                        onTap = { at ->
                            when (mode) {
                                EditMode.TEXT -> {
                                    val line = linesByPage[index]?.firstOrNull { it.rect.grow(0.006f).contains(at) }
                                    dialog = if (line != null) EditDialog.ReplaceLine(line) else EditDialog.NewText(index, at)
                                }
                                EditMode.NOTE -> dialog = EditDialog.NewNote(index, at)
                                EditMode.SIGN -> {
                                    val bmp = signature
                                    if (bmp == null) signing = index to at else placeSignature(index, at, bmp)
                                }
                                else -> Unit
                            }
                        },
                    )
                }
                if (count == null) item { Text(tr(R.string.pages_loading), style = Type.small, color = p.muted) }
            }
            Row(
                Modifier.fillMaxWidth().background(p.surface).horizontalScroll(rememberScrollState()).padding(horizontal = 10.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                EditMode.entries.forEach { m ->
                    val on = m == mode
                    Column(
                        Modifier.widthIn(min = 58.dp).heightIn(min = 56.dp).clip(RoundedCornerShape(14.dp))
                            .background(if (on) p.primarySoft else Color.Transparent)
                            .clickable(role = Role.Tab) {
                                if (m == EditMode.REDACT && !vm.canUse(Tool.REDACT)) vm.offerPro(Tool.REDACT) { mode = EditMode.REDACT } else mode = m
                            }
                            .semantics { stateDescription = if (on) tr(R.string.a11y_selected) else "" }
                            .padding(horizontal = 6.dp, vertical = 4.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(3.dp, Alignment.CenterVertically),
                    ) {
                        Icon(m.icon, null, tint = if (on) p.primaryText else p.text, modifier = Modifier.size(19.dp))
                        Text(m.label, style = Type.tiny, color = if (on) p.primaryText else p.text)
                    }
                }
            }
        }
    }

    if (picking) FilePickerSheet(vm, route.tool, route.files, onChosen = { vm.setToolFiles(it) }, onDismiss = { picking = false })

    dialog?.let { d ->
        var text by remember(d) { mutableStateOf(if (d is EditDialog.ReplaceLine) d.line.text else "") }
        val title = when (d) { is EditDialog.NewText -> tr(R.string.edit_add_text); is EditDialog.ReplaceLine -> tr(R.string.edit_change_text); is EditDialog.NewNote -> tr(R.string.edit_add_note) }
        AlertDialog(
            onDismissRequest = { dialog = null },
            containerColor = p.surface,
            title = { Text(title, style = Type.section.copy(fontSize = 17.sp), color = p.text) },
            text = { OutlinedTextField(text, { text = it }, colors = appTextFieldColors(), modifier = Modifier.fillMaxWidth(), minLines = if (d is EditDialog.NewNote) 3 else 1) },
            confirmButton = {
                Text(tr(R.string.edit_add), style = Type.bodyStrong, color = p.primaryText, modifier = Modifier.clickable(role = Role.Button) {
                    if (text.isNotBlank()) {
                        marks += when (d) {
                            is EditDialog.NewText -> Mark.TextBox(d.page, NRect(d.at.x, d.at.y - 0.012f, (d.at.x + 0.6f).coerceAtMost(0.98f), d.at.y + 0.012f), text, 0.014f, 0xFF1F2733.toInt(), coverOriginal = false)
                            is EditDialog.ReplaceLine -> Mark.TextBox(d.line.page, d.line.rect, text, d.line.fontSize, 0xFF000000.toInt(), coverOriginal = true)
                            is EditDialog.NewNote -> Mark.Note(d.page, d.at, text)
                        }
                    }
                    dialog = null
                }.padding(12.dp))
            },
            dismissButton = { Text(tr(R.string.common_cancel), style = Type.bodyStrong, color = p.text, modifier = Modifier.clickable(role = Role.Button) { dialog = null }.padding(12.dp)) },
        )
    }

    signing?.let { (page, at) ->
        SignaturePadSheet(vm.signatureFile, onSaved = { bmp ->
            signatureVersion++
            placeSignature(page, at, bmp)
            signing = null
        }, onDismiss = { signing = null })
    }

    if (confirmRedact) {
        val n = marks.count { it is Mark.Redaction }
        ConfirmSheet(
            trPlural(R.plurals.edit_redact_title, n, n),
            tr(R.string.edit_redact_body),
            tr(R.string.edit_redact_go), danger = true,
            onConfirm = { vm.runEdit(route.tool, file!!, marks.toList()) },
            onDismiss = { confirmRedact = false },
        )
    }
    if (confirmLeave) {
        ConfirmSheet(tr(R.string.edit_discard_title), trPlural(R.plurals.edit_discard_body, marks.size, marks.size), tr(R.string.edit_discard), danger = true,
            onConfirm = { vm.back() }, onDismiss = { confirmLeave = false })
    }
}

private fun NRect.grow(d: Float) = NRect(left - d, top - d, right + d, bottom + d)
private fun NRect.clamp(): NRect {
    val dx = when { left < 0f -> -left; right > 1f -> 1f - right; else -> 0f }
    val dy = when { top < 0f -> -top; bottom > 1f -> 1f - bottom; else -> 0f }
    return NRect(left + dx, top + dy, right + dx, bottom + dy)
}

@Composable
private fun EditablePage(
    file: DocFile,
    index: Int,
    mode: EditMode,
    marks: List<Mark>,
    lines: List<TextLine>,
    signature: Bitmap?,
    onAdd: (Mark) -> Unit,
    onTap: (NPoint) -> Unit,
) {
    val density = LocalDensity.current
    BoxWithConstraints(Modifier.fillMaxWidth()) {
        val widthPx = with(density) { maxWidth.toPx() }.toInt().coerceIn(400, 1400)
        val bitmap by produceState<Bitmap?>(null, file.path, index, widthPx) {
            value = withContext(Dispatchers.IO) { PdfPages.render(file.file, index, widthPx) }
        }
        val ratio = bitmap?.let { it.width.toFloat() / it.height } ?: 0.707f
        var dragStart by remember { mutableStateOf<Offset?>(null) }
        var dragNow by remember { mutableStateOf<Offset?>(null) }
        val stroke = remember { mutableStateListOf<Offset>() }
        val measurer = rememberTextMeasurer()

        Box(
            Modifier.fillMaxWidth().aspectRatio(ratio).background(Color.White)
                .semantics { contentDescription = tr(R.string.a11y_page, index + 1) },
        ) {
            bitmap?.let { Image(it.asImageBitmap(), null, contentScale = ContentScale.FillBounds, modifier = Modifier.fillMaxSize()) }
            val gestures = when (mode) {
                EditMode.HIGHLIGHT, EditMode.REDACT -> Modifier.pointerInput(mode) {
                    detectDragGestures(
                        onDragStart = { dragStart = it; dragNow = it },
                        onDrag = { change, _ -> change.consume(); dragNow = change.position },
                        onDragEnd = {
                            val a = dragStart; val b = dragNow
                            if (a != null && b != null) {
                                val r = NRect(a.x / size.width, a.y / size.height, b.x / size.width, b.y / size.height).normalized()
                                if (r.width > 0.01f && r.height > 0.004f) {
                                    onAdd(if (mode == EditMode.REDACT) Mark.Redaction(index, r) else Mark.Highlight(index, r))
                                }
                            }
                            dragStart = null; dragNow = null
                        },
                        onDragCancel = { dragStart = null; dragNow = null },
                    )
                }
                EditMode.DRAW -> Modifier.pointerInput(mode) {
                    detectDragGestures(
                        onDragStart = { stroke.clear(); stroke += it },
                        onDrag = { change, _ -> change.consume(); stroke += change.position },
                        onDragEnd = {
                            if (stroke.size > 1) onAdd(Mark.Ink(index, listOf(stroke.map { NPoint(it.x / size.width, it.y / size.height) }), INK_COLOR, INK_WIDTH))
                            stroke.clear()
                        },
                        onDragCancel = { stroke.clear() },
                    )
                }
                EditMode.TEXT, EditMode.NOTE, EditMode.SIGN -> Modifier.pointerInput(mode) {
                    detectTapGestures { onTap(NPoint(it.x / size.width, it.y / size.height)) }
                }
                EditMode.VIEW -> Modifier
            }
            Canvas(Modifier.fillMaxSize().then(gestures)) {
                val w = size.width
                val h = size.height
                fun rectOf(r: NRect) = Offset(r.left * w, r.top * h) to Size(r.width * w, r.height * h)
                if (mode == EditMode.TEXT) {
                    for (line in lines) {
                        val (o, s) = rectOf(line.rect)
                        drawRect(Color(0x55217346), o, s, style = Stroke(1.5f, pathEffect = PathEffect.dashPathEffect(floatArrayOf(6f, 5f))))
                    }
                }
                for (m in marks) when (m) {
                    is Mark.Highlight -> { val (o, s) = rectOf(m.rect.normalized()); drawRect(Color(0x73FFE234), o, s) }
                    is Mark.Redaction -> { val (o, s) = rectOf(m.rect.normalized()); drawRect(Color.Black, o, s) }
                    is Mark.Ink -> m.strokes.forEach { pts ->
                        val path = Path()
                        pts.forEachIndexed { i, pt -> if (i == 0) path.moveTo(pt.x * w, pt.y * h) else path.lineTo(pt.x * w, pt.y * h) }
                        drawPath(path, Color(m.color), style = Stroke(m.width * w, cap = StrokeCap.Round, join = StrokeJoin.Round))
                    }
                    is Mark.Note -> {
                        drawRect(Color(0xFFFFD66B), Offset(m.at.x * w, m.at.y * h - 18f), Size(36f, 36f))
                        drawText(measurer, tr(R.string.edit_note), Offset(m.at.x * w + 2f, m.at.y * h - 14f), TextStyle(fontSize = 8.sp, color = Color(0xFF4A3700)))
                    }
                    is Mark.TextBox -> {
                        val r = m.rect.normalized()
                        val fontPx = (m.fontSize * h).coerceAtLeast(6f)
                        if (m.coverOriginal) drawRect(Color.White, Offset(r.left * w - 1f, r.top * h - 1f), Size(r.width * w + 2f, r.height * h + 2f))
                        val maxW = ((if (m.coverOriginal) r.width else (1f - r.left)) * w).toInt().coerceAtLeast(40)
                        drawText(measurer, m.text, Offset(r.left * w, r.top * h), TextStyle(fontSize = fontPx.toSp(), color = Color(m.color)),
                            size = Size(maxW.toFloat(), (h - r.top * h).coerceAtLeast(1f)))
                    }
                    is Mark.Signature -> signature?.let { bmp ->
                        val r = m.rect.normalized()
                        drawImage(bmp.asImageBitmap(), dstOffset = androidx.compose.ui.unit.IntOffset((r.left * w).toInt(), (r.top * h).toInt()),
                            dstSize = androidx.compose.ui.unit.IntSize((r.width * w).toInt().coerceAtLeast(1), (r.height * h).toInt().coerceAtLeast(1)))
                    }
                }
                val a = dragStart; val b = dragNow
                if (a != null && b != null) {
                    val o = Offset(minOf(a.x, b.x), minOf(a.y, b.y))
                    val s = Size(kotlin.math.abs(b.x - a.x), kotlin.math.abs(b.y - a.y))
                    drawRect(if (mode == EditMode.REDACT) Color(0xAA000000) else Color(0x73FFE234), o, s)
                }
                if (stroke.size > 1) {
                    val path = Path()
                    stroke.forEachIndexed { i, pt -> if (i == 0) path.moveTo(pt.x, pt.y) else path.lineTo(pt.x, pt.y) }
                    drawPath(path, Color(INK_COLOR), style = Stroke(INK_WIDTH * w, cap = StrokeCap.Round, join = StrokeJoin.Round))
                }
            }
        }
    }
}
