package android.print

import android.os.CancellationSignal
import android.os.ParcelFileDescriptor
import kotlinx.coroutines.suspendCancellableCoroutine
import java.io.File
import kotlin.coroutines.resume

/**
 * Runs a [PrintDocumentAdapter] (such as a WebView's) straight into a PDF file, without
 * the system print dialog. Lives in android.print because the layout and write
 * callbacks only have package-private constructors.
 */
object PdfPrinter {

    /** Returns null on success, or the error message. Call on the main thread. */
    suspend fun print(adapter: PrintDocumentAdapter, attributes: PrintAttributes, out: File): String? = suspendCancellableCoroutine { cont ->
        val cancel = CancellationSignal()
        cont.invokeOnCancellation { cancel.cancel() }
        adapter.onStart()
        adapter.onLayout(null, attributes, cancel, object : PrintDocumentAdapter.LayoutResultCallback() {
            override fun onLayoutFinished(info: PrintDocumentInfo, changed: Boolean) {
                val fd = ParcelFileDescriptor.open(out, ParcelFileDescriptor.MODE_CREATE or ParcelFileDescriptor.MODE_TRUNCATE or ParcelFileDescriptor.MODE_READ_WRITE)
                adapter.onWrite(arrayOf(PageRange.ALL_PAGES), fd, cancel, object : PrintDocumentAdapter.WriteResultCallback() {
                    override fun onWriteFinished(pages: Array<out PageRange>) {
                        runCatching { fd.close() }
                        adapter.onFinish()
                        if (cont.isActive) cont.resume(null)
                    }

                    override fun onWriteFailed(error: CharSequence?) {
                        runCatching { fd.close() }
                        adapter.onFinish()
                        if (cont.isActive) cont.resume(error?.toString() ?: "write failed")
                    }

                    override fun onWriteCancelled() {
                        runCatching { fd.close() }
                        adapter.onFinish()
                        if (cont.isActive) cont.resume("cancelled")
                    }
                })
            }

            override fun onLayoutFailed(error: CharSequence?) {
                adapter.onFinish()
                if (cont.isActive) cont.resume(error?.toString() ?: "layout failed")
            }

            override fun onLayoutCancelled() {
                adapter.onFinish()
                if (cont.isActive) cont.resume("cancelled")
            }
        }, null)
    }
}
